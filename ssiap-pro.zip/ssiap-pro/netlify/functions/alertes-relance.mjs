// Kaelum e-PCS — alertes forcées : relance toutes les 2 minutes des téléphones qui n'ont pas confirmé la réception (5 relances au plus)
// Application créée par Rochdi Mecheti
import { relancerAlertes, pourChaqueSite } from "./api.mjs";

export const config = { schedule: "*/2 * * * *" };

import { battement } from "../lib/core.mjs";
export default async () => {
  await battement("alertes-relance");
  const n = await pourChaqueSite(relancerAlertes);
  return new Response(JSON.stringify({ relances: n }), { headers: { "content-type": "application/json" } });
};
