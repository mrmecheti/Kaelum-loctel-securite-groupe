// Kaelum e-PCS — toutes les 5 minutes : agents non pointés signalés au PC + mot de motivation (signé Roch) au début de chaque vacation
// Application créée par Rochdi Mecheti
import { signalerNonPointes, motiverAgents, pourChaqueSite } from "./api.mjs";

export const config = { schedule: "*/5 * * * *" };

import { battement } from "../lib/core.mjs";
export default async () => {
  await battement("agents-non-pointes");
  const n = await pourChaqueSite(signalerNonPointes);
  const mo = await pourChaqueSite(motiverAgents).catch(() => 0);
  return new Response(JSON.stringify({ signales: n, motivation: mo }), { headers: { "content-type": "application/json" } });
};
