// Kaelum e-PCS — PTI / DATI : toutes les minutes, contrôle des agents sous protection (rappel, alarme, relance)
// Application créée par Rochdi Mecheti
import { veillePTI, pourChaqueSite } from "./api.mjs";

export const config = { schedule: "* * * * *" };

import { battement } from "../lib/core.mjs";
export default async () => {
  await battement("pti-veille");
  const n = await pourChaqueSite(veillePTI);
  return new Response(JSON.stringify({ alarmes: n }), { headers: { "content-type": "application/json" } });
};
