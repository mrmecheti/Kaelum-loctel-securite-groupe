// Kaelum e-PCS — toutes les 10 minutes : rappel de ronde aux agents en vacation qui n'en ont pas lancé depuis X heures
// Application créée par Rochdi Mecheti
import { rappelRondes, pourChaqueSite } from "./api.mjs";

export const config = { schedule: "*/10 * * * *" };

import { battement } from "../lib/core.mjs";
export default async () => {
  await battement("ronde-rappel");
  const n = await pourChaqueSite(rappelRondes);
  return new Response(JSON.stringify({ rappels: n }), { headers: { "content-type": "application/json" } });
};
