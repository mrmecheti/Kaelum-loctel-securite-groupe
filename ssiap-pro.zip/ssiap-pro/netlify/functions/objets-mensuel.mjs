// Kaelum e-PCS — le 30 de chaque mois (le dernier jour en février) : compte rendu des objets trouvés.
// Alerte (notification) à Laurent Hernandez et au PC sécurité, mail avec le bordereau PDF à Rochdi Mecheti et Laurent Hernandez.
// Les objets restants sont mis en sac et remis à M. Pascal Malvezin, responsable sécurité SPL OE.
// Application créée par Rochdi Mecheti
import { objetsMensuel, pourChaqueSite } from "./api.mjs";

export const config = { schedule: "10 7 28-31 * *" }; // vers 9 h 10 à Montpellier, filtré ci-dessous

import { battement } from "../lib/core.mjs";
export default async () => {
  await battement("objets-mensuel");
  const p = new Intl.DateTimeFormat("fr-CA", { timeZone: "Europe/Paris", year: "numeric", month: "2-digit", day: "2-digit" }).format(new Date());
  const [y, m, d] = p.split("-").map(Number), dernier = new Date(Date.UTC(y, m, 0)).getUTCDate();
  const jour = Math.min(30, dernier); // février : 28 ou 29
  if (d !== jour) return new Response(JSON.stringify({ ignore: true, jour: d }), { headers: { "content-type": "application/json" } });
  const r = await pourChaqueSite(objetsMensuel);
  return new Response(JSON.stringify(r), { headers: { "content-type": "application/json" } });
};
