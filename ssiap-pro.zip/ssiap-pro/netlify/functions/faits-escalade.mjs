// Kaelum e-PCS — faits urgents ou moyens restés ouverts : relance automatique du PC sécurité
// Application créée par Rochdi Mecheti
import { escaladerFaits, pourChaqueSite } from "./api.mjs";

export const config = { schedule: "*/5 * * * *" };

import { battement } from "../lib/core.mjs";
export default async () => {
  await battement("faits-escalade");
  const n = await pourChaqueSite(escaladerFaits);
  return new Response(JSON.stringify({ relances: n }), { headers: { "content-type": "application/json" } });
};
