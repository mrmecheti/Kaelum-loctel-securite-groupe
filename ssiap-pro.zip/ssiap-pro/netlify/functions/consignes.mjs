// Kaelum e-PCS — consignes permanentes (notes PC01 à PC07, process sécurité, note interne) : servies seulement aux comptes connectés
// Application créée par Rochdi Mecheti
import { currentUser, json } from "../lib/core.mjs";
import DOCS from "../lib/consignes-permanentes.json" with { type: "json" };

export default async (req) => {
  const me = await currentUser(req);
  if (!me) return json({ error: "Session expirée, reconnecte-toi" }, 401);
  if (me.role === "client") return json({ error: "Consignes internes au service de sécurité" }, 403);
  const url = new URL(req.url), id = url.searchParams.get("doc"), p = parseInt(url.searchParams.get("p") || "0", 10);
  if (id) {
    const d = DOCS.find((x) => x.id === id), b64 = d && d.pages[p - 1];
    if (!b64) return json({ error: "Page introuvable" }, 404);
    return new Response(Buffer.from(b64, "base64"), { headers: { "content-type": "image/jpeg", "cache-control": "private, max-age=86400" } });
  }
  return json(DOCS.map(({ pages, ...d }) => ({ ...d, nbPages: pages.length })));
};
