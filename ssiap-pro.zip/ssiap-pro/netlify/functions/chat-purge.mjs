// Kaelum e-PCS — toutes les 5 minutes : effacement des messages éphémères expirés des discussions
// Application créée par Rochdi Mecheti
import { purgerChat, pourChaqueSite } from "./api.mjs";
import { battement } from "../lib/core.mjs";

export const config = { schedule: "*/5 * * * *" };

export default async () => {
  const n = await pourChaqueSite(purgerChat); await battement("chat-purge", `${n} effacé(s)`);
  return new Response(JSON.stringify({ effaces: n }), { headers: { "content-type": "application/json" } });
};
