// Kaelum e-PCS — chaque dimanche vers 4 h (heure de Montpellier) : sauvegarde complète des données
// (magasin séparé + copie chiffrée envoyée par mail au propriétaire). v5.85 : une sauvegarde séparée par site client.
// Application créée par Rochdi Mecheti
import { sauvegarder } from "./api.mjs";
import { listeSites, siteRun } from "../lib/core.mjs";

export const config = { schedule: "0 2 * * 0" };

export default async () => {
  const r = await sauvegarder("automatique", true);
  const autres = [];
  for (const f of Object.values(await listeSites())) { // sites clients : sauvegarde dans leur magasin, sans mail
    if (f.id === "arena" || f.actif === false) continue;
    try { const x = await siteRun(f.id, () => sauvegarder("automatique", false), f); autres.push({ site: f.id, n: x.n }); }
    catch (e) { autres.push({ site: f.id, erreur: String(e.message || e).slice(0, 120) }); }
  }
  return new Response(JSON.stringify({ n: r.n, envoi: r.envoi, sites: autres }), { headers: { "content-type": "application/json" } });
};
