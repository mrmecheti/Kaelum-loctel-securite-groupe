// Kaelum e-PCS — API (toutes les routes /api/*)
// Application créée par Rochdi Mecheti
import {
  load, save, listeCles, json, deny, uid, currentUser, isStaff, isAdmin, isRH, signToken, verifyToken, checkPin, hashPin, sendMail, storeNomme, battement,
  siteRun, SITE_COURANT, SITE_CFG, SITE_ORIGINE, listeSites,
  DEFAULT_CONTACTS, DEFAULT_RECIPIENTS, DIFFUSION, DEFAULT_RONDES, DEFAULT_ZONES, DEFAULT_PRESTATAIRES, ROLES,
} from "../lib/core.mjs";
import { seedDemo } from "../lib/demo-site.mjs";
import "../../public/rapports-types.js"; // catalogue des rapports partagé avec l'appli
import "../../public/planif-calc.js";
import "../../public/motivation.js"; // mot de motivation des agents (signé Kaelum e-PCS)
import "../../public/mc-postes.js"; // main courante par poste (contrôle des types autorisés) // planification : heures, contrôles réglementaires, devis
import { fetchPrevisions, analyser, vigilanceMF, SITE } from "../lib/meteo.mjs";
import { documentPro } from "../lib/pdf.mjs";

import crypto from "node:crypto";
import ANNUAIRE_INITIAL from "../lib/annuaire-initial.json" with { type: "json" };
import PLANNING_INITIAL from "../lib/planning-initial.json" with { type: "json" };
import PARCOURS_INITIAL from "../lib/parcours-initial.json" with { type: "json" };
import { rondePDF } from "../lib/ronde-pdf.mjs";
import ASCENSEURS from "../lib/ascenseurs.json" with { type: "json" }; // v4.51 · ascenseurs et monte-charges Parc / Arena (prestataire OTIS)
import CODES_INITIAUX from "../lib/codes-initiaux.json" with { type: "json" };
import AVATARS_INITIAUX from "../lib/avatars-initiaux.json" with { type: "json" }; // v4.64 · photos de l'équipe PC, chiffrées : seul le code PIN les ouvre // v4.49 · codes du PDF « Cadenas / Bornes / Téléphones PC », chiffrés : seul le code PIN les ouvre
import CLES_INITIAL from "../lib/cles-initial.json" with { type: "json" };
import MATERIEL_INITIAL from "../lib/materiel-initial.json" with { type: "json" };
import BRIEF_FIM26 from "../lib/brief-fim26.json" with { type: "json" };
import FIM26_EXPLOIT from "../lib/brief-fim26-exploitation.json" with { type: "json" }; // v4.86 · consignes d'exploitation de la Foire (brief gardiens)
import BESOINS_FIM26 from "../lib/besoins-fim26.json" with { type: "json" };
import PLANNING_PARC_2026_10 from "../lib/planning-parc-2026-10-v2210.json" with { type: "json" }; // v5.50 · export Comète du 22/10
import POSTES_PLAN from "../lib/postes-plan.json" with { type: "json" };
import PLANNING_ARENA_2026_10 from "../lib/planning-arena-2026-10-v2210.json" with { type: "json" }; // v5.50 · export Comète du 22/10
import PLANNING_PARC_2026_11 from "../lib/planning-parc-2026-11-v2810.json" with { type: "json" }; // v5.92 · export Comète du 28/10
import PLANNING_ARENA_2026_11 from "../lib/planning-arena-2026-11-v2810.json" with { type: "json" }; // v5.92 · export Comète du 28/10

export const config = { path: "/api/*" };

const MAX_PHOTO = 900_000; // ~650 Ko d'image (compressée côté téléphone)

// Historique : chaque action est notée ici et remonte en direct aux administrateurs (cloche 🔔)
async function journal(type, qui, detail, niveau = "info", lien = "") {
  const j = await load("journal", []);
  j.unshift({ id: uid(), t: new Date().toISOString(), type, qui, detail, niveau, lien });
  await save("journal", j.slice(0, 5000));
}
const fmtParis = (t) => new Date(t).toLocaleString("fr-FR", { timeZone: "Europe/Paris", day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit" });
const fmtHeure = (h) => (h ? `${h.slice(8, 10)}/${h.slice(5, 7)} ${h.slice(11, 16)}` : ""); // heure saisie sur le téléphone (déjà en heure de Paris)
function genMdp() { // 10 caractères faciles à recopier (sans 0/O/l/1)
  const c = "ABCDEFGHJKMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz23456789";
  return Array.from({ length: 10 }, () => c[crypto.randomInt(c.length)]).join("");
}
/* ---------- Propriétaire : seul compte autorisé à modifier l'application ---------- */
const VERSION_SERVEUR = "5.95";
const PROPRIO = () => String(process.env.OWNER_EMAIL || process.env.ADMIN_EMAIL || "mr.mecheti@gmail.com").trim().toLowerCase();
// Un seul propriétaire : Rochdi Mecheti
const hashBadge = (sn) => crypto.createHash("sha256").update("badge|" + String(sn || "").toUpperCase().replace(/[^0-9A-F]/g, "") + "|" + (process.env.APP_SECRET || "n")).digest("hex"); // v4.72
const DEST_DISPOS = (u) => estProprio(u) || /j[ée]r[ée]my\s+mercher/i.test(u.nom || ""); // v5.70 · Rochdi et Jérémy Mercher reçoivent une notification à chaque envoi de disponibilités
const estProprio = (u) => !!u && (u.id === "__admin" || u.id === PROPRIO() || (SITE_COURANT() !== SITE_ORIGINE && !!u.diamant)); // v5.85 · dans un site client, le badge Diamant du client = tous les droits sur CE site seulement
const estProprioPrincipal = (u) => !!u && (u.id === "__admin" || u.id === PROPRIO());
const TENANT = () => SITE_COURANT() !== SITE_ORIGINE; // site client (vierge) : jamais les listes par défaut d'Arena
const refusProprio = () => json({ error: "Seul le propriétaire de l'application peut modifier ce réglage" }, 403);

/* ---------- Accès des agents selon le planning ---------- */
const AGENTS = ["ads", "ssiap1", "ssiap2", "ssiap3"];
const MAIL_PC_DEFAUT = "pcparc@spl-occitanie-events.com";
const ACCES24_DEFAUT = [MAIL_PC_DEFAUT];
/* ---------- v4.12 · Aperçu des profils (propriétaire) : voir l'appli exactement comme chaque profil, en lecture seule ---------- */
const AP_DOM = "@apercu.n-manager";
const AP_PROFILS = {
  admin: { lb: "Accès admin", nom: "Aperçu · Admin", role: "admin", id: "admin" + AP_DOM },
  pcparc: { lb: "Accès PC Parc", nom: "Aperçu · PC Parc", role: "pc", id: MAIL_PC_DEFAUT },
  pcarena: { lb: "Accès PC Arena (SSIAP 2)", nom: "Aperçu · PC Arena", role: "ssiap2", id: "pcarena" + AP_DOM, vac: { poste: "SSIAP 2 PCS ARENA", site: "Arena Sud de France" } },
  ssiap1: { lb: "Accès utilisateur SSIAP 1", nom: "Aperçu · SSIAP 1", role: "ssiap1", id: "ssiap1" + AP_DOM, vac: { poste: "SSIAP 1 HALLS", site: "Parc des Expositions" } },
  ads: { lb: "Accès utilisateur ADS", nom: "Aperçu · ADS", role: "ads", id: "ads" + AP_DOM, vac: { poste: "ADS ACCUEIL A / FOUILLE 1", site: "Parc des Expositions" } },
  client: { lb: "Accès client", nom: "Aperçu · Client", role: "client", id: "client" + AP_DOM },
  planif: { lb: "Accès planificateur", nom: "Aperçu · Planificateur", role: "admin", id: "planif" + AP_DOM },
  ssiap3: { lb: "Accès SSIAP 3", nom: "Aperçu · SSIAP 3", role: "ssiap3", id: "ssiap3" + AP_DOM, vac: { poste: "SSIAP 3 CHEF DE SERVICE SECURITE", site: "Parc des Expositions" } },
  adjoint: { lb: "Accès adjoint planificateur", nom: "Aperçu · Adjoint planif.", role: "responsable", id: "adjoint" + AP_DOM },
  chefsite: { lb: "Accès chef de site", nom: "Aperçu · Chef de site", role: "responsable", id: "chefsite" + AP_DOM },
};
const APERCU_AUTORISES = ["courrier.laurent@free.fr"]; // v4.22 · Laurent Hernandez : « Voir comme… » comme le propriétaire (lecture seule)
const peutApercu = (u) => !!u && !u.apercu && (estProprio(u) || APERCU_AUTORISES.includes(String(u.id || "").toLowerCase()) || (SITE_COURANT() !== SITE_ORIGINE && !!u.equipe)); // v5.85 · dans un site client, l'équipe Kaelum peut aussi « voir comme »
const APERCU_SITE = ["ssiap3", "ssiap1", "ads", "client", "admin"]; // profils proposés dans un site client (les autres sont propres à Arena)
const apId = (u, k) => !!u && String(u.id || "").toLowerCase() === k + AP_DOM && !!u.apercu;
// v4.58 · comptes désactivés : plus aucun accès (connexion refusée, session coupée, retirés des listes)
const COMPTES_BLOQUES = ["a.brand@groupenicollin.com", "jeremy.bourg@sfr.fr"], NOMS_BLOQUES = ["alexandre brand", "jeremy bourg"]; // v5.41 · Jérémy Bourg banni
// v5.84 · ACCÈS RESTREINT (demande du propriétaire) : seuls Rochdi Mecheti, Yazid Mecheti, Laurent Hernandez et Jérémy Mercher peuvent se connecter et utiliser l'application.
// Tous les autres comptes sont refusés à la connexion et déconnectés (leur jeton est rejeté). Mettre ACCES_RESTREINT à false pour rouvrir l'application.
const infosSite = () => { const f = SITE_CFG() || {}; return { id: SITE_COURANT(), nom: f.nom || "Parc des Expositions · Arena Sud de France", adresse: f.adresse || "", lat: f.lat || null, lon: f.lon || null, demo: !!f.demo, origine: SITE_COURANT() === SITE_ORIGINE }; }; // fiche publique du site courant
const NOM_SAUV = () => (SITE_COURANT() === SITE_ORIGINE ? "sauvegardes" : "sauvegardes-" + SITE_COURANT()); // sauvegardes séparées par site
const DIFFUSION_SITE = () => (SITE_COURANT() === SITE_ORIGINE ? DIFFUSION() : (((SITE_CFG() || {}).admins) || []).filter((a) => /@/.test(a.email))); // mails : l'équipe d'Arena, ou les administrateurs du site client
const ACCES_RESTREINT = true;
const IDS_AUTORISES = ["mr.mecheti@gmail.com", "cyberologue@gmail.com", "jerre34@hotmail.fr", "courrier.laurent@free.fr"];
const NOMS_AUTORISES = ["rochdi mecheti", "yazid mecheti", "laurent hernandez", "jeremy mercher"];
const nomNorm = (x) => String(x || "").trim().toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/\s+/g, " ");
const accesEquipe = (u) => !!u && (IDS_AUTORISES.includes(String(u.id || "").toLowerCase()) || NOMS_AUTORISES.includes(nomNorm(u.nom)) || NOMS_AUTORISES.includes(nomNorm(u.nom).split(" ").reverse().join(" ")));
const accesFahd = (u) => !!u && (estFahd(u) || String(u.id || "").toLowerCase() === "fhadouche@mhscfoot.com"); // v5.86 · Fahd Hadouche : accès au site d'origine (Parc / Arena) uniquement, badge Or
const accesOuvert = (u) => !ACCES_RESTREINT || (SITE_COURANT() !== SITE_ORIGINE ? (!!u && (!u.equipe || estProprio(u) || accesEquipe(u))) : (!!u && (!!u.apercu || estProprio(u) || accesEquipe(u) || accesFahd(u))));
const estBloque = (u) => !!u && !estProprio(u) && (COMPTES_BLOQUES.includes(String(u.id || "").toLowerCase()) || NOMS_BLOQUES.includes(String(u.nom || "").trim().toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "")));
const ADMINS_DEFAUT = ["jeremy.bourg@sfr.fr", "courrier.laurent@free.fr"]; // Jérémy Bourg + Laurent Hernandez. Le compte PC sécurité est en vision 24 h/24 (lecture). // PC sécurité + Jérémy Bourg (responsable PCS journée) // comptes administrateurs : voient et font tout (l'écran Administration reste au propriétaire)
async function estAdminPC(id) { const i = String(id || "").toLowerCase(); if (!i || i === "__admin" || i === MAIL_PC_DEFAUT) return false; if (i === "admin" + AP_DOM || i === "planif" + AP_DOM) return true; // compte PC : vision 24 h/24 seulement
  return [...(await load("admins_pc", ADMINS_DEFAUT)), ...(await load("planificateurs", [])), "courrier.laurent@free.fr", "jerre34@hotmail.fr", "fhadouche@mhscfoot.com", "jeremy.bourg@sfr.fr"].filter((e) => !COMPTES_BLOQUES.includes(String(e).toLowerCase())).map((e) => String(e).toLowerCase()).includes(i); }
const REDAC_DEFAUT = [MAIL_PC_DEFAUT, "courrier.laurent@free.fr"]; // le PC sécurité peut téléverser des documents (Laurent Hernandez à ajouter)
const TYPES_RAPPORT = Object.fromEntries(globalThis.RAP_CATS.flatMap((c) => c.types).map((t) => [t.k, t]));
const MARGE_AVANT = 60, MARGE_APRES = 60; // minutes autour de la vacation
const toksNom = (s) => String(s || "").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z ]/g, " ").split(/\s+/).filter(Boolean);
const lev = (a, b) => { const m = [...Array(b.length + 1).keys()]; for (let i = 1; i <= a.length; i++) { let p = m[0]; m[0] = i; for (let j = 1; j <= b.length; j++) { const t = m[j]; m[j] = Math.min(m[j] + 1, m[j - 1] + 1, p + (a[i - 1] === b[j - 1] ? 0 : 1)); p = t; } } return m[b.length]; };
const tel9 = (t) => String(t || "").replace(/\D/g, "").slice(-9);
function memeAgent(u, v) {
  if (tel9(u.tel).length === 9 && tel9(u.tel) === tel9(v.tel)) return true;
  const a = toksNom(u.nom), b = toksNom(v.nom);
  if (!a.length || !b.length) return false;
  if ([...a].sort().join(" ") === [...b].sort().join(" ")) return true;
  const ok = a.filter((x) => b.some((y) => x === y || (x.length >= 5 && lev(x, y) <= (x.length >= 8 ? 2 : 1)))).length;
  if (ok < Math.min(2, a.length) || ok < Math.min(2, b.length)) return false;
  // v5.50 · deux noms de famille différents (un mot de 4 lettres ou plus sans équivalent, même approché, de chaque côté) = deux personnes, même si le prénom est le même
  const voisin = (x, y) => x === y || (x.length >= 4 && y.length >= 4 && lev(x, y) <= 2);
  return !(a.some((x) => x.length >= 4 && !b.some((y) => voisin(x, y))) && b.some((y) => y.length >= 4 && !a.some((x) => voisin(x, y))));
}
const minutesLocales = (date, hm) => { const [y, mo, d] = date.split("-").map(Number), [h, mi] = (hm || "00:00").split(":").map(Number); return Date.UTC(y, mo - 1, d, h, mi) / 60000; };
function maintenantParis() {
  const p = Object.fromEntries(new Intl.DateTimeFormat("fr-CA", { timeZone: "Europe/Paris", year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit", hourCycle: "h23" })
    .formatToParts(new Date()).map((x) => [x.type, x.value]));
  return minutesLocales(`${p.year}-${p.month}-${p.day}`, `${p.hour}:${p.minute}`);
}
const fenetre = (v) => { const d = minutesLocales(v.date, v.debut); let f = minutesLocales(v.date, v.fin || v.debut); if (f <= d) f += 1440; return [d - MARGE_AVANT, f + MARGE_APRES]; };
const TELPC = () => (SITE_COURANT() === SITE_ORIGINE ? " (04 67 17 68 68)" : "");
async function accesPlanning(u) {
  if (u && u.apercu) return u.apVac ? { ok: true, vacation: { ...u.apVac, nom: u.nom, date: jourParis(), debut: "07:00", fin: "19:00" } } : { ok: true };
  if (!u || !AGENTS.includes(u.role) || u.horsPlanning || u.testeurTotal || u.id === "__admin") return { ok: true };
  const pl = await load("planning", PLANNING_INITIAL), now = maintenantParis();
  const siens = pl.filter((v) => v.debut && memeAgent(u, v));
  const enCours = siens.find((v) => { const [a, b] = fenetre(v); return now >= a && now <= b; });
  if (enCours) return { ok: true, vacation: enCours };
  const proch = siens.map((v) => [fenetre(v)[0], v]).filter(([a]) => a > now).sort((x, y) => x[0] - y[0])[0];
  const msg = !siens.length ? "Tu n'apparais pas au planning : l'accès est réservé aux agents planifiés. Contacte le PC sécurité" + TELPC() + "."
    : proch ? `Accès possible uniquement pendant tes vacations (1 h avant à 1 h après). Prochaine vacation : ${new Date(proch[1].date + "T12:00:00").toLocaleDateString("fr-FR", { weekday: "long", day: "numeric", month: "long" })} de ${proch[1].debut} à ${proch[1].fin} — ${proch[1].site || ""}.`
    : "Aucune vacation à venir au planning : accès impossible pour le moment. Contacte le PC sécurité" + TELPC() + ".";
  return { ok: false, message: msg };
}

// Planning personnel d'un agent (ses vacations à venir seulement)
async function planningDe(u) {
  if (u && (u.id === "__admin" || u.id === PROPRIO())) u = { ...u, nom: process.env.OWNER_NOM || "Rochdi Mecheti" }; // planning du propriétaire (le co-propriétaire garde le sien)
  const pl = await load("planning", PLANNING_INITIAL), d1 = new Date(Date.now() - 864e5).toISOString().slice(0, 10);
  return pl.filter((v) => v.date >= d1 && memeAgent(u, v)).sort((a, b) => (a.date + a.debut).localeCompare(b.date + b.debut))
    .map(({ date, debut, fin, poste, evenement, site, code }) => ({ date, debut, fin, poste, evenement, site, code }));
}
// Périmètre d'un agent selon son poste au planning : PCS Arena, P3, portail, ou SSIAP 2 du PC Parc (voit et gère tout)
function perimetreDe(poste, site = "") {
  const p = (String(poste || "") + (/ARENA/i.test(String(site || "")) ? " ARENA" : "")).toUpperCase();
  if (/PCS?\s*ARENA/.test(p)) return "arena";
  if (/\bP\s?3\b/.test(p)) return "p3";
  if (/PORTAIL|BARRI[EÈ]RE/.test(p)) return "portail";
  if (/SSIAP\s?2/.test(p) && /ARENA/.test(p)) return "arena"; // SSIAP 2 de l'Arena (PCS, représentation…)
  if (/SSIAP\s?2/.test(p) && !/ARENA/.test(p)) return "pcparc";
  return "";
}
// Dossier des agents : diplômes, carte pro, habilitations, recyclages (+ visite médicale pour l'équipe du PCS)
// [type, libellé, validité en années (0 = pas d'échéance)]
const DOC_TYPES = [["ads", "Diplôme initial ADS (CQP / TFP APS)", 0], ["cartepro", "Carte professionnelle CNAPS", 5], ["macaps", "MAC APS (maintien des compétences)", 5],
  ["ssiap1", "Diplôme initial SSIAP 1", 0], ["ssiap2", "Diplôme initial SSIAP 2", 0], ["ssiap3", "Diplôme initial SSIAP 3", 0],
  ["recyclage", "Recyclage SSIAP", 3], ["ran", "Remise à niveau SSIAP (RAN)", 3], ["sst", "SST / MAC SST", 2], ["pse1", "PSE1 (formation continue)", 1],
  ["habelec", "Habilitation électrique", 3], ["visite", "Visite médicale (fiche d'aptitude)", 3], ["autre", "Autre document", 0]];
const EQUIPE_PCS_DEFAUT = [{ nom: "Jérémy Mercher", q: "ssiap3" }, { nom: "Laurent Hernandez", q: "ssiap2" }, { nom: "Xavier Négrier", q: "ssiap2" }, { nom: "Stéphane Gomez", q: "ssiap2" }, { nom: "Rochdi Mecheti", q: "ssiap2" }];
async function profilDossier(u) {
  const nom = estProprio(u) ? process.env.OWNER_NOM || "Rochdi Mecheti" : u.nom;
  const pcs = (await load("equipe_pcs", EQUIPE_PCS_DEFAUT)).find((x) => memeAgent({ nom }, { nom: x.nom }));
  const q = pcs ? pcs.q : AGENTS.includes(u.role) ? u.role : "";
  return { pcs: !!pcs, q };
}
// Lecture réglementaire du dossier : pour chaque obligation, échéance réelle, statut, action et date conseillée
const isoJ = (d) => d.toISOString().slice(0, 10);
const plusAns = (iso, n) => { const d = new Date(iso + "T12:00:00Z"); d.setUTCFullYear(d.getUTCFullYear() + n); d.setUTCDate(d.getUTCDate() - 1); return isoJ(d); };
const moinsMois = (iso, n) => { const d = new Date(iso + "T12:00:00Z"); d.setUTCMonth(d.getUTCMonth() - n); return isoJ(d); };
const joursAvant = (iso) => Math.floor((new Date(iso + "T23:59:59Z") - Date.now()) / 864e5);
function conformite(q, pcs, docs) {
  const der = (types) => docs.filter((d) => types.includes(d.type) && (d.obtention || d.echeance)).sort((x, y) => String(y.obtention || y.echeance).localeCompare(String(x.obtention || x.echeance)))[0];
  const out = [];
  const item = (k, lb, doc, ech, fenetre, action, conseil, ref, note = "") => {
    const j = ech ? joursAvant(ech) : null;
    const statut = !doc ? "manquant" : !ech ? "ok" : j < 0 ? "expire" : j <= fenetre ? "bientot" : "ok";
    let suggestion = "";
    if (ech && statut !== "ok") { const c = conseil(ech); suggestion = c > isoJ(new Date()) ? c : isoJ(new Date(Date.now() + 7 * 864e5)); }
    out.push({ k, lb, statut, echeance: ech || "", jours: j, action: doc ? action(statut) : `Déposer le document : ${lb.toLowerCase()}`, suggestion, ref, note, doc: doc ? doc.id : "" });
  };
  // échéance : date inscrite sur le document si elle respecte la réglementation, sinon date réglementaire
  const ech = (doc, ans) => { if (!doc) return ""; const regl = doc.obtention && ans ? plusAns(doc.obtention, ans) : "";
    if (doc.echeance && (!regl || doc.echeance <= regl)) return [doc.echeance, ""];
    return [regl || doc.echeance || "", doc.echeance && regl && doc.echeance > regl ? `échéance saisie (${doc.echeance.split("-").reverse().join("/")}) au-delà de la durée réglementaire : ramenée au ${regl.split("-").reverse().join("/")}` : ""]; };
  if (q === "ads") {
    const dip = der(["ads"]); item("ads", "Diplôme ADS (CQP / TFP APS)", dip, "", 0, () => "Diplôme sans date de fin", () => "", "Code de la sécurité intérieure, livre VI");
    const cp = der(["cartepro"]), [e, n] = ech(cp, 5), mac = der(["macaps"]);
    item("cartepro", "Carte professionnelle CNAPS", cp, e, 150,
      (st) => st === "expire" ? "Carte expirée : l'agent ne peut plus exercer. Demande de renouvellement CNAPS immédiate." : `${mac && mac.obtention && e && mac.obtention >= moinsMois(e, 24) ? "MAC APS fait : " : "Faire le MAC APS, puis "}déposer la demande de renouvellement au CNAPS au plus tard le ${e ? moinsMois(e, 3).split("-").reverse().join("/") : "—"} (3 mois avant l'échéance)`,
      (x) => moinsMois(x, 4), "Carte valable 5 ans, renouvellement à demander au moins 3 mois avant l'échéance, MAC APS préalable", n);
  }
  if (/^ssiap[123]$/.test(q)) {
    const niv = q.slice(-1), dip = der([q]);
    item("diplome", `Diplôme SSIAP ${niv}`, dip, "", 0, () => "Diplôme initial", () => "", "Arrêté du 2 mai 2005 modifié");
    const rec = der(["recyclage", "ran"]), base = [dip && dip.obtention, rec && rec.obtention].filter(Boolean).sort().pop();
    const e = base ? plusAns(base, 3) : "";
    item("recyclage", `Recyclage SSIAP ${niv} (tous les 3 ans)`, dip || rec ? { id: (rec || dip).id } : null, e, 90,
      (st) => st === "expire" ? `Recyclage dépassé : remise à niveau (RAN) SSIAP ${niv} obligatoire avant de reprendre la fonction` : `Inscrire au recyclage SSIAP ${niv} avant le ${e.split("-").reverse().join("/")} (secourisme SST / PSE1 valide exigé)`,
      (x) => moinsMois(x, 2), "Arrêté du 2 mai 2005, art. 7 : recyclage tous les 3 ans, sinon remise à niveau", base ? "" : "date d'obtention ou de dernier recyclage manquante");
    const sst = der(["sst"]), pse = der(["pse1"]), [es] = ech(sst, 2), [ep] = ech(pse, 1);
    const best = [[sst, es, "MAC SST (tous les 24 mois)"], [pse, ep, "formation continue PSE1 (annuelle)"]].filter((x) => x[0]).sort((x, y) => String(y[1] || "9").localeCompare(String(x[1] || "9")))[0];
    item("secourisme", "Secourisme SST ou PSE1", best && best[0], best ? best[1] : "", 60, (st) => `${st === "expire" ? "Secourisme expiré : " : ""}${best ? best[2] : ""} à faire avant le ${best && best[1] ? best[1].split("-").reverse().join("/") : "—"}`,
      (x) => moinsMois(x, 1), "SST ou PSE1 en cours de validité exigé pour le recyclage SSIAP");
    const he = der(["habelec"]), [eh, nh] = ech(he, 3);
    item("habelec", "Habilitation électrique", he, eh, 60, (st) => `${st === "expire" ? "Habilitation périmée : " : ""}recyclage habilitation électrique avant le ${eh ? eh.split("-").reverse().join("/") : "—"}, puis nouveau titre signé par l'employeur`,
      (x) => moinsMois(x, 2), "NF C 18-510 : recyclage recommandé tous les 3 ans", nh);
  }
  if (pcs) {
    const vm = der(["visite"]), [ev, nv] = ech(vm, 3);
    item("visite", "Visite médicale", vm, ev, 60, (st) => `${st === "expire" ? "Visite dépassée : " : ""}demander un rendez-vous au service de santé au travail avant le ${ev ? ev.split("-").reverse().join("/") : "—"}`,
      (x) => moinsMois(x, 1), "Code du travail R4624-17 / R4624-18 : au plus tous les 5 ans, 3 ans pour le travail de nuit", nv);
  }
  return out;
}
// Toutes les fiches de conformité (comptes + équipe PCS sans compte)
async function lectureDossiers() {
  const tous = await load("dossiers", {}), users0 = await load("users", []);
  const users = users0.some((u) => u.id === PROPRIO()) ? users0 : [...users0, { id: PROPRIO(), nom: process.env.OWNER_NOM || "Rochdi Mecheti", role: "admin" }];
  const out = [];
  for (const u of users) { if (u.actif === false || u.id === "__admin") continue; const p = await profilDossier(u), docs = tous[u.id] || [];
    if (!p.q && !p.pcs && !docs.length) continue;
    out.push({ id: u.id, nom: u.nom, role: u.role, ...p, docs, etat: conformite(p.q, p.pcs, docs) }); }
  for (const x of await load("equipe_pcs", EQUIPE_PCS_DEFAUT)) if (!users.some((u) => memeAgent({ nom: estProprio(u) ? process.env.OWNER_NOM || "Rochdi Mecheti" : u.nom }, { nom: x.nom })))
    out.push({ id: "", nom: x.nom, role: "", pcs: true, q: x.q, sansCompte: true, docs: [], etat: conformite(x.q, true, []) });
  return out.sort((a, b) => (b.pcs - a.pcs) || a.nom.localeCompare(b.nom, "fr"));
}
// Alertes « bientôt expiré » : mail au PC sécurité et au coordinateur PC (Laurent Hernandez) + notification dans l'appli
export async function alertesDossiers({ essai = false } = {}) {
  const liste = await lectureDossiers(), deja = await load("alertes_dossiers", {}), now = Date.now();
  const seuil = (j) => (j < 0 ? "expire" : j <= 7 ? "7" : j <= 15 ? "15" : j <= 30 ? "30" : j <= 60 ? "60" : j <= 90 ? "90" : "150");
  const items = [];
  for (const a of liste) for (const e of a.etat) if (e.statut === "bientot" || e.statut === "expire") {
    const cle = `${a.id || a.nom}|${e.k}|${e.echeance}`, s = seuil(e.jours), prev = deja[cle];
    const nouveau = !prev || prev.s !== s || (s === "expire" && now - prev.t > 7 * 864e5);
    items.push({ agent: a.nom, pcs: a.pcs, ...e, nouveau, cle, s });
  }
  items.sort((x, y) => x.jours - y.jours);
  const aEnvoyer = essai ? items : items.filter((x) => x.nouveau);
  const fr = (x) => (x ? x.split("-").reverse().join("/") : "");
  const dest = DIFFUSION_SITE().map((d) => d.email); // liste de diffusion : Rochdi Mecheti, Laurent Hernandez
  if (aEnvoyer.length) {
    const nbE = aEnvoyer.filter((x) => x.statut === "expire").length;
    const sujet = `${essai ? "[ESSAI] " : ""}${nbE ? "🔴 " : "🟠 "}Kaelum e-PCS — ${aEnvoyer.length} document(s) d'agents à renouveler${nbE ? ` dont ${nbE} expiré(s)` : ""}`;
    const td = "padding:6px;border-bottom:1px solid #ddd;vertical-align:top;font-size:13px";
    const html = `<div style="font-family:Arial,sans-serif;max-width:760px"><h2 style="margin:0 0 6px">${escH(sujet)}</h2>
      <p style="color:#555;margin:0 0 10px">Lecture des diplômes et recyclages selon la réglementation. Date conseillée = date à laquelle lancer la démarche pour rester en règle.</p>
      <table style="border-collapse:collapse;width:100%"><tr style="background:#f3f3f3"><th style="${td};text-align:left">Agent</th><th style="${td};text-align:left">Document</th><th style="${td};text-align:left">Échéance</th><th style="${td};text-align:left">À faire</th><th style="${td};text-align:left">Date conseillée</th></tr>
      ${aEnvoyer.map((x) => `<tr><td style="${td}"><b>${escH(x.agent)}</b>${x.pcs ? "<br><span style='color:#888'>équipe PCS</span>" : ""}</td><td style="${td}">${escH(x.lb)}</td>
        <td style="${td};color:${x.statut === "expire" ? "#d7002e" : "#e07000"};white-space:nowrap"><b>${fr(x.echeance)}</b><br>${x.jours < 0 ? `expiré depuis ${-x.jours} j` : `dans ${x.jours} j`}</td>
        <td style="${td}">${escH(x.action)}${x.note ? `<br><i style="color:#888">${escH(x.note)}</i>` : ""}<br><span style="color:#888;font-size:11px">${escH(x.ref)}</span></td><td style="${td};white-space:nowrap"><b>${fr(x.suggestion)}</b></td></tr>`).join("")}</table>
      <p style="color:#888;font-size:12px">Kaelum e-PCS — Le PC Sécurité Parc des Expositions (T) / Arena Sud de France (L) · Dossiers des agents : https://ssiap-ads-pro.netlify.app/#/dossiers</p></div>`;
    if (dest.length) await sendMail(DIFFUSION_SITE(), sujet, html).catch(() => {});
    await journal("dossiers", "Kaelum e-PCS", `${essai ? "[essai] " : ""}${aEnvoyer.length} document(s) à renouveler : ${aEnvoyer.slice(0, 3).map((x) => `${x.agent} (${x.lb}, ${fr(x.echeance)})`).join(", ")}${aEnvoyer.length > 3 ? "…" : ""}`, nbE ? "urgent" : "attention", "#/dossiers");
  }
  if (!essai) { for (const x of items) deja[x.cle] = { s: x.s, t: x.nouveau ? now : (deja[x.cle] || {}).t || now }; await save("alertes_dossiers", deja); }
  return { nb: items.length, envoyes: aEnvoyer.length, destinataires: dest, items: aEnvoyer };
}
// Demandes de DPAE : le SSIAP 3 (et le propriétaire) les fait, le coordinateur PC suit
const peutDPAE = (u) => !!u && (estProprio(u) || u.role === "admin" || u.role === "ssiap3" || u.roleAgent === "ssiap3" || u.profilMC === "ssiap3");
// Main courante imposée selon le poste du planning (sinon selon la qualification)
const PROFILS_MC = ["pcsarena", "ssiap2", "ssiap3", "ssiap1", "ssiap1v", "ads", "adsv", "p3", "portail"];
function profilDe(poste, role) {
  const p = String(poste || "").toUpperCase(), volant = /VOLANT/.test(p), per = perimetreDe(p);
  if (per === "arena") return "pcsarena";
  if (per === "p3" || per === "portail") return per;
  if (per === "pcparc") return "ssiap2";
  if (/SSIAP\s?3/.test(p)) return "ssiap3";
  if (/SSIAP\s?1/.test(p)) return volant ? "ssiap1v" : "ssiap1";
  if (/\bADS\b|AGENT DE S[EÉ]CURIT|FOUILLE|PALPATION|ACCUEIL|PARKING|GARDIENNAGE|VIGILANCE|SANITAIRE|R[EÉ]GULATION|CONTR[OÔ]LE/.test(p)) return volant ? "adsv" : "ads";
  if (volant) return role === "ssiap1" ? "ssiap1v" : "adsv";
  return { ssiap1: "ssiap1", ssiap2: "ssiap2", ssiap3: "ssiap3", ads: "ads" }[role] || "";
}
// ---------- Main courante rangée par mois (mc/AAAA-MM) : rien n'est effacé, l'appli ne charge que les mois utiles ----------
const moisDe = (iso) => new Intl.DateTimeFormat("fr-CA", { timeZone: "Europe/Paris", year: "numeric", month: "2-digit" }).format(new Date(iso || Date.now())).slice(0, 7);
const moisPrec = (m, n = 1) => { const [y, mo] = m.split("-").map(Number), d = new Date(Date.UTC(y, mo - 1 - n, 15)); return d.toISOString().slice(0, 7); };
async function mcMigrer() {
  if (await load("mc_migre", false)) return;
  const old = (await load("incidents", null)) || [], par = {};
  for (const i of old) (par[moisDe(i.t)] ||= []).push(i);
  const idx = new Set(await load("mc_index", []));
  for (const [m, l] of Object.entries(par)) { const cur = await load("mc/" + m, []), ids = new Set(cur.map((x) => x.id));
    await save("mc/" + m, [...cur, ...l.filter((x) => !ids.has(x.id))].sort((a, b) => b.t.localeCompare(a.t))); idx.add(m); }
  await save("mc_index", [...idx].sort().reverse());
  if (old.length) await save("incidents_avant_archivage", old); // copie de sécurité de l'ancienne liste
  await save("incidents", []); await save("mc_migre", true);
}
async function mcIndex() { await mcMigrer(); return load("mc_index", []); }
async function mcMois(m) { await mcMigrer(); return load("mc/" + m, []); }
async function mcRecents(n = 2) { const m = moisDe(); let out = []; for (let k = 0; k < n; k++) out = out.concat(await mcMois(moisPrec(m, k))); return out; }
async function mcEntre(du, au) { // du / au : AAAA-MM-JJ
  const idx = await mcIndex(), m1 = String(du || "0000").slice(0, 7), m2 = String(au || "9999").slice(0, 7);
  let out = []; for (const m of idx.filter((x) => x >= m1 && x <= m2).slice(0, 24)) out = out.concat(await mcMois(m)); return out.sort((a, b) => b.t.localeCompare(a.t));
}
async function mcAjouter(inc) {
  const m = moisDe(inc.t), l = await mcMois(m); l.unshift(inc); await save("mc/" + m, l);
  const idx = await load("mc_index", []); if (!idx.includes(m)) await save("mc_index", [...idx, m].sort().reverse());
}
async function mcTrouver(id) { // cherche dans les mois récents puis dans les archives
  const idx = await mcIndex(), cur = moisDe(), ordre = [cur, moisPrec(cur), ...idx.filter((x) => x !== cur && x !== moisPrec(cur))];
  for (const m of ordre) { const l = await load("mc/" + m, []); const inc = l.find((i) => id === i.id || id.startsWith(i.id + "-")); if (inc) return { inc, mois: m, list: l }; }
  return { inc: null };
}
// Copie mensuelle : CSV (Excel) + version imprimable, envoyée au PC et au coordinateur PC
const csvMC = (l) => "﻿" + [["N°", "Date saisie", "Heure du fait", "Poste", "Famille", "Type", "Gravité", "Statut", "Site", "Lieu", "Événement", "Faits", "Intervenants", "Actions", "Prestataire", "Société", "Immatriculation", "Auteur", "Photos", "Suivi"],
  ...[...l].reverse().map((i) => [i.numero, fmtParis(i.t) + " " + i.t.slice(0, 4), i.heure ? fmtHeure(i.heure) : "", i.poste, i.famille, i.categorie, i.gravite, i.statut, i.site, i.lieu, i.evenement, i.description, i.intervenants, i.actions, i.prestataire, i.societe, i.immat, i.auteur, i.photos || (i.photo ? 1 : 0),
    (i.suivi || []).map((x) => `${fmtParis(x.t)} ${x.qui} : ${x.note}`).join(" | ")])]
  .map((r) => r.map((v) => `"${String(v ?? "").replace(/"/g, '""').replace(/\r?\n/g, " ")}"`).join(";")).join("\r\n");
const nomMois = (m) => new Date(m + "-15T12:00:00Z").toLocaleDateString("fr-FR", { month: "long", year: "numeric" });
const htmlMC = (m, l) => `<!doctype html><html lang="fr"><meta charset="utf-8"><title>Main courante ${nomMois(m)}</title>
<style>body{font-family:Arial,sans-serif;font-size:11px;margin:16px}h1{font-size:18px;margin:0}table{border-collapse:collapse;width:100%;margin-top:10px}td,th{border:1px solid #bbb;padding:4px;vertical-align:top;text-align:left}th{background:#eee}.u{color:#c00;font-weight:bold}@media print{a{display:none}}</style>
<h1>Main courante — ${escH(nomMois(m))}</h1><p>Le PC Sécurité Parc des Expositions (T) / Arena Sud de France (L) · ${l.length} saisie(s) · éditée le ${fmtParis(new Date().toISOString())}<br>Kaelum e-PCS — Application créée par Rochdi Mecheti</p>
<table><tr><th>N°</th><th>Date</th><th>Type</th><th>Gravité</th><th>Lieu</th><th>Faits / actions</th><th>Auteur</th><th>Statut</th></tr>
${[...l].reverse().map((i) => `<tr><td>${escH(i.numero)}</td><td>${escH(i.heure ? fmtHeure(i.heure) : fmtParis(i.t))}</td><td>${escH([i.famille, i.categorie].filter(Boolean).join(" · "))}</td><td class="${i.gravite === "urgente" ? "u" : ""}">${escH(i.gravite)}</td>
<td>${escH([i.site, i.lieu].filter(Boolean).join(" · "))}</td><td>${escH(i.description)}${i.actions ? "<br>➜ " + escH(i.actions) : ""}${(i.suivi || []).map((x) => `<br>↳ ${escH(fmtParis(x.t))} ${escH(x.qui)} : ${escH(x.note)}`).join("")}</td><td>${escH(i.auteur)}</td><td>${escH(i.statut)}</td></tr>`).join("")}</table></html>`;
// Saisie automatique dans la main courante (mode crise, consignes…)
async function mcSysteme(me, categorie, description, gravite = "info", extra = {}) {
  const year = new Date().getFullYear(), cpt = await load("mc_compteur", {}); cpt[year] = (cpt[year] || 0) + 1; await save("mc_compteur", cpt);
  const inc = { id: uid(), numero: `MC-${year}-${String(cpt[year]).padStart(4, "0")}`, t: new Date().toISOString(), heure: null, auteurId: me.id, auteur: me.nom, role: me.role, evenementId: null, evenement: "",
    categorie, famille: "", poste: "", societe: "", immat: "", gravite, site: "", lieu: "", description: String(description).slice(0, 4000), intervenants: "", actions: "", prestataire: "", gps: null,
    statut: "ouvert", suivi: [], photo: false, photos: 0, ...extra };
  await mcAjouter(inc); return inc;
}
// Agents dont la vacation est en cours maintenant (planning)
async function agentsEnVacation() {
  const pl = await load("planning", PLANNING_INITIAL), now = maintenantParis(), users = await load("users", []);
  const enCours = pl.filter((v) => v.debut && v.nom && (([a, b]) => now >= a && now <= b)(fenetre(v)));
  const out = new Map();
  for (const v of enCours) { const u = users.find((x) => AGENTS.includes(x.role) && memeAgent(x, v)); const k = u ? u.id : "nom:" + v.nom;
    if (!out.has(k)) out.set(k, { id: u ? u.id : "", nom: u ? u.nom : v.nom, poste: v.poste || "", site: v.site || "", tel: v.tel || (u && u.tel) || "" }); }
  return [...out.values()].sort((a, b) => a.nom.localeCompare(b.nom, "fr"));
}
// ---------- Bilan mensuel (client / PC) : chiffres du mois ----------
async function bilanMois(m) {
  const dans = (t) => moisDe(t) === m, compte = (l, f) => { const o = {}; for (const x of l) { const k = f(x) || "Autre"; o[k] = (o[k] || 0) + 1; } return Object.entries(o).sort((a, b) => b[1] - a[1]); };
  const mc = (await mcMois(m)).filter((i) => !i.rapport);
  const raps = ((await load("rap", null)) || []).filter((r) => dans(r.t)), libres = (await load("rapports", [])).filter((r) => dans(r.t));
  const rondes = (await load("rondes_nfc", [])).filter((r) => dans(r.debut) && r.statut !== "en cours"), cks = (await load("checklists", [])).filter((c) => dans(c.t));
  const alertes = (await load("alertes", [])).filter((a) => dans(a.t)), cles = (await load("cles_mvt", [])).filter((x) => dans(x.t) && x.type === "sortie");
  const bats = (await load("batiments_mvt", [])).filter((x) => dans(x.t)), objets = await load("objets", []);
  const pl = (await load("planning", PLANNING_INITIAL)).filter((v) => v.date && v.date.slice(0, 7) === m && v.debut && v.fin);
  let h = 0, hn = 0, hd = 0; for (const v of pl) { const x = globalThis.PLANIF.vacation(v); h += x.heures; hn += x.hNuit; hd += x.hDim + x.hFer; }
  const auj = jourParis(), passees = pl.filter((v) => v.date <= auj).length, prises = mc.filter((i) => i.categorie === "Prise de service").length;
  const site = (s) => (/arena/i.test(s || "") ? "Arena" : "Parc");
  return { mois: m, nom: nomMois(m),
    mc: { total: mc.length, urgentes: mc.filter((i) => i.gravite === "urgente").length, moyennes: mc.filter((i) => i.gravite === "moyenne").length, ouvertes: mc.filter((i) => i.statut !== "clos").length,
      parCategorie: compte(mc.filter((i) => !/^(Prise|Fin) de service$/.test(i.categorie)), (i) => i.categorie).slice(0, 12), parSite: compte(mc, (i) => site(i.site)) },
    rapports: { total: raps.length + libres.length, urgents: raps.filter((r) => r.urgence === "urgente").length, parType: compte(raps, (r) => r.label).slice(0, 12), libres: libres.length },
    rondes: { total: rondes.length, anomalies: rondes.reduce((s, r) => s + (r.anomalies || 0), 0), oublis: rondes.reduce((s, r) => s + (r.oublies || 0), 0),
      dureeMoy: rondes.length ? Math.round(rondes.reduce((s, r) => s + (r.duree || 0), 0) / rondes.length) : 0 },
    checklists: { total: cks.length, nonConformes: cks.filter((c) => c.conforme === false).length },
    alertes: { total: alertes.length, forcees: alertes.filter((a) => a.forcee).length, parNature: compte(alertes, (a) => a.nature) },
    moyens: { clesSorties: cles.length, operationsBatiments: bats.length, objetsTrouves: objets.filter((o) => dans(o.t)).length, objetsRestitues: objets.filter((o) => o.restitution && dans(o.restitution.t)).length },
    personnel: { vacations: pl.length, agents: new Set(pl.map((v) => globalThis.PLANIF.cleAgent(v.nom))).size, heures: Math.round(h), heuresNuit: Math.round(hn), heuresDimFerie: Math.round(hd),
      tauxPointage: passees ? Math.min(100, Math.round((prises / passees) * 100)) : null } };
}
function htmlBilan(b) {
  const P = b.personnel || null, PP = P || {};
  const barres = (l) => { const max = Math.max(1, ...l.map((x) => x[1])); return l.length ? `<table class="bar">${l.map(([k, v]) => `<tr><td class="k">${escH(k)}</td><td class="b"><div style="width:${Math.max(2, (v / max) * 100)}%"></div></td><td class="v">${v}</td></tr>`).join("")}</table>` : `<p class="mut">Aucun.</p>`; };
  const tuile = (v, l) => v == null || String(v).startsWith("undefined") ? "" : `<div class="t"><b>${v}</b><span>${escH(l)}</span></div>`;
  return `<!doctype html><html lang="fr"><head><meta charset="utf-8"><title>Bilan ${escH(b.nom)}</title><style>
  body{font-family:Arial,Helvetica,sans-serif;color:#111;margin:28px;max-width:900px}h1{margin:0;font-size:22px}h2{font-size:15px;margin:22px 0 8px;color:#b5122b;border-bottom:1px solid #ddd;padding-bottom:4px}
  .hd{display:flex;justify-content:space-between;align-items:flex-end;border-bottom:3px solid #c8102e;padding-bottom:10px}.mut{color:#666}.tiles{display:grid;grid-template-columns:repeat(4,1fr);gap:8px}
  .t{border:1px solid #ddd;border-radius:8px;padding:10px}.t b{display:block;font-size:22px}.t span{font-size:12px;color:#555}
  table.bar{width:100%;border-collapse:collapse;font-size:13px}table.bar td{padding:3px 4px}.k{width:42%}.v{width:40px;text-align:right;font-weight:bold}.b div{height:12px;border-radius:0 4px 4px 0;background:#c8102e}
  @media print{body{margin:12mm}}</style></head><body>
  <div class="hd"><div><h1>Kaelum e-PCS — Bilan mensuel</h1><div class="mut">Le PC Sécurité Parc des Expositions / Arena</div></div><div style="text-align:right"><b style="font-size:18px;text-transform:capitalize">${escH(b.nom)}</b><br><span class="mut">édité le ${new Date().toLocaleDateString("fr-FR")}</span></div></div>
  <h2>En bref</h2><div class="tiles">${tuile(b.mc.total, "saisies de main courante")}${tuile(b.rapports.total, "rapports")}${tuile(b.rondes.total, "rondes effectuées")}${tuile(b.alertes.total, "alertes")}
  ${tuile(b.mc.urgentes, "événements urgents")}${tuile(PP.vacations, "vacations planifiées")}${tuile(PP.heures + " h", "heures d'agents")}${tuile(PP.agents, "agents mobilisés")}</div>
  <h2>Main courante par catégorie</h2>${barres(b.mc.parCategorie)}<p class="mut">Hors prises et fins de service. ${b.mc.moyennes} de gravité moyenne, ${b.mc.urgentes} urgente(s), ${b.mc.ouvertes} non close(s).</p>
  <h2>Rapports d'intervention par type</h2>${barres(b.rapports.parType)}<p class="mut">${b.rapports.urgents} urgent(s) · ${b.rapports.libres} rapport(s) libre(s).</p>
  <h2>Rondes et contrôles</h2><div class="tiles">${tuile(b.rondes.total, "rondes")}${tuile(b.rondes.anomalies, "anomalies relevées")}${tuile(b.rondes.oublis, "points oubliés")}${tuile(b.rondes.dureeMoy + " min", "durée moyenne")}</div>
  <p class="mut">${b.checklists.total} check-list(s), dont ${b.checklists.nonConformes} non conforme(s).</p>
  <h2>Alertes</h2>${barres(b.alertes.parNature)}<p class="mut">${b.alertes.forcees} alerte(s) forcée(s).</p>
  <h2>Moyens et services</h2><div class="tiles">${tuile(b.moyens.clesSorties, "clés remises")}${tuile(b.moyens.operationsBatiments, "ouvertures / fermetures")}${tuile(b.moyens.objetsTrouves, "objets trouvés")}${tuile(b.moyens.objetsRestitues, "objets restitués")}</div>
  ${P ? `<h2>Personnel</h2><div class="tiles">${tuile(PP.heures + " h", "heures planifiées")}${tuile(PP.heuresNuit + " h", "dont nuit")}${tuile(PP.heuresDimFerie + " h", "dont dimanche / férié")}${tuile(PP.tauxPointage == null ? "—" : PP.tauxPointage + " %", "prises de service pointées")}</div>` : ""}
  <p class="mut" style="margin-top:28px;font-size:11px">Document généré par Kaelum e-PCS — Application créée par Rochdi Mecheti.</p></body></html>`;
}
// ---------- Objets trouvés : bilan mensuel et remise à la SPL OE (M. Pascal Malvezin) ----------
const rangementObjet = (cat) => (/t[ée]l[ée]phone|portefeuille|papiers|cl[ée]s|bijou|montre|[ée]lectronique|carte bancaire|argent/i.test(cat || "") ? "Coffre-fort" : "Bac de rangement en plastique"); // objets de valeur et électronique : coffre-fort
const RECEVEUR_OBJETS = { nom: "Pascal Malvezin", fonction: "Responsable sécurité SPL OE" };
const frJ = (t) => (t ? new Date(t).toLocaleDateString("fr-FR", { timeZone: "Europe/Paris" }) : "");
async function bilanObjets(mois) {
  const m = mois || moisDe(), list = (await load("objets", [])).map((o) => (o.stockage === "Grande boîte en plastique" ? { ...o, stockage: "Bac de rangement en plastique" } : o)), dans = (t) => t && moisDe(t) === m;
  const remises = await load("objets_remises", []);
  return {
    mois: m, nom: nomMois(m),
    restants: list.filter((o) => o.statut === "en stock").sort((a, b) => String(a.stockage || "").localeCompare(String(b.stockage || ""), "fr") || a.t.localeCompare(b.t)),
    trouves: list.filter((o) => dans(o.t)).length,
    restitues: list.filter((o) => o.restitution && dans(o.restitution.t)).sort((a, b) => a.restitution.t.localeCompare(b.restitution.t)),
    autres: list.filter((o) => (o.suivi || []).some((s) => dans(s.t) && s.statut !== "remis à la SPL OE") && o.statut !== "en stock" && o.statut !== "restitué"),
    remises: remises.filter((r) => dans(r.t)), receveur: RECEVEUR_OBJETS,
  };
}
function pdfObjets(b, remise = null) {
  const d = documentPro({ titre: `Objets trouvés · compte rendu mensuel · ${b.nom}`, sousTitre: remise ? `Bordereau de remise ${remise.numero} · ${frJ(remise.t)} · remis à M. ${remise.receveur}, ${remise.fonction}` : `Situation au ${frJ(new Date())} · objets à remettre à M. ${b.receveur.nom}, ${b.receveur.fonction}`, reference: remise ? remise.numero : `Objets trouvés ${b.mois}` });
  const restants = remise ? remise.objets : b.restants;
  d.tuiles([[b.trouves, "objets trouvés ce mois", "#1f6fb2"], [b.restitues.length, "restitués à leur propriétaire", "#1e7a43"], [b.autres.length, "autres suites (police, organisateur…)", "#a0620a"], [restants.length, remise ? "objets remis à la SPL OE" : "objets restants à remettre", "#c8102e"]]);
  d.section(remise ? `Objets remis à M. ${remise.receveur} (${restants.length})` : `Objets restants à remettre à la SPL OE (${restants.length})`);
  d.para(remise ? "Les objets ci-dessous ont été placés dans un sac scellé et remis en main propre. Chaque objet porte son étiquette OT." : `Les objets ci-dessous sont à placer dans un sac et à remettre en main propre à M. ${b.receveur.nom}, ${b.receveur.fonction}. Chaque objet porte son étiquette OT. Rangement : vêtements, gourdes et sacs dans le bac de rangement en plastique ; objets de valeur et électronique dans le coffre-fort.`, { size: 8.5, color: "#5b6573" });
  d.tableau([["N°", 1.3], ["Trouvé le", 1], ["Catégorie", 1.2], ["Description", 3.2], ["Lieu", 1.5], ["Rangement", 1.4]],
    restants.map((o) => [o.numero, frJ(o.t), o.categorie, o.description, [o.site && (/arena/i.test(o.site) ? "Arena" : "Parc"), o.lieu].filter(Boolean).join(" · "), o.stockage || ""]), { vide: "Aucun objet en stock : rien à remettre ce mois-ci." });
  d.section(`Objets restitués en ${b.nom} (${b.restitues.length})`);
  d.tableau([["N°", 1.3], ["Objet", 3], ["Trouvé le", 1], ["Restitué le", 1], ["Restitué à", 1.8], ["Par", 1.5]],
    b.restitues.map((o) => [o.numero, `${o.categorie} — ${o.description}`, frJ(o.t), frJ(o.restitution.t), o.restitution.nom, o.restitution.par]), { vide: "Aucune restitution ce mois-ci." });
  if (b.autres.length) { d.section(`Autres suites en ${b.nom} (${b.autres.length})`);
    d.tableau([["N°", 1.3], ["Objet", 3.2], ["Suite donnée", 2], ["Le", 1], ["Par", 1.5]], b.autres.map((o) => { const s = [...(o.suivi || [])].reverse().find((x) => x.statut === o.statut) || {}; return [o.numero, `${o.categorie} — ${o.description}`, o.statut, frJ(s.t), s.par || ""]; })); }
  d.section("Remise");
  d.signatures([["Remis par — PC sécurité", remise ? [remise.par, `le ${frJ(remise.t)}`, `Bordereau ${remise.numero}`, "Signé dans Kaelum e-PCS"] : ["Nom :", "Date :", "Nombre d'objets : " + restants.length]],
    [`Reçu par — ${b.receveur.fonction}`, remise ? [`M. ${remise.receveur}`, `le ${frJ(remise.t)}`, `${restants.length} objet(s) dans le sac`, "Signé dans Kaelum e-PCS"] : [`M. ${b.receveur.nom}`, "Date :", "Sac reçu et vérifié"]]]);
  return d.fin();
}
export async function objetsMensuel({ essai = false } = {}) { // le 30 du mois (le dernier jour en février)
  const b = await bilanObjets(), pdf = pdfObjets(b), m = b.mois;
  if (!essai) await save("objets_rappel", { mois: m, t: new Date().toISOString() });
  const titre = `Objets trouvés : remise du mois à M. ${RECEVEUR_OBJETS.nom}`;
  const texte = `${b.restants.length} objet(s) à mettre dans le sac pour la SPL OE · ${b.restitues.length} restitué(s) ce mois. Compte rendu PDF dans Objets trouvés.`;
  if (!essai) {
    await envoyerPush({ titre, texte, url: "/#/objets", alerte: true }, (u) => u.id === "courrier.laurent@free.fr" || u.id === MAIL_PC_DEFAUT || u.role === "pc" || estProprio(u)).catch(() => 0);
    await mcSysteme({ id: "systeme", nom: "Kaelum e-PCS", role: "admin" }, "Objets trouvés", `Remise mensuelle à faire : ${b.restants.length} objet(s) à remettre à M. ${RECEVEUR_OBJETS.nom} (${RECEVEUR_OBJETS.fonction}). ${b.restitues.length} restitution(s) en ${b.nom}.`, "moyenne");
  }
  const html = `<div style="font-family:Arial,sans-serif;max-width:640px"><h2 style="margin:0 0 8px">${escH(titre)} — ${escH(b.nom)}</h2>
    <p>Compte rendu mensuel des objets trouvés du PC sécurité Parc des Expositions / Arena Sud de France.</p>
    <ul><li><b>${b.trouves}</b> objet(s) trouvé(s) ce mois</li><li><b>${b.restitues.length}</b> restitué(s) à leur propriétaire</li><li><b>${b.autres.length}</b> autre(s) suite(s)</li><li><b>${b.restants.length}</b> objet(s) restant(s) à remettre en sac à M. ${escH(RECEVEUR_OBJETS.nom)}, ${escH(RECEVEUR_OBJETS.fonction)}</li></ul>
    <p>Le bordereau PDF est en pièce jointe (liste des objets restants, récapitulatif des restitutions, cadre de signature). La remise se valide dans l'application : Objets trouvés &gt; Remise mensuelle.</p>
    <p style="color:#888;font-size:12px">Kaelum e-PCS — Application créée par Rochdi Mecheti</p></div>`;
  await sendMail(DIFFUSION_SITE(), `${essai ? "[ESSAI] " : ""}Kaelum e-PCS — Objets trouvés — ${b.nom} (${b.restants.length} à remettre)`, html, [{ name: `objets-trouves-${m}.pdf`, content: pdf.toString("base64") }]).catch(() => {});
  await journal("objets trouvés", "Kaelum e-PCS", `${essai ? "[essai] " : ""}compte rendu mensuel ${b.nom} : ${b.restants.length} à remettre, ${b.restitues.length} restitué(s)`, "attention", "#/objets");
  return { mois: m, restants: b.restants.length, restitues: b.restitues.length };
}
export async function copieMensuelleMC({ mois, essai = false } = {}) {
  const m = mois || moisPrec(moisDe()), l = await mcMois(m);
  const dest = DIFFUSION_SITE().map((d) => d.email); // liste de diffusion : Rochdi Mecheti, Laurent Hernandez
  const urg = l.filter((i) => i.gravite === "urgente").length, ouverts = l.filter((i) => i.statut !== "clos").length;
  const sujet = `${essai ? "[ESSAI] " : ""}📦 Kaelum e-PCS — Main courante — ${nomMois(m)} (${l.length} saisies)`;
  const html = `<div style="font-family:Arial,sans-serif;max-width:620px"><h2 style="margin:0 0 8px">${escH(sujet)}</h2>
    <p>Copie mensuelle de la main courante, à garder hors de l'application.</p><ul><li><b>${l.length}</b> saisie(s)</li><li><b>${urg}</b> urgente(s)</li><li><b>${ouverts}</b> non close(s)</li></ul>
    <p>En pièces jointes : le tableau Excel (CSV), la version imprimable et le bilan du mois avec les chiffres clés (ouvrir puis Imprimer ➜ PDF).</p><p style="color:#888;font-size:12px">Kaelum e-PCS — Le PC Sécurité Parc des Expositions (T) / Arena Sud de France (L)</p></div>`;
  const b64 = (x) => Buffer.from(x, "utf8").toString("base64");
  if (dest.length) await sendMail(DIFFUSION_SITE(), sujet, html,
    [{ name: `main-courante-${m}.csv`, content: b64(csvMC(l)) }, { name: `main-courante-${m}.html`, content: b64(htmlMC(m, l)) }, { name: `bilan-${m}.html`, content: b64(htmlBilan(await bilanMois(m))) }]).catch(() => {});
  const arch = await load("mc_copies", {}); if (!essai) { arch[m] = new Date().toISOString(); await save("mc_copies", arch); }
  await journal("main courante", "Kaelum e-PCS", `${essai ? "[essai] " : ""}copie mensuelle de ${nomMois(m)} envoyée (${l.length} saisies)`, "info", "#/mc");
  // Conservation (désactivée tant que le propriétaire ne l'a pas validée) : supprime les mois trop anciens et les photos
  const cons = await load("mc_conservation", { actif: false, ansTexte: 5, ansPhotos: 3 });
  let purge = 0;
  if (cons.actif && !essai) {
    const idx = await mcIndex(), limT = moisPrec(moisDe(), cons.ansTexte * 12), limP = moisPrec(moisDe(), cons.ansPhotos * 12);
    for (const mm of idx) {
      if (mm < limT) { for (const i of await mcMois(mm)) for (let k = 0; k < Math.max(i.photos || 0, i.photo ? 1 : 0); k++) await save(`photo/${i.id}-${k}`, null);
        await save("mc/" + mm, null); purge++; }
      else if (mm < limP) { const l2 = await mcMois(mm); let ch = false; for (const i of l2) if (i.photos || i.photo) { for (let k = 0; k < Math.max(i.photos || 0, 1); k++) { await save(`photo/${i.id}-${k}`, null); await save("photo/" + i.id, null); } i.photos = 0; i.photo = false; i.photosSupprimees = true; ch = true; } if (ch) await save("mc/" + mm, l2); }
    }
    if (purge) await save("mc_index", idx.filter((x) => x >= limT));
  }
  return { mois: m, nb: l.length, destinataires: dest, purge };
}
// Infos sécurité de départ du plan (complétées ensuite dans l'appli)
const PLAN_INFOS_DEFAUT = {
  accB: { dae: "DAE à l'accueil B" },
  expl: { dae: "DAE au service d'exploitation" },
};
// ---------- Notifications push (Web Push, sans contenu chiffré : le téléphone vient chercher le message) ----------
const b64u = (buf) => Buffer.from(buf).toString("base64").replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
async function vapid() {
  let v = await load("vapid", null);
  if (!v) { const { privateKey, publicKey } = crypto.generateKeyPairSync("ec", { namedCurve: "prime256v1" });
    const jwk = publicKey.export({ format: "jwk" }); v = { prive: privateKey.export({ format: "jwk" }), cle: b64u(Buffer.concat([Buffer.from([4]), Buffer.from(jwk.x, "base64url"), Buffer.from(jwk.y, "base64url")])) };
    await save("vapid", v); }
  return v;
}
async function envoyerPush(dernier, pourQui = () => true) {
  const abos = await load("push_abos", {}), v = await vapid(), cle = crypto.createPrivateKey({ key: v.prive, format: "jwk" });
  dernier = { ...dernier, t: new Date().toISOString() }; await save("push_dernier", dernier);
  const users = await load("users", []); let envoyes = 0, change = false; const details = [];
  for (const [uid_, liste] of Object.entries(abos)) {
    const u = users.find((x) => x.id === uid_) || (estProprio({ id: uid_ }) ? { id: uid_, role: "admin" } : null);
    if (!u || !accesOuvert(u) || !(await pourQui(u))) continue;
    for (const sub of [...liste]) {
      try {
        const aud = new URL(sub.endpoint).origin, h = b64u(JSON.stringify({ typ: "JWT", alg: "ES256" })), pl = b64u(JSON.stringify({ aud, exp: Math.floor(Date.now() / 1000) + 12 * 3600, sub: "mailto:" + PROPRIO() }));
        const sig = b64u(crypto.sign("sha256", Buffer.from(h + "." + pl), { key: cle, dsaEncoding: "ieee-p1363" }));
        const r = await fetch(sub.endpoint, { method: "POST", headers: { TTL: "3600", Urgency: "high", Authorization: `vapid t=${h}.${pl}.${sig}, k=${v.cle}`, "Content-Length": "0" } });
        const service = /apple/.test(aud) ? "Apple (iPhone)" : /google|fcm/.test(aud) ? "Google (Android / Chrome)" : /mozilla/.test(aud) ? "Mozilla (Firefox)" : /windows|notify/.test(aud) ? "Microsoft (Edge)" : aud;
        details.push({ service, status: r.status, texte: r.ok ? "" : (await r.text().catch(() => "")).slice(0, 160) });
        if (r.status === 404 || r.status === 410) { abos[uid_] = abos[uid_].filter((x) => x.endpoint !== sub.endpoint); change = true; } else if (r.ok) envoyes++;
      } catch (e) { details.push({ service: "?", status: 0, texte: String(e.message || e).slice(0, 160) }); }
    }
  }
  if (change) await save("push_abos", abos);
  const log = await load("push_log", []); log.unshift({ t: new Date().toISOString(), titre: dernier.titre, envoyes, details: details.slice(0, 20) }); await save("push_log", log.slice(0, 30));
  envoyerPush.details = details;
  return envoyes;
}
// qui reçoit : les responsables et le PC toujours ; les agents seulement pendant leur vacation
const enService = async (u) => u.role !== "client" && (isStaff(u) || estProprio(u) || !AGENTS.includes(u.role) || u.horsPlanning || (await accesPlanning(u)).ok);
// ---------- Planification (type Comète) : SSIAP 3 Jérémy Mercher ; administrateurs en lecture ----------
const CODE_PLANIF_DEFAUT = "018cef442b60a42f9abab7ce:6c03db9347b9271b66ece4d28781ea47ed944d545457ccd48d1d663824d041cb"; // code de la planification (empreinte, le code n'est pas écrit en clair)
const PLANIFS_NOMS = ["Jérémy Mercher"];
// Licences planificateur (nominatives, gérées par le propriétaire) : niveau valideur / rédacteur / lecture, site, date de fin
async function licencePlanif(u) {
  if (!u || !u.id) return null; const id = String(u.id).toLowerCase(), auj = new Date().toISOString().slice(0, 10);
  const L = (await load("licences_planif", [])).find((x) => x.id === id);
  return L && L.actif !== false && (!L.fin || L.fin >= auj) ? L : null;
}
async function peutPlanif(u) {
  if (!u) return false; if (estProprio(u)) return true; if (apId(u, "planif")) return true;
  if (await estChefPlanif(u)) return true; // Jérémy Mercher
  if (await estValideurPC(u)) return false; // planning du PC Parc seulement (niveau « valideur-pc »)
  if ((await licencePlanif(u))?.niveau === "valideur") return true;
  if (PLANIFS_MAILS.includes(String(u.id).toLowerCase())) return true;
  const mails = (await load("planificateurs", [])).map((e) => String(e).toLowerCase());
  if (mails.includes(String(u.id).toLowerCase())) return true;
  return !mails.length && PLANIFS_NOMS.some((n) => memeAgent({ nom: u.nom }, { nom: n })); // tant que la liste n'est pas remplie : reconnus par leur nom
}
// rédacteurs : planifient, mais leurs saisies attendent la validation d'un planificateur (Jérémy Mercher) avant publication
const REDAC_PLANIF_DEFAUT = ["jeremy.bourg@sfr.fr", "courrier.laurent@free.fr"];
async function estRedacPlanif(u) { return !!u && (await load("planif_redacteurs", REDAC_PLANIF_DEFAUT)).map((e) => String(e).toLowerCase()).includes(String(u.id).toLowerCase()); }
// Laurent Hernandez : seulement le planning du PC Parc (SSIAP 2), en brouillon validé par Jérémy Mercher
const REDAC_PC_DEFAUT = []; // (vide : Laurent Hernandez est planificateur)
// Comptes « SMS seulement » : planning général (lecture) + envoi des SMS de prise de poste, rien d'autre
const SMS_SEULS_DEFAUT = []; // v4.73 · Fahd Hadouche repasse en accès SSIAP 2
const estFahd = (u) => !!u && u.role !== "client" && /\bfahd\b/i.test(String(u.nom || "")) && /had+ouche/i.test(String(u.nom || "")); // v5.12 · Fahd Hadouche reconnu aussi par son nom (quel que soit l'identifiant de son compte)
const ADJOINTS_PLANIF_DEFAUT = ["fhadouche@mhscfoot.com"]; // v4.74 · SSIAP 2 + adjoint planification (SMS, planning, feuille de route, intitulés des postes)
const sansDevis = (u) => !!u && !estProprio(u) && (estFahd(u) || ADJOINTS_PLANIF_DEFAUT.includes(String(u.id || "").toLowerCase())); // v5.14 · Fahd : tout sauf les devis (et leurs tarifs)
const adjPlanif = (u) => !!u && (u.role === "sms" || !!u.adjointPlanif);
// v4.77 · jeton « notifications » : sert seulement à lire la dernière notification (le téléphone le garde même après la fermeture de session)
const pushJeton = (id) => "P:" + Buffer.from(String(id)).toString("base64url") + "." + crypto.createHmac("sha256", (process.env.APP_SECRET || "n") + "|push").update(String(id)).digest("base64url");
const pushJetonOk = (t) => { const m = /^P:([\w-]+)\.([\w-]+)$/.exec(String(t || "")); if (!m) return false; const id = Buffer.from(m[1], "base64url").toString(); return pushJeton(id) === t; };
// v4.77 · niveaux de badge : or (Rochdi, Laurent Hernandez, Jérémy Mercher), all accès (SSIAP 2 du PC Parc + adjoint planification), admin, utilisateur (agents)
const BADGES_OR = ["Laurent Hernandez", "Jérémy Mercher", "Yazid Mecheti", "Fahd Hadouche", "Fahd Haddouche"];
// v4.81 · badges NFC préparés par le propriétaire : seule l'empreinte du numéro est ici (jamais le numéro), rattachée au compte au premier passage
const BADGES_INITIAUX = [{ h: "e5180433f13291f8713afee41a4bce95c4bc98099340ad325782916c390a9ae1", nom: "Laurent Hernandez" }, { h: "fdd323792c74af4a0e6a0b90a6aa362d396385bdd4844aa1bdf527bf291d1901", nom: "Laurent Hernandez" }]; // 2 badges pour Laurent
const empreinteInit = (sn) => crypto.createHash("sha256").update("badgeinit|" + String(sn || "").toUpperCase().replace(/[^0-9A-F]/g, "")).digest("hex");
async function badgeDe(u) {
  if (!u || u.role === "client" || u.apercu) return u && u.apercu ? "user" : "";
  const nomU = estProprio(u) ? (process.env.OWNER_NOM || "Rochdi Mecheti") : u.nom;
  if (estProprio(u)) return "diamant"; // v5.85 · badge Diamant : propriétaire (et administrateur d'un site client sur son site)
  if (BADGES_OR.some((n) => memeAgent({ nom: nomU }, { nom: n }))) return "or";
  if (u.testeur) return "testeur";
  const adj = (await load("adjoints_planif", ADJOINTS_PLANIF_DEFAUT)).map((e) => String(e).toLowerCase()).includes(String(u.id).toLowerCase()) || estFahd(u);
  if (adj || u.adjointPlanif || u.role === "pc" || u.perimetre === "pcparc" || (await load("equipe_pcs", EQUIPE_PCS_DEFAUT)).some((x) => x.q === "ssiap2" && memeAgent({ nom: nomU }, { nom: x.nom }))) return "allaccess";
  if (["admin", "responsable"].includes(u.role) || (await estAdminPC(u.id))) return "admin";
  return "user";
}
// v4.75 · une vacation modifiée ou supprimée met à jour la feuille de route du jour si elle a été retouchée à la main (sinon elle est recalculée depuis le planning)
async function syncFeuille(date, avant, apres) {
  const FR = await load("feuilles_route", {}), f = FR[date]; if (!f || !avant) return;
  const N = (x) => String(x || "").toUpperCase().replace(/\s+/g, " ").trim();
  for (const e of f.evenements || []) { const i = (e.agents || []).findIndex((a) => N(a.nom) === N(avant.nom) && N(a.poste) === N(avant.poste)); if (i < 0) continue;
    if (apres) Object.assign(e.agents[i], { nom: apres.nom, poste: apres.poste, debut: apres.debut, fin: apres.fin }); else e.agents.splice(i, 1);
    await save("feuilles_route", FR); return; }
}
// v5.21 · feuille de route du jour calculée depuis le planning
async function construireFeuille(d, pl, evs) {
  const P = globalThis.PLANIF;
  const RG = (v) => { const q = P.qualifPaie(v); return { "SSIAP 3": 0, "SSIAP 2": 1, "Chef d'équipe": 2, "SSIAP 1": 3, "Cynophile": 4, "ADS": 5 }[q] ?? 6; };
  const groupes = new Map();
  for (const v of pl.filter((x) => x.date === d)) {
    const k = (v.evenement || "Exploitation courante") + "|" + (/arena/i.test((v.site || "") + " " + (v.poste || "")) ? "Arena Sud de France" : v.site || "Parc des Expositions");
    if (!groupes.has(k)) groupes.set(k, []); groupes.get(k).push(v);
  }
  const out = [...groupes.entries()].map(([k, l]) => { const [nom, site] = k.split("|"), e = evs.find((x) => x.nom === nom);
    return { evenement: nom, site, organisateur: e ? e.organisateur || "" : "", effectif: e ? e.effectif || "" : "",
      agents: l.sort((a, b) => RG(a) - RG(b) || String(a.debut).localeCompare(String(b.debut)) || String(a.poste).localeCompare(String(b.poste), "fr"))
        .map((v) => ({ poste: v.poste || "", nom: /^NON AFFECT/i.test(v.nom || "") ? "" : v.nom, qualif: P.qualifPaie(v), debut: v.debut || "", fin: v.fin || "", ...(v.mission ? { mission: v.mission } : {}) })) }; })
    .sort((a, b) => (a.evenement === "Exploitation courante") - (b.evenement === "Exploitation courante") || a.evenement.localeCompare(b.evenement, "fr"));
  return out;
}
// v4.75 · planning mensuel d'un agent en PDF
function pdfPlanningAgent(nom, mois, vacs) {
  const lb = new Date(mois + "-15T12:00:00").toLocaleDateString("fr-FR", { month: "long", year: "numeric" }), P = globalThis.PLANIF;
  const h = vacs.reduce((a, v) => { try { return a + (P.vacation(v).heures || 0); } catch { return a; } }, 0);
  const d = documentPro({ titre: `Planning de ${nom}`, sousTitre: `${lb.charAt(0).toUpperCase() + lb.slice(1)} · ${vacs.length} vacation(s) · ${Math.round(h * 10) / 10} h`, reference: `Planning ${mois}` });
  d.tableau([["Date", 2.2], ["Horaires", 1.4], ["Poste", 3], ["Site", 1.8], ["Événement", 2.4]], vacs.map((v) => [new Date(v.date + "T12:00:00").toLocaleDateString("fr-FR", { weekday: "short", day: "2-digit", month: "2-digit" }), `${v.debut || ""} – ${v.fin || ""}`, v.poste || "", /arena/i.test(v.site || "") ? "Arena" : "Parc des Expo", v.evenement || ""]), { vide: "Aucune vacation ce mois-ci." });
  d.para("Planning publié par le PC sécurité. Toute modification est communiquée par SMS. En cas de question : PC sécurité 04 67 17 68 68.", { size: 8.5, color: "#5b6573" });
  return d.fin();
}
async function estSmsSeul(id) { const i = String(id || "").toLowerCase(); if (ADJOINTS_PLANIF_DEFAUT.includes(i)) return false; // v5.16 · Fahd n'est plus jamais « SMS seulement » (ancienne liste enregistrée)
  if (i === "adjoint" + AP_DOM) return true; return !!i && (await load("sms_seuls", SMS_SEULS_DEFAUT)).map((e) => String(e).toLowerCase()).includes(i); }
// v4.23 · moyens de secours et d'extinction (le site n'a ni sprinkleurs ni rideau d'eau)
// v4.25 · rondes ADS : malveillance et fermeture des halls / du site (portails, portes, issues…)
const SURETE_TYPES = [["PORTAIL", "Portail / barrière"], ["PORTE", "Porte"], ["IS", "Issue de secours"], ["RIDEAU", "Porte sectionnelle / rideau métallique"], ["VITRAGE", "Fenêtre / vitrage"], ["CLOTURE", "Clôture / grille"], ["LOCAL", "Local technique / réserve"], ["ECLAIRAGE", "Éclairage"], ["ALARME", "Alarme intrusion / contrôle d'accès"], ["AUTRE", "Autre point"]];
const MOYENS_TYPES = [["EXT", "Extincteur"], ["RIA", "RIA"], ["BAES", "BAES / éclairage de sécurité"], ["IS", "Issue de secours"], ["DM", "Déclencheur manuel (DM)"], ["DAE", "DAE / défibrillateur"], ["PCF", "Porte coupe-feu"], ["DESENF", "Désenfumage (commande / ouvrant)"], ["CS", "Colonne sèche"], ["COUPGAZ", "Coupure gaz"], ["COUPELEC", "Coupure électrique / TGBT"], ["COUPEAU", "Coupure eau"], ["HYDR", "Poteau / bouche incendie"], ["RASS", "Point de rassemblement"], ["POMP", "Accès / voie pompiers"], ["SSI", "SSI / tableau de report"], ["TROUSSE", "Trousse de secours"], ["AUTRE", "Autre (au choix)"]]; // v5.20 · coupures, hydrants, rassemblement, accès pompiers, SSI, trousse
// v4.20 · absences des agents dans la planification
const ABS_CODES = { EV: "Événement familial", CP: "Congés payés", FOR: "Formation", CSS: "Congé sans solde", AT: "Accident du travail", AM: "Arrêt maladie" };
const absenceDe = (abs, nom, date) => abs.find((a) => a.du <= date && a.au >= date && memeAgent({ nom: a.nom }, { nom }));
const PLANIFS_MAILS = ["jerre34@hotmail.fr"]; // Jérémy Mercher
// v4.13 · Jérémy Mercher : accès à tout, voient tout, gèrent tout (planning général compris)
async function estChefPlanif(u) {
  if (!u || u.apercu || estProprio(u) || estBloque(u)) return false; const id = String(u.id || "").toLowerCase();
  if (PLANIFS_MAILS.includes(id)) return true;
  if (estFahd(u) || ADJOINTS_PLANIF_DEFAUT.includes(id)) return true; // v5.14 · Fahd Hadouche : même accès que Jérémy Mercher, sauf les devis
  const mails = (await load("planificateurs", [])).map((e) => String(e).toLowerCase()); if (mails.includes(id)) return true;
  // reconnus par leur nom tant que leur adresse n'est pas dans la liste « Planificateurs » (Administration) : seul le 1er compte créé à ce nom compte
  const users = await load("users", []), mailsPl = [...mails, ...PLANIFS_MAILS];
  for (const n of PLANIFS_NOMS) { if (!memeAgent({ nom: u.nom }, { nom: n })) continue;
    if (users.some((x) => mailsPl.includes(String(x.id).toLowerCase()) && memeAgent({ nom: x.nom }, { nom: n }))) return false; // adresse déjà enregistrée pour cette personne
    const premier = users.filter((x) => x.actif !== false && memeAgent({ nom: x.nom }, { nom: n })).sort((a, b) => String(a.cree || "").localeCompare(String(b.cree || "")))[0];
    return !!premier && premier.id === u.id; }
  return false;
}
// Téléchargement du planning général : le propriétaire, Jérémy Mercher, Laurent Hernandez
const DL_PLANNING_DEFAUT = ["courrier.laurent@free.fr"];
async function peutDLPlanning(u) { if (!u || u.apercu) return false; if (estProprio(u) || u.role === "pc" || (await estChefPlanif(u))) return true; /* v4.21 : PCS Parc (compte PC et SSIAP 2 du PC) aussi */ return (await load("dl_planning", DL_PLANNING_DEFAUT)).map((e) => String(e).toLowerCase()).includes(String(u.id).toLowerCase()); }
// Feuille de route du jour : PC sécurité (compte PC et SSIAP 2 du PCS), administrateurs, propriétaire
// v4.30 · Contacts SPL Occitanie Events : PC sécurité, SSIAP 2, Rochdi, Jérémy Mercher et Laurent Hernandez uniquement
const ANNU_SPL_PERSO = ["jerre34@hotmail.fr", "fhadouche@mhscfoot.com", "courrier.laurent@free.fr"], ANNU_SPL_EDIT = ["courrier.laurent@free.fr"];
const peutAnnuaireSPL = (u) => !!u && u.role !== "client" && (estFahd(u) || u.role === "pc" || u.role === "ssiap2" || u.roleAgent === "ssiap2" || estProprio(u) || (!u.apercu && ANNU_SPL_PERSO.includes(String(u.id || "").toLowerCase())));
const editAnnuaireSPL = (u) => !!u && !u.apercu && (estProprio(u) || ANNU_SPL_EDIT.includes(String(u.id || "").toLowerCase()));
const peutFeuilleRoute = (u) => !!u && (["pc", "admin", "ssiap3", "sms"].includes(u.role) || !!u.adjointPlanif || u.roleAgent === "ssiap3" || estProprio(u)); // v4.26 : + SSIAP 3 et adjoint planification (modifient aussi la feuille)
// Responsable PCS (Laurent Hernandez) et référent chef de poste PCS jour (Jérémy Bourg) : accès à tout, planification limitée au planning SSIAP 2 du PC Parc (publié directement)
const VALIDEURS_PC_DEFAUT = ["courrier.laurent@free.fr", "jeremy.bourg@sfr.fr"];
async function estValideurPC(u) { if (apId(u, "admin")) return true; return !!u && !estProprio(u) && (await load("planif_valideurs_pc", VALIDEURS_PC_DEFAUT)).map((e) => String(e).toLowerCase()).filter((e) => !COMPTES_BLOQUES.includes(e)).includes(String(u.id).toLowerCase()); } // Laurent Hernandez + Jérémy (jerre34) // accès à vraiment tout, planning compris
async function estRedacPC(u) { return !!u && (await load("planif_redac_pc", REDAC_PC_DEFAUT)).map((e) => String(e).toLowerCase()).includes(String(u.id).toLowerCase()); }
const estPostePC = (poste, site = "") => perimetreDe(poste, site) === "pcparc";
async function niveauPlanif(u) { if (await peutPlanif(u)) return "valideur"; if (await estValideurPC(u)) return "valideur-pc"; if (await estRedacPC(u)) return "redacteur-pc"; if ((await licencePlanif(u))?.niveau === "redacteur") return "redacteur"; return (await accesPlanif(u)) ? "lecture" : ""; }
// Planification : réservée aux SSIAP 3 et aux administrateurs (pas au compte du PC sécurité, ni aux autres)
const estPCcompte = (u) => !!u && String(u.id).toLowerCase() === MAIL_PC_DEFAUT;
async function accesPlanif(u) {
  if (!u) return false; if (estProprio(u)) return true; if (estPCcompte(u)) return false;
  return (await peutPlanif(u)) || (await estValideurPC(u)) || (await estRedacPC(u)) || !!(await licencePlanif(u)) || u.role === "ssiap3" || u.roleAgent === "ssiap3" || (await estAdminPC(u.id));
}
async function voirPlanif(u) { return accesPlanif(u); }
// Planning complet (tous les postes, toutes les dates) : tous ceux qui ont accès à la planification, sauf le rédacteur limité au PC Parc
async function planningComplet(u) { return (await accesPlanif(u)) && !((await estRedacPC(u)) && !(await peutPlanif(u))); }
/* ---------- v4.12 · PTI / DATI : protection du travailleur isolé (complément, ne remplace pas un DATI certifié) ---------- */
const PTI_GRACE = 3; // minutes de tolérance après l'heure du contrôle
const ptiTxt = { sos: "SOS déclenché par l'agent", chute: "chute ou immobilité détectée", absence: "pas de réponse au contrôle" };
// v4.88 · Réponses des agents à une alerte ou à une alarme PTI (nom + poste)
const REPONSES = { arrive: "J'arrive", details: "Plus de détails ?", danger: "Ne te mets pas en danger !" };
const ROLE_POSTE = { ads: "ADS", ssiap1: "SSIAP 1", ssiap2: "SSIAP 2", ssiap3: "SSIAP 3", responsable: "Responsable", admin: "Administrateur" };
const gpsOk = (g) => { const la = Number(g && g.lat), lo = Number(g && g.lon); return Number.isFinite(la) && Number.isFinite(lo) && Math.abs(la) <= 90 && Math.abs(lo) <= 180 && (la || lo) ? { lat: +la.toFixed(6), lon: +lo.toFixed(6), acc: Math.max(0, Math.min(5000, Math.round(Number(g.acc) || 0))) } : null; };

// v5.56 · points d'attention, qualité des données, compte rendu de vacation, rappel de ronde
async function veilleItems() {
  const out = [], now = Date.now(), etat = await load("cles_etat", {}), cles = await load("cles", CLES_INITIAL), h = (t) => Math.round((now - Date.parse(t)) / 3600e3);
  for (const [n, e] of Object.entries(etat)) { if (e && e.t && now - Date.parse(e.t) > 10 * 3600e3) out.push({ type: "clé", texte: `Clé « ${(cles.find((c) => c.n === n) || {}).nom || n} » sortie depuis ${h(e.t)} h par ${e.nom || "?"}${e.societe ? " (" + e.societe + ")" : ""}` }); }
  for (const i of await mcRecents(1)) { const age = now - Date.parse(i.t); if (i.statut === "ouvert" && !/^(Prise|Fin) de service$/.test(i.categorie || "") && age > 2 * 3600e3 && age < 3 * 864e5) out.push({ type: "fait", texte: `${i.numero} · ${i.categorie}${i.lieu ? " · " + i.lieu : ""} : ouvert depuis ${h(i.t)} h` }); }
  return out.slice(0, 30);
}
async function qualiteDonnees() {
  const users = await load("users", []), an = await load("sms_annuaire", ANNUAIRE_INITIAL), par = new Map();
  const add = (nom, tel) => { const k = tel9(tel); if (!k || k.length < 9 || !nom) return; if (!par.has(k)) par.set(k, []); par.get(k).push(nom); };
  users.forEach((u) => add(u.nom, u.tel)); an.forEach((x) => add(x.nom, x.tel));
  const doublons = [];
  for (const [k, l] of par) { const diff = []; for (const nom of l) if (!diff.some((d) => memeAgent({ nom }, { nom: d }))) diff.push(nom); if (diff.length > 1) doublons.push({ tel: "0" + k, noms: diff }); }
  return { doublons: doublons.slice(0, 30), sansTel: an.filter((x) => x.nom && tel9(x.tel).length < 9).map((x) => x.nom).slice(0, 40), nbAnnuaire: an.length, nbComptes: users.length };
}
const hmParis = (t) => new Date(t).toLocaleTimeString("fr-FR", { timeZone: "Europe/Paris", hour: "2-digit", minute: "2-digit" });
async function compteRendu(me) {
  const now = Date.now(), dep = now - 14 * 3600e3, rec = (t) => Date.parse(t) > dep;
  const mc = (await mcRecents(2)).filter((i) => i.auteurId === me.id && rec(i.t) && !/^(Prise|Fin) de service$/.test(i.categorie || "")).sort((a, b) => a.t.localeCompare(b.t));
  const rd = (await load("rondes_nfc", [])).filter((r) => r.agentId === me.id && rec(r.debut)).sort((a, b) => a.debut.localeCompare(b.debut));
  const al = (await load("alertes", [])).filter((a) => a.auteurId === me.id && rec(a.t)), pa = (await load("passations", [])).filter((x) => x.parId === me.id && rec(x.t));
  const vac = await vacationDe((await load("users", [])).find((x) => x.id === me.id) || me).catch(() => null);
  const L = [`COMPTE RENDU DE VACATION`, `${me.nom}${posteDe(me) ? " · " + posteDe(me) : ""}`, `${new Date().toLocaleDateString("fr-FR", { timeZone: "Europe/Paris", weekday: "long", day: "numeric", month: "long", year: "numeric" })}`];
  if (vac) L.push(`Vacation : ${vac.debut}–${vac.fin}${vac.poste ? " · " + vac.poste : ""}${vac.site ? " · " + vac.site : ""}`);
  L.push("", `Rondes effectuées : ${rd.length}`); rd.forEach((r) => L.push(`- ${hmParis(r.debut)} ${r.nom}${r.statut === "en cours" ? " (en cours)" : ""}`));
  L.push("", `Main courante : ${mc.length} saisie(s)`); mc.forEach((i) => L.push(`- ${hmParis(i.t)} ${i.numero} · ${i.categorie}${i.lieu ? " · " + i.lieu : ""}${i.statut === "ouvert" ? " (OUVERT)" : ""}${i.description ? " : " + String(i.description).slice(0, 140) : ""}`));
  if (al.length) { L.push("", `Alertes lancées : ${al.length}`); al.forEach((a) => L.push(`- ${hmParis(a.t)} ${a.nature}${a.lieu ? " · " + a.lieu : ""}`)); }
  if (pa.length) { L.push("", "Passation :"); pa.forEach((x) => L.push(`- ${x.texte}`)); }
  L.push("", "Observations : RAS");
  return L.join("\n");
}
export async function rappelRondes() {
  const cfg = { actif: true, heures: 3, ...(await load("ronde_rappel", {})) }; if (!cfg.actif) return 0;
  const now = Date.now(), H = cfg.heures * 3600e3, rondes = await load("rondes_nfc", []), etat = await load("ronde_rappel_fait", {}), vac = await agentsEnVacation(), ids = new Set(vac.filter((a) => a.id).map((a) => a.id)); let n = 0;
  for (const k of Object.keys(etat)) if (!ids.has(k)) delete etat[k]; // agent plus en vacation : on repart de zéro à la prochaine
  for (const a of vac) { if (!a.id) continue; const e = (etat[a.id] ||= { vu: now, rappel: 0 }), mes = rondes.filter((r) => r.agentId === a.id);
    if (!mes.some((r) => now - Date.parse(r.debut) < 7 * 864e5)) continue; // seulement les agents qui font des rondes
    const der = Math.max(0, ...mes.map((r) => (r.statut === "en cours" ? now : Date.parse(r.debut))));
    if (now - e.vu < H || now - der < H || now - e.rappel < H) continue;
    e.rappel = now; n++; const hh = Math.round((now - Math.max(der, e.vu)) / 36e5);
    await envoyerPush({ titre: "🚶 Ronde à faire", texte: `Aucune ronde depuis ${hh} h : pense à en lancer une.`, url: "/#/rondes" }, (u) => u.id === a.id).catch(() => 0);
    await journal("rondes", "Kaelum e-PCS", `🚶 rappel de ronde envoyé à ${a.nom} (aucune ronde depuis ${hh} h)`, "info", "#/rondes");
  }
  await save("ronde_rappel_fait", etat); return n;
}
const QUIZ_BANQUE = [
  { theme: "Incendie et SSI", q: "Quels sont les trois éléments du triangle du feu ?", options: ["Combustible, comburant, énergie d'activation", "Eau, air, chaleur", "Fumée, flamme, gaz", "Bois, oxygène, vent"], bonne: 0, explication: "Il faut les trois ensemble pour qu'un feu naisse ; en supprimer un l'éteint." },
  { theme: "Incendie et SSI", q: "Un feu de classe B concerne…", options: ["Les liquides inflammables", "Les solides (bois, papier)", "Les gaz", "Les métaux"], bonne: 0, explication: "A = solides, B = liquides, C = gaz, D = métaux." },
  { theme: "Incendie et SSI", q: "Un extincteur à eau est INTERDIT sur…", options: ["Un feu d'origine électrique sous tension", "Un feu de papier", "Un feu de bois", "Un feu de textile"], bonne: 0, explication: "L'eau conduit l'électricité : on utilise du CO2 ou de la poudre." },
  { theme: "Incendie et SSI", q: "Que signifie « SSI » ?", options: ["Système de sécurité incendie", "Service de secours intérieur", "Surveillance et sûreté intégrée", "Signal sonore d'incendie"], bonne: 0, explication: "Le SSI regroupe la détection, l'alarme et la mise en sécurité (désenfumage, compartimentage…)." },
  { theme: "Incendie et SSI", q: "À quoi correspond le type L des ERP ?", options: ["Salles d'audition, de conférences, de réunions, de spectacles", "Salles d'exposition", "Commerces", "Hôtels"], bonne: 0, explication: "Type L = spectacles et réunions (ex. Arena) ; type T = salles d'exposition (ex. Parc des Expositions)." },
  { theme: "Incendie et SSI", q: "À quoi correspond le type T des ERP ?", options: ["Salles d'exposition", "Salles de spectacles", "Établissements de soins", "Parkings"], bonne: 0, explication: "Type T = salles d'exposition." },
  { theme: "Incendie et SSI", q: "Un ERP de 1re catégorie accueille…", options: ["Plus de 1 500 personnes", "Moins de 100 personnes", "Entre 300 et 700 personnes", "Exactement 1 000 personnes"], bonne: 0, explication: "La 1re catégorie est la plus grande : plus de 1 500 personnes." },
  { theme: "Incendie et SSI", q: "Où vise-t-on avec un extincteur ?", options: ["À la base des flammes", "Au sommet des flammes", "Dans la fumée", "Au plafond"], bonne: 0, explication: "On attaque le foyer à sa base, en balayant, en se plaçant dos à la sortie." },
  { theme: "Incendie et SSI", q: "À quoi sert le désenfumage ?", options: ["Évacuer fumées et chaleur pour faciliter l'évacuation et l'intervention", "Éteindre le feu", "Refroidir les murs", "Couper l'électricité"], bonne: 0, explication: "La fumée est le premier danger : le désenfumage garde des voies praticables." },
  { theme: "Incendie et SSI", q: "Que signifie « levée de doute » ?", options: ["Vérifier sur place la réalité du sinistre avant de décider", "Couper le système", "Évacuer sans vérifier", "Rappeler le client"], bonne: 0, explication: "Un agent vérifie la zone en alarme, puis on confirme ou on infirme." },
  { theme: "Secours à personne", q: "Que fait-on devant une victime inconsciente qui respire ?", options: ["La mettre en PLS et alerter les secours", "Lui donner à boire", "La laisser sur le dos", "La faire asseoir"], bonne: 0, explication: "Position latérale de sécurité, alerte (15/18/112), surveillance de la respiration." },
  { theme: "Secours à personne", q: "Quel est le numéro d'urgence européen ?", options: ["112", "110", "911", "17"], bonne: 0, explication: "Le 112 fonctionne dans toute l'Europe." },
  { theme: "Secours à personne", q: "Combien de compressions pour 2 insufflations dans le massage cardiaque ?", options: ["30", "15", "5", "50"], bonne: 0, explication: "30 compressions / 2 insufflations, ou compressions seules si on ne sait pas insuffler." },
  { theme: "Secours à personne", q: "Quand utiliser le DAE ?", options: ["Sur une personne inconsciente qui ne respire pas, dès que possible", "Uniquement par un médecin", "Après l'arrivée du SAMU", "Sur toute personne qui tombe"], bonne: 0, explication: "Le DAE guide à la voix et s'utilise dès l'arrêt cardiaque." },
  { theme: "Secours à personne", q: "Face à une hémorragie, que fait-on en premier ?", options: ["Appuyer directement sur la plaie avec la main", "Poser un garrot sans réfléchir", "Donner à boire", "Attendre les secours"], bonne: 0, explication: "Compression manuelle directe, puis alerte, en protégeant la victime." },
  { theme: "Secours à personne", q: "Étouffement complet (la personne ne peut plus parler ni respirer) : que fait-on ?", options: ["5 claques dans le dos, puis 5 compressions abdominales", "Lui faire boire de l'eau", "Lui donner du pain", "La laisser tousser sans rien faire"], bonne: 0, explication: "On alterne claques dans le dos et compressions abdominales en alertant les secours." },
  { theme: "Secours à personne", q: "Que signifie « SST » ?", options: ["Sauveteur secouriste du travail", "Service de sécurité du territoire", "Sécurité et surveillance technique", "Signal de secours tactique"], bonne: 0, explication: "Le SST sait protéger, alerter et secourir en attendant les secours." },
  { theme: "Secours à personne", q: "Brûlure légère : quel est le bon réflexe ?", options: ["Refroidir à l'eau pendant au moins 10 minutes", "Mettre du beurre", "Percer les cloques", "Frotter la peau"], bonne: 0, explication: "L'eau refroidit et limite l'étendue de la brûlure ; on ne perce pas les cloques." },
  { theme: "Secours à personne", q: "Les trois temps de base face à un accident sont…", options: ["Protéger, alerter, secourir", "Courir, crier, filmer", "Déplacer, soigner, partir", "Observer, attendre, noter"], bonne: 0, explication: "Protéger d'abord (soi, la victime, les autres), puis alerter, puis secourir." },
  { theme: "Sûreté et gestion de foule", q: "Face à un colis suspect, que fait-on ?", options: ["Ne pas le toucher, isoler la zone, alerter le PC et la police (17)", "L'ouvrir pour vérifier", "Le déplacer dehors", "Le photographier de très près"], bonne: 0, explication: "On ne manipule jamais un colis suspect : périmètre et alerte." },
  { theme: "Sûreté et gestion de foule", q: "Une palpation de sécurité nécessite…", options: ["Le consentement de la personne et un agent du même sexe, habilité", "Aucune condition", "Un agent de n'importe quel sexe", "Une autorisation écrite du client"], bonne: 0, explication: "Elle est encadrée : agent habilité, même sexe, consentement de la personne." },
  { theme: "Sûreté et gestion de foule", q: "Un visiteur refuse l'inspection visuelle de son sac. Que fait-on ?", options: ["On peut lui refuser l'accès", "On le fouille de force", "On le laisse entrer", "On confisque le sac"], bonne: 0, explication: "L'inspection se fait avec le consentement ; en cas de refus, l'accès est refusé." },
  { theme: "Sûreté et gestion de foule", q: "Début de bagarre entre deux personnes : premier réflexe ?", options: ["Alerter le PC et chercher à calmer (désescalade) sans s'exposer seul", "Se jeter dans la bagarre", "Filmer et attendre", "Partir"], bonne: 0, explication: "On alerte, on appelle du renfort et on privilégie le dialogue ; la police (17) si besoin." },
  { theme: "Sûreté et gestion de foule", q: "Que peut faire toute personne face à un crime ou délit flagrant puni d'emprisonnement ?", options: ["L'appréhender et la conduire devant un OPJ", "Rien du tout", "La punir sur place", "La retenir toute la nuit"], bonne: 0, explication: "Article 73 du Code de procédure pénale : on l'appréhende et on la remet sans délai à un officier de police judiciaire." },
  { theme: "Sûreté et gestion de foule", q: "Que note-t-on pour un fait de sûreté en main courante ?", options: ["Heure, lieu, faits constatés, personnes, actions menées", "Seulement le nom de l'agent", "Rien tant que ce n'est pas grave", "Uniquement les opinions"], bonne: 0, explication: "Des faits précis, datés et factuels, sans interprétation." },
  { theme: "Évacuation", q: "Que doit-on faire d'une issue de secours bloquée par du matériel ?", options: ["La dégager ou faire dégager tout de suite et le noter en main courante", "La laisser si c'est temporaire", "La fermer à clé", "L'ignorer la nuit"], bonne: 0, explication: "Une issue de secours doit rester libre en permanence." },
  { theme: "Évacuation", q: "Que signifie « BAES » ?", options: ["Bloc autonome d'éclairage de sécurité", "Bouton d'alarme et d'extinction", "Barrière automatique d'entrée sécurisée", "Boîtier d'alerte électrique simple"], bonne: 0, explication: "Les BAES éclairent les évacuations en cas de coupure secteur." },
  { theme: "Évacuation", q: "Quelle autonomie minimale pour un BAES d'évacuation ?", options: ["1 heure", "5 minutes", "10 minutes", "24 heures"], bonne: 0, explication: "Un BAES doit pouvoir éclairer l'évacuation pendant au moins 1 heure." },
  { theme: "Évacuation", q: "Pendant une évacuation, peut-on utiliser les ascenseurs ?", options: ["Non, on prend les escaliers", "Oui, c'est plus rapide", "Seulement les agents", "Seulement au 1er étage"], bonne: 0, explication: "En cas d'incendie, on n'utilise pas les ascenseurs." },
  { theme: "Évacuation", q: "Où se trouve le point de rassemblement ?", options: ["À l'extérieur, à bonne distance du bâtiment, en lieu sûr", "Devant la porte principale, collé au bâtiment", "Dans le hall", "Au parking souterrain"], bonne: 0, explication: "On se regroupe à distance pour compter les personnes sans gêner les secours." },
  { theme: "Évacuation", q: "Quel est le rôle du serre-file ?", options: ["Fermer la marche et vérifier que personne ne reste dans les locaux", "Ouvrir la marche", "Couper l'électricité", "Appeler la presse"], bonne: 0, explication: "Le guide-file ouvre, le serre-file ferme et contrôle les locaux." },
  { theme: "Évacuation", q: "Que faire à l'arrivée des pompiers ?", options: ["Les accueillir et leur transmettre lieu, nature du sinistre et personnes concernées", "Les laisser chercher seuls", "Couper l'alarme", "Fermer les issues"], bonne: 0, explication: "Un compte rendu clair fait gagner un temps précieux." },
];


// v5.61 · Mode testeur : notification de bienvenue (push + message dans l'appli)
async function bienvenueTesteurs(ids, total) {
  if (!ids.length) return 0; const texte = total ? "Bienvenue dans le mode testeur 24/24 heures" : "Bienvenue dans le mode testeur", list = await load("messagerie", []);
  list.unshift({ id: uid(), t: new Date().toISOString(), par: process.env.OWNER_NOM || "Rochdi Mecheti", texte, important: true, profils: [], ids, dest: ids, lus: {} }); await save("messagerie", list.slice(0, 1000));
  await envoyerPush({ titre: "🧪 Mode testeur", texte, url: "/#/messagerie" }, (u) => ids.includes(u.id)).catch(() => 0); return ids.length;
}
const posteDe = (me) => String(me.postePlanning || me.fonction || ROLE_POSTE[me.role] || me.role || "").slice(0, 80);
// v4.89 · Flammes (fidélité), badges tous les 1000, médailles de vaillant, missions validées par le SSIAP 3
const NIVEAUX = ["Recrue", "Sentinelle", "Veilleur", "Gardien", "Vigie", "Rempart", "Pilier", "Bouclier", "Vétéran", "Élite", "Légende"];
const niveauNom = (n) => NIVEAUX[Math.min(n, NIVEAUX.length - 1)] + (n >= NIVEAUX.length ? " " + "★".repeat(Math.min(5, n - NIVEAUX.length + 1)) : "");
const MEDAILLES = { secours: "Vaillant · secours à personne", feu: "Vaillant · feu maîtrisé", sangfroid: "Vaillant · sang-froid", vigilance: "Vaillant · vigilance", equipe: "Vaillant · esprit d'équipe" };
const MISSIONS = { malaise: ["Malaise / secours à personne", 150], feu: ["Feu maîtrisé", 250], autre: ["Fait important", 100] };
const missionDe = (cat) => /malaise|secours à (personne|victime)|évacuation d'une victime/i.test(cat) ? "malaise" : /^(départ de feu|incendie|feu maîtrisé)$/i.test(String(cat).trim()) ? "feu" : /altercation|rixe|agression|intrusion|enfant perdu|personne recherch|^évacuation$/i.test(cat) ? "autre" : "";
const estSSIAP3 = (u) => !!u && (u.role === "ssiap3" || u.fonction === "SSIAP 3" || PLANIFS_NOMS.includes(u.nom) || estProprio(u));
async function flammes(u, n, motif, { cle = "", capJour = 0, stat = "" } = {}) {
  if (!u || !u.id || u.role === "client" || u.role === "sms" || !(n > 0)) return 0; // v4.96 : tout le monde participe, propriétaire compris
  const F = await load("flammes", {}), j = jourParis();
  const f = (F[u.id] ||= { nom: u.nom, total: 0, hist: [], cles: [], jours: {}, medailles: [], stats: {}, serie: 0, depuis: u.cree || new Date().toISOString() });
  f.nom = u.nom || f.nom; f.cles ||= []; f.jours ||= {}; f.stats ||= {}; f.hist ||= [];
  if (cle && f.cles.includes(cle)) return 0;
  if (capJour) { const k = j + "|" + (stat || motif); if ((f.jours[k] || 0) >= capJour) return 0; f.jours[k] = (f.jours[k] || 0) + 1; for (const x of Object.keys(f.jours)) if (x.slice(0, 10) < j) delete f.jours[x]; }
  const avant = Math.floor(f.total / 1000); f.total += Math.round(n);
  if (cle) { f.cles.push(cle); f.cles = f.cles.slice(-600); }
  if (stat) { f.stats[stat] = (f.stats[stat] || 0) + 1; const mo = j.slice(0, 7); f.mois ||= {}; (f.mois[mo] ||= {})[stat] = (f.mois[mo][stat] || 0) + 1; for (const k of Object.keys(f.mois).sort().slice(0, -14)) delete f.mois[k]; } // v4.92 · compteurs du mois (agent du mois)
  const t = new Date().toISOString(); f.hist.unshift({ t, n: Math.round(n), motif });
  const apres = Math.floor(f.total / 1000);
  if (apres > avant) f.hist.unshift({ t, n: 0, motif: `Nouveau badge : ${niveauNom(apres)}`, badge: apres });
  f.hist = f.hist.slice(0, 150); await save("flammes", F);
  if (apres > avant) { await journal("flammes", u.nom, `🏅 ${u.nom} décroche le badge ${niveauNom(apres)} (${f.total} flammes)`, "info", "#/flammes");
    await envoyerPush({ titre: "🏅 Nouveau badge !", texte: `${niveauNom(apres)} · ${f.total} flammes. Bravo !`, url: "/#/flammes" }, (x) => x.id === u.id).catch(() => 0); }
  return Math.round(n);
}
async function flammesRetirer(id, n, motif, stat = "") { // v4.90 · annulation d'un gain par le SSIAP 3
  const F = await load("flammes", {}), f = F[id]; if (!f) return 0; const k = Math.min(Math.round(n), f.total || 0);
  if (stat) { const mo = jourParis().slice(0, 7); if (f.mois && f.mois[mo] && f.mois[mo][stat]) f.mois[mo][stat]--; if (f.stats && f.stats[stat]) f.stats[stat]--; }
  f.total = (f.total || 0) - k; f.hist = [{ t: new Date().toISOString(), n: -k, motif }, ...(f.hist || [])].slice(0, 150); await save("flammes", F); return k;
}
const flNbS = (n) => Number(n).toLocaleString("fr-FR");
const PROMO_TEXTE = "Salut l'équipe ! VICTOIRE, c'est pour vous : chaque bon réflexe compte et se voit enfin. Testez tout et dites-moi ce que vous en pensez. On compte sur vous !";
const PAS_FLAMME = 1000, PAS_GAIN = 5, PAS_MAX_JOUR = 30000; // podomètre : +5 flammes / 1 000 pas, 30 000 pas comptés par jour au maximum
async function flammesService(me, kind) { // prise / fin de service : fidélité, ponctualité, série de vacations complètes
  const j = jourParis();
  if (kind === "prise") {
    const n = await flammes(me, 10, "Prise de service", { cle: "prise-" + j, stat: "prise" });
    if (n) { const v = await vacationDe(me).catch(() => null);
      if (v && v.debut && v.date) { const d = minutesLocales(v.date, v.debut) - maintenantParis(); if (d >= -5 && d <= 45) await flammes(me, 15, "Ponctualité : prise de service à l'heure", { cle: "ponct-" + j, stat: "ponctuel" }); } }
    const F = await load("flammes", {}), f = F[me.id]; if (f) { if (f.priseOuverte && f.priseOuverte !== j && Date.parse(j) - Date.parse(f.priseOuverte) > 864e5) f.serie = 0; f.priseOuverte = j; await save("flammes", F); }
  } else {
    const n = await flammes(me, 10, "Fin de service", { cle: "fin-" + j, stat: "fin" }); if (!n) return;
    const F = await load("flammes", {}), f = F[me.id]; if (!f || !f.priseOuverte) return;
    f.serie = (f.serie || 0) + 1; f.priseOuverte = null; f.serieMax = Math.max(f.serieMax || 0, f.serie); await save("flammes", F);
    await flammes(me, 5, "Vacation complète (prise + fin de service)", { cle: "complete-" + j, stat: "complete" });
    if (f.serie % 10 === 0) await flammes(me, 50, `Série de ${f.serie} vacations complètes d'affilée`, { cle: "serie-" + j });
  }
}
// v4.93 · Spécialités des agents (postes maîtrisés) : Rochdi, Jérémy Mercher (planification), Laurent Hernandez
const peutSpecialites = async (u) => !!u && !u.apercu && (estProprio(u) || PLANIFS_NOMS.includes(u.nom) || String(u.id || "").toLowerCase() === "courrier.laurent@free.fr" || (await peutPlanif(u)));
const specDe = (S, nom) => { const k = globalThis.PLANIF.cleAgent(nom); return (k && S[k] && S[k].specialites) || []; };
// v5.09 · Sauvegardes automatiques (magasin séparé « ssiap-pro-sauvegardes ») + copie chiffrée envoyée par mail au propriétaire
const SAUV_EXCLUS = (k) => /^(photo|avatar)\//.test(k) || ["vapid", "resets", "locks"].includes(k);
const cleSauv = () => crypto.createHash("sha256").update("sauvegarde|" + (process.env.APP_SECRET || "change-moi")).digest();
export async function sauvegarder(par = "automatique", mail = true) {
  const cles = (await listeCles()).filter((k) => !SAUV_EXCLUS(k)), data = {};
  for (let i = 0; i < cles.length; i += 25) { const lot = cles.slice(i, i + 25); const vals = await Promise.all(lot.map((k) => load(k, null).catch(() => null))); lot.forEach((k, j) => { if (vals[j] != null) data[k] = vals[j]; }); }
  const t = new Date().toISOString(), k = "snap/" + t, brut = JSON.stringify({ v: 1, t, version: VERSION_SERVEUR, par, data }), taille = Buffer.byteLength(brut);
  const SV = await storeNomme(NOM_SAUV()); await SV.set(k, { v: 1, t, version: VERSION_SERVEUR, par, n: Object.keys(data).length, data });
  const idx = (await SV.get("index")) || []; idx.unshift({ k, t, par, n: Object.keys(data).length, taille, version: VERSION_SERVEUR });
  for (const x of idx.slice(10)) await SV.del(x.k).catch(() => {}); await SV.set("index", idx.slice(0, 10));
  let envoi = "non";
  if (mail && process.env.BREVO_API_KEY) { try {
    const zlib = await import("node:zlib"), gz = zlib.gzipSync(brut), iv = crypto.randomBytes(12), c = crypto.createCipheriv("aes-256-gcm", cleSauv(), iv), enc = Buffer.concat([c.update(gz), c.final()]);
    const fichier = Buffer.from(JSON.stringify({ app: "Kaelum e-PCS", v: 1, t, version: VERSION_SERVEUR, iv: iv.toString("base64"), tag: c.getAuthTag().toString("base64"), data: enc.toString("base64") })).toString("base64");
    if (fichier.length < 9e6) { await sendMail([{ nom: "Rochdi Mecheti", email: PROPRIO() }], `Kaelum e-PCS — sauvegarde du ${fmtParis(t)}`, `<p>Sauvegarde ${par} des données de Kaelum e-PCS : ${Object.keys(data).length} éléments (photos non comprises).</p><p>Le fichier joint est chiffré : il ne s'ouvre qu'avec le serveur de l'appli. Garde ce mail. La restauration se fait dans Pilotage → Santé de l'appli.</p>`, [{ name: `m-manager-sauvegarde-${t.slice(0, 10)}.mmsave`, content: fichier }]); envoi = "oui"; }
    else envoi = "trop lourd pour le mail";
  } catch (e) { envoi = "échec : " + String(e.message || e).slice(0, 80); } }
  if (par === "automatique") await battement("sauvegarde", `${Object.keys(data).length} éléments · mail ${envoi}`);
  await journal("admin", par === "automatique" ? "Kaelum e-PCS" : par, `💾 sauvegarde ${par === "automatique" ? "automatique" : "manuelle"} : ${Object.keys(data).length} éléments (${Math.round(taille / 1024)} Ko) · mail : ${envoi}`, "info");
  return { k, t, n: Object.keys(data).length, taille, envoi };
}
async function restaurer(k, par) {
  const SV = await storeNomme(NOM_SAUV()), snap = await SV.get(k); if (!snap || !snap.data) throw new Error("Sauvegarde introuvable");
  await sauvegarder(`avant restauration (${par})`, false); // filet de sécurité : l'état actuel est sauvegardé avant de restaurer
  const cles = Object.keys(snap.data); for (let i = 0; i < cles.length; i += 25) await Promise.all(cles.slice(i, i + 25).map((c) => save(c, snap.data[c])));
  await journal("admin", par, `♻️ données restaurées depuis la sauvegarde du ${fmtParis(snap.t)} (${cles.length} éléments)`, "attention"); return { n: cles.length, t: snap.t };
}
// v4.92 · Agent du mois : ponctualité, assiduité, professionnalisme, réactivité (entre agents, jamais côté client)
const CRITERES = { ponctualite: "Ponctualité", assiduite: "Assiduité", professionnalisme: "Professionnalisme", reactivite: "Réactivité" };
function scoresMois(F, mo, min = 3) {
  const L = Object.entries(F).map(([id, f]) => ({ id, nom: f.nom, s: (f.mois || {})[mo] || {} })).filter((x) => (x.s.prise || 0) >= min);
  const pro = (s) => (s.consignes || 0) + 2 * (s.rondes || 0) + 2 * (s.retex || 0) + 0.5 * (s.mc || 0), rea = (s) => (s.arrive || 0) + 3 * (s.missions || 0) + 3 * (s.medaille || 0);
  const mx = (fn) => Math.max(1, ...L.map((x) => fn(x.s))), mP = mx(pro), mR = mx(rea), mC = mx((s) => s.complete || 0);
  return L.map(({ id, nom, s }) => { const pr = s.prise || 0;
    const sc = { ponctualite: Math.round(100 * Math.min(1, (s.ponctuel || 0) / pr)), assiduite: Math.round(60 * Math.min(1, (s.fin || 0) / pr) + 40 * (s.complete || 0) / mC), professionnalisme: Math.round(100 * pro(s) / mP), reactivite: Math.round(100 * rea(s) / mR) };
    return { id, nom, ...sc, global: Math.round((sc.ponctualite + sc.assiduite + sc.professionnalisme + sc.reactivite) / 4), vacations: pr }; })
    .sort((a, b) => b.global - a.global || b.vacations - a.vacations || a.nom.localeCompare(b.nom, "fr"));
}
async function agentDuMois(F) { // désigne (une seule fois) l'agent du mois précédent
  const prev = moisPrec(jourParis().slice(0, 7)), A = await load("agent_du_mois", {});
  if (!A[prev]) { const sc = scoresMois(F, prev); if (sc.length) { const w = sc[0]; A[prev] = { id: w.id, nom: w.nom, scores: w, auto: true, t: new Date().toISOString() }; await save("agent_du_mois", A);
    const u = (await load("users", [])).find((x) => x.id === w.id) || { id: w.id, nom: w.nom, role: "ads" };
    await flammes(u, 200, `🏆 Agent du mois (${prev})`, { cle: "adm-" + prev, stat: "agentmois" });
    await journal("flammes", "Kaelum e-PCS", `🏆 Agent du mois de ${new Date(prev + "-15").toLocaleDateString("fr-FR", { month: "long", year: "numeric" })} : ${w.nom}`, "info", "#/honneur");
    await envoyerPush({ titre: "🏆 Agent du mois", texte: `Bravo à ${w.nom} !`, url: "/#/honneur" }, (x) => x.role !== "client" && x.role !== "sms").catch(() => 0); } }
  return { A, prev };
}
function profilFlammes(f, u) {
  const st = f.stats || {}, niv = Math.floor((f.total || 0) / 1000), mois = Math.max(0, (Date.now() - Date.parse((u && u.cree) || f.depuis || Date.now())) / (30.4 * 864e5));
  const pr = st.prise || 0, eff = pr ? 0.6 * Math.min(1, (st.ponctuel || 0) / pr) + 0.4 * Math.min(1, (st.fin || 0) / pr) : 0;
  const reac = (st.arrive || 0) + 2 * (st.missions || 0) + 0.5 * (st.retex || 0) + 2 * (f.medailles || []).length;
  return { nom: f.nom, total: f.total || 0, niveau: niv, badge: niveauNom(niv), prochain: (niv + 1) * 1000, badges: Array.from({ length: niv + 1 }, (_, k) => niveauNom(k)),
    serie: f.serie || 0, serieMax: f.serieMax || 0, medailles: f.medailles || [], stats: st,
    indicateurs: { anciennete: { mois: Math.floor(mois), note: Math.min(5, 1 + Math.floor(mois / 3)) }, efficacite: { pct: Math.round(eff * 100), note: pr ? Math.max(1, Math.round(eff * 5)) : 0 }, reactivite: { score: Math.round(reac), note: Math.min(5, Math.round(reac / 4)) } } };
}
function ajouterReponse(cible, me, type) {
  if (!REPONSES[type]) return null;
  cible.reponses ||= []; const r = { id: me.id, nom: me.nom, poste: posteDe(me), type, t: new Date().toISOString() };
  const i = cible.reponses.findIndex((x) => x.id === me.id && x.type === type); if (i >= 0) cible.reponses.splice(i, 1);
  cible.reponses.push(r); cible.reponses = cible.reponses.slice(-60); return r;
}
async function ptiAlarme(s, motif, gps) {
  s.alarme = { motif, t: new Date().toISOString(), gps: gps || s.gps || null, ack: null };
  const g = s.alarme.gps, lien = g ? ` · position : https://maps.google.com/?q=${g.lat},${g.lon}` : "";
  await journal("PTI", s.nom, `🆘 PTI · ${ptiTxt[motif] || motif} · ${s.poste || "poste ?"}${lien}`, "urgent", "#/pti");
  await mcSysteme({ id: s.userId, nom: s.nom, role: s.role }, "PTI / DATI — alarme", `PTI : ${ptiTxt[motif] || motif}${s.poste ? " — poste " + s.poste : ""}${lien}`, "urgente", { gps: g ? { lat: g.lat, lon: g.lon } : null, site: s.site || "" }).catch(() => {});
  await envoyerPush({ titre: `🆘 PTI — ${s.nom}`, texte: `${ptiTxt[motif] || motif} · ${s.poste || "poste ?"}`, url: "/#/pti", alerte: true }, (u) => u.id !== s.userId && enService(u)).catch(() => 0); // v4.88 · tous les agents en service peuvent répondre
}
// toutes les minutes : contrôle des agents sous protection
export async function veillePTI() {
  const L = await load("pti", {}), now = Date.now(); let change = false, n = 0;
  for (const s of Object.values(L)) {
    if (!s.actif) continue;
    const due = Date.parse(s.prochain);
    if (!s.rappel && now >= due) { s.rappel = new Date().toISOString(); change = true; // rappel à l'agent : « tout va bien ? »
      await envoyerPush({ titre: "PTI : tout va bien ?", texte: "Confirme dans l'appli que tout va bien", url: "/#/pti", alerte: true }, (u) => u.id === s.userId).catch(() => 0); }
    if (!s.alarme && now >= due + PTI_GRACE * 60e3) { await ptiAlarme(s, "absence"); change = true; n++; }
    else if (s.alarme && !s.alarme.ack && now - Date.parse(s.alarme.relance || s.alarme.t) >= 5 * 60e3) { // relance toutes les 5 min tant que le PC n'a pas pris en compte
      s.alarme.relance = new Date().toISOString(); change = true;
      await envoyerPush({ titre: `🆘 PTI non pris en compte — ${s.nom}`, texte: `${ptiTxt[s.alarme.motif] || ""} · ${s.poste || ""}`, url: "/#/pti", alerte: true }, (u) => isStaff(u) || estProprio(u)).catch(() => 0); }
  }
  for (const [k, s] of Object.entries(L)) if (!s.actif && now - Date.parse(s.fin || s.debut) > 7 * 864e5) { delete L[k]; change = true; }
  if (change) await save("pti", L);
  return n;
}
// Alertes forcées : nouvelle sonnerie toutes les 2 minutes (5 fois au plus) pour ceux qui n'ont pas confirmé
// Agents non pointés : 15 min après le début de la vacation sans prise de service ➜ notification au PC et aux responsables (une seule fois par vacation)
// v4.13 · mot de motivation (signé Kaelum e-PCS) envoyé à chaque agent au début de sa vacation, une fois par vacation
export async function motiverAgents() {
  const now = maintenantParis(), deja = new Set(await load("motivation_envoyee", [])), users = (await load("users", [])).filter((u) => AGENTS.includes(u.role) && u.actif !== false);
  const pl = (await load("planning", PLANNING_INITIAL)).filter((v) => v.debut && v.nom && !/^NON AFFECT/i.test(v.nom) && [jourParis(-1), jourParis()].includes(v.date));
  let n = 0;
  for (const v of pl) { const deb = minutesLocales(v.date, v.debut); if (now < deb - 10 || now > deb + 5 || deja.has(v.id)) continue; deja.add(v.id);
    const ids = new Set(users.filter((u) => memeAgent(u, v)).map((u) => u.id)); if (!ids.size) continue;
    n += await envoyerPush({ titre: "Kaelum e-PCS — bonne vacation", texte: `${globalThis.motivationDuJour()} — ${globalThis.MOTIVATION_SIGNE}`, url: "/#/" }, (u) => ids.has(u.id)).catch(() => 0); }
  await save("motivation_envoyee", [...deja].slice(-600)); return n;
}
export async function signalerNonPointes() {
  const deja = await load("non_pointes_signales", {}), now = maintenantParis(), auj = jourParis(), hier = jourParis(-1); let n = 0;
  for (const d of [hier, auj]) for (const l of await presencesDu(d)) {
    if (!["absent"].includes(l.statut) || /^NON AFFECT/i.test(l.nom)) continue;
    const deb = minutesLocales(d, l.debut); if (now < deb + 15 || now > deb + 180) continue;
    const k = `${d}|${l.nom}|${l.debut}`; if (deja[k]) continue; deja[k] = Date.now(); n++;
    await journal("présences", "Kaelum e-PCS", `⏰ ${l.nom} non pointé : vacation ${l.debut}–${l.fin} · ${l.poste}${l.site ? " · " + l.site : ""}`, "attention", "#/presences");
    await envoyerPush({ titre: "Agent non pointé", texte: `${l.nom} · ${l.poste} · prévu à ${l.debut} : pas de prise de service`, url: "/#/tdb" }, async (u) => isStaff(u) || estProprio(u) || (await estAdminPC(u.id))).catch(() => 0);
  }
  if (n) { const lim = Date.now() - 3 * 864e5; for (const [k, t] of Object.entries(deja)) if (t < lim) delete deja[k]; await save("non_pointes_signales", deja); }
  return n;
}
// v4.83 · faits ouverts trop longtemps : relance du PC (urgent : 15, 30, 60 min · moyen : 60 min)
export async function escaladerFaits() {
  const now = Date.now(), mois = new Date(now).toISOString().slice(0, 7), prec = new Date(now - 20 * 864e5).toISOString().slice(0, 7);
  const L = [...(await mcMois(mois)), ...(prec !== mois ? await mcMois(prec) : [])], E = await load("escalades", {}); let n = 0, change = false;
  for (const i of L) {
    if (i.statut === "clos" || !["urgente", "moyenne"].includes(i.gravite)) continue;
    const dep = Date.parse(i.t), min = (now - dep) / 60e3; // heure d'enregistrement (UTC)
    if (!(min >= 0) || min > 24 * 60) continue;
    const paliers = i.gravite === "urgente" ? [15, 30, 60] : [60], fait = E[i.id] || 0, pal = paliers.filter((x) => min >= x).pop();
    if (!pal || pal <= fait) continue;
    E[i.id] = pal; change = true; n++;
    await envoyerPush({ titre: `⏱ ${i.gravite === "urgente" ? "URGENT" : "Fait"} ouvert depuis ${pal} min`, texte: `${i.numero || ""} · ${i.categorie || ""}${i.lieu ? " · " + i.lieu : ""} — à traiter ou à clore`, url: "/#/mc", alerte: i.gravite === "urgente" },
      (u) => isStaff(u) || estProprio(u) || u.role === "pc").catch(() => 0);
    await journal("main courante", "Kaelum e-PCS", `relance : ${i.numero} ${i.categorie} ouvert depuis ${pal} min`, i.gravite === "urgente" ? "urgent" : "attention", "#/mc");
  }
  if (change) { for (const k of Object.keys(E)) if (!L.some((i) => i.id === k && i.statut !== "clos")) delete E[k]; await save("escalades", E); }
  return n;
}
// v5.35 · contenus éphémères : les photos preuve sont effacées (fichiers compris) après 24 h
export async function purgerEphemeres() {
  const now = Date.now(), vieux = (x) => now - Date.parse(x.t) >= 864e5; let n = 0;
  for (const [cle, nom] of [["preuves_liste", "preuves"]]) {
    const l = await load(cle, []), morts = l.filter(vieux); if (!morts.length) continue; const S = await storeNomme(nom);
    for (const x of morts) { await S.del(x.id).catch(() => {}); n++; } await save(cle, l.filter((x) => !vieux(x)));
  }
  return n;
}
// v5.63 · Discussions : effacement des messages expirés (et de leurs photos)
export async function purgerChat() {
  const convs = await load("chat_convs", []), now = Date.now(); let n = 0; const I = await storeNomme("chat-img");
  for (const c of convs) { const l = await load("chat_m_" + c.id, []), ok = l.filter((x) => !x.exp || Date.parse(x.exp) > now); if (ok.length === l.length) continue;
    for (const x of l) if (!ok.includes(x) && x.img) await I.del(x.id).catch(() => {}); n += l.length - ok.length; await save("chat_m_" + c.id, ok); }
  return n;
}
export async function relancerAlertes() {
  const list = await load("alertes", []), now = Date.now(); let n = 0, change = false;
  for (const a of list) {
    if (!a.forcee || a.fin || Date.parse(a.exp) <= now || (a.relances || 0) >= 5 || now - Date.parse(a.derniereRelance || a.t) < 110e3) continue;
    const vus = new Set((a.vus || []).map((v) => v.id));
    a.relances = (a.relances || 0) + 1; a.derniereRelance = new Date().toISOString(); change = true;
    n += await envoyerPush({ titre: `RAPPEL ALERTE FORCÉE — ${a.nature}`, texte: `${a.lieu ? a.lieu + " · " : ""}${a.texte.slice(0, 150)} — confirme la réception`, url: "/#/alertes", alerte: true },
      async (u) => !vus.has(u.id) && !(estProprio(u) && vus.has("__admin")) && (await enService(u))).catch(() => 0);
  }
  if (change) await save("alertes", list);
  return n;
}
// Exemples de présentation : entrées réalistes avec les vrais agents du planning (marquées demo)
async function genererExemples(me) {
  // agents réels du planning : aujourd'hui, sinon le jour le plus proche qui a des vacations
  const pl = (await load("planning", PLANNING_INITIAL)).filter((v) => v.nom && v.debut), auj = jourParis();
  const jours = [...new Set(pl.map((v) => v.date))].sort((a, b) => Math.abs(Date.parse(a) - Date.parse(auj)) - Math.abs(Date.parse(b) - Date.parse(auj)));
  let jourPl = "", lignes = [];
  for (const j of jours) { lignes = pl.filter((v) => v.date === j); if (new Set(lignes.map((v) => v.nom)).size >= 3) { jourPl = j; break; } }
  if (!lignes.length) throw new Error("Aucun agent au planning");
  const vus = new Set(), ag = lignes.filter((v) => !vus.has(v.nom) && vus.add(v.nom)).sort(() => Math.random() - 0.5);
  const parc = ag.filter((v) => !/arena/i.test((v.site || "") + " " + (v.poste || ""))), arena = ag.filter((v) => /arena/i.test((v.site || "") + " " + (v.poste || "")));
  const pick = (l, i) => (l.length ? l[i % l.length] : ag[i % ag.length]);
  const nomA = (v) => v.nom.split(/\s+/).map((x) => x.charAt(0) + x.slice(1).toLowerCase()).join(" ");
  const now = Date.now(), T = (minAgo) => new Date(now - minAgo * 60e3).toISOString();
  const hLoc = (iso) => new Intl.DateTimeFormat("sv-SE", { timeZone: "Europe/Paris", year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit" }).format(new Date(iso)).replace(" ", "T");
  const SITE = (v) => (/arena/i.test((v.site || "") + " " + (v.poste || "")) ? "Arena Sud de France" : "Parc des Expositions");
  const year = new Date().getFullYear(), cpt = await load("mc_compteur", {}), rcpt = await load("rap_compteur", {});
  const MC = (minAgo, v, x) => { cpt[year] = (cpt[year] || 0) + 1; const t = T(minAgo);
    return { id: uid(), numero: `MC-${year}-${String(cpt[year]).padStart(4, "0")}`, t, heure: hLoc(t), auteurId: "demo", auteur: nomA(v), role: "ads", evenementId: null, evenement: v.evenement || "",
      categorie: "Information / consigne", famille: "", poste: "", societe: "", immat: "", gravite: "info", site: SITE(v), lieu: v.poste || "", description: "", intervenants: "", actions: "", prestataire: "", gps: null,
      statut: "clos", suivi: [], photo: false, photos: 0, demo: true, ...x }; };
  const RAP = (minAgo, v, kind, x) => { const K = TYPES_RAPPORT[kind] || TYPES_RAPPORT.autre; rcpt[K.pre + year] = (rcpt[K.pre + year] || 0) + 1; const t = T(minAgo);
    return { id: uid(), t, kind: TYPES_RAPPORT[kind] ? kind : "autre", label: K.lb, auteurId: "demo", auteur: nomA(v), poste: [v.poste, v.evenement].filter(Boolean).join(" — "), heure: hLoc(t), urgence: "normale", site: SITE(v),
      prestataire: "", details: {}, securise: "", intervenants: "", gps: null, photos: 0, statut: "ouvert", suivi: [], numero: `${K.pre}-${year}-${String(rcpt[K.pre + year]).padStart(4, "0")}`, demo: true, ...x }; };
  const a = [0, 1, 2, 3, 4, 5].map((i) => pick(parc, i)), b = [0, 1].map((i) => pick(arena, i));
  const mc = [
    MC(300, a[0], { categorie: "Prise de service", description: `Prise de service ${a[0].poste || ""}. Matériel radio et clés vérifiés, consignes du jour lues.` }),
    MC(296, a[1], { categorie: "Prise de service", description: `Prise de service ${a[1].poste || ""}. Radio OK, RAS.` }),
    MC(292, b[0], { categorie: "Prise de service", description: `Prise de service ${b[0].poste || ""} à l'Arena. Tour des issues effectué.` }),
    MC(250, a[2], { categorie: "Ouverture / fermeture site", description: "Ouverture du portail principal et des accès piétons pour l'arrivée des exposants.", lieu: "Portail principal" }),
    MC(205, a[3], { categorie: "Accès / contrôle entrée", famille: "Livraison", societe: "Transports Sud Logistique", immat: "GH-512-KL", description: "Livraison stand B12, véhicule orienté vers le quai Hall B.", lieu: "Accès livraisons" }),
    MC(160, a[0], { categorie: "Information / consigne", description: "Consigne PC : fermeture de la passerelle à 19 h, report des flux par le mail central.", lieu: "PC sécurité" }),
    MC(95, b[1], { categorie: "Refus d'entrée", gravite: "moyenne", description: "Personne sans billet refusant de quitter la file, dialogue puis départ sans incident.", lieu: "Porte 3", statut: "clos" }),
    MC(40, a[4], { categorie: "Alarme incendie / levée de doute", gravite: "moyenne", description: "Déclenchement détecteur Hall A1 zone 4. Levée de doute : poussière de montage, aucun feu. Réarmement SSI par le PC.", lieu: "Hall A1", actions: "Levée de doute, réarmement" }),
  ];
  for (const i of mc) await mcAjouter(i);
  await save("mc_compteur", cpt);
  const raps = [
    RAP(230, a[2], "issue", { lieu: "Hall B — issue n°4", texte: "Issue de secours encombrée par des palettes d'un exposant. Exposant prévenu, issue dégagée.", securise: "Issue dégagée et contrôlée", statut: "clos" }),
    RAP(130, a[5], "malaise", { lieu: "Hall A — allée centrale", urgence: "normale", details: { Victime: "Femme", "Âge approximatif": "45" }, texte: "Visiteuse prise d'un malaise, mise au repos et hydratée, partie par ses propres moyens après 20 min.", securise: "Zone sécurisée, victime accompagnée", statut: "clos" }),
    RAP(70, pick(parc, 6), "extincteur", { lieu: "Hall C — stand C08", texte: "Extincteur CO2 déplacé derrière un stand. Remis à son emplacement, signalé au chef de projet.", statut: "ouvert" }),
  ];
  const rapL = (await load("rap", null)) || []; await save("rap", [...raps.reverse(), ...rapL]); await save("rap_compteur", rcpt);
  const rapports = await load("rapports", []);
  rapports.unshift({ id: uid(), t: T(20), auteurId: "demo", auteur: nomA(a[1]), titre: "Point de situation montage", site: "Parc des Expositions", lieu: "Halls A et B", texte: "Montage en cours, accès livraisons fluides. Deux issues rappelées aux exposants. Aucun incident à signaler.", gps: null, photos: 0, demo: true });
  await save("rapports", rapports);
  const pc = (await load("parcours", PARCOURS_INITIAL))[0];
  if (pc) { const rondes = await load("rondes_nfc", []), deb = now - 180 * 60e3;
    rondes.unshift({ id: uid(), parcoursId: pc.id, nom: pc.nom, site: pc.site, dureeMax: pc.dureeMax || 0, points: pc.points, agentId: "demo", agent: nomA(a[3]), poste: a[3].poste || "", debut: new Date(deb).toISOString(), fin: new Date(deb + 38 * 60e3).toISOString(), statut: "terminée", duree: 38, oublies: 0, anomalies: 1,
      passages: pc.points.map((p, i) => ({ uid: p.uid, nom: p.nom, t: new Date(deb + (i + 1) * 6 * 60e3).toISOString(), ras: i !== 2, obs: i === 2 ? "Éclairage extérieur défaillant" : "", ordre: i + 1, mode: "nfc" })), ordreOk: true, obs: "", demo: true });
    await save("rondes_nfc", rondes); }
  const ck = await load("checklists", []);
  ck.unshift({ id: uid(), t: T(270), agentId: "demo", agent: nomA(a[0]), modele: "Ouverture du PC sécurité", evenement: a[0].evenement || "", lieu: "PC sécurité", obs: "", items: ["Report SSI vérifié", "Radios chargées", "Main courante ouverte", "Clés au tableau"].map((label) => ({ label, ok: true, nc: false })), conforme: true, demo: true });
  await save("checklists", ck);
  const cm = await load("cles_mvt", []), s1 = T(240);
  cm.unshift({ id: uid(), n: "B4", cle: "Local technique Hall B", type: "retour", nom: "SPIE", societe: "SPIE", sortie: s1, duree: 110, obs: "", t: T(130), par: nomA(a[0]), demo: true },
    { id: uid(), n: "B4", cle: "Local technique Hall B", type: "sortie", cat: "prestataire", nom: "SPIE", societe: "SPIE", motif: "Intervention électrique", t: s1, par: nomA(a[0]), demo: true });
  await save("cles_mvt", cm);
  const bm = await load("batiments_mvt", []);
  bm.unshift({ id: uid(), t: T(280), halls: ["Hall A", "Hall B"], actions: ["ouverture", "eclairage_on"], libelle: "Ouverture + Mise en fonction éclairage", dem: { type: "organisateur", societe: "", nom: "Chef de projet" }, commentaire: "Arrivée des exposants", par: nomA(a[0]), demo: true });
  await save("batiments_mvt", bm);
  const al = await load("alertes", []);
  al.unshift({ id: uid(), t: T(150), exp: T(90), nature: "Enfant perdu", texte: "Garçon 6 ans, t-shirt rouge, vu vers le Hall B.", lieu: "Hall B", site: "Parc des Expositions", auteur: nomA(a[2]), auteurId: "demo", forcee: false, vus: [],
    fin: { t: T(135), par: nomA(a[0]), note: "Enfant retrouvé et remis à ses parents au PC" }, demo: true });
  await save("alertes", al);
  const ob = await load("objets", []), anO = new Date().getFullYear();
  ob.unshift({ id: uid(), numero: `OT-${anO}-EX01`, t: T(110), auteurId: "demo", auteur: nomA(a[1]), categorie: "Téléphone", description: "Smartphone noir, coque bleue, écran fissuré", site: "Parc des Expositions", lieu: "Hall B — allée centrale", rapportePar: "Visiteur", stockage: "Armoire PC, étagère 1", statut: "en stock", photo: false, demo: true },
    { id: uid(), numero: `OT-${anO}-EX02`, t: T(260), auteurId: "demo", auteur: nomA(a[0]), categorie: "Portefeuille / papiers", description: "Portefeuille marron avec carte d'identité", site: "Parc des Expositions", lieu: "Accueil A", rapportePar: "Hôtesse d'accueil", stockage: "Coffre PC", statut: "restitué", photo: false, demo: true,
      restitution: { t: T(60), par: nomA(a[0]), nom: "Propriétaire (pièce d'identité vérifiée)", tel: "", piece: "CNI", note: "" } });
  await save("objets", ob);
  await journal("admin", me.nom, `exemples de présentation créés avec ${ag.length} agent(s) du planning du ${jourPl.split("-").reverse().join("/")}`);
  return { ok: true, jour: jourPl, agents: [...new Set([...a, ...b].map(nomA))], nb: mc.length + raps.length + 8 };
}
// ---------- Habilitations des agents (ADS, SSIAP 1, 2, 3) : modules autorisés, réglés par le propriétaire ----------
// v4.17 · QR de signalement réservés aux bâtiments privés (personnel SPL) : anomalies de sûreté et de sécurité
const SIGNAL_LIEUX = [["Parc des Expositions", "Atelier SPL"], ["Parc des Expositions", "Bureaux d'exploitation SPL"], ["Parc des Expositions", "Bureaux de direction SPL"],
  ["Arena Sud de France", "Bureaux Arena"], ["Parc des Expositions", "Local Sud Service"], ["Parc des Expositions", "Salle de pause R+1 CDC"]];
const SIGNAL_NATURES_SURETE = ["Porte ou accès laissé ouvert / forcé", "Personne non autorisée / intrusion", "Objet ou colis suspect", "Vol / dégradation", "Comportement suspect / menace"];
const SIGNAL_NATURES_SECURITE = ["Issue de secours / porte coupe-feu bloquée", "Extincteur, RIA ou DAE manquant / abîmé", "Éclairage de sécurité hors service", "Odeur de brûlé, fumée ou gaz", "Fuite d'eau / danger électrique", "Chute, sol glissant, danger"];
const SIGNAL_NATURES_OLD = ["Malaise / personne blessée", "Départ de feu / fumée", "Objet suspect", "Bagarre / comportement agressif", "Enfant perdu", "Fuite d'eau / dégât", "Issue ou porte bloquée", "Propreté / danger au sol", "Autre"];
// Registre de sécurité : installations et périodicités par défaut (paramétrables)
const REGISTRE_DEFAUT = () => { const L = [["SSI — système de sécurité incendie", 12], ["Désenfumage", 12], ["Extincteurs", 12], ["RIA — robinets d'incendie armés", 12], ["Éclairage de sécurité / BAES", 12],
    ["Installations électriques", 12], ["Installations gaz", 12], ["Portes et clapets coupe-feu", 6], ["Groupe électrogène — essai", 1], ["Ascenseurs et monte-charges", 12], ["Sonorisation de sécurité", 12], ["Exercice d'évacuation", 6]];
  return ["Parc des Expositions", "Arena Sud de France"].flatMap((site) => L.map(([nom, mois]) => ({ id: (site[0] + nom).toLowerCase().normalize("NFD").replace(/[^a-z0-9]+/g, "-").slice(0, 40), site, nom, mois, derniere: "", organisme: "", obs: "", conforme: null, historique: [] }))); };
function registreCalc(reg) { // prochaine échéance et état de chaque installation
  const auj = new Intl.DateTimeFormat("fr-CA", { timeZone: "Europe/Paris" }).format(new Date()), d30 = new Intl.DateTimeFormat("fr-CA", { timeZone: "Europe/Paris" }).format(new Date(Date.now() + 30 * 864e5));
  return reg.map((x) => { if (!x.derniere) return { ...x, prochaine: "", etat: "a-renseigner" };
    const d = new Date(x.derniere + "T12:00:00Z"); d.setUTCMonth(d.getUTCMonth() + (x.mois || 12)); const prochaine = d.toISOString().slice(0, 10);
    return { ...x, prochaine, etat: x.conforme === false ? "non-conforme" : prochaine < auj ? "retard" : prochaine <= d30 ? "bientot" : "ok" }; });
}
// ---------- v3.81 · Statistiques en direct : réservées au client (anonymes : ni noms, ni planning, ni clés) ----------
async function statsClient() {
  const now = Date.now(), auj = jourParis();
  const fH = new Intl.DateTimeFormat("fr-CA", { timeZone: "Europe/Paris", year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", hourCycle: "h23" });
  const cleH = (t) => fH.format(new Date(t)).replace(", ", "T").slice(0, 13), fJ = (t) => new Intl.DateTimeFormat("fr-CA", { timeZone: "Europe/Paris" }).format(new Date(t));
  const horsService = (i) => !/^(Prise|Fin) de service$/.test(i.categorie);
  const mc2 = (await mcRecents(2)).filter(horsService), heures = [], jours = [];
  for (let k = 23; k >= 0; k--) { const c = cleH(now - k * 3600e3); heures.push({ h: c.slice(11, 13), n: 0, c }); }
  for (let k = 6; k >= 0; k--) jours.push({ j: fJ(now - k * 864e5), n: 0, u: 0 });
  for (const i of mc2) { const ti = Date.parse(i.t);
    if (now - ti < 24 * 3600e3) { const b = heures.find((x) => x.c === cleH(ti)); if (b) b.n++; }
    if (now - ti < 8 * 864e5) { const b = jours.find((x) => x.j === fJ(ti)); if (b) { b.n++; if (i.gravite === "urgente") b.u++; } } }
  const jour = mc2.filter((i) => fJ(i.t) === auj), cats = {};
  jour.forEach((i) => (cats[i.categorie] = (cats[i.categorie] || 0) + 1));
  const raps = ((await load("rap", null)) || []).filter((r) => fJ(r.t) === auj).length + (await load("rapports", [])).filter((r) => fJ(r.t) === auj).length;
  return { t: new Date().toISOString(), heures: heures.map(({ h, n }) => ({ h, n })), jours,
    gravite: { info: jour.filter((i) => !["moyenne", "urgente"].includes(i.gravite)).length, moyenne: jour.filter((i) => i.gravite === "moyenne").length, urgente: jour.filter((i) => i.gravite === "urgente").length },
    categories: Object.entries(cats).sort((a, b) => b[1] - a[1]).slice(0, 5),
    compteurs: { mcJour: jour.length, ouvertes: mc2.filter((i) => i.statut !== "clos" && now - Date.parse(i.t) < 31 * 864e5).length, rapports: raps,
      rondes: (await load("rondes_nfc", [])).filter((r) => r.statut === "en cours").length, alertes: (await load("alertes", [])).filter((a) => !a.fin && Date.parse(a.exp) > now).length,
      objets: (await load("objets", [])).filter((o) => o.statut === "en stock").length, signalements: jour.filter((i) => /^Signalement (public|anomalie)/.test(i.categorie || "")).length, secours: jour.filter((i) => i.categorie === "Appel secours").length } };
}
// ---------- Planification automatique (partagée) : remplit les postes avec les agents qualifiés, disponibles et en règle ----------
async function autoRemplir(postes, du, au, me) {
  const P = globalThis.PLANIF, cle = P.cleAgent, users = await load("users", []);
  const normQ = (q, poste = "") => { const x = (String(q || "") + " " + String(poste || "")).toUpperCase(); return /SSIAP\s*3/.test(x) ? 3 : /SSIAP\s*2/.test(x) ? 2 : /SSIAP\s*1|SSIAP(?!\s*[23])/.test(x) ? 1 : 0; };
  const pl = await load("planning", PLANNING_INITIAL), avant = new Date(Date.parse(du) - 90 * 864e5).toISOString().slice(0, 10);
  // qualification de chaque agent : comptes, historique du planning, disponibilités déclarées
  const agents = new Map(), ajoute = (nom, q, tel) => { if (!nom) return; const k = cle(nom); const a = agents.get(k) || { nom, q: -1, tel: "", vus: {} }; a.q = Math.max(a.q, q); if (tel && !a.tel) a.tel = tel; agents.set(k, a); return a; };
  for (const u of users) if (AGENTS.includes(u.role) && u.actif !== false) ajoute(u.nom, { ads: 0, ssiap1: 1, ssiap2: 2, ssiap3: 3 }[u.role] ?? 0, u.tel);
  for (const v of pl) if (v.date >= avant && v.nom) { const a = ajoute(v.nom, normQ(v.qualif, v.poste), v.tel); a.vus[String(v.poste || "").toUpperCase()] = (a.vus[String(v.poste || "").toUpperCase()] || 0) + 1; }
  const moisListe = [...new Set([du.slice(0, 7), au.slice(0, 7)])], dispo = {};
  for (const mm of moisListe) for (const [id, d] of Object.entries(await load("dispos/" + mm, {}))) { const u = users.find((x) => x.id === id); const a = ajoute((u && u.nom) || d.nom, Math.max(-1, ...(d.qualifs || []).map((q) => normQ(q))), u && u.tel); if (a) dispo[cle(a.nom)] = { ...(dispo[cle(a.nom)] || {}), ...(d.jours || {}) }; }
  // emploi du temps déjà connu : planning publié + postes (brouillons compris)
  const emploi = {}, pose = (nom, v) => (emploi[cle(nom)] ||= []).push(v);
  const lim1 = new Date(Date.parse(du) - 21 * 864e5).toISOString().slice(0, 10), lim2 = new Date(Date.parse(au) + 8 * 864e5).toISOString().slice(0, 10);
  for (const v of pl) if (v.date >= lim1 && v.date <= lim2 && v.nom && !v.posteId) pose(v.nom, { date: v.date, debut: v.debut, fin: v.fin, nom: v.nom, id: v.id });
  for (const p of postes) if (!p.supprime && p.date >= lim1 && p.date <= lim2) for (const a of p.agents) pose(a.nom, { date: p.date, debut: p.debut, fin: p.fin, nom: a.nom, id: p.id });
  const rouges = (l) => P.controles(l).filter((c) => c.niveau === "rouge").length;
  const heuresSem = (k, date) => { const lun = P.lundi(Date.parse(date)); return (emploi[k] || []).filter((v) => P.lundi(Date.parse(v.date)) === lun).reduce((s, v) => s + P.vacation(v).heures, 0); };
  let pourvus = 0, manquants = 0; const touches = new Set();
  const cibles = postes.filter((p) => !p.supprime && p.date >= du && p.date <= au && p.agents.length < p.nb).sort((a, b) => (a.date + a.debut).localeCompare(b.date + b.debut));
  for (const p of cibles) {
    const qReq = normQ(p.qualif, p.poste), nuit = +p.debut.slice(0, 2) >= 19 || +p.debut.slice(0, 2) < 5;
    while (p.agents.length < p.nb) {
      const pris = new Set(p.agents.map((a) => cle(a.nom)));
      let best = null, bestS = -1e9;
      for (const [k, a] of agents) {
        if (pris.has(k) || a.q < qReq) continue;
        const dj = (dispo[k] || {})[p.date]; if (dj === "indispo" || (dj === "jour" && nuit) || (dj === "nuit" && !nuit)) continue;
        const l = emploi[k] || [], essai = { date: p.date, debut: p.debut, fin: p.fin, nom: a.nom, id: "essai" };
        if (rouges([...l, essai]) > rouges(l)) continue;
        const sc = (dj ? 40 : 0) + Math.min(15, (a.vus[String(p.poste || "").toUpperCase()] || 0) * 3) - heuresSem(k, p.date) * 1.5 - (a.q - qReq) * 6 + ((k.length * 7 + p.date.charCodeAt(9)) % 5) * 0.1;
        if (sc > bestS) { bestS = sc; best = [k, a]; }
      }
      if (!best) { manquants += p.nb - p.agents.length; break; }
      const [k, a] = best; p.agents.push({ nom: a.nom, tel: String(a.tel || "").replace(/[^\d+]/g, ""), auto: true });
      pose(a.nom, { date: p.date, debut: p.debut, fin: p.fin, nom: a.nom, id: p.id }); pourvus++;
      p.modifie = true; p.maj = new Date().toISOString(); p.majPar = me.nom + " (auto)"; touches.add(p.id);
    }
  }
  return { pourvus, manquants, touches };
}
const HAB_MODULES = [["mc", "Main courante", ["incidents"]], ["rapports", "Rapports d'intervention et rapports libres", ["rap", "di", "rapports"]], ["rondes", "Rondes et check-lists", ["ronde", "rondes", "parcours", "checklists"]],
  ["alertes", "Lancer une alerte", []], ["cles", "Registre des clés", ["cles"]], ["materiel", "Prêt de matériel", ["materiel"]], ["batiments", "Ouverture / fermeture des bâtiments", ["batiments"]],
  ["objets", "Objets trouvés", ["objets"]], ["jauge", "Comptage de la jauge", ["jauge"]], ["plan", "Plan du site et carte des postes", ["plan", "sitepostes"]], ["docs", "Documents du PC sécurité", ["docs"]],
  ["memo", "Mémo, fiches site et évaluation des risques", ["risques"]], ["dispos", "Déclarer ses disponibilités", ["dispos"]]];
const HAB_ROLES = ["ads", "ssiap1", "ssiap2", "ssiap3"];
const HAB_NIVEAU_PC = ["cles", "materiel", "batiments", "docs"]; // modules du niveau SSIAP 2 / PC : fermés par défaut aux ADS et SSIAP 1
async function habilitations() { const h = await load("habilitations", {}); const out = {}; for (const r of HAB_ROLES) { out[r] = {}; for (const [k] of HAB_MODULES) { const v = (h[r] || {})[k]; out[r][k] = v === undefined ? !(["ads", "ssiap1"].includes(r) && HAB_NIVEAU_PC.includes(k)) : v !== false; } } return out; }
async function habilDe(role) { return HAB_ROLES.includes(role) ? (await habilitations())[role] : null; }
// Coordinateur Arena : poste du planning « COORD… » à l'Arena ➜ il répartit les ADS du jour par groupe
const estCoordArena = (v) => !!v && /COORD/i.test(v.poste || "") && /ARENA/i.test((v.poste || "") + " " + (v.site || ""));
const GROUPES_ARENA = [["portes", "🚪 Portes fouilles", /PORTE|FOUILLE|PALPATION/], ["bord", "🏟️ Bord terrain", /BORD|TERRAIN|PISTE/], ["interv", "🚨 Intervention", /INTERV|VOLANT|R[EÉ]GUL/],
  ["parterre", "👥 Parterre", /PARTERRE|FOSSE|PELOUSE/], ["joueurs", "⛹️ Entrée joueurs", /JOUEUR|VESTIAIRE/], ["artistes", "🎤 Accès artistes", /ARTISTE|LOGE ARTISTE|BACKSTAGE/],
  ["crash", "🛑 Crash", /CRASH/], ["vip", "🥂 Loges VIP partenaires", /VIP|PARTENAIRE|LOGE/]];
const estADS = (v) => /\bADS\b|AGENT DE S[EÉ]CURIT/i.test((v.qualif || "") + " " + (v.poste || "")) || (!/SSIAP|PC\b|COORD|CHEF/i.test(v.poste || "") && !/SSIAP/i.test(v.qualif || ""));
// ADS de l'Arena d'un jour, rangés par groupe (planning + répartition du coordinateur)
async function equipeArenaJour(date) {
  const eq = (await load("arena_equipes", {}))[date] || { affect: {}, requis: {}, ajouts: [], retires: [] };
  const pl = (await load("planning", PLANNING_INITIAL)).filter((v) => v.date === date && /ARENA/i.test((v.site || "") + " " + (v.poste || "")) && estADS(v) && !estCoordArena(v));
  const auto = (poste) => (GROUPES_ARENA.find((g) => g[2].test(String(poste || "").toUpperCase())) || ["aplacer"])[0];
  const agents = pl.map((v) => { const id = `${v.nom}|${v.debut}`; return { id, nom: v.nom, debut: v.debut, fin: v.fin, poste: v.poste || "", groupe: eq.affect[id] || auto(v.poste), retire: (eq.retires || []).includes(id) }; })
    .concat((eq.ajouts || []).map((a) => ({ id: a.id, nom: a.nom, debut: a.debut, fin: a.fin, poste: "ajouté par " + a.par, groupe: eq.affect[a.id] || "aplacer", ajoute: true }))).filter((a) => !a.retire);
  return { date, evenement: [...new Set(pl.map((v) => v.evenement).filter(Boolean))].join(" · "),
    groupes: [["aplacer", "❓ À placer"], ...GROUPES_ARENA.map(([k, lb]) => [k, lb])].map(([k, lb]) => ({ k, lb, requis: (eq.requis || {})[k] || 0, agents: agents.filter((a) => a.groupe === k).sort((x, y) => x.nom.localeCompare(y.nom, "fr")) })).filter((g) => g.agents.length || g.requis) };
}
const jourParis = (decal = 0) => new Intl.DateTimeFormat("fr-CA", { timeZone: "Europe/Paris" }).format(new Date(Date.now() + decal * 864e5));
// Rôle, périmètre et main courante d'un agent pour sa vacation en cours
function infosPoste(u, acc) {
  const poste = acc && acc.ok && acc.vacation ? acc.vacation.poste : "";
  const posteSite = acc && acc.ok && acc.vacation ? acc.vacation.poste + (/ARENA/i.test(acc.vacation.site || "") ? " ARENA" : "") : "";
  const perimetre = acc && acc.vacation ? perimetreDe(acc.vacation.poste, acc.vacation.site) : "";
  return { role: acc && acc.ok && perimetre === "pcparc" ? "pc" : u.role, perimetre, profilMC: AGENTS.includes(u.role) ? profilDe(posteSite, u.role) : "", postePlanning: poste || "",
    coordArena: estCoordArena(acc && acc.ok ? acc.vacation : null) ? acc.vacation.date : "" };
}
// Confidentialité : un agent ne voit que ses propres saisies ; seul le PC (PC Parc, et PC Arena pour l'Arena) voit celles des autres
const dansPerimetre = (me, i) => i.auteurId === me.id || (me.perimetre === "arena" && /arena/i.test(i.site || ""));
// Superviseurs (lecture 24h/24) = accès 24h/24 + rédacteurs de documents
async function superviseurs() { return [...(await load("acces24", ACCES24_DEFAUT)), ...(await load("redacteurs", REDAC_DEFAUT))].map((e) => String(e).toLowerCase()); }
async function estRedac(me) { return !!me && (estProprio(me) || (await load("redacteurs", REDAC_DEFAUT)).map((e) => String(e).toLowerCase()).includes(me.id)); }
const COORD_DEFAUT = ["courrier.laurent@free.fr"]; // coordinateur PC sécurité : numéros, adresses mail, planning
const COORD_ADMIN = ["contacts", "destinataires", "acces24", "mail-pc", "test-mail"];
async function estCoord(me) { return !!me && (estProprio(me) || apId(me, "chefsite") || me.role === "admin" || (await estAdminPC(me.id)) || (await load("coordinateurs", COORD_DEFAUT)).map((e) => String(e).toLowerCase()).includes(me.id)); }
const MAX_DOC = 5_600_000;
const normUID = (x) => String(x || "").toUpperCase().replace(/[^0-9A-F]/g, "").slice(0, 32); // « 04:41:82:6a… » ➜ « 0441826A… » // ≈ 4 Mo de PDF une fois encodé

// Vacation de l'agent en ce moment (ou la plus proche aujourd'hui) — pour signer les rapports avec son poste
async function vacationDe(u) {
  if (!u || u.id === "__admin") return null;
  const pl = await load("planning", PLANNING_INITIAL), now = maintenantParis();
  const siens = pl.filter((v) => v.debut && memeAgent(u, v));
  return siens.find((v) => { const [a, b] = fenetre(v); return now >= a && now <= b; })
    || siens.map((v) => [Math.abs(fenetre(v)[0] - now), v]).filter(([d]) => d < 12 * 60).sort((a, b) => a[0] - b[0]).map((x) => x[1])[0] || null;
}
const ERP = (site) => (/arena/i.test(site || "") ? "Arena Sud de France (ERP type L)" : /parc/i.test(site || "") ? "Parc des Expositions (ERP type T)" : site || "");
async function lignesAgent(me) {
  const v = await vacationDe(me);
  return [["Agent", me.nom], ["Téléphone", me.tel || ""],
    ["Poste planifié", v ? [v.poste, v.evenement].filter(Boolean).join(" — ") || "(poste non précisé au planning)" : "Hors planning"],
    ["Vacation", v ? `${new Date(v.date + "T12:00:00").toLocaleDateString("fr-FR", { weekday: "long", day: "numeric", month: "long" })} de ${v.debut} à ${v.fin}${v.site ? " — " + v.site : ""}` : ""]];
}

// Envoi d'un rapport à l'adresse mail du PC sécurité (avec photos en pièces jointes)
const escH = (x) => String(x ?? "").replace(/[&<>]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;" }[c]));
async function mailPC(sujet, lignes, photos = [], pieces = []) { return mailVers(DIFFUSION_SITE().map((d) => d.email).join(","), sujet, lignes, photos, "Liste de diffusion Kaelum e-PCS", pieces); } // plus aucun mail au PC sécurité
// v4.44 · PDF du rapport de ronde (photos des anomalies en premier, 12 maximum)
async function pdfRonde(r) {
  const photos = [], tri = [...(r.passages || [])].sort((a, b) => (a.ras === b.ras ? 0 : a.ras ? 1 : -1));
  for (const x of tri) for (let k = 0; k < (x.photos || 0) && photos.length < 12; k++) { const f = await load(`photo/${r.id}-${x.uid}-${k}`, null); if (f && /^data:image\/jpe?g/.test(f.d)) photos.push({ d: f.d, legende: `Point ${x.ordre || ""} · ${x.nom}`.slice(0, 70), sous: x.ras ? "RAS" : "Anomalie : " + (x.obs || "") }); }
  return rondePDF(r, { photos, fmt: fmtParis });
}
async function mailVers(dest, sujet, lignes, photos = [], nomDest = "PC Sécurité", pieces = []) {
  if (!dest) return;
  const html = `<div style="font-family:Arial,sans-serif;max-width:620px"><h2 style="margin:0 0 8px">${escH(sujet)}</h2>
    <table style="border-collapse:collapse;width:100%">${lignes.filter(([, v]) => v).map(([k, v]) => `<tr><td style="padding:6px;border-bottom:1px solid #ddd;color:#666;width:130px;vertical-align:top">${escH(k)}</td><td style="padding:6px;border-bottom:1px solid #ddd;white-space:pre-wrap">${escH(v)}</td></tr>`).join("")}</table>
    ${photos.length ? `<p style="color:#666">${photos.length} photo(s) en pièce jointe.</p>` : ""}
    <p style="color:#888;font-size:12px">Kaelum e-PCS — Le PC Sécurité Parc des Expositions (T) / Arena Sud de France (L) — 04 67 17 68 68<br>Site exploité par la SPLOE</p></div>`;
  const att = [...pieces, ...photos.map((d, i) => ({ name: `photo-${i + 1}.jpg`, content: String(d).replace(/^data:image\/\w+;base64,/, "") }))];
  await sendMail(dest.split(/[,;\s]+/).filter(Boolean).map((email) => ({ email, nom: nomDest })), sujet, html, att).catch(() => {});
}
async function mailMdp(u, mdp, nouveau, url) {
  await sendMail([{ email: u.id, nom: u.nom }], nouveau ? "Kaelum e-PCS — ton accès à l'application" : "Kaelum e-PCS — ton nouveau mot de passe",
    `<div style="font-family:Arial,sans-serif;max-width:560px"><h2>Kaelum e-PCS</h2>
     <p>Bonjour ${u.nom},</p><p>${nouveau ? "Un compte a été créé pour toi sur l'application Kaelum e-PCS." : "Un nouveau mot de passe a été généré pour ton compte."}</p>
     <p>${(SITE_CFG() || {}).code ? `Code du site : <b style="font-size:18px;letter-spacing:2px">${(SITE_CFG() || {}).code}</b><br>` : ""}Identifiant : <b>${u.id}</b><br>Mot de passe : <b style="font-size:20px;letter-spacing:1px">${mdp}</b></p>
     <p><a href="${url}" style="display:inline-block;background:#d7102e;color:#fff;padding:10px 18px;border-radius:8px;text-decoration:none">Ouvrir Kaelum e-PCS</a></p>
     <p style="color:#666;font-size:13px">Change ce mot de passe dans « Plus ➜ Changer mon mot de passe » après ta première connexion. Ne le partage avec personne.</p>
     <p style="color:#888;font-size:12px">Kaelum e-PCS — Application créée par Rochdi Mecheti</p></div>`);
}

// Plannings Comète intégrés à la mise à jour : appliqués une seule fois (le mois entier du site est remplacé, la planification interne est conservée)
const IMPORTS_PLANNING = [
  { id: "parc-2026-10-v2210", site: "Parc des Expositions", mois: "2026-10", lignes: PLANNING_PARC_2026_10 },
  { id: "arena-2026-10-v2210", site: "Arena Sud de France", mois: "2026-10", lignes: PLANNING_ARENA_2026_10 },
  { id: "parc-2026-11-v2810", site: "Parc des Expositions", mois: "2026-11", lignes: PLANNING_PARC_2026_11 },
  { id: "arena-2026-11-v2810", site: "Arena Sud de France", mois: "2026-11", lignes: PLANNING_ARENA_2026_11 },
];
// Client (exploitant) : tout ce qui se passe sur le site, sans aucun nom d'agent ni information sur la société de sécurité
const CHAMPS_AGENT = ["auteur", "auteurId", "role", "intervenants", "poste", "par", "parId", "majPar", "creePar", "agent", "rapportePar", "remisPar", "qui", "tel", "piece", "telAgent"];
const anonyme = (o) => { if (Array.isArray(o)) return o.map(anonyme); if (!o || typeof o !== "object") return o; const r = {};
  for (const [k, v] of Object.entries(o)) if (!CHAMPS_AGENT.includes(k)) r[k] = v && typeof v === "object" ? anonyme(v) : v; return r; };
const cleOrga = (c) => /organisateur/i.test(c?.boite || ""); // le client ne voit que les boîtes à clés organisateurs (jamais la boîte du PC)
let importsFaits = false, clientDemoFait = false;
// Mises à jour de données (une seule fois chacune)
async function majDonnees() {
  const faites = await load("maj_donnees", []);
  { const D = await load("deploiements", []); if (!D[0] || D[0].version !== VERSION_SERVEUR) { D.unshift({ version: VERSION_SERVEUR, t: new Date().toISOString() }); await save("deploiements", D.slice(0, 30)); } } // v5.09 · historique des mises en ligne
  if (!faites.includes("hernandez-tel-2026-10")) { // nouveau numéro de Laurent Hernandez
    const TEL = "0757548362", c = await load("contacts", null);
    if (c) { const h = c.find((x) => x.id === "hernandez" || /hernandez/i.test(x.nom || "")); if (h) { h.tel = TEL; h.fonction = "Chef de poste Parc des Expositions / Arena"; } await save("contacts", c); }
    const us = await load("users", []), u = us.find((x) => x.id === "courrier.laurent@free.fr" || /hernandez/i.test(x.nom || "")); if (u) { u.tel = TEL; await save("users", us); }
    const an = await load("sms_annuaire", ANNUAIRE_INITIAL), a = an.find((x) => /hernandez/i.test(x.nom || "") && /laurent/i.test(x.nom || ""));
    if (a) a.tel = TEL; else an.push({ nom: "Laurent HERNANDEZ", tel: TEL }); await save("sms_annuaire", an);
    faites.push("hernandez-tel-2026-10"); await journal("admin", "Kaelum e-PCS", "numéro de Laurent Hernandez mis à jour", "info");
  }
  if (!faites.includes("baes-arena-a1-2026-10")) { // v5.36 · BAES d'Arena et du hall A1 dans la ronde incendie : AC01→AC59 (clarté) et A001→A045 (sur les issues de secours)
    const R = { items: [], rondes: [], ...(await load("moyens_secours", {})) }, now = new Date().toISOString(); let n = 0;
    const emp = (hall, pre, numero) => { if (hall !== "Arena Sud de France") return pre === "AC" ? "Clarites " + numero : "Issue de secours " + numero;
      if (pre === "AC") return `Clarites ${numero} · portes vitrées face parking Nord, côtés Est et Ouest (moitié du bâtiment)`;
      return numero === "A045" ? "Issue de secours A045 · PCS (départ de ronde)" : numero === "A007" ? "Issue de secours A007 · côté aéroport" : `Issue de secours ${numero}${+numero.slice(1) >= 7 ? " · tour du bâtiment, du PCS vers le côté aéroport" : ""}`; };
    const SERIES = [["AC", 59, 2, "BAES Clarites (éclairage d'ambiance)"], ["A", 45, 3, "BAES sur issue de secours"]];
    for (const hall of ["Arena Sud de France", "A1"]) for (const [pre, max, w, detail] of SERIES) for (let k = 1; k <= max; k++) {
      const numero = pre + String(k).padStart(w, "0"); if (R.items.some((x) => x.hall === hall && x.type === "BAES" && x.numero === numero)) continue;
      R.items.push({ id: uid(), hall, type: "BAES", numero, emplacement: emp(hall, pre, numero), detail, etat: "ok", cree: now, creePar: "Kaelum e-PCS", historique: [{ t: now, par: "Kaelum e-PCS", etat: "ok", note: "", quoi: "ajouté" }] }); n++; }
    await save("moyens_secours", R); faites.push("baes-arena-a1-2026-10"); await journal("moyens de secours", "Kaelum e-PCS", `${n} BAES ajoutés à la ronde incendie (Arena Sud de France et A1 : AC01→AC59, A001→A045)`, "info", "#/moyens");
  }
  if (!faites.includes("baes-emplacements-2026-10")) { // v5.37 · emplacements réels des BAES d'Arena (sans écraser une modification faite à la main)
    const R = { items: [], rondes: [], ...(await load("moyens_secours", {})) }; let n = 0;
    for (const it of R.items) { if (it.hall !== "Arena Sud de France" || it.type !== "BAES" || !["M Manager", "Kaelum e-PCS"].includes(it.creePar)) continue; const m = /^(AC|A)(\d+)$/.exec(it.numero || ""); if (!m) continue;
      const vieux = m[1] === "AC" ? ["Clarites " + it.numero, "Clarté " + it.numero] : ["Issue de secours " + it.numero]; if (!vieux.includes(it.emplacement)) continue;
      it.emplacement = m[1] === "AC" ? `Clarites ${it.numero} · portes vitrées face parking Nord, côtés Est et Ouest (moitié du bâtiment)`
        : it.numero === "A045" ? "Issue de secours A045 · PCS (départ de ronde)" : it.numero === "A007" ? "Issue de secours A007 · côté aéroport" : `Issue de secours ${it.numero}${+m[2] >= 7 ? " · tour du bâtiment, du PCS vers le côté aéroport" : ""}`; n++; }
    if (n) await save("moyens_secours", R); faites.push("baes-emplacements-2026-10");
  }
  if (!faites.includes("baes-clarites-2026-10")) { // v5.38 · écriture « Clarites » (et non « clarté ») pour les BAES ajoutés par Kaelum e-PCS
    const R = { items: [], rondes: [], ...(await load("moyens_secours", {})) }; let n = 0;
    for (const it of R.items) { if (it.type !== "BAES" || !["M Manager", "Kaelum e-PCS"].includes(it.creePar)) continue; const e = String(it.emplacement || "").replace(/Clart[ée]/g, "Clarites"), d = String(it.detail || "").replace(/BAES clart[ée]/g, "BAES Clarites"); if (e !== it.emplacement || d !== it.detail) { it.emplacement = e; it.detail = d; n++; } }
    if (n) await save("moyens_secours", R); faites.push("baes-clarites-2026-10");
  }
  if (!faites.includes("radio-supprimee-2026-10")) { // v5.39 · la radio (messages vocaux) est supprimée : on efface aussi les messages déjà enregistrés
    try { const l = await load("radio_msgs", []), S = await storeNomme("radio"); for (const x of l) await S.del(x.id).catch(() => {}); await save("radio_msgs", []); await save("radio_dernier_push", {}); } catch {}
    faites.push("radio-supprimee-2026-10");
  }
  if (!faites.includes("pointeau-depart-ronde-2026-10")) { // v4.36 · pointeau N°1 « PCS Parc Expo – début de ronde » scanné par Rochdi (0411E11A301291), pour toutes les rondes
    const NV = "0411E11A301291", estDepart = (x) => x.uid === "0441826AA30F91" || /PCS\s*Parc\s*Expo.*D[ée]but\s*de\s*ronde/i.test(x.nom || "");
    const pcs = await load("parcours", null); if (pcs) { pcs.forEach((p) => p.points.forEach((x) => { if (estDepart(x)) x.uid = NV; })); await save("parcours", pcs); }
    const rn = await load("rondes_nfc", []); let ch = false; for (const r of rn) if (r.statut === "en cours") r.points.forEach((x) => { if (estDepart(x)) { x.uid = NV; ch = true; } }); if (ch) await save("rondes_nfc", rn);
    faites.push("pointeau-depart-ronde-2026-10");
  }
  if (!faites.includes("pointeau-arena-02-2026-10")) { // v4.38 · Ronde Arena N°02 « Cage d'escaliers n°4 – côté cour » scanné par Rochdi (040DD61A301291)
    const NV = "040DD61A301291", est = (x) => x.uid === "04FC9E72A30F90" || /N°\s*0?2\s*Cage\s*d.escaliers\s*n°\s*4/i.test(x.nom || "");
    const pcs = await load("parcours", null); if (pcs) { pcs.forEach((p) => p.points.forEach((x) => { if (est(x)) x.uid = NV; })); await save("parcours", pcs); }
    const rn = await load("rondes_nfc", []); let ch = false; for (const r of rn) if (r.statut === "en cours") r.points.forEach((x) => { if (est(x)) { x.uid = NV; ch = true; } }); if (ch) await save("rondes_nfc", rn);
    faites.push("pointeau-arena-02-2026-10");
  }
  if (!faites.includes("ronde-test-parc-2026-10")) { // v4.50 · ronde test Parc : 6 pointeaux scannés par Rochdi
    const RT = {"nom": "Ronde test Parc (6 points)", "site": "Parc des Expositions", "dureeMax": 0, "points": [{"uid": "0421BE02F80F91", "nom": "01 - PCS Parc Expo - Début de ronde test", "consigne": ""}, {"uid": "04F2EF6AA30F90", "nom": "02 - Hall A1 - Porte principale", "consigne": ""}, {"uid": "0436886AA30F91", "nom": "03 - Mail central", "consigne": ""}, {"uid": "04CE4002F80F90", "nom": "04 - Hall B2 - Issue de secours côté parking", "consigne": ""}, {"uid": "0453C602F80F91", "nom": "05 - Portail P3 (avenue des Levades)", "consigne": ""}, {"uid": "0459D56AA30F90", "nom": "06 - Accueil B - Fin de ronde test", "consigne": ""}]};
    const pcs = await load("parcours", null); if (pcs && !pcs.some((p) => p.nom === RT.nom)) { pcs.push({ id: "p" + uid(), ...RT }); await save("parcours", pcs); }
    faites.push("ronde-test-parc-2026-10");
  }
  if (!faites.includes("ronde-test-n1-2026-10")) { // v4.54 · ronde test : le pointeau 04:21:BE:02:F8:0F:91 est le n° 1 (échange avec le n° 2)
    const A = "0421BE02F80F91", B = "0453C602F80F91", ech = (pts) => { let ch = false; for (const x of pts || []) { if (x.uid === A) { x.uid = B; ch = true; } else if (x.uid === B) { x.uid = A; ch = true; } } return ch; };
    const pcs = await load("parcours", null), pc = pcs && pcs.find((p) => /ronde test parc/i.test(p.nom || ""));
    if (pc && pc.points[0] && pc.points[0].uid === B) { ech(pc.points); await save("parcours", pcs);
      const rn = await load("rondes_nfc", []); let ch = false; for (const r of rn) if (r.statut === "en cours" && r.parcoursId === pc.id) ch = ech(r.points) || ch; if (ch) await save("rondes_nfc", rn); }
    faites.push("ronde-test-n1-2026-10");
  }
  if (!faites.includes("ronde-test-ordre-2026-10")) { // v4.55 · ronde test Parc : ordre réel des 6 pastilles donné par Rochdi
    const ORD = ["0421BE02F80F91", "04F2EF6AA30F90", "0436886AA30F91", "04CE4002F80F90", "0453C602F80F91", "0459D56AA30F90"];
    const pcs = await load("parcours", null), pc = pcs && pcs.find((p) => /ronde test parc/i.test(p.nom || ""));
    if (pc) { pc.points.forEach((x, i) => { if (ORD[i]) x.uid = ORD[i]; }); await save("parcours", pcs);
      const rn = await load("rondes_nfc", []); let ch = false; for (const r of rn) if (r.statut === "en cours" && r.parcoursId === pc.id) { r.points = pc.points; ch = true; } if (ch) await save("rondes_nfc", rn); }
    faites.push("ronde-test-ordre-2026-10");
  }
  if (!faites.includes("supprime-brand-2026-10")) { // v4.58 · Alexandre Brand supprimé de l'application
    const nq = (x) => String(x || "").trim().toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, ""), bl = (x) => COMPTES_BLOQUES.includes(nq(x.id || x.email || x)) || NOMS_BLOQUES.includes(nq(x.nom));
    const us = await load("users", null), ids = (us || []).filter(bl).map((u) => u.id); if (us) await save("users", us.filter((u) => !bl(u))); // compte supprimé de l'application
    const fi = await load("fiches", null); if (fi && ids.length) { ids.forEach((i) => delete fi[i]); await save("fiches", fi); }
    for (const k of ["planificateurs", "admins_pc"]) { const l = await load(k, null); if (Array.isArray(l)) await save(k, l.filter((e) => !COMPTES_BLOQUES.includes(nq(e)))); }
    for (const k of ["contacts", "destinataires"]) { const l = await load(k, null); if (Array.isArray(l)) await save(k, l.filter((x) => !bl(x) && x.id !== "brand")); }
    const lic = await load("licences_planif", null); if (Array.isArray(lic)) await save("licences_planif", lic.filter((x) => !COMPTES_BLOQUES.includes(nq(x.id))));
    faites.push("supprime-brand-2026-10");
  }
  if (!faites.includes("supprime-bourg-2026-10")) { // v5.41 · Jérémy Bourg banni : compte supprimé, retiré de toutes les listes
    const nq = (x) => String(x || "").trim().toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, ""), bl = (x) => COMPTES_BLOQUES.includes(nq(x.id || x.email || x)) || NOMS_BLOQUES.includes(nq(x.nom));
    const us = await load("users", null), ids = (us || []).filter(bl).map((u) => u.id); if (us) await save("users", us.filter((u) => !bl(u)));
    const fi = await load("fiches", null); if (fi && ids.length) { ids.forEach((i) => delete fi[i]); await save("fiches", fi); }
    for (const k of ["planificateurs", "admins_pc", "planif_valideurs_pc", "redacteurs", "redac_planif"]) { const l = await load(k, null); if (Array.isArray(l)) await save(k, l.filter((e) => !COMPTES_BLOQUES.includes(nq(e)))); }
    for (const k of ["contacts", "destinataires", "equipe_pcs"]) { const l = await load(k, null); if (Array.isArray(l)) await save(k, l.filter((x) => !bl(x) && x.id !== "bourg")); }
    const lic = await load("licences_planif", null); if (Array.isArray(lic)) await save("licences_planif", lic.filter((x) => !COMPTES_BLOQUES.includes(nq(x.id))));
    await journal("compte", "Kaelum e-PCS", "Jérémy Bourg banni : compte supprimé et accès coupés", "info");
    faites.push("supprime-bourg-2026-10");
  }
  if (!faites.includes("reset-ludivine-2026-10")) { // v5.05 · demande du propriétaire : Ludivine choisit un nouveau mot de passe à sa prochaine connexion
    const us = await load("users", []), L = us.filter((u) => /ludivine/i.test(u.nom || "") && u.actif !== false && !u.bloque);
    if (L.length === 1) { L[0].resetOuvert = new Date(Date.now() + 72 * 3600e3).toISOString(); await save("users", us); await journal("compte", "Kaelum e-PCS", `mot de passe de ${L[0].nom} réinitialisé (nouveau mot de passe à la prochaine connexion)`, "info"); }
    else await journal("compte", "Kaelum e-PCS", `réinitialisation Ludivine : ${L.length} compte(s) trouvé(s), rien fait (à faire dans Administration)`, "attention");
    faites.push("reset-ludivine-2026-10");
  }
  if (!faites.includes("compte-jeremy-mercher-2026-10")) { // v5.68 · demande du propriétaire : compte pour Jérémy Mercher (SSIAP 3, planification), mot de passe choisi par mail via « Mot de passe oublié »
    const us = await load("users", []), mail = "jerre34@hotmail.fr", memeNom = us.filter((u) => /j[ée]r[ée]my\s+mercher/i.test(u.nom || ""));
    if (us.some((u) => u.id === mail)) await journal("compte", "Kaelum e-PCS", `compte ${mail} déjà existant (Jérémy Mercher), rien créé`, "info");
    else if (memeNom.length) await journal("compte", "Kaelum e-PCS", `Jérémy Mercher a déjà un compte (${memeNom.map((u) => u.id).join(", ")}) : rien créé, à vérifier dans Administration`, "attention");
    else { us.push({ id: mail, nom: "Jérémy MERCHER", role: "ssiap3", tel: "", actif: true, pin: hashPin("123456789"), cree: new Date().toISOString() }); await save("users", us);
      await journal("compte", "Kaelum e-PCS", `compte créé pour Jérémy Mercher (${mail}) : mot de passe provisoire donné par le propriétaire, modifiable avec « Mot de passe oublié » (code reçu par mail)`, "info"); }
    faites.push("compte-jeremy-mercher-2026-10");
  }
  if (!faites.includes("mdp-jeremy-mercher-2026-10")) { // v5.69 · demande du propriétaire : mot de passe de départ de Jérémy Mercher (si le compte existe déjà avec l'adresse jerre34@hotmail.fr)
    const us = await load("users", []), u = us.find((x) => x.id === "jerre34@hotmail.fr");
    if (u) { u.pin = hashPin("123456789"); await save("users", us); await journal("compte", "Kaelum e-PCS", `mot de passe provisoire défini pour ${u.nom}`, "info"); }
    faites.push("mdp-jeremy-mercher-2026-10");
  }
  if (!faites.includes("compte-yazid-cyberologue-2026-10")) { // v5.73 · demande du propriétaire : compte pour Yazid (cyberologue@gmail.com), mot de passe provisoire donné ; l'adresse y.mecheti@gmail.com était une erreur
    const us = await load("users", []), mail = "cyberologue@gmail.com", faux = us.find((u) => u.id === "y.mecheti@gmail.com"), u0 = us.find((u) => u.id === mail);
    if (faux) { faux.actif = false; faux.bloque = true; }
    if (u0) { u0.pin = hashPin("123456789"); u0.actif = true; delete u0.bloque; }
    else us.push({ id: mail, nom: "Yazid MECHETI", role: "ssiap2", tel: "", actif: true, pin: hashPin("123456789"), cree: new Date().toISOString() });
    await save("users", us);
    await journal("compte", "Kaelum e-PCS", `compte Yazid : ${mail} prêt (mot de passe provisoire donné par le propriétaire)${faux ? " ; ancien compte y.mecheti@gmail.com (adresse erronée) désactivé" : ""}`, "info");
    faites.push("compte-yazid-cyberologue-2026-10");
  }
  if (!faites.includes("fim26-exploitation-v1")) { // v4.86 · brief Foire : consignes d'exploitation en tête, consignes de montage gardées à la suite
    const fus = (b) => { b.alertes = [...FIM26_EXPLOIT.alertes, ...(b.alertes || []).filter((a) => !FIM26_EXPLOIT.alertes.includes(a))];
      const anc = (b.consignes || []).filter((c) => !/\(exploitation\)|1er jour/.test(c.poste)).map((c) => ({ ...c, poste: /montage|frigo|SSIAP|volants/i.test(c.poste) ? c.poste : c.poste + " (montage)" }));
      b.consignes = [...FIM26_EXPLOIT.consignes, ...anc]; return b; };
    const L = await load("briefs", null);
    if (L) { const b = L.find((x) => x.id === "fim26"); if (b) { fus(b); await save("briefs", L); } }
    faites.push("fim26-exploitation-v1");
  }
  if (!faites.includes("fahd-ssiap2-2026-10")) { // v4.73 · Fahd Hadouche : retour en accès SSIAP 2 (n'est plus limité aux SMS / planning)
    const ss = await load("sms_seuls", null); if (Array.isArray(ss)) await save("sms_seuls", ss.filter((e) => String(e).toLowerCase() !== "fhadouche@mhscfoot.com"));
    const us = await load("users", null), f = us && us.find((u) => String(u.id).toLowerCase() === "fhadouche@mhscfoot.com" || /hadd?ouche/i.test(u.nom || ""));
    if (f) { f.role = "ssiap2"; f.actif = true; await save("users", us); }
    faites.push("fahd-ssiap2-2026-10");
  }
  if (!faites.includes("ronde-test-23-2026-10")) { // v4.59 · ronde test : pointeaux n° 2 et n° 3 inversés
    const pcs = await load("parcours", null), pc = pcs && pcs.find((p) => /ronde test parc/i.test(p.nom || ""));
    if (pc && pc.points[1] && pc.points[2]) { const u = pc.points[1].uid; pc.points[1].uid = pc.points[2].uid; pc.points[2].uid = u; await save("parcours", pcs);
      const rn = await load("rondes_nfc", []); let ch = false; for (const r of rn) if (r.statut === "en cours" && r.parcoursId === pc.id) { r.points = pc.points; ch = true; } if (ch) await save("rondes_nfc", rn); }
    faites.push("ronde-test-23-2026-10");
  }
  if (!faites.includes("psi-n-securite-2026-10")) { // « PSI » ➜ « N Sécurité » (clés)
    for (const k of ["cles", "cles_liste"]) { const v = await load(k, null); if (v) { const j = JSON.stringify(v); if (/PSI/.test(j)) await save(k, JSON.parse(j.replace(/Bureau PSI/g, "Bureau N Sécurité").replace(/\bPSI\b/g, "N Sécurité"))); } }
    faites.push("psi-n-securite-2026-10");
  }
  if (!faites.includes("levades-2026-10")) { // « avenue de l'Élevade » ➜ « avenue des Levades »
    const fix = (x) => String(x).replace(/l'avenue de l'Élevade/g, "l'avenue des Levades").replace(/avenue de l'Élevade/g, "avenue des Levades");
    const z = await load("zones", null); if (z) await save("zones", JSON.parse(fix(JSON.stringify(z))));
    const sp = await load("site_postes", null); if (sp) await save("site_postes", JSON.parse(fix(JSON.stringify(sp))));
    faites.push("levades-2026-10");
  }
  if (!faites.includes("habil-niveau-2026-10")) { // accès par niveau : ADS et SSIAP 1 sans clés, matériel, bâtiments, documents du PC
    const h = await load("habilitations", null);
    if (h) { for (const r of ["ads", "ssiap1"]) { h[r] = h[r] || {}; for (const k of ["cles", "materiel", "batiments", "docs"]) h[r][k] = false; } await save("habilitations", h); }
    faites.push("habil-niveau-2026-10");
  }
  if (!faites.includes("saoudi-tel-2026-10")) { // v5.50 · M'hamed Saoudi avait le numéro de Machkokot (rapprochement par prénom) : bon numéro partout
    const TEL = "0619993785", TEL_MK = "0664675874", est = (n) => toksNom(n).includes("saoudi"), estMk = (n) => toksNom(n).includes("machkokot"); // Machkokot : numéro d'origine de l'annuaire et du planning
    const an = await load("sms_annuaire", ANNUAIRE_INITIAL), a = an.find((x) => est(x.nom)); if (a) a.tel = TEL; else an.push({ nom: "M'AHMED SAOUDI", tel: TEL });
    for (const x of an) if (estMk(x.nom) && tel9(x.tel) === tel9(TEL)) x.tel = TEL_MK; await save("sms_annuaire", an);
    const pl = await load("planning", PLANNING_INITIAL); let nb = 0; for (const v of pl) { if (est(v.nom) && !v.nonAffecte && v.tel !== TEL) { v.tel = TEL; nb++; } else if (estMk(v.nom) && tel9(v.tel) === tel9(TEL)) { v.tel = TEL_MK; nb++; } } if (nb) await save("planning", pl);
    const us = await load("users", []); let nu = 0; for (const u of us) { if (est(u.nom) && u.tel !== TEL) { u.tel = TEL; nu++; } else if (estMk(u.nom) && tel9(u.tel) === tel9(TEL)) { u.tel = TEL_MK; nu++; } } if (nu) await save("users", us);
    await journal("annuaire", "Kaelum e-PCS", `numéro de M'hamed Saoudi corrigé : ${TEL} (${nb} vacation(s), ${nu} compte(s))`, "info");
    faites.push("saoudi-tel-2026-10");
  }
  if (!faites.includes("testeurs-total-2026-10")) { // v5.62 · accès total réservé à Samantha
    const us = await load("users", []), u = us.find((x) => !x.bloque && x.role !== "client" && memeAgent({ nom: x.nom }, { nom: "Henry Samantha" }));
    if (u) { if (u.testeur && !u.testeurTotal) { u.testeurTotal = true; await save("users", us); } faites.push("testeurs-total-2026-10"); }
  }
  if (!faites.includes("chat-15min-2026-10")) { // v5.66 · discussions : messages effacés au bout de 15 minutes
    const D = 900e3, convs = await load("chat_convs", []);
    for (const c of convs) { c.duree = D; const l = await load("chat_m_" + c.id, []); let ch = false;
      for (const x of l) { const lim = new Date(Date.parse(x.t) + D).toISOString(); if (!x.exp || x.exp > lim) { x.exp = lim; ch = true; } }
      if (ch) await save("chat_m_" + c.id, l); if (c.dernier) { const lim = new Date(Date.parse(c.dernier.t) + D).toISOString(); if (!c.dernier.exp || c.dernier.exp > lim) c.dernier.exp = lim; } }
    await save("chat_convs", convs); await purgerChat(); faites.push("chat-15min-2026-10");
  }
  if (!faites.includes("testeurs-total-tous-2026-10")) { // v5.64 · accès 24/24 pour les 4 testeurs
    const NOMS = ["Touzani Ludivine", "Henry Samantha", "Duguet Johan", "Zgorski Anthony"], us = await load("users", []), nouveaux = [], manque = [];
    for (const n of NOMS) { const u = us.find((x) => !x.bloque && x.role !== "client" && memeAgent({ nom: x.nom }, { nom: n })); if (!u) { manque.push(n); continue; } if (!u.testeur) u.testeur = true; if (!u.testeurTotal) { u.testeurTotal = true; if (n !== "Henry Samantha") nouveaux.push(u.id); } }
    await save("users", us); if (nouveaux.length) { await bienvenueTesteurs(nouveaux, true); await journal("admin", "Kaelum e-PCS", `accès 24/24 testeur activé pour ${nouveaux.length} compte(s)`, "info"); }
    if (!manque.length) faites.push("testeurs-total-tous-2026-10");
  }
  if (!faites.includes("testeurs-2026-10")) { // v5.61 · mode testeur : 4 comptes existants
    const NOMS = ["Touzani Ludivine", "Henry Samantha", "Duguet Johan", "Zgorski Anthony"], us = await load("users", []), ids = [], manque = [], tot = [];
    for (const n of NOMS) { const u = us.find((x) => !x.bloque && x.role !== "client" && memeAgent({ nom: x.nom }, { nom: n })); if (u) { if (!u.testeur) { u.testeur = true; ids.push(u.id); if (n === "Henry Samantha") { u.testeurTotal = true; tot.push(u.id); } } } else manque.push(n); }
    if (ids.length) { await save("users", us); await bienvenueTesteurs(ids.filter((i) => !tot.includes(i))); await bienvenueTesteurs(tot, true); }
    if (ids.length) await journal("admin", "Kaelum e-PCS", `mode testeur activé pour ${ids.length} compte(s)${manque.length ? " ; comptes introuvables pour l'instant : " + manque.join(", ") : ""}`, manque.length ? "attention" : "info");
    if (!manque.length) faites.push("testeurs-2026-10");
  }
  await save("maj_donnees", faites);
}
let majFaite = false;
async function importsPlanning() {
  if (importsFaits) return; importsFaits = true;
  const faits = await load("planning_imports", []);
  const aFaire = IMPORTS_PLANNING.filter((i) => !faits.includes(i.id));
  if (!aFaire.length) return;
  let pl = await load("planning", PLANNING_INITIAL);
  const ann = await load("sms_annuaire", ANNUAIRE_INITIAL);
  const telDe = (nom) => { const a = ann.find((x) => x.nom && memeAgent({ nom }, x)); if (a?.tel) return String(a.tel).replace(/[^\d+]/g, "");
    const v = pl.find((x) => x.tel && x.nom && x.nom.toUpperCase() === nom.toUpperCase()); return v ? v.tel : ""; };
  const now = new Date().toISOString();
  for (const imp of aFaire) {
    // v5.50 · une vacation inchangée (même jour, agent, horaires et poste) garde son identifiant, son rappel SMS et son téléphone
    const cleV = (v) => [v.date, String(v.nom || "").toUpperCase().replace(/\s+/g, " ").trim(), v.debut, v.fin, String(v.poste || "").toUpperCase().trim()].join("|"), anciens = new Map();
    for (const v of pl) if (v.source !== "planif" && (v.site || "") === imp.site && String(v.date || "").startsWith(imp.mois)) { const k = cleV(v); anciens.set(k, [...(anciens.get(k) || []), v]); }
    const lignes = imp.lignes.map((l) => { const ex = (anciens.get(cleV(l)) || []).shift(); return { id: (ex && ex.id) || uid(), date: l.date, nom: l.nom, tel: l.nonAffecte ? "" : (ex && ex.telApproche && ex.tel) || telDe(l.nom) || (ex && ex.tel) || "", ...(l.nonAffecte ? { nonAffecte: true } : {}), telApproche: !!(ex && ex.telApproche), ...(ex && ex.rappel ? { rappel: ex.rappel } : {}), debut: l.debut, fin: l.fin, poste: l.poste, evenement: l.evenement || "",
      site: imp.site, qualif: l.qualif || "", code: l.code || "", source: "import", importePar: "Kaelum e-PCS (mise à jour)", importeLe: now }; });
    pl = pl.filter((v) => v.source === "planif" || !((v.site || "") === imp.site && String(v.date || "").startsWith(imp.mois)));
    pl = [...pl, ...lignes];
    faits.push(imp.id);
    await journal("planning", "Kaelum e-PCS", `planning ${imp.site} ${imp.mois} mis à jour : ${lignes.length} vacation(s)`, "info", "#/planning");
  }
  pl.sort((a, b) => a.date.localeCompare(b.date));
  await save("planning", pl); await save("planning_imports", faits);
  // v5.21 · feuilles de route retouchées à la main : recalées sur le nouveau planning (notes, organisateur, effectif et missions conservés)
  try {
    const FR = await load("feuilles_route", {}), evs = await load("evenements", []), moisImp = aFaire.map((i) => i.mois); let nb = 0;
    for (const d of Object.keys(FR)) { if (!moisImp.some((mo) => d.startsWith(mo)) || d < jourParis()) continue;
      const N = (x) => String(x || "").toUpperCase().replace(/\s+/g, " ").trim(), anc = FR[d].evenements || [];
      const neuf = await construireFeuille(d, pl, evs);
      for (const e of neuf) { const o = anc.find((x) => x.evenement === e.evenement && x.site === e.site); if (o) { e.note = o.note || ""; e.organisateur = e.organisateur || o.organisateur || ""; e.effectif = e.effectif || o.effectif || "";
        for (const a of e.agents) { const oa = (o.agents || []).find((x) => N(x.nom) === N(a.nom) && N(x.poste) === N(a.poste) && x.mission); if (oa && !a.mission) a.mission = oa.mission; } } }
      FR[d] = { ...FR[d], evenements: neuf, t: new Date().toISOString() }; nb++; }
    if (nb) { await save("feuilles_route", FR); await journal("feuille de route", "Kaelum e-PCS", `${nb} feuille(s) de route retouchée(s) recalée(s) sur le nouveau planning`, "info", "#/feuille"); }
  } catch (e) { console.error("recalage feuilles", e); }
}

// Rapprochement intitulé du planning → poste de la carte (P1 INTER → « P1 inter », PORTAIL P3 → « P3 (…) »)
const VIDES_POSTE = new Set(["ADS", "AGENT", "AGENTS", "SSIAP", "DE", "DU", "DES", "LA", "LE", "LES", "L", "D", "ET", "POSTE"]);
const normPoste = (x) => String(x || "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").toUpperCase().replace(/\([^)]*\)/g, " ").replace(/[^A-Z0-9]+/g, " ").trim().split(" ").filter((w) => w && !VIDES_POSTE.has(w)).join(" ");
function posteCarteDe(v, postes) {
  const n = " " + normPoste(v.poste) + " "; let best = null, lg = 0;
  for (const p of postes) {
    if (p.site && v.site && /arena/i.test(p.site) !== /arena/i.test(v.site)) continue;
    for (const lab of [p.nom, ...(p.intitules || [])]) { const k = normPoste(lab); if (k && n.includes(" " + k + " ") && k.length > lg) { best = p; lg = k.length; } }
  }
  return best;
}
// Présences d'un jour : planning comparé aux prises / fins de service (utilisé par Présences et par la carte des postes)
async function presencesDu(d) {
      const veille = new Date(Date.parse(d) - 864e5).toISOString().slice(0, 10), lend = new Date(Date.parse(d) + 864e5).toISOString().slice(0, 10);
      const pl = (await load("planning", PLANNING_INITIAL)).filter((v) => v.date === d && v.debut && v.fin && v.nom);
      const users = await load("users", []), mc = (await mcEntre(veille, lend)).filter((i) => /^(Prise|Fin) de service$/.test(i.categorie));
      const minDe = (i) => { const h = i.heure || new Intl.DateTimeFormat("sv-SE", { timeZone: "Europe/Paris", year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit" }).format(new Date(i.t)).replace(" ", "T"); return minutesLocales(h.slice(0, 10), h.slice(11, 16)); };
      const now = maintenantParis(), fmtM = (x) => { const dd = new Date(x * 60000); return `${String(dd.getUTCHours()).padStart(2, "0")}:${String(dd.getUTCMinutes()).padStart(2, "0")}`; };
      const lignes = pl.map((v) => {
        const deb = minutesLocales(v.date, v.debut); let fin = minutesLocales(v.date, v.fin); if (fin <= deb) fin += 1440;
        const siens = mc.filter((i) => { const u = users.find((x) => x.id === i.auteurId); return memeAgent({ nom: i.auteur, tel: u ? u.tel : "" }, v); });
        const p = siens.filter((i) => i.categorie === "Prise de service").map(minDe).filter((x) => x >= deb - 120 && x <= fin).sort((a, b) => a - b)[0];
        const f = siens.filter((i) => i.categorie === "Fin de service").map(minDe).filter((x) => x >= deb && x <= fin + 240).sort((a, b) => b - a)[0];
        let statut = "à venir";
        if (f != null || (p != null && now > fin + 60)) statut = "terminé"; else if (p != null) statut = p > deb + 10 ? "présent (retard)" : "présent";
        else if (now > deb + 30) statut = now > fin ? "non pointé" : "absent"; else if (now >= deb - 15) statut = "attendu";
        return { nom: v.nom, poste: v.poste || "", site: v.site || "", evenement: v.evenement || "", debut: v.debut, fin: v.fin, tel: v.tel || "", qualif: v.qualif || "",
          arrivee: p != null ? fmtM(p) : "", depart: f != null ? fmtM(f) : "", retard: p != null && p > deb ? p - deb : 0, statut };
      }).sort((a, b) => a.debut.localeCompare(b.debut) || a.nom.localeCompare(b.nom, "fr"));
  return lignes;
}

const traiter = async (req) => {
  const url = new URL(req.url);
  const parts = url.pathname.replace(/^\/api\/?/, "").split("/").filter(Boolean);
  const [r0, r1, r2, r3] = parts;
  const m = req.method;
  const body = m === "GET" ? {} : await req.json().catch(() => ({}));

  try {
    if (SITE_COURANT() === SITE_ORIGINE) await importsPlanning().catch((e) => { importsFaits = false; console.error("imports planning", e); });
    if (!majFaite && SITE_COURANT() === SITE_ORIGINE) { majFaite = true; await majDonnees().catch((e) => { majFaite = false; console.error("maj données", e); }); }
    if (ACCES_RESTREINT && ["inscription", "dispo-public", "signal"].includes(r0)) return json({ error: "Accès fermé : application réservée.", ferme: true }, 403);
    /* ---------- Connexion ---------- */
    if (r0 === "login" && m === "POST") {
      // v4.72 · connexion par badge NFC (cartes existantes du PCS) : le numéro de série est haché, jamais stocké en clair
      let viaBadge = null;
      if (body.badge) { const ip = (req.headers.get("x-nf-client-connection-ip") || req.headers.get("x-forwarded-for") || "?").split(",")[0], kb = "badge:" + ip, lks = await load("locks", {}), lb = lks[kb];
        if (lb && lb.n >= 5 && Date.now() - lb.t < 15 * 60e3) return json({ error: "Trop d'essais, réessaie dans 15 min" }, 429);
        let B = (await load("badges", {}))[hashBadge(body.badge)];
        if (!B) { const hi = empreinteInit(body.badge), init = BADGES_INITIAUX.find((x) => x.h === hi), faits = await load("badges_init_faits", []);
          if (init && !faits.includes(hi)) { const us = await load("users", []), u0 = us.find((u) => !u.bloque && memeAgent({ nom: u.nom }, { nom: init.nom }));
            if (u0) { const bb = await load("badges", {}); bb[hashBadge(body.badge)] = B = { id: u0.id, nom: u0.nom, t: new Date().toISOString(), par: "badge préparé" }; await save("badges", bb); faits.push(hi); await save("badges_init_faits", faits);
              await journal("badges", "Kaelum e-PCS", `badge NFC préparé activé pour ${u0.nom}`, "attention"); } } }
        if (!B) { lks[kb] = { n: (lb && Date.now() - lb.t < 15 * 60e3 ? lb.n : 0) + 1, t: lb && Date.now() - lb.t < 15 * 60e3 ? lb.t : Date.now() }; await save("locks", lks);
          await journal("connexion", "Badge NFC", "badge inconnu présenté à la connexion", "attention"); return json({ error: "Badge non reconnu : demande à Rochdi de l'associer à ton compte" }, 401); }
        if (lb) { delete lks[kb]; await save("locks", lks); }
        viaBadge = B; body.email = B.id; }
      const id = String(body.email || body.id || "").trim().toLowerCase();
      if (COMPTES_BLOQUES.includes(id)) return json({ error: "Accès non autorisé" }, 403);
      const mdp = String(body.mdp ?? body.pin ?? "").trim();
      const locks = await load("locks", {});
      const lk = locks[id];
      if (lk && lk.n >= 5 && Date.now() - lk.t < 10 * 60e3) return json({ error: "Trop d'essais, réessaie dans 10 min" }, 429);

      let user = null;
      const adminPass = String(process.env.ADMIN_PASSWORD || process.env.ADMIN_PIN || "").trim();
      const adminIds = ["admin", (process.env.ADMIN_EMAIL || "mr.mecheti@gmail.com").toLowerCase()];
      let u = (await load("users", [])).find((x) => x.id === id && x.actif !== false);
      if (!u && SITE_COURANT() !== SITE_ORIGINE && !viaBadge) { // v5.85 · l'équipe Kaelum (4 personnes) entre dans tous les sites avec son compte habituel, en administrateur
        const g = (await siteRun(SITE_ORIGINE, () => load("users", []))).find((x) => x.id === id && x.actif !== false && !x.bloque && accesEquipe(x));
        if (g) u = { ...g, role: "admin", equipe: true };
      }
      if (viaBadge) { if (u && !u.bloque) user = u; else if (estProprio({ id })) user = { id: "__admin", nom: "Rochdi Mecheti", role: "admin" }; if (!user) return json({ error: "Compte du badge introuvable ou désactivé" }, 403);
        if (!["diamant", "or", "allaccess"].includes(await badgeDe(user))) return json({ error: "Connexion NFC réservée aux badges Or et All accès : utilise ton mot de passe" }, 403); }
      else if (u && checkPin(mdp, u.pin)) user = u;
      else if (!u && adminIds.includes(id) && adminPass && mdp === adminPass) user = { id: "__admin", nom: "Rochdi Mecheti", role: "admin" };
      if (!user && !u && adminIds.includes(id) && !adminPass)
        return json({ error: "Le serveur ne trouve pas ADMIN_PASSWORD : vérifie la variable dans Netlify puis relance un déploiement" }, 401);
      if (!user && u && !viaBadge && u.resetOuvert && Date.parse(u.resetOuvert) > Date.now()) // v5.05 · mot de passe réinitialisé par le propriétaire : l'agent en choisit un nouveau
        return json({ resetRequis: true, telRequis: String(u.tel || "").replace(/\D/g, "").length >= 4, nom: String(u.nom || "").split(/\s+/).slice(-1)[0] });
      if (!user) {
        locks[id] = { n: (lk && Date.now() - lk.t < 10 * 60e3 ? lk.n : 0) + 1, t: Date.now() };
        await save("locks", locks);
        return json({ error: "E-mail ou mot de passe incorrect" }, 401);
      }
      if (!accesOuvert(user)) { await journal("connexion", user.nom || id, "connexion refusée : accès réservé aux 4 personnes autorisées", "attention").catch(() => {}); return json({ error: "Accès fermé : application réservée.", ferme: true }, 403); }
      if (lk) { delete locks[id]; await save("locks", locks); }
      if (AGENTS.includes(user.role) && (await superviseurs()).includes(user.id)) {
        const us = await load("users", []), uu = us.find((x) => x.id === user.id);
        if (uu) { uu.role = "responsable"; await save("users", us); user = uu; }
      }
      const acc = (await estAdminPC(user.id)) ? { ok: true } : await accesPlanning(user); // un administrateur se connecte à toute heure
      if (viaBadge) { const bb = await load("badges", {}), hb = hashBadge(body.badge); if (bb[hb]) { bb[hb].dernier = new Date().toISOString(); await save("badges", bb); } }
      await journal("connexion", user.nom + (viaBadge ? " (badge NFC)" : ""), !acc.ok ? "hors vacation : planning et disponibilités seulement" : user.role + (acc.vacation ? ` · vacation ${acc.vacation.debut}-${acc.vacation.fin} ${acc.vacation.site || ""}` : ""));
      const fiches = await load("fiches", {});
      return json({ token: signToken(user, 24 * 30), pushToken: pushJeton(user.id), message: acc.ok ? undefined : acc.message,
        user: { id: user.id, nom: user.nom, ...infosPoste(user, acc), planif: await peutPlanif(user), niveauPlanif: await niveauPlanif(user), voitPlanif: await voirPlanif(user), planifAcces: await planningComplet(user), habil: await habilDe(infosPoste(user, acc).role), ...((await estAdminPC(user.id)) || estProprio(user) ? { role: "admin" } : {}), hors: !acc.ok, proprio: estProprio(user), redac: await estRedac(user), coord: await estCoord(user), ficheOk: isStaff(user) || user.role === "client" || !!fiches[user.id] }, site: infosSite() });
    }

    /* ---------- Inscription d'un agent : impossible sans le code d'accès donné par le PC ---------- */
    if (r0 === "inscription" && m === "POST") {
      const t = (v, n = 80) => String(v ?? "").trim().slice(0, n);
      const email = t(body.email, 120).toLowerCase();
      if (email.endsWith(AP_DOM)) return json({ error: "Adresse e-mail invalide" }, 400);
      const locks = await load("locks", {}), k = "inscr:" + (req.headers.get("x-nf-client-connection-ip") || req.headers.get("x-forwarded-for") || "?").split(",")[0];
      const lk = locks[k];
      if (lk && lk.n >= 5 && Date.now() - lk.t < 15 * 60e3) return json({ error: "Trop d'essais, réessaie dans 15 min" }, 429);
      const h = await load("code_agents", null), hResp = await load("code_resp", null), mode = await load("inscription_mode", "libre");
      const codeSaisi = String(body.code || "").trim();
      const acces24 = await superviseurs();
      const estResp = acces24.includes(email) || (!!hResp && !!codeSaisi && checkPin(codeSaisi, hResp));
      if (!estResp && mode === "ferme") return json({ error: "Les inscriptions sont fermées pour le moment : contacte le PC sécurité" }, 403);
      // Inscriptions libres : un code faux ou rempli automatiquement par le téléphone est simplement ignoré
      if (!estResp && mode === "code" && h && !checkPin(codeSaisi, h)) {
        locks[k] = { n: (lk && Date.now() - lk.t < 15 * 60e3 ? lk.n : 0) + 1, t: Date.now() }; await save("locks", locks);
        await journal("inscription", t(body.prenom) + " " + t(body.nom), `code d'accès faux (${email})`, "attention", "#/admin");
        return json({ error: "Code d'accès incorrect : demande-le au PC sécurité" }, 403);
      }
      const nom = t(body.nom).toUpperCase(), prenom = t(body.prenom), tel = t(body.tel, 20), mdp = String(body.mdp || "");
      if (!nom || !prenom) return json({ error: "Nom et prénom obligatoires" }, 400);
      if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) return json({ error: "Adresse e-mail invalide" }, 400);
      if (tel.replace(/\D/g, "").length < 9) return json({ error: "Numéro de téléphone invalide" }, 400);
      if (mdp.length < 6) return json({ error: "Mot de passe : 6 caractères minimum" }, 400);
      const users = await load("users", []);
      if (email === PROPRIO()) return json({ error: "Cette adresse est réservée" }, 403);
      if (users.some((u) => u.id === email)) return json({ error: "Un compte existe déjà avec cet e-mail : utilise « Mot de passe oublié » si besoin" }, 409);
      const role = estResp ? "responsable" : ["ads", "ssiap1", "ssiap2", "ssiap3"].includes(body.role) ? body.role : "ads";
      const u = { id: email, nom: `${prenom} ${nom}`, role, tel, actif: true, pin: hashPin(mdp), cree: new Date().toISOString(), inscrit: true };
      users.push(u); await save("users", users);
      if (lk) { delete locks[k]; await save("locks", locks); }
      await journal("inscription", u.nom, `nouveau compte ${estResp ? "RESPONSABLE" : "agent"} (${role}, ${email})`, estResp ? "attention" : "info", "#/admin");
      const acc = (await estAdminPC(u.id)) ? { ok: true } : await accesPlanning(u);
      return json({ token: signToken(u, 24 * 30), message: acc.ok ? undefined : "Compte créé ✅ " + acc.message,
        user: { id: u.id, nom: u.nom, ...infosPoste(u, acc), planif: await peutPlanif(u), niveauPlanif: await niveauPlanif(u), voitPlanif: await voirPlanif(u), planifAcces: await planningComplet(u), ...((await estAdminPC(u.id)) || estProprio(u) ? { role: "admin" } : {}), hors: !acc.ok, redac: await estRedac(u), coord: await estCoord(u), ficheOk: estResp } }, 201);
    }

    /* ---------- Mot de passe oublié : code à 6 chiffres envoyé par mail ---------- */
    if (r0 === "reset-ouvert" && m === "POST") { // v5.05 · nouveau mot de passe choisi à la connexion, après réinitialisation par le propriétaire (une seule fois, 72 h)
      const id = String(body.email || "").trim().toLowerCase(), us = await load("users", []), u = us.find((x) => x.id === id && x.actif !== false);
      if (!u || !accesOuvert(u)) return json({ error: "Accès fermé : application réservée.", ferme: true }, 403);
      const locks = await load("locks", {}), lk = locks["ro:" + id]; if (lk && lk.n >= 5 && Date.now() - lk.t < 15 * 60e3) return json({ error: "Trop d'essais, réessaie dans 15 min" }, 429);
      const echec = async (msg) => { locks["ro:" + id] = { n: (lk && Date.now() - lk.t < 15 * 60e3 ? lk.n : 0) + 1, t: Date.now() }; await save("locks", locks); return json({ error: msg }, 403); };
      if (!u || !u.resetOuvert || Date.parse(u.resetOuvert) <= Date.now()) return echec("Réinitialisation expirée : demande au PC sécurité");
      const tel = String(u.tel || "").replace(/\D/g, ""); if (tel.length >= 4 && String(body.tel4 || "").replace(/\D/g, "") !== tel.slice(-4)) return echec("Les 4 derniers chiffres du téléphone ne correspondent pas");
      const mdp = String(body.mdp || ""); if (mdp.length < 6) return json({ error: "6 caractères minimum" }, 400);
      u.pin = hashPin(mdp); delete u.resetOuvert; await save("users", us); if (lk) { delete locks["ro:" + id]; await save("locks", locks); }
      await journal("compte", u.nom, "nouveau mot de passe choisi après réinitialisation", "info"); return json({ ok: true });
    }
    if (r0 === "reset" && m === "POST") {
      const id = String(body.email || "").trim().toLowerCase();
      const users = await load("users", []), u = users.find((x) => x.id === id && x.actif !== false);
      if (!u || !accesOuvert(u)) return body.code ? json({ error: "Code expiré, redemande un code" }, 400) : json({ ok: true });
      const resets = await load("resets", {});
      if (!body.code) {
        if (u && !(resets[id] && Date.now() - resets[id].t < 60e3)) {
          const code = String(crypto.randomInt(100000, 1000000));
          resets[id] = { h: hashPin(code), t: Date.now(), n: 0 };
          await save("resets", resets);
          await sendMail([{ email: id, nom: u.nom }], "Kaelum e-PCS — code de réinitialisation",
            `<p>Bonjour ${u.nom},</p><p>Ton code pour choisir un nouveau mot de passe : <b style="font-size:22px;letter-spacing:3px">${code}</b></p><p>Valable 15 minutes. Si tu n'as rien demandé, ignore ce mail.</p>`);
        }
        return json({ ok: true }); // même réponse que le compte existe ou non
      }
      const r = resets[id];
      if (!u || !r || Date.now() - r.t > 15 * 60e3 || r.n >= 5) return json({ error: "Code expiré, redemande un code" }, 400);
      if (!checkPin(body.code, r.h)) { r.n++; await save("resets", resets); return json({ error: "Code incorrect" }, 400); }
      if (String(body.mdp || "").length < 6) return json({ error: "Mot de passe : 6 caractères minimum" }, 400);
      u.pin = hashPin(String(body.mdp)); delete resets[id];
      await save("users", users); await save("resets", resets);
      await journal("compte", u.nom, "mot de passe réinitialisé par mail");
      return json({ ok: true });
    }

    if (r0 === "theme" && m === "GET") { // v5.67 · rotation automatique des couleurs (facultative)
      const BRS = ["kaelum", "emeraude", "violet", "or", "mmanager"], au = await load("theme_auto", { jours: 0 }), fixe = await load("theme_brand", "kaelum");
      if (au.jours > 0) return json({ brand: BRS[Math.floor(Date.now() / 864e5 / au.jours) % BRS.length], auto: au.jours });
      return json({ brand: fixe, auto: 0 }); } // v5.48 · couleur de l'application, choisie par le propriétaire pour tous
    /* ---------- État de la configuration (ne montre jamais les valeurs secrètes) ---------- */
    if (r0 === "etat" && m === "GET") {
      const users = await load("users", []);
      return json({ version: VERSION_SERVEUR, ADMIN_PASSWORD: !!String(process.env.ADMIN_PASSWORD || process.env.ADMIN_PIN || "").trim(),
        ADMIN_EMAIL: process.env.ADMIN_EMAIL ? process.env.ADMIN_EMAIL.replace(/^(.).*(@.*)$/, "$1…$2") : "(défaut)",
        APP_SECRET: !!process.env.APP_SECRET, BREVO_API_KEY: !!process.env.BREVO_API_KEY, MAIL_FROM: !!process.env.MAIL_FROM,
        MF_API_KEY: !!process.env.MF_API_KEY, comptes: users.length });
    }

    /* ---------- Intitulés personnalisés (lisibles sans connexion pour l'écran d'accueil) ---------- */
    if (r0 === "textes" && m === "GET") return json(await load("textes", {}));

    /* ---------- v3.75 · Signalement public par QR code (sans compte, protégé par signature + anti-abus) ---------- */
    if (r0 === "dispo-public") { // v5.49 · formulaire public de disponibilités du mois (lien signé par mois, sans compte) : alimente la grille centralisée
      const dpZ = (mo) => crypto.createHmac("sha256", (process.env.APP_SECRET || "change-moi-dans-netlify") + ":dispo").update(String(mo)).digest("base64url").slice(0, 16);
      const mo = String((m === "GET" ? url.searchParams.get("m") : body.m) || "").slice(0, 7), k = String((m === "GET" ? url.searchParams.get("k") : body.k) || "");
      const valide = /^\d{4}-\d{2}$/.test(mo) && k.length === 16 && k === dpZ(mo), ferme = valide && (await load("dispo_public_ferme", {}))[mo] === true;
      if (m === "GET") return json({ ok: valide, ferme, mois: valide ? mo : "" });
      if (m === "POST") {
        if (!valide) return json({ error: "Lien non reconnu. Redemande le lien au PC ou à ton responsable." }, 400);
        if (ferme) return json({ error: "Le recueil des disponibilités de ce mois est clos. Contacte ton responsable." }, 403);
        const ip = (req.headers.get("x-nf-client-connection-ip") || req.headers.get("x-forwarded-for") || "?").split(",")[0].trim();
        const locks = await load("locks", {}), kk = "dsp:" + ip, lk = locks[kk], now = Date.now();
        if (lk && lk.n >= 15 && now - lk.t < 15 * 60e3) return json({ error: "Trop d'envois depuis ce téléphone : patiente quelques minutes." }, 429);
        const net = (x) => String(x || "").replace(/[^\p{L}\s'’-]/gu, "").replace(/\s+/g, " ").trim().slice(0, 40);
        const nom = net(body.nom), prenom = net(body.prenom);
        if (nom.length < 2 || prenom.length < 2) return json({ error: "Indique ton nom et ton prénom" }, 400);
        const jours = {}, indispo = {}; let nd = 0, ni = 0;
        for (const [d, v] of Object.entries(body.jours && typeof body.jours === "object" ? body.jours : {})) {
          if (!/^\d{4}-\d{2}-\d{2}$/.test(d) || !d.startsWith(mo + "-")) continue;
          if (v === "jour" || v === "nuit") { jours[d] = v; nd++; } else if (v === "jn") { jours[d] = true; nd++; } else if (v === "indispo") { indispo[d] = true; ni++; }
        }
        if (!nd && !ni) return json({ error: "Choisis au moins un jour (disponible ou indisponible)" }, 400);
        const key = "dispo_grille/" + mo, g = await load(key, {}), cle = globalThis.PLANIF.cleAgent, kc = cle(nom + " " + prenom), pren = prenom.charAt(0).toUpperCase() + prenom.slice(1).toLowerCase();
        const x = (g[kc] ||= { nom: nom.toUpperCase() + " " + pren, jours: {} });
        x.jours = jours; x.indispo = indispo; x.note = String(body.note || "").replace(/[<>]/g, "").trim().slice(0, 200); x.maj = new Date().toISOString(); x.par = "formulaire agent";
        await save(key, g); locks[kk] = { n: (lk && now - lk.t < 15 * 60e3 ? lk.n : 0) + 1, t: lk && now - lk.t < 15 * 60e3 ? lk.t : now }; await save("locks", locks);
        await journal("disponibilités", x.nom, `a envoyé ses disponibilités ${mo} par le lien (${nd} jour(s) disponible, ${ni} indisponible)`);
        await envoyerPush({ titre: "Disponibilités reçues", texte: `${x.nom} a envoyé ses disponibilités ${mo} (${nd} dispo, ${ni} indispo)`, url: "/#/dispogrille" }, DEST_DISPOS).catch(() => {});
        return json({ ok: true, nd, ni });
      }
      return json({ error: "Requête invalide" }, 400);
    }
    if (r0 === "signal") {
      const sigZ = (s, l) => crypto.createHmac("sha256", (process.env.APP_SECRET || "change-moi-dans-netlify") + ":signal").update(String(s) + "|" + String(l)).digest("base64url").slice(0, 16);
      const s = String((m === "GET" ? url.searchParams.get("s") : body.s) || "").slice(0, 60), l = String((m === "GET" ? url.searchParams.get("l") : body.l) || "").slice(0, 80), k = String((m === "GET" ? url.searchParams.get("k") : body.k) || "");
      const valide = !!(s && l && k.length === 16 && k === sigZ(s, l));
      const actif = (await load("signal_reglages", { actif: true })).actif !== false;
      const lieuOk = valide && SIGNAL_LIEUX.some(([a, b]) => a === s && b === l), NATS = [...SIGNAL_NATURES_SURETE, ...SIGNAL_NATURES_SECURITE, "Autre anomalie"];
      if (m === "GET" && r1 === "info") return json({ ok: !!lieuOk, actif, site: lieuOk ? s : "", lieu: lieuOk ? l : "", surete: SIGNAL_NATURES_SURETE, securite: SIGNAL_NATURES_SECURITE, max: 3000 });
      if (m === "POST" && !r1) {
        if (!lieuOk) return json({ error: "QR code non reconnu ou remplacé. Prévenez le PC sécurité." }, 400);
        if (!actif) return json({ error: "Le signalement en ligne est momentanément fermé. Adressez-vous à un agent de sécurité." }, 403);
        const ip = (req.headers.get("x-nf-client-connection-ip") || req.headers.get("x-forwarded-for") || "?").split(",")[0].trim();
        const locks = await load("locks", {}), kk = "sig:" + ip, lk = locks[kk], now = Date.now();
        if (lk && lk.n >= 10 && now - lk.t < 15 * 60e3) return json({ error: "Plusieurs signalements viennent d'être transmis : patientez quelques minutes. Urgence vitale : 112." }, 429);
        const h = await load("signal_compteur", { h: "", n: 0 }), heure = new Date().toISOString().slice(0, 13);
        if (h.h === heure && h.n >= 40) return json({ error: "Trop de signalements en ce moment. Adressez-vous à un agent de sécurité." }, 429);
        const nature = NATS.includes(body.nature) ? body.nature : "Autre anomalie", texte = String(body.texte || "").trim().slice(0, 3000), tel = String(body.tel || "").replace(/[^\d+ ]/g, "").slice(0, 20), qui = String(body.qui || "").trim().slice(0, 80);
        const photo = typeof body.photo === "string" && /^data:image\/(jpeg|png|webp);base64,/.test(body.photo) && body.photo.length < MAX_PHOTO ? body.photo : "";
        if (nature === "Autre anomalie" && texte.length < 3 && !photo) return json({ error: "Décrivez l'anomalie en quelques mots ou ajoutez une photo" }, 400);
        const famille = SIGNAL_NATURES_SURETE.includes(nature) ? "Sûreté" : SIGNAL_NATURES_SECURITE.includes(nature) ? "Sécurité" : "Anomalie";
        locks[kk] = { n: (lk && now - lk.t < 15 * 60e3 ? lk.n : 0) + 1, t: lk && now - lk.t < 15 * 60e3 ? lk.t : now }; await save("locks", locks);
        await save("signal_compteur", { h: heure, n: h.h === heure ? h.n + 1 : 1 });
        const urgent = /intrusion|suspect|fumée|gaz|menace|forcé/i.test(nature);
        const inc = await mcSysteme({ id: "public", nom: qui ? `${qui} (QR bâtiment)` : "Personnel SPL (QR bâtiment)", role: "public" }, "Signalement anomalie (QR)", `${famille} · ${nature}${texte ? " — " + texte : ""}`, urgent ? "urgente" : "moyenne",
          { site: s, lieu: l, famille, photos: photo ? 1 : 0, photo: !!photo, suivi: tel ? [{ t: new Date().toISOString(), qui: qui || "Signalement QR", note: "Rappel possible au " + tel }] : [] });
        if (photo) await save(`photo/${inc.id}-0`, { d: photo, auteurId: "public" });
        await envoyerPush({ titre: `ANOMALIE ${famille.toUpperCase()} — ${l}`, texte: `${nature}${texte ? " · " + texte.slice(0, 140) : ""}${photo ? " · 📷" : ""}`, url: "/#/mc", alerte: urgent }, (u) => isStaff(u) || estProprio(u) || u.role === "admin");
        await journal("signalement", qui || "QR bâtiment", `📲 ${famille} · ${nature} · ${l}${texte ? " · " + texte.slice(0, 100) : ""}${photo ? " · photo" : ""}${tel ? " · rappel " + tel : ""}`, urgent ? "urgent" : "attention", "#/mc");
        return json({ ok: true, numero: inc.numero }, 201);
      }
      return json({ error: "Requête invalide" }, 400);
    }

    if (r0 === "push" && r1 === "dernier" && m === "GET" && pushJetonOk((req.headers.get("authorization") || "").replace(/^Bearer /, "")))
      return json((await load("push_dernier", null)) || { titre: "Kaelum e-PCS", texte: "Nouvelle notification", url: "/#/" });
    const me = await currentUser(req);
    if (me && estBloque(me)) return json({ error: "Accès non autorisé" }, 401);
    if (me && !accesOuvert(me)) return json({ error: "Accès fermé : application réservée.", ferme: true }, 401); // v5.84 · déconnecte les comptes non autorisés
    if (me) { me.roleCompte = me.role; if (me.id === "__admin") { me.nom = "Rochdi Mecheti"; me.fonction = me.fonction || "SSIAP 2"; } } // nom et fonction du propriétaire (connexion de secours)
    if (me && (await estAdminPC(me.id))) me.role = "admin"; // le PC sécurité est administrateur
    const chefPl = !!me && (await estChefPlanif(me)); if (chefPl) me.role = "admin"; // Jérémy Mercher (et Fahd Hadouche, v5.14) : tout voir, tout gérer
    if (me && estProprio(me)) me.role = "admin"; // propriétaire : tous les droits
    else if (me && String(me.id).toLowerCase() === MAIL_PC_DEFAUT) me.role = "pc"; // compte du PC Parc : accès à tout (sauf modifier le planning et les devis)
    else if (me && !chefPl && (await estSmsSeul(me.id))) { me.role = "sms"; me.smsSeul = true; if (!me.fonction) me.fonction = "Adjoint responsable planification"; }
    if (me && !me.apercu && ((await load("adjoints_planif", ADJOINTS_PLANIF_DEFAUT)).map((e) => String(e).toLowerCase()).includes(String(me.id).toLowerCase()) || estFahd(me))) { me.adjointPlanif = true; me.fonction = "SSIAP 2 · Adjoint planification"; }
    // v4.11 · remontée automatique des erreurs de l'appli (pour corriger vite) — consultation : propriétaire seulement
    if (r0 === "erreurs") {
      if (!me) return json({ error: "Session expirée, reconnecte-toi" }, 401);
      if (m === "POST") { const t = (v, n) => String(v ?? "").slice(0, n), l = await load("erreurs_app", []);
        const e = { t: new Date().toISOString(), qui: me.nom || me.id, role: me.role, msg: t(body.msg, 300), ou: t(body.ou, 200), page: t(body.page, 60), v: t(body.v, 20), ua: t(req.headers.get("user-agent"), 160) };
        const dbl = l.find((x) => x.msg === e.msg && x.ou === e.ou); if (dbl) { dbl.n = (dbl.n || 1) + 1; dbl.t = e.t; dbl.qui = e.qui; } else l.unshift(e);
        await save("erreurs_app", l.slice(0, 200)); return json({ ok: true }); }
      if (!estProprio(me)) return deny();
      if (m === "DELETE") { await save("erreurs_app", []); return json({ ok: true }); }
      return json(await load("erreurs_app", []));
    }
    // v4.16 · Retrouver l'auteur d'une capture d'écran à partir du code du filigrane (propriétaire)
    if (r0 === "admin" && r1 === "tracage" && m === "GET") {
      if (!me || !estProprio(me) || me.apercu) return deny();
      const fnv = (x) => { let h = 0x811c9dc5; for (const ch of String(x)) { h ^= ch.codePointAt(0); h = Math.imul(h, 0x01000193) >>> 0; } return h.toString(36).toUpperCase().padStart(7, "0").slice(-6); };
      const code = String(url.searchParams.get("code") || "").toUpperCase().replace(/[^A-Z0-9]/g, "").slice(-6);
      const users = await load("users", []), l = [...users.map((u) => ({ id: u.id, nom: u.nom, role: u.role })), ...Object.values(AP_PROFILS).map((p) => ({ id: p.id, nom: p.nom + " (aperçu)", role: p.role }))];
      return json(l.filter((u) => fnv(String(u.id).toLowerCase()) === code));
    }
    // v4.12 · Aperçu des profils : le propriétaire voit l'appli comme chaque profil (jeton de 2 h, lecture seule)
    if (r0 === "admin" && r1 === "apercu") {
      if (!peutApercu(me)) return deny();
      const tenant = SITE_COURANT() !== SITE_ORIGINE, ok = (k) => !tenant || APERCU_SITE.includes(k);
      if (m === "GET") return json(Object.entries(AP_PROFILS).filter(([k]) => ok(k)).map(([k, p]) => ({ k, lb: p.lb, role: p.role })));
      const p0 = AP_PROFILS[body.profil]; if (!p0 || !ok(body.profil)) return json({ error: "Profil inconnu" }, 400);
      let p = p0;
      if (tenant && p0.vac) { const cfg = await load("site_config", {}), po = (cfg.postes || []).find((x) => x.qualif === ({ ssiap3: "SSIAP 3", ssiap1: "SSIAP 1", ads: "ADS" })[body.profil]) || (cfg.postes || [])[0]; p = { ...p0, vac: { poste: po ? po.nom : "Poste", site: (SITE_CFG() || {}).nom || "" } }; }
      await journal("admin", me.nom, `aperçu de l'appli : ${p.lb}`, "info");
      return json({ token: signToken({ id: p.id, nom: p.nom, role: p.role, ap: { k: body.profil, nom: p.nom, role: p.role, vac: p.vac || null } }, 2), profil: body.profil, lb: p.lb });
    }
    if (me && me.apercu && m !== "GET" && !(r0 === "deverrouiller" || (r0 === "planif" && r1 === "deverrouiller") || r0 === "erreurs" || r0 === "impression"))
      return json({ error: "👁 Mode aperçu : lecture seule, rien n'est enregistré" }, 403);
    // Compte SMS seulement : planning général en lecture + envoi des SMS de prise de poste
    if (me && me.role === "sms") {
      const okSms = (r0 === "me" && m === "GET") || r0 === "dispo-grille" || (r0 === "mdp" && m === "POST") || (r0 === "push" && ["cle", "dernier", "abonner", "test"].includes(r1)) || (r0 === "securite" && m === "POST")
        || (r0 === "planning" && (m === "GET" || (m === "PATCH" && r1) || (m === "DELETE" && r1) || (m === "POST" && r1 && (r2 === "affecter" || r1 === "envoyer" || r1 === "ajouter" || r1 === "verifier")))) || (r0 === "sms" && (m === "GET" || m === "PUT" || ((r1 === "journal" || r1 === "numero") && m === "POST"))) || (r0 === "postes" && (m === "GET" || (m === "POST" && r1 === "ajouter"))) || r0 === "feuille-route" || r0 === "impression";
      if (!okSms) return json({ error: "Accès SMS : seuls le planning général et l'envoi des SMS sont autorisés" }, 403);
    }
    // Accès client (SPL OE) : fil de l'eau sans noms d'agents, bilan, alertes et météo ; ni planning, ni clés, ni contacts
    if (me && me.role === "client") {
      const okClient = (m === "GET" && ["me", "fil", "bilan", "meteo", "alertes", "crise", "stats", "incidents", "evenements", "rap", "rapports", "objets", "batiments", "registre", "briefs", "plan", "site-config", "plan-site", "sitepostes", "jauge", "ecran", "photo"].includes(r0) && !(r0 === "cles" && r1 === "agents") && !(r0 === "incidents" && r1 === "mois")) || (r0 === "push" && ["cle", "dernier", "abonner", "test"].includes(r1)) || (r0 === "mdp" && m === "POST") || (r0 === "securite" && m === "POST");
      if (!okClient) return json({ error: "Accès client : cette information n'est pas disponible" }, 403);
    }
    if (!me) return json({ error: "Session expirée, reconnecte-toi" }, 401);
    // v5.61 · Mode testeur « accès total » (Samantha seulement) : accès 24 h / 24, tout consultable ; sauf planification et codes d'accès
    if (me.testeurTotal && !me.apercu && me.role !== "client") {
      if (["planning", "planif", "plangen", "sms", "dispo-grille", "feuille-route", "arena-affect", "postes", "commande", "cadenas"].includes(r0)) return json({ error: "Mode testeur : la planification et les codes d'accès ne sont pas accessibles" }, 403);
      me.horsPlanning = true; if (m === "GET" && !["me", "login"].includes(r0)) me.role = "responsable"; // lecture de tout ; les saisies restent celles d'un agent
    }
    if (me.role === "responsable" && m !== "GET" && !["mdp", "deverrouiller", "notifs", "fiche", "alertes", "dossier", "push", "secours", "cadenas", "securite", "dispo-grille", "pti", "impression", "ascenseurs", "permis-feu", "arena-affect", "avatar", "messagerie", "position", "passation", "rochbot", "compterendu", "quiz", "motdujour", "chat"].includes(r0) && !(r0 === "docs" && (await estRedac(me)))
      && !(((r0 === "admin" && COORD_ADMIN.includes(r1)) || r0 === "planning" || r0 === "sms" || r0 === "risques" || r0 === "dispos" || r0 === "parcours" || r0 === "cles" || r0 === "materiel" || r0 === "batiments" || r0 === "dpae" || r0 === "arena-equipe" || r0 === "plan") && (await estCoord(me)))
      && !((r0 === "planif" && ((await niveauPlanif(me)) || r1 === "deverrouiller")) || (r0 === "planning" && (await accesPlanif(me)))))
      return json({ error: "Accès en lecture seule : tu peux tout consulter, mais pas modifier ni saisir" }, 403);
    if (AGENTS.includes(me.role)) {
      const u = (await load("users", [])).find((x) => x.id === me.id);
      const acc = await accesPlanning(u || me);
      // Hors vacation : seulement son planning, ses disponibilités, sa fiche et son mot de passe
      if (!acc.ok && !["impression", "me", "monplanning", "mesabsences", "monservice", "mapaie", "releve-heures", "dispos", "fiche", "mdp", "dossier", "push", "securite", "messagerie", "chat", "avatar", "retex", "flammes", "specialites", "lettres"].includes(r0) && !(me.adjointPlanif && ["planning", "sms", "postes", "feuille-route", "dispo-grille", "impression"].includes(r0)) && !(r0 === "dpae" && peutDPAE(u || me)) && !((r0 === "planif" || r0 === "planning") && (await accesPlanif(u || me)))) return json({ error: acc.message, hors: true }, 403);
      me.hors = !acc.ok; me.horsMessage = acc.ok ? "" : acc.message;
      const ip = infosPoste(u || me, acc);
      me.perimetre = ip.perimetre; me.profilMC = ip.profilMC; me.postePlanning = ip.postePlanning; me.coordArena = ip.coordArena;
      if (ip.role === "pc") { me.roleAgent = me.role; me.role = "pc"; } // SSIAP 2 du PC Parc : voit et gère tout, comme le PC
      if (AGENTS.includes(me.role) && acc.ok) { // habilitations du poste
        const hab = (await habilitations())[me.role]; me.habil = hab;
        const mod = HAB_MODULES.find(([, , rs]) => rs.includes(r0));
        const priseFin = r0 === "incidents" && m === "POST" && /^(Prise|Fin) de service$/.test(String(body.categorie || ""));
        if (mod && hab[mod[0]] === false && !priseFin && !(r0 === "dispos" && m === "GET") && !(me.adjointPlanif && ["planning", "sms", "postes", "feuille-route", "dispo-grille"].includes(r0))) return json({ error: `Accès non autorisé pour ton poste : ${mod[1]}` }, 403);
        if (r0 === "alertes" && m === "POST" && !r1 && hab.alertes === false) return json({ error: "Accès non autorisé pour ton poste : lancer une alerte" }, 403);
      }
    }

    /* ---------- v5.85 · Sites clients (propriétaire seul) : créer, suspendre, renommer, nouveau mot de passe de l'administrateur ---------- */
    if (r0 === "sites") {
      if (!(me.id === "__admin" || me.id === PROPRIO())) return deny();
      const R = await listeSites(), ISO = new Date().toISOString();
      const enregistrer = () => siteRun(SITE_ORIGINE, () => save("sites", R));
      const mdpProv = () => { const A = "abcdefghjkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789"; return Array.from({ length: 10 }, () => A[crypto.randomInt(A.length)]).join(""); };
      if (m === "GET") return json({ sites: await Promise.all(Object.entries(R).map(async ([code, f]) => ({ code, id: f.id, nom: f.nom, adresse: f.adresse || "", actif: f.actif !== false, demo: !!f.demo, cree: f.cree || "", admins: f.admins || [], agents: f.id === SITE_ORIGINE ? null : (await siteRun(f.id, () => load("users", []))).length }))) });
      if (m === "POST" && !r1) {
        const nom = String(body.nom || "").trim().slice(0, 80), mail = String(body.adminEmail || "").trim().toLowerCase(), an = String(body.adminNom || "").trim().slice(0, 60);
        if (nom.length < 3) return json({ error: "Nom du site : 3 caractères minimum" }, 400);
        if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(mail)) return json({ error: "Adresse e-mail de l'administrateur invalide" }, 400);
        let code; do { code = String(crypto.randomInt(100000, 1000000)); } while (R[code]);
        let id = idSite(nom); while (id === SITE_ORIGINE || Object.values(R).some((f) => f.id === id)) id = idSite(nom).slice(0, 18) + "-" + crypto.randomBytes(2).toString("hex");
        const mdp = mdpProv();
        R[code] = { id, nom, adresse: String(body.adresse || "").trim().slice(0, 120), lat: Number(body.lat) || null, lon: Number(body.lon) || null, admins: [{ email: mail, nom: an || mail }], actif: true, cree: ISO };
        await enregistrer();
        await siteRun(id, async () => {
          await save("users", [{ id: mail, nom: an || mail, role: "admin", diamant: true, fonction: "Administrateur du site", tel: "", actif: true, pin: hashPin(mdp), cree: ISO }]);
          await journal("compte", "Kaelum e-PCS", `site « ${nom} » créé : administrateur ${mail}`, "info");
        }, R[code]);
        await journal("compte", me.nom || "Propriétaire", `site client créé : ${nom} (code ${code}), administrateur ${mail}`, "info");
        return json({ ok: true, code, id, nom, adminEmail: mail, motDePasse: mdp }, 201);
      }
      const f = R[String(r1 || "").replace(/\D/g, "")];
      if (!f) return json({ error: "Site introuvable" }, 404);
      if (f.id === SITE_ORIGINE) return json({ error: "Le site d'origine ne se modifie pas ici" }, 400);
      if (m === "PUT") {
        if (typeof body.actif === "boolean") f.actif = body.actif;
        if (typeof body.nom === "string" && body.nom.trim().length >= 3) f.nom = body.nom.trim().slice(0, 80);
        if (typeof body.adresse === "string") f.adresse = body.adresse.trim().slice(0, 120);
        if (body.lat !== undefined) f.lat = Number(body.lat) || null; if (body.lon !== undefined) f.lon = Number(body.lon) || null;
        await enregistrer(); await journal("compte", me.nom || "Propriétaire", `site ${f.nom} : ${f.actif === false ? "suspendu" : "actif"}`, "info"); return json({ ok: true });
      }
      if (m === "POST" && r2 === "reinit" && f.demo) { // remet le site de démonstration à zéro avec les données fictives
        await siteRun(f.id, async () => { for (const k of await listeCles()) await save(k, null); await seedDemo({ load, save, hashPin, mcSysteme, journal, aujourdhui: jourParis(), uid }); }, f);
        return json({ ok: true });
      }
      if (m === "POST" && r2 === "admin") { // crée (ou remplace) l'administrateur Diamant d'un site existant, avec un mot de passe provisoire
        const mail = String(body.adminEmail || "").trim().toLowerCase(), an = String(body.adminNom || "").trim().slice(0, 60);
        if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(mail)) return json({ error: "Adresse e-mail de l'administrateur invalide" }, 400);
        const mdp = mdpProv();
        await siteRun(f.id, async () => { const us = await load("users", []).then((l) => l.filter((x) => !x.diamant)); us.unshift({ id: mail, nom: an || mail, role: "admin", diamant: true, fonction: "Administrateur du site", tel: "", actif: true, pin: hashPin(mdp), cree: ISO }); await save("users", us); await journal("compte", "Kaelum e-PCS", `administrateur du site : ${mail}`, "info"); }, f);
        f.admins = [{ email: mail, nom: an || mail }]; await enregistrer();
        return json({ ok: true, code: String(r1), adminEmail: mail, motDePasse: mdp });
      }
      if (m === "POST" && r2 === "mdp") { // nouveau mot de passe provisoire pour l'administrateur du site
        const ad = (f.admins || [])[0]; if (!ad) return json({ error: "Aucun administrateur" }, 400);
        const mdp = mdpProv();
        const ok = await siteRun(f.id, async () => { const us = await load("users", []), u = us.find((x) => x.id === ad.email); if (!u) return false; u.pin = hashPin(mdp); u.actif = true; delete u.bloque; await save("users", us); return true; }, f);
        return ok ? json({ ok: true, adminEmail: ad.email, motDePasse: mdp }) : json({ error: "Compte administrateur introuvable" }, 404);
      }
      return json({ error: "Requête invalide" }, 400);
    }
    /* ---------- v5.85 · Paramétrage du site et plan interactif (sites clients) : modifiables par l'administrateur Diamant du site ---------- */
    if (r0 === "site-config") {
      const f = SITE_CFG() || {}, def = { nom: f.nom || "", adresse: f.adresse || "", lat: f.lat || null, lon: f.lon || null, secteurs: [], postes: [] };
      if (m === "GET") return json({ site: infosSite(), cfg: SITE_COURANT() === SITE_ORIGINE ? { ...def, secteurs: ["Parc des Expositions", "Arena Sud de France"] } : { ...def, ...(await load("site_config", {})) } });
      if (m === "PUT") {
        if (!estProprio(me) || SITE_COURANT() === SITE_ORIGINE) return refusProprio();
        const txt = (x, n) => String(x ?? "").trim().slice(0, n), QUA = ["ADS", "SSIAP 1", "SSIAP 2", "SSIAP 3", "CDP (chef de poste)", "Responsable"];
        const hh = (x) => (/^([01]\d|2[0-3]):[0-5]\d$/.test(String(x)) ? String(x) : "");
        const cfg = { nom: txt(body.nom, 80) || def.nom, adresse: txt(body.adresse, 120), lat: Number(body.lat) || null, lon: Number(body.lon) || null,
          secteurs: (Array.isArray(body.secteurs) ? body.secteurs : []).map((x) => txt(x, 60)).filter(Boolean).slice(0, 12),
          postes: (Array.isArray(body.postes) ? body.postes : []).slice(0, 80).map((x) => ({ nom: txt(x.nom, 60), qualif: QUA.includes(x.qualif) ? x.qualif : "", debut: hh(x.debut), fin: hh(x.fin), mission: txt(x.mission, 240) })).filter((x) => x.nom) };
        await save("site_config", cfg);
        const R = await listeSites(), e = Object.entries(R).find(([, v]) => v.id === SITE_COURANT());
        if (e) { R[e[0]] = { ...e[1], nom: cfg.nom, adresse: cfg.adresse, lat: cfg.lat, lon: cfg.lon }; await siteRun(SITE_ORIGINE, () => save("sites", R)); }
        await journal("admin", me.nom, "paramétrage du site modifié", "info"); return json({ ok: true });
      }
      return json({ error: "Requête invalide" }, 400);
    }
    if (r0 === "plan-site") {
      if (SITE_COURANT() === SITE_ORIGINE) return json({ origine: true, image: "", zones: [], points: [] });
      if (m === "GET") return json(await load("plan_site", { image: "", w: 0, h: 0, zones: [], points: [] }));
      if (m === "PUT") {
        if (!estProprio(me)) return refusProprio();
        const txt = (x, n) => String(x ?? "").trim().slice(0, n), num = (x) => Math.round(Number(x) * 10) / 10 || 0;
        const img = String(body.image || "");
        if (img && (!/^data:image\/(jpeg|png|webp|svg\+xml)[;,]/.test(img) || img.length > 4.5e6)) return json({ error: "Image invalide ou trop lourde (4 Mo maximum)" }, 400);
        const info = (o) => Object.fromEntries(["niveau", "surface", "eff", "acces", "risques", "moyens", "note"].map((k) => [k, txt(o && o[k], 240)]));
        const zones = (Array.isArray(body.zones) ? body.zones : []).slice(0, 200).map((z, i) => ({ id: txt(z.id, 20) || "z" + i, nom: txt(z.nom, 60) || "Zone " + (i + 1), couleur: /^#[0-9a-f]{6}$/i.test(z.couleur) ? z.couleur : "#2f78d8", ...info(z),
          ...(Array.isArray(z.pts) ? { pts: z.pts.slice(0, 400).map((p) => [num(p[0]), num(p[1])]) } : {}),
          ...(z.masque && typeof z.masque === "object" ? { masque: { gw: Math.min(1000, +z.masque.gw || 0), gh: Math.min(1000, +z.masque.gh || 0), rle: txt(z.masque.rle, 60000) } } : {}) }));
        const points = (Array.isArray(body.points) ? body.points : []).slice(0, 300).map((q, i) => ({ id: txt(q.id, 20) || "p" + i, nom: txt(q.nom, 60) || "Point " + (i + 1), type: ["poste", "acces", "pompiers", "secours", "nfc", "autre"].includes(q.type) ? q.type : "autre", x: num(q.x), y: num(q.y), note: txt(q.note, 240) }));
        const plan = { image: img, w: Math.min(6000, +body.w || 0), h: Math.min(6000, +body.h || 0), zones, points, maj: new Date().toISOString() };
        await save("plan_site", plan); await journal("admin", me.nom, `plan du site mis à jour (${zones.length} zone(s), ${points.length} point(s))`, "info"); return json({ ok: true });
      }
      return json({ error: "Requête invalide" }, 400);
    }
    if (r0 === "me") { const ls = await load("licences_planif", []), li = ls.find((x) => x.id === String(me.id).toLowerCase());
      if (li && (!li.derniere || Date.now() - Date.parse(li.derniere) > 3600e3)) { li.derniere = new Date().toISOString(); await save("licences_planif", ls); } }
    if (r0 === "me" && me.apercu) { const ap = AP_PROFILS[me.apercu] || {}; return json({ ...me, licence: null, planif: await peutPlanif(me), niveauPlanif: await niveauPlanif(me), voitPlanif: await voirPlanif(me), planifAcces: await planningComplet(me), proprio: false, redac: await estRedac(me), coord: await estCoord(me), ficheOk: true, dlPlanning: false, feuilleRoute: peutFeuilleRoute(me), annuaireSpl: peutAnnuaireSPL(me), habil: me.habil || (AGENTS.includes(me.role) ? (await habilitations())[me.role] : undefined), apercu: me.apercu, apercuLb: ap.lb || "" }); }
    // v4.16 · fonction affichée : Rochdi = SSIAP 3 quand il est planifié en SSIAP 3 (sinon inchangé) ; Jérémy Mercher = chef de site, responsable planification
    if (r0 === "me" && estProprio(me)) { const nom = process.env.OWNER_NOM || "Rochdi Mecheti", now = maintenantParis();
      const v = (await load("planning", PLANNING_INITIAL)).find((x) => x.debut && memeAgent({ nom }, x) && (([a, b]) => now >= a && now <= b)(fenetre(x)));
      if (v && globalThis.PLANIF.qualifPaie(v) === "SSIAP 3") { me.fonction = "SSIAP 3"; me.postePlanning = v.poste || ""; } }
    if (r0 === "me" && !me.fonction && (await estChefPlanif(me))) me.fonction = "SSIAP 3 · Chef de site · Resp. planification";
    if (r0 === "me") return json({ site: infosSite(), ...me, specialites: await peutSpecialites(me), badge: await badgeDe(me), pushToken: me.apercu ? undefined : pushJeton(me.id), apercuOK: peutApercu(me), dlPlanning: await peutDLPlanning(me), feuilleRoute: peutFeuilleRoute(me), annuaireSpl: peutAnnuaireSPL(me), licence: await licencePlanif(me), planif: await peutPlanif(me), niveauPlanif: await niveauPlanif(me), voitPlanif: await voirPlanif(me), planifAcces: await planningComplet(me), proprio: estProprio(me), redac: await estRedac(me), coord: await estCoord(me), ficheOk: isStaff(me) || me.role === "client" || me.role === "sms" || !!(await load("fiches", {}))[me.id] });

    /* ---------- v4.12 · PTI / DATI ---------- */
    if (r0 === "pti") {
      const L = await load("pti", {}), sup = isStaff(me) || estProprio(me) || (await estCoord(me)), gpsDe = (g) => g && Number.isFinite(+g.lat) && Number.isFinite(+g.lon) ? { lat: +(+g.lat).toFixed(5), lon: +(+g.lon).toFixed(5), acc: Number.isFinite(+g.acc) ? Math.round(+g.acc) : null, t: new Date().toISOString() } : null;
      if (me.role === "client" || me.role === "sms") return deny();
      const moi = L[me.id];
      const alarmesEnCours = () => Object.values(L).filter((x) => x.actif && x.alarme && !x.alarme.ack && x.userId !== me.id).map((x) => ({ userId: x.userId, nom: x.nom, poste: x.poste || "", site: x.site || "", motif: x.alarme.motif, t: x.alarme.t, gps: x.alarme.gps || x.gps || null, reponses: x.alarme.reponses || [], precisions: x.alarme.precisions || [] }));
      if (m === "GET") return json({ moi: moi || null, alarmes: alarmesEnCours(), sessions: sup ? Object.values(L).sort((a, b) => (!!b.alarme && !b.alarme.ack) - (!!a.alarme && !a.alarme.ack) || b.actif - a.actif || String(b.debut).localeCompare(a.debut)) : [], superviseur: sup, grace: PTI_GRACE });
      if (m === "POST" && r1 === "start") {
        const iv = [10, 15, 20, 30, 45, 60].includes(+body.intervalle) ? +body.intervalle : 30;
        L[me.id] = { userId: me.id, nom: me.nom, role: me.role, poste: me.postePlanning || String(body.poste || "").slice(0, 80) || posteDe(me), site: String(body.site || "").slice(0, 60), intervalle: iv, actif: true,
          debut: new Date().toISOString(), dernierOk: new Date().toISOString(), prochain: new Date(Date.now() + iv * 60e3).toISOString(), gps: gpsDe(body.gps), alarme: null, rappel: null, chute: !!body.chute };
        await save("pti", L); await journal("PTI", me.nom, `protection travailleur isolé activée (contrôle toutes les ${iv} min)${L[me.id].poste ? " · " + L[me.id].poste : ""}`, "info", "#/pti");
        return json(L[me.id]);
      }
      if (!moi && ["ok", "stop", "sos"].includes(r1)) { if (r1 !== "sos") return json({ error: "Protection non activée" }, 400); }
      if (m === "POST" && r1 === "ok") { Object.assign(moi, { dernierOk: new Date().toISOString(), prochain: new Date(Date.now() + moi.intervalle * 60e3).toISOString(), rappel: null, gps: gpsDe(body.gps) || moi.gps });
        if (moi.alarme && !moi.alarme.ack) { moi.alarme.ack = { par: me.nom + " (l'agent)", t: new Date().toISOString() }; await journal("PTI", me.nom, "l'agent a confirmé que tout va bien après l'alarme", "attention", "#/pti"); }
        await save("pti", L); return json(moi); }
      if (m === "POST" && r1 === "stop") { Object.assign(moi, { actif: false, fin: new Date().toISOString() }); await save("pti", L); await journal("PTI", me.nom, "protection travailleur isolé arrêtée", "info", "#/pti"); return json(moi); }
      if (m === "POST" && r1 === "sos") {
        const s = moi || (L[me.id] = { userId: me.id, nom: me.nom, role: me.role, poste: posteDe(me), site: "", intervalle: 30, actif: true, debut: new Date().toISOString(), dernierOk: new Date().toISOString(), prochain: new Date(Date.now() + 30 * 60e3).toISOString(), gps: null, alarme: null });
        if (!s.actif) Object.assign(s, { actif: true, debut: new Date().toISOString(), fin: null, prochain: new Date(Date.now() + (s.intervalle || 30) * 60e3).toISOString() }); // v4.88 · un SOS réactive la protection
        s.gps = gpsDe(body.gps) || s.gps; await ptiAlarme(s, body.motif === "chute" ? "chute" : "sos", s.gps); await save("pti", L); return json(s);
      }
      if (m === "POST" && r1 === "precision") { // v4.88 · l'agent en alarme précise sa situation
        if (!moi || !moi.alarme) return json({ error: "Aucune alarme en cours" }, 400);
        const tx = String(body.texte || "").trim().slice(0, 600); if (!tx) return json({ error: "Écris la précision" }, 400);
        moi.alarme.precisions ||= []; moi.alarme.precisions.push({ id: me.id, nom: me.nom, poste: posteDe(me), texte: tx, t: new Date().toISOString() }); moi.alarme.precisions = moi.alarme.precisions.slice(-30);
        await save("pti", L); await journal("PTI", me.nom, `ℹ️ précision de l'agent en alarme : ${tx.slice(0, 160)}`, "urgent", "#/pti");
        await envoyerPush({ titre: `🆘 ${me.nom} précise`, texte: tx.slice(0, 160), url: "/#/pti", alerte: true }, enService).catch(() => 0);
        return json(moi);
      }
      if (m === "POST" && r1 && r2 === "reponse") { // v4.88 · un collègue répond à l'alarme PTI
        const s2 = L[decodeURIComponent(r1)]; if (!s2 || !s2.alarme || s2.alarme.ack || !s2.actif) return json({ error: "Alarme terminée" }, 404);
        if (s2.userId === me.id) return deny();
        const r = ajouterReponse(s2.alarme, me, body.type); if (!r) return json({ error: "Réponse inconnue" }, 400);
        await save("pti", L);
        if (r.type === "arrive") await flammes(me, 20, `Réactivité : « J'arrive » sur l'alarme PTI de ${s2.nom}`, { cle: "ptirep-" + s2.userId + s2.alarme.t, stat: "arrive" }).catch(() => 0);
        await journal("PTI", me.nom, `↪ ${me.nom}${r.poste ? " (" + r.poste + ")" : ""} → ${s2.nom} : ${REPONSES[r.type]}`, "urgent", "#/pti");
        await envoyerPush({ titre: `${me.nom}${r.poste ? " · " + r.poste : ""}`, texte: `${REPONSES[r.type]} (alarme PTI de ${s2.nom})`, url: "/#/pti", alerte: true }, (u) => u.id === s2.userId || isStaff(u) || estProprio(u)).catch(() => 0);
        return json({ ok: true, reponses: s2.alarme.reponses });
      }
      if (m === "POST" && r1 && r2 === "ack") { if (!sup) return deny(); const s = L[decodeURIComponent(r1)]; if (!s || !s.alarme) return json({ error: "Aucune alarme" }, 404);
        s.alarme.ack = { par: me.nom, t: new Date().toISOString(), note: String(body.note || "").slice(0, 300) }; s.prochain = new Date(Date.now() + s.intervalle * 60e3).toISOString(); s.rappel = null;
        await save("pti", L); await journal("PTI", me.nom, `alarme PTI de ${s.nom} prise en compte${s.alarme.ack.note ? " : " + s.alarme.ack.note : ""}`, "attention", "#/pti"); return json(s); }
      if (m === "POST" && r1 && r2 === "clore") { if (!sup) return deny(); const s = L[decodeURIComponent(r1)]; if (!s) return json({ error: "Introuvable" }, 404);
        Object.assign(s, { actif: false, fin: new Date().toISOString() }); if (s.alarme && !s.alarme.ack) s.alarme.ack = { par: me.nom, t: new Date().toISOString() };
        await save("pti", L); await journal("PTI", me.nom, `protection de ${s.nom} arrêtée par le PC`, "info", "#/pti"); return json(s); }
      return json({ error: "Requête invalide" }, 400);
    }

    /* ---------- v4.12 · Gestion de la société (propriétaire) : clients, contrats, factures, stocks / EPI, marge, échéances ---------- */
    if (r0 === "gestion") {
      if (!estProprio(me)) return json({ error: "Gestion de la société : réservée au propriétaire" }, 403);
      const t = (v, n = 200) => String(v ?? "").trim().slice(0, n), nb = (v) => { const x = parseFloat(String(v ?? "").replace(",", ".")); return Number.isFinite(x) ? Math.round(x * 100) / 100 : 0; };
      const dte = (v) => (/^\d{4}-\d{2}-\d{2}$/.test(v || "") ? v : ""), auj = jourParis();
      const G = { societe: {}, clients: [], contrats: [], factures: [], articles: [], mouvements: [], couts: {}, ...(await load("gestion", {})) };
      const totFact = (f) => { const ht = Math.round(f.lignes.reduce((s, l) => s + nb(l.qte) * nb(l.pu), 0) * 100) / 100, tx = G.societe.franchise ? 0 : nb(f.tva ?? 20), tva = Math.round(ht * tx) / 100; return { ht, tvaMontant: tva, ttc: Math.round((ht + tva) * 100) / 100, tauxTva: tx }; };
      const COLL = {
        clients: (b, o) => ({ nom: t(b.nom, 120), contact: t(b.contact, 120), email: t(b.email, 120), tel: t(b.tel, 20), adresse: t(b.adresse, 300), siret: t(b.siret, 20), tvaIntra: t(b.tvaIntra, 20), delai: Math.max(0, Math.min(90, parseInt(b.delai) || 30)), notes: t(b.notes, 1000) }),
        contrats: (b) => ({ agent: t(b.agent, 80), type: ["CDI", "CDD", "CDD d'usage", "Extra / vacation", "Intérim", "Sous-traitance"].includes(b.type) ? b.type : "CDI", qualif: t(b.qualif, 40), coef: t(b.coef, 10), debut: dte(b.debut), fin: dte(b.fin), heures: nb(b.heures), taux: nb(b.taux), motif: t(b.motif, 160), essaiFin: dte(b.essaiFin), notes: t(b.notes, 600) }),
        articles: (b) => ({ nom: t(b.nom, 80), cat: ["EPI", "Tenue", "Radio / matériel", "Consommable"].includes(b.cat) ? b.cat : "EPI", taille: t(b.taille, 20), seuil: Math.max(0, parseInt(b.seuil) || 0), pu: nb(b.pu), renouv: Math.max(0, parseInt(b.renouv) || 0) }),
        factures: (b, o) => { if (o && o.statut !== "brouillon") return { statut: ["émise", "payée", "annulée"].includes(b.statut) ? b.statut : o.statut, paiement: dte(b.paiement) || o.paiement || "", relance: dte(b.relance) || o.relance || "" }; // facture émise : seuls le statut et le paiement changent
          const cl = G.clients.find((c) => c.id === b.client);
          return { client: cl ? cl.id : "", clientNom: cl ? cl.nom : t(b.clientNom, 120), date: dte(b.date) || auj, echeance: dte(b.echeance), objet: t(b.objet, 300), devis: t(b.devis, 30), tva: b.tva === "" ? 20 : nb(b.tva ?? 20),
            lignes: (Array.isArray(b.lignes) ? b.lignes : []).slice(0, 80).map((l) => ({ lib: t(l.lib, 200), qte: nb(l.qte), pu: nb(l.pu), unite: t(l.unite, 12) })).filter((l) => l.lib), statut: b.statut === "émise" ? "émise" : "brouillon", notes: t(b.notes, 600) }; },
      };
      if (m === "PUT" && r1 === "societe") { const b = body; G.societe = { raison: t(b.raison, 120), forme: t(b.forme, 40), siret: t(b.siret, 20), tvaIntra: t(b.tvaIntra, 20), cnaps: t(b.cnaps, 40), adresse: t(b.adresse, 300), tel: t(b.tel, 20), email: t(b.email, 120), iban: t(b.iban, 40), bic: t(b.bic, 15), franchise: !!b.franchise, conditions: t(b.conditions, 300), logo: "" }; await save("gestion", G); return json(G.societe); }
      if (m === "PUT" && r1 === "couts") { G.couts = Object.fromEntries(["ADS", "SSIAP 1", "SSIAP 2", "SSIAP 3", "Chef d'équipe", "Cynophile"].map((q) => [q, body[q] === "" || body[q] == null ? "" : nb(body[q])])); await save("gestion", G); return json(G.couts); }
      if (m === "POST" && r1 === "mouvement") { const a = G.articles.find((x) => x.id === body.article); if (!a) return json({ error: "Article introuvable" }, 404);
        const type = ["entrée", "dotation", "retour", "perte"].includes(body.type) ? body.type : "entrée", q = Math.max(1, parseInt(body.qte) || 1);
        if ((type === "dotation" || type === "perte") && (a.stock || 0) < q) return json({ error: `Stock insuffisant (${a.stock || 0} en stock)` }, 400);
        if (type === "dotation" && !t(body.agent)) return json({ error: "Indique l'agent" }, 400);
        a.stock = (a.stock || 0) + (type === "entrée" || type === "retour" ? q : -q);
        G.mouvements.unshift({ id: uid(), t: new Date().toISOString(), date: dte(body.date) || auj, article: a.id, nom: a.nom + (a.taille ? " (" + a.taille + ")" : ""), type, qte: q, agent: t(body.agent, 80), par: me.nom });
        G.mouvements = G.mouvements.slice(0, 3000); await save("gestion", G); return json({ article: a }); }
      if (COLL[r1] && (m === "POST" || m === "PUT")) {
        const list = G[r1], o = r2 ? list.find((x) => x.id === r2) : null; if (r2 && !o) return json({ error: "Introuvable" }, 404);
        const v = COLL[r1](body, o); if (r1 === "clients" && !v.nom) return json({ error: "Nom du client obligatoire" }, 400); if (r1 === "contrats" && !v.agent) return json({ error: "Nom de l'agent obligatoire" }, 400); if (r1 === "articles" && !v.nom) return json({ error: "Nom de l'article obligatoire" }, 400);
        if (r1 === "factures" && (!o || o.statut === "brouillon")) { if (!v.clientNom) return json({ error: "Choisis le client" }, 400); if (v.statut === "émise" && !v.lignes.length) return json({ error: "Ajoute au moins une ligne" }, 400);
          if (!v.echeance) { const cl = G.clients.find((c) => c.id === v.client); v.echeance = new Date(Date.parse(v.date) + (cl ? cl.delai : 30) * 864e5).toISOString().slice(0, 10); } }
        const x = o ? Object.assign(o, v, { maj: new Date().toISOString() }) : { id: uid(), cree: new Date().toISOString(), ...(r1 === "articles" ? { stock: Math.max(0, parseInt(body.stock) || 0) } : {}), ...v };
        if (r1 === "factures") { if (x.statut !== "brouillon" && !x.numero) { const an = x.date.slice(0, 4); G.cptFact = G.cptFact || {}; G.cptFact[an] = (G.cptFact[an] || 0) + 1; x.numero = `FA-${an}-${String(G.cptFact[an]).padStart(4, "0")}`; x.emise = new Date().toISOString(); } Object.assign(x, totFact(x)); }
        if (!o) list.unshift(x); await save("gestion", G);
        if (r1 === "factures" && x.numero && (!o || !o.numero)) await journal("gestion", me.nom, `facture ${x.numero} émise · ${x.clientNom} · ${x.ttc.toFixed(2)} € TTC`, "info");
        return json(x, o ? 200 : 201);
      }
      if (COLL[r1] && m === "DELETE" && r2) { const list = G[r1], o = list.find((x) => x.id === r2); if (!o) return json({ error: "Introuvable" }, 404);
        if (r1 === "factures" && o.statut !== "brouillon") return json({ error: "Une facture émise ne se supprime pas (numérotation continue obligatoire) : passe-la en « annulée » et fais un avoir" }, 400);
        G[r1] = list.filter((x) => x !== o); await save("gestion", G); return json({ ok: true }); }
      if (m !== "GET") return json({ error: "Requête invalide" }, 400);
      // synthèse : échéances, marge, devis disponibles
      const P = globalThis.PLANIF, pl = (await load("planning", PLANNING_INITIAL)).filter((v) => v.debut && v.fin && v.nom && !/^NON AFFECT/i.test(v.nom));
      const marge = []; for (let k = 11; k >= 0; k--) { const d = new Date(); d.setUTCDate(1); d.setUTCMonth(d.getUTCMonth() - k); const mm = d.toISOString().slice(0, 7);
        const fs = G.factures.filter((f) => ["émise", "payée"].includes(f.statut) && String(f.date).startsWith(mm)), ca = Math.round(fs.reduce((s, f) => s + (f.ht || 0), 0) * 100) / 100;
        const parQ = {}; pl.filter((v) => v.date.startsWith(mm)).forEach((v) => { const q = P.qualifPaie(v); parQ[q] = (parQ[q] || 0) + P.vacation(v).heures; });
        const heures = Object.values(parQ).reduce((s, h) => s + h, 0), manquants = Object.keys(parQ).filter((q) => G.couts[q] === "" || G.couts[q] == null);
        const cout = Math.round(Object.entries(parQ).reduce((s, [q, h]) => s + h * (nb(G.couts[q]) || 0), 0) * 100) / 100;
        marge.push({ mois: mm, ca, heures: Math.round(heures * 10) / 10, cout, marge: Math.round((ca - cout) * 100) / 100, taux: ca ? Math.round(((ca - cout) / ca) * 1000) / 10 : null, manquants, parQ: Object.fromEntries(Object.entries(parQ).map(([q, h]) => [q, Math.round(h * 10) / 10])) }); }
      const ech = [], jours = (d) => Math.round((Date.parse(d) - Date.parse(auj)) / 864e5);
      for (const a of await lectureDossiers().catch(() => [])) { const manq = (a.etat || []).filter((e) => e.statut === "manquant");
        if (manq.length) ech.push({ type: "Dossier incomplet", qui: a.nom, quoi: `${manq.length} document(s) manquant(s) : ${manq.map((e) => e.lb).join(", ")}`.slice(0, 220), date: "", jours: null, niveau: "manquant", action: "Compléter le dossier de l'agent" });
        for (const e of a.etat || []) if (e.statut !== "manquant" && (e.statut !== "ok" || (e.echeance && jours(e.echeance) <= 60))) ech.push({ type: "Dossier agent", qui: a.nom, quoi: e.lb, date: e.echeance || "", jours: e.echeance ? jours(e.echeance) : null, niveau: e.statut === "ok" ? "bientot" : e.statut, action: e.action || "" }); }
      for (const c of G.contrats) { if (c.fin && jours(c.fin) <= 30 && jours(c.fin) >= -7) ech.push({ type: "Contrat", qui: c.agent, quoi: `Fin de ${c.type}`, date: c.fin, jours: jours(c.fin), niveau: jours(c.fin) < 0 ? "expire" : "bientot" });
        if (c.essaiFin && jours(c.essaiFin) <= 15 && jours(c.essaiFin) >= 0) ech.push({ type: "Contrat", qui: c.agent, quoi: "Fin de période d'essai", date: c.essaiFin, jours: jours(c.essaiFin), niveau: "bientot" }); }
      for (const f of G.factures) if (f.statut === "émise" && f.echeance && jours(f.echeance) < 0) ech.push({ type: "Facture impayée", qui: f.clientNom, quoi: `${f.numero} · ${(f.ttc || 0).toFixed(2)} € TTC`, date: f.echeance, jours: jours(f.echeance), niveau: "expire", action: "Relancer le client" });
      for (const a of G.articles) if ((a.stock || 0) <= a.seuil) ech.push({ type: "Stock", qui: a.nom + (a.taille ? " " + a.taille : ""), quoi: `${a.stock || 0} en stock (seuil ${a.seuil})`, date: "", jours: null, niveau: (a.stock || 0) === 0 ? "expire" : "bientot", action: "Commander" });
      for (const a of G.articles.filter((x) => x.renouv)) { const derniers = new Map(); G.mouvements.filter((x) => x.article === a.id && x.type === "dotation").forEach((x) => { if (!derniers.has(x.agent)) derniers.set(x.agent, x.date); });
        for (const [ag, d] of derniers) { const fin = new Date(Date.parse(d) + a.renouv * 30.44 * 864e5).toISOString().slice(0, 10); if (jours(fin) <= 30) ech.push({ type: "EPI à renouveler", qui: ag, quoi: a.nom, date: fin, jours: jours(fin), niveau: jours(fin) < 0 ? "expire" : "bientot" }); } }
      ech.sort((a, b) => ({ expire: 0, bientot: 1, manquant: 2 }[a.niveau] ?? 3) - ({ expire: 0, bientot: 1, manquant: 2 }[b.niveau] ?? 3) || (a.jours ?? 999) - (b.jours ?? 999));
      const tarifs = await load("planif_tarifs", {}), devis = (await load("planif_devis", [])).map((d) => { const c = P.calcDevis(d, tarifs); return { id: d.id, numero: d.numero, client: d.client, objet: d.objet || d.evenement || "", statut: d.statut, parQualif: c.parQualif.map((q) => ({ qualif: q.qualif, heures: Math.round(q.heures * 100) / 100, montant: q.montant })) }; });
      return json({ ...G, echeances: ech, marge, devis });
    }

    /* ---------- Changer son mot de passe ---------- */
    if (r0 === "mdp" && m === "POST") {
      const users = await load("users", []), u = users.find((x) => x.id === me.id);
      if (!u || !checkPin(String(body.ancien || ""), u.pin)) return json({ error: "Mot de passe actuel incorrect" }, 400);
      if (String(body.mdp || "").length < 6) return json({ error: "6 caractères minimum" }, 400);
      u.pin = hashPin(String(body.mdp)); await save("users", users);
      return json({ ok: true });
    }

    /* ---------- Code d'accès aux contacts (SMS + fiches agents) ---------- */
    const unlockSig = (uid, exp) => crypto.createHmac("sha256", (process.env.APP_SECRET || "change-moi-dans-netlify") + ":contacts").update(uid + "." + exp).digest("base64url");
    const unlocked = () => {
      const [exp, sig] = String(req.headers.get("x-contacts") || "").split(".");
      return exp && Number(exp) > Date.now() && sig === unlockSig(me.id, exp);
    };
    // Code d'accès à la planification (planning, postes, devis, tarifs) : demandé à tout le monde, propriétaire compris
    const planifSig = (uid, exp) => crypto.createHmac("sha256", (process.env.APP_SECRET || "change-moi-dans-netlify") + ":planif").update(uid + "." + exp).digest("base64url");
    const planifOuvert = () => { const [exp, sig] = String(req.headers.get("x-planif") || "").split("."); return exp && Number(exp) > Date.now() && sig === planifSig(me.id, exp); };
    if (r0 === "deverrouiller" && m === "POST") {
      if (!isStaff(me)) return deny();
      const h = await load("code_contacts", null);
      if (!h) return json({ error: isAdmin(me) ? "Définis d'abord le code dans Administration" : "Code non défini, contacte un administrateur" }, 400);
      const locks = await load("locks", {}), k = "code:" + me.id, lk = locks[k];
      if (lk && lk.n >= 5 && Date.now() - lk.t < 15 * 60e3) return json({ error: "Trop d'essais, réessaie dans 15 min" }, 429);
      if (!checkPin(String(body.code || ""), h)) {
        locks[k] = { n: (lk && Date.now() - lk.t < 15 * 60e3 ? lk.n : 0) + 1, t: Date.now() }; await save("locks", locks);
        await journal("contacts", me.nom, "code d'accès incorrect", "attention");
        return json({ error: "Code incorrect" }, 403);
      }
      if (lk) { delete locks[k]; await save("locks", locks); }
      const exp = String(Date.now() + 4 * 3600e3); // déverrouillé 4 h
      await journal("contacts", me.nom, "accès aux contacts ouvert");
      return json({ token: exp + "." + unlockSig(me.id, exp), exp: Number(exp) });
    }
    if (["sms", "fiches", "planning", "postes"].includes(r0) && isStaff(me) && me.role !== "admin" && !unlocked()) return json({ error: "Code d'accès requis", verrou: true }, 423);

    /* ---------- Fiche de renseignement agent ---------- */
    if (r0 === "fiche") {
      const fiches = await load("fiches", {});
      if (m === "GET") {
        if (fiches[me.id]) return json(fiches[me.id]);
        const u = (await load("users", [])).find((x) => x.id === me.id); // pré-remplissage depuis l'inscription
        return json(u ? { tel: u.tel || "", email: /@/.test(u.id) ? u.id : "" } : null);
      }
      if (m === "PUT") {
        if (me.id === "__admin") return json({ error: "Crée d'abord ton compte personnel" }, 400);
        const t = (v, n = 120) => String(v ?? "").trim().slice(0, n);
        const f = {
          nom: t(body.nom, 60).toUpperCase(), prenom: t(body.prenom, 60), naissance: t(body.naissance, 10),
          adresse: t(body.adresse, 200), cp: t(body.cp, 10), ville: t(body.ville, 80),
          tel: t(body.tel, 20), email: t(body.email, 120).toLowerCase(),
          diplomes: Array.isArray(body.diplomes) ? body.diplomes.slice(0, 20).map((d) => ({
            code: t(d.code, 40), numero: t(d.numero, 40), echeance: t(d.echeance, 10) })) : [],
          consentement: body.consentement === true, maj: new Date().toISOString(),
        };
        if (!f.nom || !f.prenom || !/^\d{4}-\d{2}-\d{2}$/.test(f.naissance) || !f.tel || !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(f.email) || !f.adresse)
          return json({ error: "Champs obligatoires manquants ou invalides" }, 400);
        if (!f.consentement) return json({ error: "Coche l'acceptation du traitement des données" }, 400);
        fiches[me.id] = f;
        await save("fiches", fiches);
        // le numéro de la fiche alimente la liste SMS
        const users = await load("users", []); const u = users.find((x) => x.id === me.id);
        if (u) { u.tel = f.tel; await save("users", users); }
        await journal("fiche", me.nom, "fiche de renseignement mise à jour");
        return json({ ok: true });
      }
    }
    // Consultation des fiches : responsables/admin = tout ; PC = nom, téléphone, diplômes
    if (r0 === "fiches" && m === "GET") {
      if (!isStaff(me)) return deny();
      const fiches = await load("fiches", {}), users = await load("users", []);
      return json(users.map((u) => {
        const f = fiches[u.id];
        if (!f) return { id: u.id, nom: u.nom, role: u.role, fiche: null };
        const fiche = isRH(me) ? f : { nom: f.nom, prenom: f.prenom, tel: f.tel, diplomes: f.diplomes };
        return { id: u.id, nom: u.nom, role: u.role, fiche };
      }));
    }

    /* ---------- Contacts : jamais de numéro envoyé à l'affichage ---------- */
    if (r0 === "contacts" && m === "GET") {
      const c = await load("contacts", DEFAULT_CONTACTS), presta = (x) => /spie|otis|astreinte|prestataire/i.test(`${x.id} ${x.nom}`);
      const bas = !estProprio(me) && (["ads", "ssiap1"].includes(me.role) || me.role === "client"); // v4.57 · ADS / SSIAP 1 / client : pas les prestataires
      return json(c.filter((x) => !(bas && presta(x))).map(({ id, nom, fonction, tel }) => ({ id, nom, fonction, dispo: !!tel, presta: presta({ id, nom }) })));
    }
    if (r0 === "appel" && m === "POST") {
      const c = (await load("contacts", DEFAULT_CONTACTS)).find((x) => x.id === body.id);
      if (!c || !c.tel) return json({ error: "Numéro non configuré" }, 404);
      if (!estProprio(me) && (["ads", "ssiap1"].includes(me.role) || me.role === "client") && /spie|otis|astreinte|prestataire/i.test(`${c.id} ${c.nom}`)) return json({ error: "Contact réservé au PC sécurité" }, 403);
      await journal("appel", me.nom, c.nom);
      return json({ href: "tel:" + c.tel.replace(/[^\d+]/g, "") });
    }

    /* ---------- Événements (Parc des Expositions / Arena) ---------- */
    if (r0 === "evenements") {
      let evs = await load("evenements", []);
      if (m === "GET") return json(isStaff(me) || me.role === "client" ? evs : evs.filter((e) => e.statut !== "clos").map(({ id, nom, site }) => ({ id, nom, site })));
      // Événement Arena : SSIAP 2 du PC Parc + SSIAP 2 de l'Arena ; événement Parc : SSIAP 2 du PC Parc seulement (+ administrateurs, propriétaire)
      const pcsArena = me.perimetre === "arena" && AGENTS.includes(me.roleAgent || me.role);
      if (!(isStaff(me) && me.role !== "responsable") && !estProprio(me) && !pcsArena) return deny();
      if (m === "POST" || m === "PUT") {
        let e = r1 ? evs.find((x) => x.id === r1) : null;
        if (r1 && !e) return json({ error: "Introuvable" }, 404);
        if (pcsArena && !isStaff(me) && (!/arena/i.test(body.site ?? e?.site ?? "") || (e && !/arena/i.test(e.site || "")))) return json({ error: "Événement du Parc des Expositions : géré par le SSIAP 2 du PC Parc" }, 403);
        if (!e) { e = { id: uid(), cree: new Date().toISOString(), statut: "ouvert" }; evs.unshift(e); }
        const t = (v, n = 120) => String(v ?? "").trim().slice(0, n);
        if (body.nom !== undefined) e.nom = t(body.nom);
        if (!e.nom) return json({ error: "Nom de l'événement requis" }, 400);
        for (const k of ["site", "lieux", "type", "organisateur", "debut", "fin", "responsable"]) if (body[k] !== undefined) e[k] = t(body[k], 200);
        if (body.effectif !== undefined) e.effectif = Math.max(0, parseInt(body.effectif, 10) || 0);
        if (body.statut && ["ouvert", "clos"].includes(body.statut)) {
          if (body.statut !== e.statut) await journal("événement", me.nom, `${e.nom} ${body.statut === "clos" ? "clôturé" : "rouvert"}`, "info", "#/mc");
          e.statut = body.statut;
        }
        await save("evenements", evs.slice(0, 500));
        return json(e, r1 ? 200 : 201);
      }
    }

    /* ---------- Main courante électronique ---------- */
    if (r0 === "incidents") {
      if (m === "GET" && r1 === "mois") { // mois archivés (avec le nombre de saisies)
        if (!isStaff(me) && !(await estCoord(me))) return deny();
        const idx = await mcIndex(), copies = await load("mc_copies", {});
        return json({ mois: await Promise.all(idx.map(async (mm) => ({ mois: mm, nb: (await mcMois(mm)).length, copie: copies[mm] || "" }))), conservation: await load("mc_conservation", { actif: false, ansTexte: 5, ansPhotos: 3 }) });
      }
      if (m === "POST" && r1 === "copie") { // envoyer la copie d'un mois au PC et au coordinateur
        if (!estProprio(me) && me.role !== "admin" && !(await estCoord(me))) return deny();
        const mm = /^\d{4}-\d{2}$/.test(body.mois || "") ? body.mois : undefined;
        return json(await copieMensuelleMC({ mois: mm, essai: !!body.essai }));
      }
      if (m === "PUT" && r1 === "conservation") {
        if (!estProprio(me)) return refusProprio();
        const c = { actif: !!body.actif, ansTexte: Math.max(1, Math.min(30, parseInt(body.ansTexte) || 5)), ansPhotos: Math.max(1, Math.min(30, parseInt(body.ansPhotos) || 3)) };
        if (c.ansPhotos > c.ansTexte) c.ansPhotos = c.ansTexte;
        await save("mc_conservation", c); await journal("admin", me.nom, `conservation main courante : ${c.actif ? `${c.ansTexte} ans, photos ${c.ansPhotos} ans` : "désactivée"}`, "attention"); return json(c);
      }
      if (m === "GET") {
        const ev = url.searchParams.get("evenement"), mm = url.searchParams.get("mois");
        let list;
        if (/^\d{4}-\d{2}$/.test(mm || "")) list = await mcMois(mm);
        else if (ev) { const e = (await load("evenements", [])).find((x) => x.id === ev); const d0 = [e && e.debut, e && e.cree].find((x) => /^\d{4}-\d{2}-\d{2}/.test(String(x || ""))); list = await mcEntre(d0 ? moisPrec(String(d0).slice(0, 7), 1) + "-01" : moisPrec(moisDe(), 3) + "-01", "9999"); }
        else list = await mcRecents(2);
        if (me.role === "client") { list = anonyme(list.filter((i) => !/^(Prise|Fin) de service$/.test(i.categorie || "") && !/^SPL - REX$/.test(i.famille || ""))); if (ev) list = list.filter((i) => i.evenementId === ev); return json(list.slice(0, ev || mm ? 5000 : 400)); }
        if (!isStaff(me)) list = list.filter((i) => dansPerimetre(me, i));
        if (ev) list = list.filter((i) => i.evenementId === ev);
        return json(list.slice(0, ev || mm ? 5000 : 400));
      }
      if (m === "POST") {
        const t = (v, n = 120) => String(v ?? "").trim().slice(0, n);
        const evs = await load("evenements", []);
        const ev = evs.find((e) => e.id === body.evenementId && e.statut !== "clos");
        // types autorisés selon le poste : un agent ne saisit que dans la main courante de son poste (SSIAP 3 : rapport libre seulement)
        if (AGENTS.includes(me.role) && me.profilMC) {
          const P = (globalThis.MC_POSTES || []).find((x) => x.k === me.profilMC), cat = String(body.categorie || "");
          if (P && !Object.values(P.familles).some((l) => l.some(([tp]) => tp === cat))) return json({ error: `« ${cat} » n'est pas dans la main courante de ton poste (${P.lb.replace(/^\S+\s/, "")})` }, 403);
        }
        // SSIAP 2 de l'Arena : faits de l'Arena seulement (les événements du Parc sont tenus par le PC Parc)
        if (me.perimetre === "arena" && !isStaff(me)) {
          if (ev && !/arena/i.test(ev.site || "")) return json({ error: "Événement du Parc des Expositions : main courante tenue par le SSIAP 2 du PC Parc" }, 403);
          if (body.site && !/arena/i.test(body.site)) body.site = "Arena Sud de France";
        }
        const year = new Date().getFullYear(), cpt = await load("mc_compteur", {});
        cpt[year] = (cpt[year] || 0) + 1; await save("mc_compteur", cpt);
        const inc = {
          id: uid(), numero: `MC-${year}-${String(cpt[year]).padStart(4, "0")}`,
          t: new Date().toISOString(), heure: /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}/.test(body.heure || "") ? body.heure.slice(0, 16) : null,
          auteurId: me.id, auteur: me.nom, role: me.role,
          evenementId: ev ? ev.id : null, evenement: ev ? ev.nom : "",
          categorie: t(body.categorie || "Autre", 120), famille: t(body.famille, 60), poste: PROFILS_MC.includes(body.poste) ? body.poste : "", societe: t(body.societe, 80), immat: t(body.immat, 20).toUpperCase(),
          gravite: ["info", "moyenne", "urgente"].includes(body.gravite) ? body.gravite : "info",
          site: t(body.site, 60), lieu: t(body.lieu), description: t(body.description, 4000),
          intervenants: t(body.intervenants, 300), actions: t(body.actions, 2000), prestataire: t(body.prestataire, 80),
          gps: body.gps && typeof body.gps.lat === "number" ? { lat: body.gps.lat, lon: body.gps.lon } : null,
          statut: body.clos ? "clos" : "ouvert", suivi: [], photo: false, photos: 0,
        };
        if (!inc.description) return json({ error: "Description obligatoire" }, 400);
        if (/^(Prise|Fin) de service$/.test(inc.categorie)) inc.gps = null; // v4.13 : aucune géolocalisation à la prise et à la fin de service
        const phs = (Array.isArray(body.photos) ? body.photos : body.photo ? [body.photo] : [])
          .filter((d) => typeof d === "string" && d.startsWith("data:image/") && d.length < MAX_PHOTO).slice(0, 4);
        for (let k = 0; k < phs.length; k++) await save(`photo/${inc.id}-${k}`, { d: phs[k], auteurId: me.id });
        inc.photos = phs.length; inc.photo = phs.length > 0;
        await mcAjouter(inc);
        try { // v4.89 · flammes + mission à valider par le SSIAP 3
          if (inc.categorie === "Prise de service") await flammesService(me, "prise");
          else if (inc.categorie === "Fin de service") await flammesService(me, "fin");
          else await flammes(me, 3, "Saisie en main courante", { capJour: 10, stat: "mc" });
          const mt = AGENTS.includes(me.role) || me.role === "ssiap3" ? missionDe(inc.categorie) : "";
          if (mt) { const MI = await load("missions", []), mid = uid(), pts = MISSIONS[mt][1]; // v4.90 · gain automatique, le SSIAP 3 peut annuler en cas d'abus
            MI.unshift({ id: mid, t: inc.t, mcId: inc.id, numero: inc.numero, auteurId: me.id, nom: me.nom, poste: posteDe(me), type: mt, categorie: inc.categorie, lieu: inc.lieu, description: inc.description.slice(0, 400), statut: "créditée", points: pts }); await save("missions", MI.slice(0, 800));
            await flammes(me, pts, `Mission : ${MISSIONS[mt][0]} (${inc.numero})`, { cle: "mission-" + mid, stat: "missions" });
            await envoyerPush({ titre: `🔥 Mission créditée : ${me.nom}`, texte: `${MISSIONS[mt][0]} · ${inc.categorie}${inc.lieu ? " · " + inc.lieu : ""} · +${pts} flammes`, url: "/#/flammes" }, (u) => estSSIAP3(u) && u.id !== me.id).catch(() => 0); }
        } catch {}
        await mailPC(`${inc.gravite === "urgente" ? "🚨 " : ""}Main courante ${inc.numero} — ${inc.categorie}`, [...(await lignesAgent(me)), ["Heure", (inc.heure ? fmtHeure(inc.heure) : fmtParis(inc.t))],
          ["Événement", inc.evenement], ["Site", ERP(inc.site)], ["Lieu", inc.lieu], ["Famille", inc.famille], ["Société", inc.societe], ["Immatriculation", inc.immat], ["Prestataire concerné", inc.prestataire], ["Gravité", inc.gravite], ["Faits", inc.description], ["Intervenants", inc.intervenants], ["Actions", inc.actions],
          ["Position", inc.gps ? `https://maps.google.com/?q=${inc.gps.lat},${inc.gps.lon}` : ""]], phs);
        await journal("main courante", me.nom, `${inc.numero} · ${inc.categorie}${inc.lieu ? " · " + inc.lieu : ""}${inc.evenement ? " · " + inc.evenement : ""}`,
          inc.gravite === "urgente" ? "urgent" : inc.gravite === "moyenne" ? "attention" : "info", "#/mc");
        if (inc.gravite === "urgente") {
          await envoyerPush({ titre: `URGENT — ${inc.categorie}`, texte: `${inc.numero} · ${inc.lieu || ""} · ${inc.description.slice(0, 140)}`, url: "/#/mc", alerte: true }, (u) => isStaff(u) || estProprio(u)).catch(() => 0);
          const dest = DIFFUSION_SITE();
          await sendMail(dest, `🚨 Kaelum e-PCS — ${inc.numero} urgent : ${inc.categorie}`,
            `<h2>Main courante — fait urgent</h2><p><b>${inc.numero} · ${inc.categorie}</b> — ${inc.lieu}${inc.evenement ? " — " + inc.evenement : ""}</p>
             <p>${inc.description.replace(/</g, "&lt;")}</p><p>Saisi par ${inc.auteur} le ${fmtParis(inc.t)}</p>`).catch(() => {});
        }
        return json(inc, 201);
      }
      if (m === "PATCH" && r1) {
        const { inc, mois: mInc, list } = await mcTrouver(r1);
        if (!inc || inc.id !== r1) return json({ error: "Introuvable" }, 404);
        if (!isStaff(me) && !(me.perimetre && dansPerimetre(me, inc))) return deny();
        const avant = inc.statut;
        if (body.statut && ["ouvert", "en cours", "clos"].includes(body.statut)) inc.statut = body.statut;
        if (body.note) inc.suivi.push({ t: new Date().toISOString(), qui: me.nom, note: String(body.note).slice(0, 1000) });
        if (inc.statut === "clos" && avant !== "clos") inc.clos = { t: new Date().toISOString(), qui: me.nom };
        await save("mc/" + mInc, list);
        if (avant !== inc.statut || body.note) await journal("main courante", me.nom, `${inc.numero || ""} → ${inc.statut}${body.note ? " · " + String(body.note).slice(0, 80) : ""}`, "info", "#/mc");
        return json(inc);
      }
    }
    if (r0 === "photo" && r1) {
      const p = await load("photo/" + r1, null);
      if (!p) return json({ error: "Introuvable" }, 404);
      if (!isStaff(me) && !estProprio(me) && p.auteurId !== me.id && !(p.fil && p.fil === me.id) && !p.objet && !p.poste && !(p.moyen && me.role !== "client") && !(p.pf && me.role !== "client")) {
        const inc = me.perimetre ? (await mcTrouver(r1)).inc : null;
        if (!inc || !dansPerimetre(me, inc)) return deny();
      }
      return json({ d: p.d });
    }

    /* ---------- Dossier des agents (diplômes, carte pro, habilitations, recyclages, visite médicale) ---------- */
    if (r0 === "dossier") {
      const moi = me.id === "__admin" ? PROPRIO() : me.id; // le compte administrateur = le dossier du propriétaire
      const coordPC = await estCoord(me), gere = estProprio(me) || coordPC || me.role === "admin"; // ajoute / supprime pour les autres
      const vueTous = gere || me.role === "admin" || me.role === "responsable" || (me.role === "pc" && !me.roleAgent);
      const tous = await load("dossiers", {}), t = (v, n = 120) => String(v ?? "").trim().slice(0, n), types = DOC_TYPES.map((x) => x[0]);
      const users0 = await load("users", []), users = users0.some((u) => u.id === PROPRIO()) ? users0 : [...users0, { id: PROPRIO(), nom: process.env.OWNER_NOM || "Rochdi Mecheti", role: "admin" }];
      if (m === "GET" && !r1) { const p = await profilDossier(estProprio(me) ? { ...me, id: moi } : me), docs = tous[moi] || [];
        return json({ docs, ...p, types: DOC_TYPES, etat: conformite(p.q, p.pcs, docs) }); }
      if (m === "POST" && r1 === "essai-alertes") { if (!gere) return deny(); return json(await alertesDossiers({ essai: true })); }
      if (m === "GET" && r1 === "equipe") return json(await load("equipe_pcs", EQUIPE_PCS_DEFAUT));
      if (m === "PUT" && r1 === "equipe") {
        if (!estProprio(me)) return deny();
        const l = (Array.isArray(body.items) ? body.items : []).map((x) => ({ nom: t(x.nom, 60), q: ["ssiap1", "ssiap2", "ssiap3", "ads"].includes(x.q) ? x.q : "ssiap2" })).filter((x) => x.nom).slice(0, 40);
        await save("equipe_pcs", l); await journal("admin", me.nom, `équipe PCS : ${l.length} personne(s)`); return json({ ok: true, nb: l.length });
      }
      if (m === "GET" && r1 === "agents") {
        if (!vueTous) return deny();
        return json((await lectureDossiers()).map((a) => ({ ...a, docs: a.docs.map(({ id, type, libelle, numero, obtention, echeance, fichier, mime, t: tt }) => ({ id, type, libelle, numero, obtention, echeance, fichier, mime, t: tt })) })));
      }
      if (m === "GET" && r1 === "fichier" && r2) {
        const uidDoc = Object.keys(tous).find((k) => tous[k].some((d) => d.id === r2)); const d = uidDoc && tous[uidDoc].find((x) => x.id === r2);
        if (!d) return json({ error: "Introuvable" }, 404);
        if (uidDoc !== moi && !(gere || (vueTous && d.type !== "visite"))) return deny(); // la visite médicale : l'agent, le propriétaire et le coordinateur PC seulement
        const f = await load("dossierf/" + d.id, null); if (!f) return json({ error: "Fichier introuvable" }, 404);
        return json({ d: f.d, type: d.mime, nom: d.nomFichier || d.libelle });
      }
      if (m === "POST" && !r1) {
        const pour = t(body.pour, 120) && t(body.pour, 120) !== moi ? t(body.pour, 120) : moi;
        if (pour !== moi && !gere) return deny();
        if (pour !== moi && !users.some((u) => u.id === pour)) return json({ error: "Agent introuvable" }, 404);
        if (!types.includes(body.type)) return json({ error: "Type de document inconnu" }, 400);
        const dt = (v) => (/^\d{4}-\d{2}-\d{2}$/.test(v || "") ? v : "");
        const d = { id: uid(), type: body.type, libelle: t(body.libelle, 80) || DOC_TYPES.find((x) => x[0] === body.type)[1], numero: t(body.numero, 40), obtention: dt(body.obtention), echeance: dt(body.echeance),
          fichier: false, mime: "", nomFichier: t(body.nomFichier, 100), t: new Date().toISOString(), par: me.nom };
        const f = String(body.fichier || "");
        if (f) { const mm = f.match(/^data:(application\/pdf|image\/jpeg|image\/png|image\/webp);base64,/); if (!mm) return json({ error: "Fichier PDF, JPG ou PNG seulement" }, 400);
          if (f.length > MAX_DOC) return json({ error: "Fichier trop lourd (4 Mo maximum)" }, 413);
          await save("dossierf/" + d.id, { d: f, userId: pour }); d.fichier = true; d.mime = mm[1]; }
        if (!d.fichier && !d.numero && !d.obtention) return json({ error: "Joins le document (photo ou PDF) ou indique au moins le numéro / la date" }, 400);
        tous[pour] = [d, ...(tous[pour] || [])].slice(0, 60); await save("dossiers", tous);
        await journal("dossier", me.nom, `${d.libelle}${pour !== moi ? " pour " + ((users.find((u) => u.id === pour) || {}).nom || pour) : ""}`, "info", "#/dossiers");
        return json(d, 201);
      }
      if (m === "DELETE" && r1) {
        const uidDoc = Object.keys(tous).find((k) => tous[k].some((d) => d.id === r1));
        if (!uidDoc) return json({ error: "Introuvable" }, 404);
        if (uidDoc !== moi && !gere) return deny();
        tous[uidDoc] = tous[uidDoc].filter((d) => d.id !== r1); await save("dossiers", tous); await save("dossierf/" + r1, null);
        return json({ ok: true });
      }
      return json({ error: "Méthode non gérée" }, 405);
    }

    /* ---------- Équipe ADS Arena du jour, répartie par groupe (coordinateur Arena) ---------- */
    /* ---------- v4.60 · Affectation des agents sur le plan de l'Arena (agent → poste du plan, par jour) ---------- */
    /* ---------- v4.72 · Badges NFC de connexion (SSIAP 2 du PCS) : seul le propriétaire associe ou retire un badge ---------- */
    if (r0 === "badges") {
      if (!estProprio(me) || me.apercu) return deny();
      const bb = await load("badges", {}), users = await load("users", []);
      const BD = {}; for (const u of users) BD[u.id] = await badgeDe(u);
      const ok = (u) => u && !u.bloque && (estProprio(u) || ["diamant", "or", "allaccess"].includes(BD[u.id]));
      if (m === "GET") return json({ badges: Object.entries(bb).map(([h, b]) => ({ h: h.slice(0, 16), id: b.id, nom: b.nom, t: b.t, dernier: b.dernier || null })).sort((a, b) => String(a.nom).localeCompare(String(b.nom), "fr")),
        comptes: [{ id: me.id, nom: me.nom || "Rochdi Mecheti", role: "badge Or" }, ...users.filter((u) => ok(u) && u.id !== me.id).map((u) => ({ id: u.id, nom: u.nom, role: BD[u.id] === "or" ? "badge Or" : "badge All accès" }))] });
      if (m === "POST") { const sn = String(body.serie || "").toUpperCase().replace(/[^0-9A-F]/g, ""); if (sn.length < 8) return json({ error: "Numéro de badge illisible" }, 400);
        const u = body.id === me.id ? { id: me.id, nom: me.nom || "Rochdi Mecheti" } : users.find((x) => x.id === body.id); if (!u || (u.id !== me.id && !ok(u))) return json({ error: "Connexion NFC réservée aux badges Or et All accès" }, 400);
        const h = hashBadge(sn); if (bb[h] && bb[h].id !== u.id) return json({ error: `Ce badge est déjà associé à ${bb[h].nom}` }, 409);
        bb[h] = { id: u.id, nom: u.nom, t: new Date().toISOString() }; await save("badges", bb); await journal("badges", me.nom, `badge NFC associé à ${u.nom}`, "attention"); return json({ ok: true }); }
      if (m === "DELETE" && r1) { const h = Object.keys(bb).find((k) => k.startsWith(r1)); if (!h) return json({ error: "Badge introuvable" }, 404); const n = bb[h].nom; delete bb[h]; await save("badges", bb); await journal("badges", me.nom, `badge NFC retiré (${n})`, "attention"); return json({ ok: true }); }
    }

    /* ---------- v4.69 · Messagerie à sens unique : seul le propriétaire écrit, aux profils et personnes qu'il choisit. Pas de réponse. Jamais le client ---------- */
    // v5.57 · Mot du jour (Rochdi / encadrement → tous les agents)
    if (r0 === "motdujour") {
      if (me.role === "client") return deny();
      const x = await load("motdujour", null);
      if (m === "GET") return json(x && Date.now() - Date.parse(x.t) < 48 * 3600e3 ? x : {});
      if (m === "PUT") { if (!estProprio(me) && !isStaff(me)) return deny(); const texte = String(body.texte ?? "").trim().slice(0, 400);
        if (!texte) { await save("motdujour", null); return json({}); }
        const n = { texte, par: me.nom, t: new Date().toISOString() }; await save("motdujour", n);
        await envoyerPush({ titre: `💬 Mot de ${me.nom.split(" ")[0]}`, texte: texte.slice(0, 160), url: "/#/" }, (u) => u.id !== me.id && enService(u)).catch(() => 0); return json(n); }
      return json({ error: "Route inconnue" }, 404);
    }
    // v5.57 · Quiz SSIAP (révision, 5 questions)
    if (r0 === "quiz") {
      if (me.role === "client") return deny();
      const S0 = await load("quiz_scores", {}), mien = S0[me.id] || { n: 0, meilleur: 0, hist: [] };
      if (m === "GET") return json({ n: mien.n, meilleur: mien.meilleur, hist: mien.hist.slice(0, 5) });
      if (m === "POST" && r1 === "generer") {
        const theme = ["Incendie et SSI", "Secours à personne", "Sûreté et gestion de foule", "Évacuation", "Mélange"].includes(body.theme) ? body.theme : "Mélange";
        const pool = QUIZ_BANQUE.filter((x) => theme === "Mélange" || x.theme === theme), qs = (pool.length >= 5 ? pool : QUIZ_BANQUE).slice().sort(() => Math.random() - 0.5).slice(0, 5).map(({ q, options, bonne, explication }) => ({ q, options, bonne, explication }));
        return json({ theme, questions: qs });
      }
      if (m === "POST" && r1 === "fin") { const total = Math.max(1, Math.min(10, parseInt(body.total) || 5)), score = Math.max(0, Math.min(total, parseInt(body.score) || 0));
        mien.n++; mien.meilleur = Math.max(mien.meilleur, Math.round((score / total) * 100)); mien.hist.unshift({ t: new Date().toISOString(), theme: String(body.theme || "").slice(0, 40), score, total }); mien.hist = mien.hist.slice(0, 20); S0[me.id] = mien; await save("quiz_scores", S0);
        const g = await flammes(me, score * 4, `Quiz SSIAP ${score}/${total}`, { capJour: 2, stat: "quiz" }).catch(() => 0); return json({ ok: true, flammes: g, meilleur: mien.meilleur }); }
      return json({ error: "Route inconnue" }, 404);
    }
    // v5.56 · Compte rendu de fin de vacation
    if (r0 === "compterendu" && m === "GET") { if (me.role === "client") return deny(); return json({ texte: await compteRendu(me) }); }
    // v5.56 · Espace propriétaire
    if (r0 === "proprio") {
      if (!estProprio(me) || me.apercu) return refusProprio();
      if (r1 === "testeurs") { const us = await load("users", []);
        if (m === "GET") return json({ testeurs: us.filter((u) => u.testeur).map((u) => ({ id: u.id, nom: u.nom, total: !!u.testeurTotal })), users: us.filter((u) => !u.bloque && !u.testeur && u.role !== "client" && !estProprio(u)).map((u) => ({ id: u.id, nom: u.nom })).sort((a, b) => String(a.nom).localeCompare(String(b.nom), "fr")) });
        if (m === "POST") { const u = us.find((x) => x.id === String(body.id || "")); if (!u || estProprio(u)) return json({ error: "Compte introuvable" }, 404); if (body.total !== undefined) { u.testeurTotal = !!body.total && !!u.testeur; } else { u.testeur = !!body.actif; if (!u.testeur) u.testeurTotal = false; } await save("users", us);
          await journal("admin", me.nom, `mode testeur ${body.total !== undefined ? (u.testeurTotal ? "accès total activé" : "accès total retiré") : (u.testeur ? "activé" : "retiré")} : ${u.nom}`, "info"); if (body.total === undefined && u.testeur && body.notifier !== false) await bienvenueTesteurs([u.id]); return json({ ok: true }); } }
      if (m === "POST" && r1 === "ronde") { const c = { actif: !!body.actif, heures: Math.max(1, Math.min(8, parseInt(body.heures) || 3)) }; await save("ronde_rappel", c); await journal("admin", me.nom, `rappel de ronde : ${c.actif ? c.heures + " h" : "désactivé"}`, "info"); return json(c); }
      if (m === "GET") { const users = await load("users", []), jour = (await mcRecents(1)).filter((i) => String(i.t).slice(0, 10) === jourParis() && !/^(Prise|Fin) de service$/.test(i.categorie || "")), cpt = await load("rochbot_cpt", {}), hh = new Date().toISOString().slice(0, 13), SV = await storeNomme(NOM_SAUV());
        return json({ version: VERSION_SERVEUR, comptes: users.filter((u) => !u.bloque).length, enVacation: (await agentsEnVacation()).length, faitsJour: jour.length, alertes: (await load("alertes", [])).filter((a) => !a.fin && Date.parse(a.exp) > Date.now()).length,
                    veille: await veilleItems(), qualite: await qualiteDonnees(), sauvegardes: ((await SV.get("index")) || []).slice(0, 3), ronde: { actif: true, heures: 3, ...(await load("ronde_rappel", {})) } }); }
      return json({ error: "Route inconnue" }, 404);
    }
    // v5.60 · Rochbot (aide intégrée, SANS intelligence artificielle) : fournit seulement les données de l'appli que la personne peut déjà voir
    if (r0 === "rochbot") {
      if (me.role === "client" || m !== "GET") return deny();
      const auj = jourParis(), pil = isStaff(me) || estProprio(me);
      const planning = await planningDe((await load("users", [])).find((x) => x.id === me.id) || me).catch(() => []);
      const consignes = (await load("consignes", [])).filter((c) => !c.archive && (!c.fin || c.fin >= auj) && (!c.debut || c.debut <= auj)).map(({ titre, texte, importante }) => ({ titre, texte: String(texte || "").slice(0, 300), importante }));
      const alertes = (await load("alertes", [])).filter((a) => !a.fin && Date.parse(a.exp) > Date.now()).map((a) => ({ nature: a.nature, lieu: a.lieu, texte: String(a.texte || "").slice(0, 200) }));
      const enVacation = (await agentsEnVacation()).map(({ nom, poste, site }) => ({ nom, poste, site }));
      return json({ planning: planning.slice(0, 30), consignes, alertes, enVacation, veille: pil ? await veilleItems() : null });
    }
    // v5.52 · Passation de vacation : un mot laissé à l'équipe suivante (visible 24 h)
    if (r0 === "passation") {
      if (me.role === "client") return deny();
      let list = (await load("passations", [])).filter((x) => Date.now() - Date.parse(x.t) < 24 * 3600e3);
      if (m === "GET") return json({ notes: list.slice(0, 20).map((x) => ({ ...x, mienne: x.parId === me.id })) });
      if (m === "POST" && !r1) { const texte = String(body.texte ?? "").trim().slice(0, 1000); if (!texte) return json({ error: "Écris ta passation" }, 400);
        const x = { id: uid(), t: new Date().toISOString(), par: me.nom, parId: me.id, poste: posteDe(me), texte };
        list.unshift(x); await save("passations", list.slice(0, 60));
        await envoyerPush({ titre: `📝 Passation de ${me.nom}`, texte: texte.slice(0, 160), url: "/#/passation" }, (u) => u.id !== me.id && enService(u)).catch(() => 0);
        await journal("passation", me.nom, `📝 passation : ${texte.slice(0, 120)}`, "info", "#/passation"); return json(x, 201); }
      if (m === "DELETE" && r1) { const x = list.find((y) => y.id === r1); if (x && (x.parId === me.id || estProprio(me) || isStaff(me))) { list = list.filter((y) => y.id !== r1); await save("passations", list); } return json({ ok: true }); }
      return json({ error: "Route inconnue" }, 404);
    }
    // v5.51 · Positions partagées d'agent à agent (valables 2 h, agents en service seulement)
    if (r0 === "position") {
      if (me.role === "client") return deny();
      let list = (await load("positions", [])).filter((x) => Date.parse(x.exp) > Date.now());
      if (m === "GET" && r1 === "destinataires") { const users = await load("users", []), out = [];
        for (const u of users) { if (u.bloque || u.id === me.id || u.role === "client") continue; if (await enService(u)) out.push({ id: u.id, nom: u.nom, poste: posteDe(u) }); }
        return json(out.sort((a, b) => String(a.nom).localeCompare(String(b.nom), "fr"))); }
      if (m === "GET") return json({ recues: list.filter((x) => (x.dest || []).includes(me.id) || x.deId === me.id).map(({ id, deId, de, poste, gps, note, t, exp, dest }) => ({ id, deId, de, poste, gps, note, t, exp, nb: (dest || []).length })) });
      if (m === "POST" && r1 === "envoyer") {
        const gps = gpsOk(body.gps); if (!gps) return json({ error: "Position introuvable : active la localisation et réessaie" }, 400);
        const users = await load("users", []); let dest = Array.isArray(body.ids) ? body.ids.map(String) : [];
        if (body.tous) { dest = []; for (const u of users) if (!u.bloque && u.id !== me.id && u.role !== "client" && (await enService(u))) dest.push(u.id); }
        dest = [...new Set(dest)].filter((id) => id !== me.id && users.some((u) => u.id === id && !u.bloque && u.role !== "client")).slice(0, 200);
        if (!dest.length) return json({ error: "Choisis au moins un collègue" }, 400);
        const x = { id: uid(), deId: me.id, de: me.nom, poste: posteDe(me), gps, note: body.renfort ? "🆘 BESOIN DE RENFORT" : String(body.note ?? "").trim().slice(0, 200), renfort: !!body.renfort, dest, t: new Date().toISOString(), exp: new Date(Date.now() + 2 * 3600e3).toISOString() };
        list = list.filter((y) => !(y.deId === me.id && y.dest.length === dest.length && y.dest.every((d) => dest.includes(d)))); // un nouvel envoi remplace le précédent au même groupe
        list.unshift(x); await save("positions", list.slice(0, 300));
        await envoyerPush({ titre: x.renfort ? `🆘 RENFORT — ${me.nom}` : `📍 ${me.nom} partage sa position`, texte: `${x.poste ? x.poste + " · " : ""}${x.renfort ? "demande du renfort — touche pour voir où" : x.note || "Touche pour voir sur la carte"}`, url: "/#/position", alerte: !!x.renfort }, (u) => dest.includes(u.id)).catch(() => 0);
        await journal("position", me.nom, `${x.renfort ? "🆘 renfort demandé" : "📍 position envoyée"} à ${dest.length} collègue(s)${x.note && !x.renfort ? " · " + x.note : ""}`, x.renfort ? "urgent" : "info", "#/position");
        return json({ ok: true, n: dest.length }, 201);
      }
      if (m === "DELETE" && r1) { const x = list.find((y) => y.id === r1); if (!x) return json({ ok: true }); if (x.deId !== me.id && !estProprio(me)) { x.dest = (x.dest || []).filter((d) => d !== me.id); } else list = list.filter((y) => y.id !== r1); await save("positions", list); return json({ ok: true }); }
      return json({ error: "Route inconnue" }, 404);
    }
    if (r0 === "messagerie") {
      if (me.role === "client") return deny();
      const PROFILS = ["pc", "ssiap3", "ssiap2", "ssiap1", "ads", "admin", "responsable"];
      const auteur = estProprio(me) && !me.apercu, list = await load("messagerie", []), t = (v, n) => String(v ?? "").trim().slice(0, n);
      const pourMoi = (x) => (x.dest || []).includes(me.id);
      if (m === "GET" && r1 === "nonlus") return json({ n: auteur ? 0 : list.filter((x) => pourMoi(x) && !(x.lus || {})[me.id]).length });
      if (m === "GET" && r1 === "destinataires") { if (!auteur) return deny(); const users = await load("users", []);
        return json(users.filter((u) => !u.bloque && u.role !== "client" && !estProprio(u)).map((u) => ({ id: u.id, nom: u.nom, role: u.role, roleAgent: u.roleAgent || "" })).sort((a, b) => String(a.nom).localeCompare(String(b.nom), "fr"))); }
      if (m === "GET") { if (auteur) { const users = await load("users", []), nomDe = (id) => (users.find((u) => u.id === id) || {}).nom || id;
          return json({ auteur: true, messages: list.slice(0, 200).map((x) => ({ ...x, lusPar: Object.entries(x.lus || {}).map(([id, tl]) => ({ nom: nomDe(id), t: tl })), nonLus: (x.dest || []).filter((id) => !(x.lus || {})[id]).map(nomDe) })) }); }
        return json({ auteur: false, messages: list.filter(pourMoi).slice(0, 200).map(({ id, t: tm, texte, important, par }) => ({ id, t: tm, texte, important, par, lu: !!((list.find((y) => y.id === id) || {}).lus || {})[me.id] })) }); }
      if (m === "POST" && r1 && r2 === "lu") { const x = list.find((y) => y.id === r1); if (!x || !pourMoi(x)) return json({ error: "Message introuvable" }, 404);
        x.lus ||= {}; if (!x.lus[me.id]) { x.lus[me.id] = new Date().toISOString(); await save("messagerie", list); } return json({ ok: true }); }
      if (!auteur) return deny();
      if (m === "POST" && !r1) {
        const texte = t(body.texte, 2000); if (!texte) return json({ error: "Écris le message" }, 400);
        const profils = (Array.isArray(body.profils) ? body.profils : []).filter((p) => PROFILS.includes(p)), ids = (Array.isArray(body.ids) ? body.ids : []).map((x) => t(x, 120));
        const users = await load("users", []);
        const dest = users.filter((u) => !u.bloque && u.role !== "client" && !estProprio(u) && (ids.includes(u.id) || profils.includes(u.role) || (u.roleAgent && profils.includes(u.roleAgent)))).map((u) => u.id);
        if (!dest.length) return json({ error: "Choisis au moins un profil ou une personne" }, 400);
        const x = { id: uid(), t: new Date().toISOString(), par: me.nom || "Rochdi Mecheti", texte, important: !!body.important, profils, ids, dest, lus: {} };
        list.unshift(x); await save("messagerie", list.slice(0, 1000));
        await envoyerPush({ titre: `${x.important ? "IMPORTANT — " : ""}Message de ${x.par}`, texte: texte.slice(0, 160), url: "/#/messagerie" }, (u) => dest.includes(u.id)).catch(() => 0);
        await journal("messagerie", me.nom, `message envoyé à ${dest.length} personne(s)`, "info", "#/messagerie");
        return json({ ok: true, n: dest.length }, 201); }
      if (m === "DELETE" && r1) { const i = list.findIndex((y) => y.id === r1); if (i < 0) return json({ error: "Message introuvable" }, 404); list.splice(i, 1); await save("messagerie", list); return json({ ok: true }); }
      return json({ error: "Action inconnue" }, 400);
    }

    /* ---------- v5.63 · Discussions (façon Messenger) : privées et en groupe, photos, réactions, « vu », messages éphémères ---------- */
    if (r0 === "chat") { // réservé aux testeurs et au propriétaire
      if (me.role === "client" || !(me.testeur || estProprio(me))) return deny("Les discussions sont réservées aux testeurs");
      const norm = (id) => (id === PROPRIO() ? "__admin" : id), moi = estProprio(me) ? "__admin" : me.id, tx = (v, n) => String(v ?? "").trim().slice(0, n);
      const DUREES = [900e3, 3600e3, 864e5, 7 * 864e5, 30 * 864e5], REAC = ["👍", "❤️", "😂", "😮", "😢", "🙏"], vivant = (x) => !x.exp || Date.parse(x.exp) > Date.now();
      const convs = await load("chat_convs", []), users = await load("users", []);
      const nomDe = (id) => { const u = users.find((x) => norm(x.id) === id); return u ? u.nom : id === "__admin" ? process.env.OWNER_NOM || "Rochdi Mecheti" : "Ancien membre"; };
      const valides = () => users.filter((u) => !u.bloque && u.role !== "client" && u.testeur).map((u) => norm(u.id));
      const pousser = (c, texte, dest) => envoyerPush({ titre: c.type === "groupe" ? `${nomDe(moi)} · ${c.nom}` : nomDe(moi), texte: texte.slice(0, 120), url: "/#/chat/" + c.id }, (u) => dest.includes(norm(u.id)) || (dest.includes("__admin") && estProprio(u))).catch(() => 0);
      const nomConv = (c) => (c.type === "groupe" ? c.nom : nomDe(c.membres.find((x) => x !== moi) || moi));
      const aperçu = (c) => { const d = c.dernier; return d && (!d.exp || Date.parse(d.exp) > Date.now()) ? { t: d.t, de: d.de === moi ? "Toi" : nomDe(d.de), texte: d.texte } : null; };
      const mienne = (id) => { const c = convs.find((x) => x.id === id); return c && c.membres.includes(moi) ? c : null; };
      const sys = async (c, texte) => { const l = await load("chat_m_" + c.id, []); l.push({ id: uid(), sys: true, texte, t: new Date().toISOString(), exp: new Date(Date.now() + c.duree).toISOString(), lus: {}, reac: {} }); await save("chat_m_" + c.id, l.slice(-300)); };
      if (m === "GET" && !r1) return json(convs.filter((c) => c.membres.includes(moi)).map((c) => ({ id: c.id, type: c.type, nom: nomConv(c), nb: c.membres.length, duree: c.duree, nl: (c.nl || {})[moi] || 0, dernier: aperçu(c), t: c.t }))
        .sort((a, b) => String((b.dernier || b).t).localeCompare(String((a.dernier || a).t))));
      if (m === "GET" && r1 === "nonlus") return json({ n: convs.filter((c) => c.membres.includes(moi)).reduce((s, c) => s + ((c.nl || {})[moi] || 0), 0) });
      if (m === "GET" && r1 === "contacts") { const vus = new Set(), L = [];
        for (const u of users) { const id = norm(u.id); if (u.bloque || u.role === "client" || !(u.testeur || estProprio(u)) || id === moi || vus.has(id)) continue; vus.add(id); L.push({ id, nom: u.nom, role: u.role }); }
        if (moi !== "__admin" && !vus.has("__admin")) L.push({ id: "__admin", nom: nomDe("__admin"), role: "admin" });
        return json(L.sort((a, b) => String(a.nom).localeCompare(String(b.nom), "fr"))); }
      if (m === "POST" && !r1) {
        if (me.apercu) return deny(); const ok = new Set(valides()); ok.add("__admin");
        if (body.type === "groupe") { const nom = tx(body.nom, 40), mb = [...new Set((Array.isArray(body.membres) ? body.membres : []).map((x) => tx(x, 120)).filter((x) => ok.has(x) && x !== moi))].slice(0, 40);
          if (!nom) return json({ error: "Donne un nom au groupe" }, 400); if (!mb.length) return json({ error: "Choisis au moins une personne" }, 400);
          const c = { id: uid(), type: "groupe", nom, membres: [moi, ...mb], par: moi, t: new Date().toISOString(), duree: 900e3, nl: {}, dernier: null }; convs.unshift(c); await save("chat_convs", convs.slice(0, 2000));
          await sys(c, `${nomDe(moi)} a créé le groupe « ${nom} »`); await pousser(c, "t'a ajouté au groupe", mb); return json({ id: c.id }, 201); }
        const avec = tx(body.avec, 120); if (!ok.has(avec) || avec === moi) return json({ error: "Personne introuvable" }, 404);
        let c = convs.find((x) => x.type === "dm" && x.membres.includes(moi) && x.membres.includes(avec));
        if (!c) { c = { id: uid(), type: "dm", nom: "", membres: [moi, avec], par: moi, t: new Date().toISOString(), duree: 900e3, nl: {}, dernier: null }; convs.unshift(c); await save("chat_convs", convs.slice(0, 2000)); }
        return json({ id: c.id }, 201); }
      const c = mienne(r1); if (!c) return json({ error: "Discussion introuvable" }, 404);
      const cle = "chat_m_" + c.id;
      if (m === "GET" && r2 === "img") { const mid = tx(r3, 60); const l = await load(cle, []); if (!l.some((x) => x.id === mid && x.img && vivant(x))) return json({ error: "Photo expirée" }, 404);
        const d = await (await storeNomme("chat-img")).get(mid); return json({ d: d && d.d || "" }); }
      if (m === "GET" && !r2) { const tous = await load(cle, []), l = tous.filter(vivant); let ch = l.length !== tous.length; const now = new Date().toISOString();
        for (const x of l) if (!x.sys && x.de !== moi && !(x.lus || {})[moi]) { (x.lus ||= {})[moi] = now; ch = true; }
        if (ch) await save(cle, l); if ((c.nl || {})[moi]) { c.nl[moi] = 0; await save("chat_convs", convs); }
        const autres = c.membres.filter((x) => x !== moi);
        return json({ conv: { id: c.id, type: c.type, nom: nomConv(c), duree: c.duree, moi, createur: c.par === moi, membres: c.membres.map((id) => ({ id, nom: nomDe(id) })) },
          messages: l.map((x) => ({ id: x.id, de: x.de, nom: x.de ? nomDe(x.de) : "", sys: !!x.sys, t: x.t, texte: x.texte || "", img: !!x.img, reac: x.reac || {}, exp: x.exp, vu: x.de === moi ? autres.filter((a) => (x.lus || {})[a]).map(nomDe) : [] })) }); }
      if (me.apercu) return deny();
      if (m === "POST" && !r2) { const texte = tx(body.texte, 2000), img = typeof body.img === "string" && /^data:image\/jpeg;base64,/.test(body.img) && body.img.length < 420000 ? body.img : "";
        if (!texte && !img) return json({ error: "Écris un message" }, 400);
        const l = (await load(cle, [])).filter(vivant), x = { id: uid(), de: moi, t: new Date().toISOString(), texte, img: !!img, exp: new Date(Date.now() + c.duree).toISOString(), lus: { [moi]: new Date().toISOString() }, reac: {} };
        if (img) await (await storeNomme("chat-img")).set(x.id, { d: img }); l.push(x); await save(cle, l.slice(-300));
        c.nl ||= {}; for (const a of c.membres) if (a !== moi) c.nl[a] = (c.nl[a] || 0) + 1; c.dernier = { t: x.t, de: moi, texte: texte ? texte.slice(0, 70) : "📷 Photo", exp: x.exp }; await save("chat_convs", convs);
        await pousser(c, texte || "📷 Photo", c.membres.filter((a) => a !== moi)); return json({ id: x.id }, 201); }
      if (m === "POST" && r2 === "reac") { const l = await load(cle, []), x = l.find((y) => y.id === tx(body.mid, 60)); if (!x || !REAC.includes(body.emoji)) return json({ error: "Message introuvable" }, 404);
        x.reac ||= {}; if (x.reac[moi] === body.emoji) delete x.reac[moi]; else x.reac[moi] = body.emoji; await save(cle, l); return json({ ok: true }); }
      if (m === "DELETE" && r2) { const l = await load(cle, []), x = l.find((y) => y.id === r2); if (!x) return json({ error: "Message introuvable" }, 404);
        if (x.de !== moi && !(estProprio(me) && !me.apercu)) return deny(); if (x.img) await (await storeNomme("chat-img")).del(x.id).catch(() => {}); await save(cle, l.filter((y) => y !== x)); return json({ ok: true }); }
      if (m === "PUT" && !r2) { if (body.duree !== undefined) { const d = Number(body.duree); if (!DUREES.includes(d)) return json({ error: "Durée invalide" }, 400); c.duree = d;
          await save("chat_convs", convs); await sys(c, `${nomDe(moi)} a réglé les messages éphémères sur ${d === 900e3 ? "15 minutes" : d === 3600e3 ? "1 heure" : d === 864e5 ? "24 heures" : d === 7 * 864e5 ? "7 jours" : "30 jours"}`); }
        if (body.nom !== undefined && c.type === "groupe") { const n = tx(body.nom, 40); if (n) { c.nom = n; await save("chat_convs", convs); } } return json({ ok: true }); }
      if (m === "POST" && r2 === "ajouter" && c.type === "groupe") { const ok = new Set(valides()); ok.add("__admin"); const nouveaux = (Array.isArray(body.ids) ? body.ids : []).map((x) => tx(x, 120)).filter((x) => ok.has(x) && !c.membres.includes(x)).slice(0, 20);
        if (!nouveaux.length) return json({ error: "Personne à ajouter" }, 400); c.membres.push(...nouveaux); await save("chat_convs", convs); await sys(c, `${nomDe(moi)} a ajouté ${nouveaux.map(nomDe).join(", ")}`); await pousser(c, "t'a ajouté au groupe", nouveaux); return json({ ok: true }); }
      if (m === "POST" && r2 === "quitter" && c.type === "groupe") { c.membres = c.membres.filter((x) => x !== moi);
        if (!c.membres.length) await save("chat_convs", convs.filter((x) => x !== c)); else { await save("chat_convs", convs); await sys(c, `${nomDe(moi)} a quitté le groupe`); } return json({ ok: true }); }
      return json({ error: "Action inconnue" }, 400);
    }

    /* ---------- v4.64 · Photos de profil : chacun la sienne, le propriétaire et les admins pour tout le monde. Stockées sur le serveur, jamais dans le code ; le client n'y a pas accès ---------- */
    if (r0 === "avatar") {
      if (me.role === "client") return deny();
      if (r1 === "cfg") { const C = await load("avatar_cfg", {}); // v5.58 · réglages du créateur d'avatar
        if (m === "GET") return json({ cfg: C[me.id] || null });
        if (m === "PUT") { if (me.apercu) return deny(); const src = body.cfg && typeof body.cfg === "object" ? body.cfg : null; if (!src) return json({ error: "Avatar invalide" }, 400);
          const cfg = {}; for (const [k, v] of Object.entries(src).slice(0, 30)) { if (!/^[a-z]{1,12}$/.test(k)) continue; if (typeof v === "number" && Number.isFinite(v)) cfg[k] = v; else if (typeof v === "string") cfg[k] = v.slice(0, 30); else if (Array.isArray(v)) cfg[k] = v.filter((x) => typeof x === "string").slice(0, 10).map((x) => x.slice(0, 20)); }
          C[me.id] = cfg; await save("avatar_cfg", C); return json({ ok: true }); }
        return json({ error: "Route inconnue" }, 404); }
      const gere = estProprio(me) || (me.role === "admin" && !me.apercu);
      if (m === "GET" && r1 === "liste") { if (!gere) return deny(); const idx = await load("avatars", {}), users = await load("users", []);
        const cn = (n) => String(n || "").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").split(/[^a-z]+/).filter(Boolean).sort().join(" "), att = await load("avatars_attente", {});
        return json(users.filter((u) => !u.bloque && u.role !== "client").map((u) => ({ id: u.id, nom: u.nom, role: u.role, photo: !!idx[u.id] || !!att[cn(u.nom)] })).sort((a, b) => String(a.nom).localeCompare(String(b.nom), "fr"))); }
      const cleNom = (n) => String(n || "").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").split(/[^a-z]+/).filter(Boolean).sort().join(" ");
      if (m === "GET" && r1 === "etat") return json({ installables: gere && Number(await load("avatars_initiaux_v", (await load("avatars_initiaux_v1", false)) ? 1 : 0)) < (AVATARS_INITIAUX.v || 1) ? AVATARS_INITIAUX.n : 0 });
      if (m === "POST" && r1 === "installer") { // déchiffre les photos de l'équipe avec le code PIN, puis les range au nom de chacun
        if (!gere || me.apercu) return deny(); const B = AVATARS_INITIAUX; let L;
        try { const key = crypto.scryptSync(String(body.code || ""), Buffer.from(B.salt, "base64"), 32, { N: 2 ** 17, r: 8, p: 1, maxmem: 512 * 1024 * 1024 });
          const dc = crypto.createDecipheriv("aes-256-gcm", key, Buffer.from(B.iv, "base64")); dc.setAuthTag(Buffer.from(B.tag, "base64"));
          L = JSON.parse(Buffer.concat([dc.update(Buffer.from(B.data, "base64")), dc.final()]).toString("utf8")); } catch { await journal("profil", me.nom, "code erroné pour installer les photos de l'équipe", "attention"); return json({ error: "Code incorrect" }, 403); }
        const users = await load("users", []), idx = await load("avatars", {}), att = await load("avatars_attente", {}), now = new Date().toISOString(); let places = 0;
        for (const x of L) { const k = cleNom(x.nom), us = users.filter((u) => cleNom(u.nom) === k);
          if (k === cleNom(me.nom) && !us.some((u) => u.id === me.id)) us.push({ id: me.id });
          for (const u of us) { const ex = idx[u.id] ? await load(`avatar/${u.id}`, null) : null; if (!ex || ["M Manager", "Kaelum e-PCS"].includes(ex.par)) { await save(`avatar/${u.id}`, { d: x.d, t: now, par: "Kaelum e-PCS" }); idx[u.id] = now; places++; } }
          att[k] = x.d; }
        await save("avatars", idx); await save("avatars_attente", att); await save("avatars_initiaux_v1", true); await save("avatars_initiaux_v", B.v || 1);
        await journal("profil", me.nom, `photos de l'équipe installées (${L.length})`, "info"); return json({ ok: true, n: L.length, places }); }
      const id = !r1 || r1 === "me" ? me.id : decodeURIComponent(r1);
      if (m === "GET") { const a = await load(`avatar/${id}`, null); if (a) return json({ d: a.d });
        // photo installée au nom de la personne, pas encore rattachée à son compte : rattachée à la première lecture
        const u = id === me.id ? me : (await load("users", [])).find((x) => x.id === id), att = u ? (await load("avatars_attente", {}))[cleNom(u.nom)] : null;
        if (att) { await save(`avatar/${id}`, { d: att, t: new Date().toISOString(), par: "Kaelum e-PCS" }); const idx = await load("avatars", {}); idx[id] = new Date().toISOString(); await save("avatars", idx); }
        return json({ d: att || null }); }
      if (me.apercu) return deny();
      if (id !== me.id && !gere) return deny();
      const idx = await load("avatars", {});
      if (m === "PUT") { const d = String(body.d || ""); if (!/^data:image\/(jpeg|png|webp);base64,/.test(d) || d.length > 400_000) return json({ error: "Photo invalide ou trop lourde" }, 400);
        await save(`avatar/${id}`, { d, t: new Date().toISOString(), par: me.nom }); idx[id] = new Date().toISOString(); await save("avatars", idx);
        await journal("profil", me.nom, id === me.id ? "photo de profil mise à jour" : `photo de profil mise pour un compte`, "info"); return json({ ok: true }); }
      if (m === "DELETE") { await save(`avatar/${id}`, null); delete idx[id]; await save("avatars", idx); return json({ ok: true }); }
    }

    if (r0 === "arena-affect") {
      const coordPC = await estCoord(me), voit = isStaff(me) || estProprio(me) || coordPC || !!me.coordArena || me.role === "ssiap3";
      if (!voit || me.role === "client") return deny();
      const peutModif = !me.apercu && (estProprio(me) || me.role === "admin" || me.role === "pc" || coordPC || !!me.coordArena || (await peutPlanif(me)));
      const date = /^\d{4}-\d{2}-\d{2}$/.test(url.searchParams.get("date") || body.date || "") ? (url.searchParams.get("date") || body.date) : jourParis();
      const toutes = await load("arena_affect", {}), A = toutes[date] || {};
      if (m === "GET") return json({ date, affect: A, peutModif });
      if (m === "PUT") { if (!peutModif) return json({ error: "Affectation réservée au PC, au coordinateur Arena et aux responsables" }, 403);
        const id = String(body.id || "").trim().slice(0, 140), poste = String(body.poste || "").trim().slice(0, 40);
        if (!id) return json({ error: "Agent manquant" }, 400);
        if (poste && !/^[a-z0-9-]+$/i.test(poste)) return json({ error: "Poste invalide" }, 400);
        if (poste) A[id] = { poste, par: me.nom, t: new Date().toISOString() }; else delete A[id];
        toutes[date] = A; for (const d of Object.keys(toutes).sort().slice(0, -60)) delete toutes[d]; await save("arena_affect", toutes);
        await journal("plan Arena", me.nom, `${id.split("|")[0]} ${poste ? "affecté au poste " + poste : "affectation retirée"} (${date.split("-").reverse().join("/")})`, "info", "#/plan");
        return json({ date, affect: A, peutModif }); }
      return json({ error: "Méthode non gérée" }, 405);
    }
    if (r0 === "arena-equipe") {
      const coordPC = await estCoord(me), voit = isStaff(me) || estProprio(me) || coordPC || !!me.coordArena;
      if (!voit) return deny();
      const peutModif = estProprio(me) || me.role === "admin" || me.role === "pc" || coordPC || !!me.coordArena;
      const t = (v, n = 80) => String(v ?? "").trim().slice(0, n);
      if (m === "GET" && r1 === "agents") { const vus = new Map();
        (await load("sms_annuaire", ANNUAIRE_INITIAL)).forEach((a) => a.nom && vus.set(a.nom.toUpperCase(), { nom: a.nom, tel: a.tel || "" }));
        return json([...vus.values()].sort((a, b) => a.nom.localeCompare(b.nom, "fr"))); }
      const date = me.coordArena && !isStaff(me) && !coordPC && !estProprio(me) ? me.coordArena : /^\d{4}-\d{2}-\d{2}$/.test(url.searchParams.get("date") || body.date || "") ? (url.searchParams.get("date") || body.date) : new Date().toISOString().slice(0, 10);
      const toutes = await load("arena_equipes", {}), eq = toutes[date] || { affect: {}, requis: {}, ajouts: [], retires: [] };
      if (m === "PUT") {
        if (!peutModif) return deny();
        const ks = GROUPES_ARENA.map((g) => g[0]).concat("aplacer");
        if (body.affect && typeof body.affect === "object") for (const [id, g] of Object.entries(body.affect).slice(0, 400)) if (ks.includes(g)) eq.affect[t(id, 120)] = g;
        if (body.requis && typeof body.requis === "object") for (const [k, n] of Object.entries(body.requis)) if (ks.includes(k)) eq.requis[k] = Math.max(0, Math.min(200, parseInt(n) || 0));
        if (body.ajout && t(body.ajout.nom)) {
          const n = t(body.ajout.nom).toUpperCase(), dejaPl = (await load("planning", PLANNING_INITIAL)).some((v) => v.date === date && /ARENA/i.test((v.site || "") + " " + (v.poste || "")) && String(v.nom || "").toUpperCase() === n);
          if (dejaPl || eq.ajouts.some((a) => a.nom.toUpperCase() === n)) return json({ error: "Cet ADS est déjà dans l'équipe du jour" }, 400);
          const a = { id: "a" + uid(), nom: t(body.ajout.nom), tel: t(body.ajout.tel, 20).replace(/[^\d+]/g, ""), debut: t(body.ajout.debut, 5), fin: t(body.ajout.fin, 5), par: me.nom };
          eq.ajouts.push(a); eq.affect[a.id] = ks.includes(body.ajout.groupe) ? body.ajout.groupe : "aplacer"; }
        if (body.retirer) { const id = t(body.retirer, 120); eq.ajouts = eq.ajouts.filter((a) => a.id !== id); if (!id.startsWith("a")) eq.retires = [...new Set([...(eq.retires || []), id])]; delete eq.affect[id]; }
        if (body.remettre) eq.retires = (eq.retires || []).filter((x) => x !== t(body.remettre, 120));
        eq.maj = new Date().toISOString(); eq.par = me.nom; toutes[date] = eq;
        for (const d of Object.keys(toutes).sort().slice(0, -60)) delete toutes[d]; // on garde 60 jours
        await save("arena_equipes", toutes);
        await journal("équipe Arena", me.nom, `répartition des ADS du ${date.split("-").reverse().join("/")}`, "info", "#/equipe");
      }
      if (m !== "GET" && m !== "PUT") return json({ error: "Méthode non gérée" }, 405);
      const pl = (await load("planning", PLANNING_INITIAL)).filter((v) => v.date === date && /ARENA/i.test((v.site || "") + " " + (v.poste || "")) && estADS(v) && !estCoordArena(v));
      const auto = (poste) => (GROUPES_ARENA.find((g) => g[2].test(String(poste || "").toUpperCase())) || ["aplacer"])[0];
      const agents = pl.map((v) => { const id = `${v.nom}|${v.debut}`; return { id, nom: v.nom, tel: v.tel || "", debut: v.debut, fin: v.fin, poste: v.poste || "", groupe: eq.affect[id] || auto(v.poste), retire: (eq.retires || []).includes(id) }; })
        .concat(eq.ajouts.map((a) => ({ ...a, poste: "ajouté par " + a.par, groupe: eq.affect[a.id] || "aplacer", ajoute: true })));
      const evs = [...new Set(pl.map((v) => v.evenement).filter(Boolean))];
      const coords = (await load("planning", PLANNING_INITIAL)).filter((v) => v.date === date && estCoordArena(v)).map((v) => v.nom);
      return json({ date, evenement: evs.join(" · "), coordinateurs: coords, modifiable: peutModif, choixDate: !(me.coordArena && !isStaff(me) && !coordPC && !estProprio(me)),
        groupes: GROUPES_ARENA.map(([k, lb]) => ({ k, lb, requis: eq.requis[k] || 0 })), agents: agents.sort((a, b) => a.nom.localeCompare(b.nom, "fr")), maj: eq.maj || "", par: eq.par || "" });
    }

    /* ---------- Demandes de DPAE (déclaration préalable à l'embauche) ---------- */
    if (r0 === "dpae") {
      const coord = await estCoord(me), ok = peutDPAE(me);
      if (!ok && !coord && !["responsable", "admin"].includes(me.role)) return deny(); // données personnelles : pas pour les autres agents
      const t = (v, n = 120) => String(v ?? "").trim().slice(0, n);
      const voitTout = isStaff(me) || coord || estProprio(me); // SSIAP 3 : seulement ses propres demandes, et les noms (sans données personnelles)
      if (m === "GET" && r1 === "agents") { // liste des agents (annuaire + comptes) avec leur fiche si elle existe
        if (!ok && !coord) return deny();
        const fiches = await load("fiches", {}), users = await load("users", []), vus = new Map();
        const cle = (n) => String(n || "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").toUpperCase().split(/[\s()-]+/).filter(Boolean).sort().join(" ");
        for (const u of users) if (AGENTS.includes(u.role)) { const f = fiches[u.id] || {}; vus.set(cle(u.nom), { nom: u.nom, tel: f.tel || u.tel || "", email: f.email || (/@/.test(u.id) ? u.id : ""), naissance: f.naissance || "", adresse: [f.adresse, f.cp, f.ville].filter(Boolean).join(" "), qualif: u.role }); }
        for (const a of await load("sms_annuaire", ANNUAIRE_INITIAL)) if (a.nom && !vus.has(cle(a.nom))) vus.set(cle(a.nom), { nom: a.nom, tel: a.tel || "" });
        const l = [...vus.values()].sort((a, b) => a.nom.localeCompare(b.nom, "fr"));
        return json(voitTout ? l : l.map(({ nom, qualif }) => ({ nom, qualif })));
      }
      if (m === "GET" && r1 === "mail") return json({ email: await load("mail_dpae", PROPRIO()) });
      if (m === "PUT" && r1 === "mail") {
        if (!estProprio(me) && !coord) return deny();
        const e = t(body.email, 300);
        if (e && !e.split(/[,;\s]+/).filter(Boolean).every((x) => /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(x))) return json({ error: "Adresse e-mail invalide" }, 400);
        await save("mail_dpae", e); await journal("admin", me.nom, "adresse des demandes de DPAE modifiée"); return json({ ok: true });
      }
      const list = await load("dpae", []);
      if (m === "GET") return json((voitTout ? list : list.filter((d) => d.demandeurId === me.id)).slice(0, 300));
      if (m === "POST") {
        if (!ok) return json({ error: "Réservé au SSIAP 3" }, 403);
        let nom = t(body.agent, 80), tel = t(body.tel, 20).replace(/[^\d+]/g, ""), nouveau = false;
        if (body.nouveau) {
          const prenom = t(body.prenom, 40), nomF = t(body.nom, 40).toUpperCase();
          if (!prenom || !nomF) return json({ error: "Nom et prénom du nouvel agent obligatoires" }, 400);
          nom = `${prenom} ${nomF}`; nouveau = true;
          const ann = await load("sms_annuaire", ANNUAIRE_INITIAL);
          if (!ann.some((a) => a.nom.toUpperCase() === nom.toUpperCase())) { ann.push({ nom, tel }); await save("sms_annuaire", ann.slice(0, 2000)); }
        }
        if (!nom) return json({ error: "Choisis un agent ou crée-le" }, 400);
        if (!body.nouveau) { // agent connu : coordonnées reprises de sa fiche côté serveur (le SSIAP 3 ne les voit pas)
          const u = (await load("users", [])).find((x) => memeAgent({ nom }, { nom: x.nom })), f = u ? (await load("fiches", {}))[u.id] || {} : {};
          body.email ||= f.email || (u && /@/.test(u.id) ? u.id : ""); body.naissance ||= f.naissance || ""; body.adresse ||= [f.adresse, f.cp, f.ville].filter(Boolean).join(" ");
          if (!tel) tel = String(f.tel || (u && u.tel) || (await load("sms_annuaire", ANNUAIRE_INITIAL)).find((a) => memeAgent({ nom }, a))?.tel || "").replace(/[^\d+]/g, ""); }
        const d = {
          id: uid(), numero: "DPAE-" + new Date().getFullYear() + "-" + String(list.length + 1).padStart(4, "0"), t: new Date().toISOString(),
          demandeur: me.nom, demandeurId: me.id, agent: nom, nouveau, tel, email: t(body.email, 120).toLowerCase(),
          naissance: /^\d{4}-\d{2}-\d{2}$/.test(body.naissance || "") ? body.naissance : "", lieuNaissance: t(body.lieuNaissance, 80), nationalite: t(body.nationalite, 40), adresse: t(body.adresse, 200),
          qualif: ["ADS", "SSIAP 1", "SSIAP 2", "SSIAP 3", "ADS + SSIAP 1"].includes(body.qualif) ? body.qualif : "ADS",
          contrat: ["CDD d'usage", "CDD", "CDI", "Extra / vacation"].includes(body.contrat) ? body.contrat : "CDD d'usage",
          debut: /^\d{4}-\d{2}-\d{2}$/.test(body.debut || "") ? body.debut : "", heure: /^\d{2}:\d{2}$/.test(body.heure || "") ? body.heure : "", fin: /^\d{4}-\d{2}-\d{2}$/.test(body.fin || "") ? body.fin : "",
          site: t(body.site, 60), evenement: t(body.evenement, 120), poste: t(body.poste, 80), commentaire: t(body.commentaire, 1000),
          nirFourni: !!t(body.nir, 30), statut: "demandée", suivi: [],
        };
        if (!d.debut) return json({ error: "Date d'embauche obligatoire" }, 400);
        const nir = t(body.nir, 30).replace(/\s/g, ""); // le n° de sécurité sociale part seulement dans le mail, il n'est pas conservé dans l'appli
        list.unshift(d); await save("dpae", list.slice(0, 2000));
        const fr = (x) => (x ? x.split("-").reverse().join("/") : "");
        await mailVers(await load("mail_dpae", PROPRIO()), `Demande de DPAE ${d.numero} — ${d.agent}`, [["Demandée par", `${me.nom} (SSIAP 3)`], ["Agent", d.agent + (nouveau ? " (nouvel agent)" : "")],
          ["Téléphone", d.tel], ["E-mail", d.email], ["Date de naissance", fr(d.naissance)], ["Lieu de naissance", d.lieuNaissance], ["Nationalité", d.nationalite], ["Adresse", d.adresse], ["N° de sécurité sociale", nir],
          ["Qualification", d.qualif], ["Contrat", d.contrat], ["Embauche le", `${fr(d.debut)}${d.heure ? " à " + d.heure : ""}`], ["Fin de contrat", fr(d.fin)],
          ["Site", ERP(d.site)], ["Événement", d.evenement], ["Poste", d.poste], ["Commentaire", d.commentaire]], [], "Service DPAE");
        await journal("DPAE", me.nom, `${d.numero} · ${d.agent} · ${fr(d.debut)}`, "info", "#/dpae");
        return json(d, 201);
      }
      if (m === "PATCH" && r1) {
        if (!ok && !coord) return deny();
        const d = list.find((x) => x.id === r1); if (!d) return json({ error: "Introuvable" }, 404);
        if (!voitTout && d.demandeurId !== me.id) return deny();
        if (["demandée", "faite", "annulée"].includes(body.statut)) d.statut = body.statut;
        if (t(body.note, 300)) d.suivi.push({ t: new Date().toISOString(), qui: me.nom, note: t(body.note, 300) });
        await save("dpae", list); return json(d);
      }
      return json({ error: "Méthode non gérée" }, 405);
    }

    /* ---------- Rondes ---------- */
    if (r0 === "rondes") {
      if (r1 === "points") return json(await load("rondes_points", DEFAULT_RONDES));
      let list = await load("rondes", []);
      if (m === "GET") {
        if (!isStaff(me)) list = list.filter((p) => p.agentId === me.id);
        return json(list.slice(0, 500));
      }
      if (m === "POST") {
        const tHL = Date.parse(body.saisieLe || ""), tRonde = tHL && tHL <= Date.now() + 6e4 && Date.now() - tHL < 3 * 864e5 ? new Date(tHL).toISOString() : new Date().toISOString(); // v5.23 : ronde saisie hors ligne = heure réelle
        const p = { id: uid(), t: tRonde, agentId: me.id, agent: me.nom,
          point: String(body.point || "").slice(0, 80), obs: String(body.obs || "").slice(0, 500),
          ras: body.ras !== false };
        list.unshift(p);
        await save("rondes", list.slice(0, 5000));
        if (!p.ras) await journal("ronde", me.nom, `Anomalie · ${p.point} · ${p.obs}`, "attention", "#/rondes");
        return json(p, 201);
      }
    }

    /* ---------- Gestion des clés (boîte à clés PC, clés organisateurs Parc / Arena) ---------- */
    if (r0 === "cles") {
      const liste = await load("cles", CLES_INITIAL), etat = await load("cles_etat", {});
      if (m === "GET" && !r1 && me.role === "client") { const L = liste.filter(cleOrga), ok = new Set(L.map((c) => c.n));
        return json({ liste: L, etat: anonyme(Object.fromEntries(Object.entries(etat).filter(([k]) => ok.has(k)))), client: true }); }
      if (me.role === "client") return deny();
      if (m === "GET" && !r1) return json({ liste, etat: isStaff(me) || estProprio(me) ? etat : Object.fromEntries(Object.entries(etat).map(([k, e]) => [k, { ...e, tel: "", piece: "" }])) });
      if (m === "GET" && r1 === "agents" && !isStaff(me) && !estProprio(me)) return json([]);
      if (m === "GET" && r1 === "agents") { // noms des agents de sécurité (sans numéros) pour la remise de clés
        const noms = new Map(); const add = (n) => { const k = String(n || "").trim(); if (k && !noms.has(k.toLowerCase())) noms.set(k.toLowerCase(), k); };
        (await load("users", [])).forEach((u) => add(u.nom)); (await load("sms_annuaire", ANNUAIRE_INITIAL)).forEach((a) => add(a.nom));
        return json([...noms.values()].sort((a, b) => a.localeCompare(b, "fr")));
      }
      if (m === "GET" && r1 === "historique") { const n = url.searchParams.get("n"); let h = await load("cles_mvt", []); if (!isStaff(me) && !estProprio(me)) h = h.filter((x) => x.parId === me.id).map(({ tel, piece, ...x }) => x); return json((n ? h.filter((x) => x.n === n) : h).slice(0, 400)); }
      if (m === "PUT" && !r1) {
        if (!(await estCoord(me))) return json({ error: "Réservé à la coordination" }, 403);
        const t = (v, n = 160) => String(v ?? "").trim().slice(0, n), vus = new Set();
        const out = (Array.isArray(body.liste) ? body.liste : []).slice(0, 600).map((c) => ({ n: t(c.n, 12), nom: t(c.nom), boite: t(c.boite, 80) })).filter((c) => c.n && c.nom && !vus.has(c.n) && vus.add(c.n));
        await save("cles", out); await journal("clés", me.nom, `liste des clés modifiée (${out.length})`, "info", "#/cles");
        return json({ ok: true, nb: out.length });
      }
      const cle = liste.find((c) => c.n === r1); if (!cle) return json({ error: "Clé introuvable" }, 404);
      const t = (v, n = 120) => String(v ?? "").trim().slice(0, n);
      const mvt = await load("cles_mvt", []);
      if (m === "POST" && r2 === "sortie") {
        if (etat[cle.n]) return json({ error: `Clé déjà sortie (remise à ${etat[cle.n].nom})` }, 400);
        const e = { cat: ["agent", "sploe", "prestataire", "orga"].includes(body.type) ? body.type : "", nom: t(body.nom), societe: t(body.societe), tel: t(body.tel, 20), motif: t(body.motif, 200), retour: /^\d{2}:\d{2}$/.test(body.retour || "") ? body.retour : "",
          piece: t(body.piece, 60), t: new Date().toISOString(), par: me.nom, parId: me.id };
        if (!e.nom) return json({ error: "Indique à qui la clé est remise" }, 400);
        etat[cle.n] = e; await save("cles_etat", etat);
        mvt.unshift({ id: uid(), n: cle.n, cle: cle.nom, type: "sortie", ...e }); await save("cles_mvt", mvt.slice(0, 5000));
        await journal("clés", me.nom, `🔑 ${cle.n} ${cle.nom} remise à ${e.nom}${e.societe ? " (" + e.societe + ")" : ""}`, "info", "#/cles");
        return json({ etat });
      }
      if (m === "POST" && r2 === "retour") {
        const e = etat[cle.n]; if (!e) return json({ error: "Cette clé est déjà au tableau" }, 400);
        delete etat[cle.n]; await save("cles_etat", etat);
        const duree = Math.round((Date.now() - Date.parse(e.t)) / 60000);
        mvt.unshift({ id: uid(), n: cle.n, cle: cle.nom, type: "retour", nom: e.nom, societe: e.societe, sortie: e.t, duree, obs: /^\s*ras\s*$/i.test(body.obs || "") ? "" : t(body.obs, 300), t: new Date().toISOString(), par: me.nom, parId: me.id });
        await save("cles_mvt", mvt.slice(0, 5000));
        await journal("clés", me.nom, `✅ ${cle.n} ${cle.nom} restituée par ${e.nom}${mvt[0].obs ? " · " + mvt[0].obs : ""}`, mvt[0].obs ? "attention" : "info", "#/cles");
        return json({ etat });
      }
    }

    /* ---------- Ouverture / fermeture des bâtiments et éclairage ---------- */
    if (r0 === "batiments") {
      const HALLS = TENANT() ? [] : ["Accueil A", "Hall A1", "Hall A2", "Hall A3", "Hall A4", "Hall A5", "Hall A6", "Accueil B", "Hall B1", "Hall B2", "Hall B3", "Hall B4", "Hall B5", "Centre de conférences", "Arena Sud de France"];
      const etat = await load("batiments_etat", {});
      if (m === "GET" && !r1) return json({ halls: HALLS, etat: me.role === "client" ? anonyme(etat) : etat });
      if (m === "GET" && r1 === "historique" && me.role === "client") return json(anonyme(await load("batiments_mvt", [])).slice(0, 400));
      if (m === "GET" && r1 === "historique") return json((await load("batiments_mvt", [])).filter((x) => isStaff(me) || estProprio(me) || x.par === me.nom).slice(0, 400));
      if (m === "POST" && !r1) {
        const t = (v, n = 120) => String(v ?? "").trim().slice(0, n);
        const halls = (Array.isArray(body.halls) ? body.halls : []).filter((h) => HALLS.includes(h));
        const ACT = { ouverture: "Ouverture", fermeture: "Fermeture", eclairage_on: "Mise en fonction éclairage", eclairage_off: "Mise hors fonction éclairage" };
        const actions = (Array.isArray(body.actions) ? body.actions : []).filter((a) => ACT[a]);
        if (!halls.length) return json({ error: "Choisis au moins un hall" }, 400);
        if (!actions.length) return json({ error: "Choisis au moins une opération" }, 400);
        const dem = { type: ["prestataire", "organisateur", "sploe", "pc", "autre"].includes(body.demType) ? body.demType : "autre", societe: t(body.demSociete), nom: t(body.demNom) };
        const mv = { id: uid(), t: new Date().toISOString(), halls, actions, libelle: actions.map((a) => ACT[a]).join(" + "), dem, commentaire: t(body.commentaire, 500), par: me.nom };
        for (const h of halls) { const e = etat[h] || {};
          if (actions.includes("ouverture")) e.ouvert = true; if (actions.includes("fermeture")) e.ouvert = false;
          if (actions.includes("eclairage_on")) e.eclairage = true; if (actions.includes("eclairage_off")) e.eclairage = false;
          e.maj = mv.t; e.par = me.nom; etat[h] = e; }
        await save("batiments_etat", etat);
        const mvt = await load("batiments_mvt", []); mvt.unshift(mv); await save("batiments_mvt", mvt.slice(0, 5000));
        const qui = { prestataire: "Prestataire", organisateur: "Organisateur", sploe: "SPL OE", pc: "PC sécurité", autre: "Autre" }[dem.type];
        await journal("bâtiments", me.nom, `🏢 ${mv.libelle} · ${halls.join(", ")} · demande : ${qui}${dem.societe ? " " + dem.societe : ""}${dem.nom ? " (" + dem.nom + ")" : ""}`, "info", "#/batiments");
        return json({ etat, mv });
      }
    }

    /* ---------- Notifications push ---------- */
    if (r0 === "push") {
      if (m === "GET" && r1 === "cle") return json({ cle: (await vapid()).cle });
      if (m === "GET" && r1 === "dernier") return json((await load("push_dernier", null)) || { titre: "Kaelum e-PCS", texte: "Nouvelle notification", url: "/#/" });
      if (r1 === "abonner") {
        const abos = await load("push_abos", {}), moi = me.id === "__admin" ? PROPRIO() : me.id;
        const sub = body.subscription;
        if (m === "POST") { if (!sub || !/^https:\/\//.test(sub.endpoint || "")) return json({ error: "Abonnement invalide" }, 400);
          for (const k of Object.keys(abos)) abos[k] = abos[k].filter((x) => x.endpoint !== sub.endpoint); // un téléphone = un seul compte
          abos[moi] = [...(abos[moi] || []), { endpoint: sub.endpoint, t: new Date().toISOString() }].slice(-5);
          await save("push_abos", abos); return json({ ok: true }); }
        if (m === "DELETE") { abos[moi] = (abos[moi] || []).filter((x) => !sub || x.endpoint !== sub.endpoint); await save("push_abos", abos); return json({ ok: true }); }
      }
      if (m === "POST" && r1 === "test") { const moi = me.id === "__admin" ? PROPRIO() : me.id;
        const n = await envoyerPush({ titre: "Kaelum e-PCS — test", texte: "Les notifications sonores fonctionnent sur ce téléphone.", url: "/#/" }, (u) => u.id === moi);
        return json({ envoyes: n, abonnements: ((await load("push_abos", {}))[moi] || []).length, details: envoyerPush.details || [] }); }
      if (m === "GET" && r1 === "journal") { if (!isStaff(me) && !estProprio(me)) return deny(); return json(await load("push_log", [])); }
      return json({ error: "Méthode non gérée" }, 405);
    }

    /* ---------- Planification (type Comète) ---------- */
    /* ---------- v4.23 · Registre des moyens de secours et d'extinction (par hall), alimenté par les rondes SSIAP ---------- */
    if (r0 === "moyens") {
      const SUR = (url.searchParams.get("reg") || body.reg) === "surete", CLE = SUR ? "rondes_surete" : "moyens_secours", TYPESL = SUR ? SURETE_TYPES : MOYENS_TYPES;
      const SSIAPS = SUR ? ["ads", "ssiap1", "ssiap2", "pc", "admin"] : ["ssiap1", "ssiap2", "pc", "admin"], lit = SSIAPS.includes(me.role) || estProprio(me) || me.role === "responsable" || isStaff(me); // secours : SSIAP 1 et SSIAP 2 du PCS ; sûreté / fermeture : ADS (+ PCS)
      if (!lit || me.role === "client") return json({ error: SUR ? "Rondes de fermeture réservées aux ADS, au PCS et aux responsables" : "Registre réservé aux SSIAP 1, au PCS (SSIAP 2) et aux responsables" }, 403);
      const ronde = SSIAPS.includes(me.role) || estProprio(me), gere = ["ssiap2", "pc", "admin"].includes(me.role) || estProprio(me) || me.roleAgent === "ssiap2";
      const t = (v, n = 120) => String(v ?? "").trim().slice(0, n), TYPES = TYPESL.map((x) => x[0]);
      const R = { items: [], rondes: [], ...(await load(CLE, {})) };
      const now = new Date().toISOString(), tr = (it, etat, note, quoi) => { it.historique = [{ t: now, par: me.nom, etat, note: note || "", quoi }, ...(it.historique || [])].slice(0, 30); };
      if (m === "GET") return json({ ...R, types: TYPESL, peutRonde: ronde, peutGerer: gere, reg: SUR ? "surete" : "secours" });
      if (m === "POST" && r1 === "item") { if (!ronde) return deny(); // un équipement (ajouté en ronde ou à la main)
        const it = { id: uid(), hall: t(body.hall, 60), type: TYPES.includes(body.type) ? body.type : "AUTRE", numero: t(body.numero, 30), emplacement: t(body.emplacement, 160), detail: t(body.detail, 120), etat: "ok", cree: now, creePar: me.nom, historique: [] };
        if (t(body.libelle, 60)) it.libelle = t(body.libelle, 60); // v5.20 · « Autre » : nom libre (ce qu'on veut)
        if (body.pos && Number.isFinite(+body.pos.x) && Number.isFinite(+body.pos.y)) it.pos = { plan: body.pos.plan === "arena" ? "arena" : "site", x: Math.round(+body.pos.x * 10) / 10, y: Math.round(+body.pos.y * 10) / 10 }; // ajouté directement depuis le plan
        if (!it.hall) return json({ error: "Hall obligatoire" }, 400);
        if (R.items.some((x) => x.hall === it.hall && x.type === it.type && it.numero && x.numero === it.numero)) return json({ error: "Ce numéro existe déjà dans ce hall" }, 409);
        tr(it, "ok", "", "ajouté"); R.items.push(it); await save(CLE, R); return json(it, 201); }
      if (m === "PUT" && r1 === "item" && r2 && r3 === "pos") { if (!(ronde || gere)) return deny(); // v4.33 · position sur le plan interactif (site ou Arena)
        const it = R.items.find((x) => x.id === r2); if (!it) return json({ error: "Introuvable" }, 404);
        if (body.effacer) it.pos = null; else { const x = +body.x, y = +body.y; if (!Number.isFinite(x) || !Number.isFinite(y)) return json({ error: "Position invalide" }, 400);
          it.pos = { plan: body.plan === "arena" ? "arena" : "site", x: Math.round(x * 10) / 10, y: Math.round(y * 10) / 10 }; }
        tr(it, it.etat, "", it.pos ? "placé sur le plan" : "retiré du plan"); await save(CLE, R); return json(it); }
      if (m === "PUT" && r1 === "item" && r2) { if (!gere) return deny(); const it = R.items.find((x) => x.id === r2); if (!it) return json({ error: "Introuvable" }, 404);
        Object.assign(it, { hall: t(body.hall, 60) || it.hall, type: TYPES.includes(body.type) ? body.type : it.type, numero: t(body.numero, 30), emplacement: t(body.emplacement, 160), detail: t(body.detail, 120) }); if (body.libelle !== undefined) { if (t(body.libelle, 60)) it.libelle = t(body.libelle, 60); else delete it.libelle; } tr(it, it.etat, "", "modifié");
        await save(CLE, R); return json(it); }
      if (m === "DELETE" && r1 === "item" && r2) { if (!gere) return deny(); const it = R.items.find((x) => x.id === r2); if (!it) return json({ error: "Introuvable" }, 404);
        R.items = R.items.filter((x) => x !== it); await save(CLE, R); await journal("moyens de secours", me.nom, `équipement retiré du registre : ${it.type} ${it.numero} · ${it.hall}`, "info", "#/moyens"); return json({ ok: true }); }
      if (m === "POST" && r1 === "ronde") { if (!ronde) return deny(); // résultat d'une ronde sur un hall
        const hall = t(body.hall, 60), res = Array.isArray(body.resultats) ? body.resultats.slice(0, 600) : [], genre = SUR ? (body.genre === "malveillance" ? "Ronde malveillance" : "Ronde de fermeture") : "Ronde moyens de secours", obs = t(body.observations, 2000);
        if (!hall || !res.length) return json({ error: "Hall et contrôles obligatoires" }, 400);
        let nOk = 0; const nouvelles = [], rectifiees = [], persistantes = [];
        for (const x of res) { const it = R.items.find((y) => y.id === x.id && y.hall === hall); if (!it) continue;
          const etat = x.etat === "anomalie" ? "anomalie" : "ok", note = t(x.note, 300);
          if (etat === "ok") { nOk++; if (it.etat === "anomalie") { rectifiees.push(it); tr(it, "ok", note, "anomalie rectifiée"); } else tr(it, "ok", "", "contrôlé"); it.etat = "ok"; it.anomalie = null; }
          else { if (it.etat === "anomalie") { persistantes.push(it); it.anomalie = { ...it.anomalie, note: note || it.anomalie?.note || "", vu: now, par2: me.nom }; tr(it, "anomalie", note, "toujours en anomalie"); }
            else { nouvelles.push(it); it.anomalie = { t: now, par: me.nom, note }; tr(it, "anomalie", note, "anomalie constatée"); }
            it.etat = "anomalie";
            if (typeof x.photo === "string" && x.photo.startsWith("data:image/") && x.photo.length < MAX_PHOTO) { await save(`photo/moyen-${it.id}`, { d: x.photo, auteurId: me.id, moyen: true }); it.anomalie.photo = true; } }
          it.dernierControle = { t: now, par: me.nom }; }
        const points = res.filter((x) => R.items.some((y) => y.id === x.id)).map((x, i) => ({ id: String(x.id).slice(0, 40), e: x.etat === "anomalie" ? "a" : "o", t: Number.isFinite(+x.t) ? +x.t : i })).sort((a, b) => a.t - b.t).map(({ id, e }) => ({ id, e })); // v4.33 · ordre de passage (tracé sur le plan)
        const rd = { id: uid(), t: now, par: me.nom, hall, genre, observations: obs, controles: res.length, ok: nOk, nouvelles: nouvelles.length, rectifiees: rectifiees.length, persistantes: persistantes.length, points, debut: Number.isFinite(+body.debut) && +body.debut > 0 ? new Date(+body.debut).toISOString() : null };
        R.rondes = [rd, ...R.rondes].slice(0, 500); R.rondes.forEach((x, i) => { if (i >= 60) delete x.points; }); await save(CLE, R);
        const lib = (it) => `${TYPESL.find((y) => y[0] === it.type)?.[1] || it.type} ${it.numero || ""}${it.emplacement ? " (" + it.emplacement + ")" : ""}${it.anomalie?.note ? " : " + it.anomalie.note : ""}`.trim();
        if (nouvelles.length || rectifiees.length || persistantes.length || obs || SUR)
          await mcSysteme(me, genre, `${SUR ? genre : "Ronde moyens de secours et d'extinction"} — ${hall} : ${res.length} point(s), ${nOk} ${SUR ? "OK / fermé(s)" : "conforme(s)"}.${nouvelles.length ? ` Nouvelles anomalies : ${nouvelles.map(lib).join(" ; ")}.` : ""}${persistantes.length ? ` Toujours en anomalie : ${persistantes.map(lib).join(" ; ")}.` : ""}${rectifiees.length ? ` Rectifiées : ${rectifiees.map(lib).join(" ; ")}.` : ""}${obs ? " Observations : " + obs : ""}`.slice(0, 4000), nouvelles.length ? "moyenne" : "info", { lieu: hall, site: /arena/i.test(hall) ? "Arena Sud de France" : "Parc des Expositions", statut: nouvelles.length || persistantes.length ? "ouvert" : "clos" });
        await journal(SUR ? "rondes de fermeture" : "moyens de secours", me.nom, `${SUR ? genre.toLowerCase() : "ronde"} ${hall} : ${nOk}/${res.length} conformes${nouvelles.length ? ` · ${nouvelles.length} nouvelle(s) anomalie(s)` : ""}${rectifiees.length ? ` · ${rectifiees.length} rectifiée(s)` : ""}`, nouvelles.length ? "attention" : "info", SUR ? "#/surete" : "#/moyens");
        return json({ ronde: rd, nouvelles: nouvelles.length, rectifiees: rectifiees.length, persistantes: persistantes.length });
      }
      return json({ error: "Requête invalide" }, 400);
    }
    /* ---------- v4.16 · Commande client → planning proposé (planificateurs : Jérémy Mercher, propriétaire) ---------- */
    if (r0 === "specialites") { // v4.93 · spécialités des agents (postes maîtrisés), utilisées par la proposition de planning
      if (!(await peutSpecialites(me))) return json({ error: "Réservé à Rochdi, Jérémy Mercher et Laurent Hernandez" }, 403);
      const P = globalThis.PLANIF, SP = await load("specialites", {});
      if (m === "GET") { const pl = await load("planning", PLANNING_INITIAL), d0 = new Date(Date.now() - 180 * 864e5).toISOString().slice(0, 10), ag = new Map(), freq = {};
        for (const v of pl) { if (!v.nom || /^NON AFFECT/i.test(v.nom) || v.date < d0) continue; const k = P.cleAgent(v.nom); if (!k) continue;
          const a = ag.get(k) || { cle: k, nom: v.nom, qualif: "", postes: {}, n: 0 }; a.n++; a.qualif = P.qualifPaie(v) || a.qualif; const pp = String(v.poste || "").trim(); if (pp) { a.postes[pp] = (a.postes[pp] || 0) + 1; freq[pp] = (freq[pp] || 0) + 1; } ag.set(k, a); }
        for (const u of await load("users", [])) { if (!AGENTS.includes(u.role) || u.actif === false) continue; const k = P.cleAgent(u.nom); if (k && !ag.has(k)) ag.set(k, { cle: k, nom: u.nom, qualif: ROLE_POSTE[u.role] || "", postes: {}, n: 0 }); }
        for (const [k, x] of Object.entries(SP)) if (!ag.has(k)) ag.set(k, { cle: k, nom: x.nom, qualif: "", postes: {}, n: 0 });
        return json({ agents: [...ag.values()].map((a) => ({ cle: a.cle, nom: a.nom, qualif: a.qualif, vacations: a.n, habitudes: Object.entries(a.postes).sort((x, y) => y[1] - x[1]).slice(0, 4).map(([p0, n]) => ({ poste: p0, n })), specialites: (SP[a.cle] || {}).specialites || [], cdi: !!(SP[a.cle] || {}).cdi, note: (SP[a.cle] || {}).note || "", par: (SP[a.cle] || {}).par || "" })).sort((a, b) => a.nom.localeCompare(b.nom, "fr")),
          suggestions: Object.entries(freq).sort((a, b) => b[1] - a[1]).slice(0, 60).map(([p0]) => p0),
          postesCommandes: Object.values(await load("postes_commandes", {})).sort((a, b) => String(b.dernier).localeCompare(String(a.dernier)) || b.n - a.n).slice(0, 120).map(({ poste, qualif, site, n, evenements, dernier }) => ({ poste, qualif, site, n, evenements, dernier })) }); }
      if (m === "DELETE" && r1 === "poste") { const PC = await load("postes_commandes", {}), k = normPoste(body.poste || url.searchParams.get("poste") || ""); if (PC[k]) { delete PC[k]; await save("postes_commandes", PC); } return json({ ok: true }); }
      if (m === "PUT") { const nom = String(body.nom || "").trim().slice(0, 80), k = P.cleAgent(nom); if (!k) return json({ error: "Agent introuvable" }, 400);
        const liste = [...new Set((Array.isArray(body.specialites) ? body.specialites : []).map((x) => String(x || "").trim().slice(0, 60)).filter(Boolean))].slice(0, 15);
        if (!liste.length && !body.note && !body.cdi) delete SP[k]; else SP[k] = { nom, specialites: liste, cdi: !!body.cdi, note: String(body.note || "").trim().slice(0, 300), par: me.nom, t: new Date().toISOString() };
        await save("specialites", SP); await journal("planification", me.nom, `spécialités de ${nom} : ${liste.join(", ") || "aucune"}`, "info"); return json(SP[k] || { nom, specialites: [] }); }
      return json({ error: "Requête invalide" }, 400);
    }
    if (r0 === "commande") {
      if (!(await peutPlanif(me))) return json({ error: "Réservé aux planificateurs (Jérémy Mercher)" }, 403);
      if (!planifOuvert()) return json({ error: "Planification verrouillée : entre le code d'accès", verrouPlanif: true }, 423);
      const P = globalThis.PLANIF, t = (v, n = 120) => String(v ?? "").trim().slice(0, n), HM = /^([01]\d|2[0-3]):[0-5]\d$/, D8 = /^\d{4}-\d{2}-\d{2}$/;
      const QL = ["ADS", "SSIAP 1", "SSIAP 2", "SSIAP 3", "Chef d'équipe", "Cynophile"], RANG = { "ADS": 0, "Cynophile": 0, "SSIAP 1": 1, "Chef d'équipe": 1, "SSIAP 2": 2, "SSIAP 3": 3 };
      const normQ = (q) => { const s = String(q || "").toUpperCase(); return /CYNO/.test(s) ? "Cynophile" : /SSIAP\s*3/.test(s) ? "SSIAP 3" : /SSIAP\s*2/.test(s) ? "SSIAP 2" : /SSIAP/.test(s) ? "SSIAP 1" : /CHEF/.test(s) ? "Chef d'équipe" : "ADS"; };
      const besoinOk = (b) => ({ date: D8.test(b.date || "") ? b.date : "", debut: HM.test(b.debut || "") ? b.debut : "", fin: HM.test(b.fin || "") ? b.fin : "", poste: t(b.poste, 80) || normQ(b.qualif), qualif: QL.includes(b.qualif) ? b.qualif : normQ(b.qualif || b.poste), nombre: Math.max(1, Math.min(80, parseInt(b.nombre) || 1)), notes: t(b.notes, 200) });
      if (m === "GET" && r1 === "brouillons") return json((await load("commandes", [])).slice(0, 20));
      if (m === "GET" && r1 === "etat") return json({ ia: !!process.env.ANTHROPIC_API_KEY });
      if (m === "POST" && r1 === "extraire") {
        const an = jourParis().slice(0, 4), texte = t(body.texte, 60000), f = String(body.fichier || ""), mm = f.match(/^data:(image\/(?:jpeg|png|webp|gif)|application\/pdf);base64,(.+)$/);
        let res = null, mode = "";
        if (process.env.ANTHROPIC_API_KEY && (mm || texte)) {
          const consigne = `Tu lis une commande de prestation de sécurité (agents de sécurité ADS, SSIAP 1/2/3, chef d'équipe, cynophile) envoyée par un client pour le Parc des Expositions ou l'Arena Sud de France (Pérols). Extrais les besoins du DISPOSITIF SÉCURITÉ uniquement (sécurité incendie, entrées / fouilles, salle, scène, salle production, extérieurs et parkings…). IGNORE totalement le dispositif contrôle (contrôleurs billets, chef contrôleur, agents de placement, consigne, point info), le nettoyage, le tri des déchets, les traiteurs et les demandes du régisseur. Dans un tableau « Désignation | Début | Fin | Hrs jour | Hrs nuit | Agts », chaque ligne = un poste : Début/Fin = horaires, Agts = nombre d'agents (2,00 = 2 ; 0 = ignorer la ligne), l'intitulé « ADS - Régie » donne le poste « Régie » en ADS, « SSIAP 1 » donne le poste SSIAP 1. La date est souvent dans l'en-tête ou le pied de page (ex. « JEUDI 8 Octobre 2026 »). Réponds UNIQUEMENT avec un JSON valide, sans texte autour :
{"client":"","evenement":"","site":"Parc des Expositions | Arena Sud de France","besoins":[{"date":"AAAA-MM-JJ","debut":"HH:MM","fin":"HH:MM","poste":"intitulé du poste (ex. Accueil Hall A, Portail P3, PC sécurité)","qualif":"ADS | SSIAP 1 | SSIAP 2 | SSIAP 3 | Chef d'équipe | Cynophile","nombre":1,"notes":""}]}
Règles : une ligne par jour, par plage horaire et par poste. Si l'année manque, prends ${an}. Si le poste n'est pas précisé, mets la qualification. « Agent de sécurité », « APS », « agent » = ADS. Ne devine pas de besoins absents de la commande.`;
          const contenu = mm ? [mm[1] === "application/pdf" ? { type: "document", source: { type: "base64", media_type: "application/pdf", data: mm[2] } } : { type: "image", source: { type: "base64", media_type: mm[1], data: mm[2] } }, { type: "text", text: consigne + (texte ? "\n\nTexte complémentaire :\n" + texte.slice(0, 20000) : "") }] : [{ type: "text", text: consigne + "\n\nCommande :\n" + texte }];
          try { const r = await fetch("https://api.anthropic.com/v1/messages", { method: "POST", headers: { "content-type": "application/json", "x-api-key": process.env.ANTHROPIC_API_KEY, "anthropic-version": "2023-06-01" },
              body: JSON.stringify({ model: process.env.ANTHROPIC_MODEL || "claude-haiku-4-5", max_tokens: 6000, messages: [{ role: "user", content: contenu }] }) });
            const d = await r.json(); if (!r.ok) throw new Error((d.error && d.error.message) || "Erreur " + r.status);
            const txt = (d.content || []).map((c) => c.text || "").join(""), js = txt.slice(txt.indexOf("{"), txt.lastIndexOf("}") + 1); res = JSON.parse(js); mode = "ia";
          } catch (e) { if (!texte) return json({ error: "Lecture automatique impossible : " + String(e.message || e).slice(0, 160) }, 502); }
        }
        if (!res && texte) { // lecture simple du texte (sans IA) : dates, horaires, « 3 ADS », « 1 SSIAP 2 »…
          const MOIS = ["janvier", "fevrier", "mars", "avril", "mai", "juin", "juillet", "aout", "septembre", "octobre", "novembre", "decembre"], besoins = []; let d = "", h1 = "", h2 = "";
          const n0 = (s) => s.normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase();
          for (const brut of texte.split(/\n+/)) { const l = n0(brut);
            let x = l.match(/\b(\d{1,2})[\/.-](\d{1,2})(?:[\/.-](\d{2,4}))?\b/); if (x) d = `${x[3] ? (x[3].length === 2 ? "20" + x[3] : x[3]) : an}-${x[2].padStart(2, "0")}-${x[1].padStart(2, "0")}`;
            x = l.match(/\b(\d{1,2})(?:er)?\s+(janvier|fevrier|mars|avril|mai|juin|juillet|aout|septembre|octobre|novembre|decembre)(?:\s+(\d{4}))?/); if (x) d = `${x[3] || an}-${String(MOIS.indexOf(x[2]) + 1).padStart(2, "0")}-${x[1].padStart(2, "0")}`;
            x = l.match(/(\d{1,2})\s*[h:]\s*(\d{0,2})\s*(?:-|a|à|>|au|jusqu.a)\s*(\d{1,2})\s*[h:]\s*(\d{0,2})/); if (x) { h1 = `${x[1].padStart(2, "0")}:${(x[2] || "00").padStart(2, "0")}`; h2 = `${x[3].padStart(2, "0")}:${(x[4] || "00").padStart(2, "0")}`; }
            const re = /(\d{1,3})\s*(?:x\s*)?(agents?\s+de\s+securite|agents?|ads|aps|ssiap\s*[123]|chefs?\s+d.equipe|cynophiles?|maitres?[- ]chiens?)/g; let q;
            const propre = brut.replace(/(\d{1,2})\s*[h:]\s*(\d{0,2})\s*(?:-|à|a|>|au)\s*(\d{1,2})\s*[h:]\s*(\d{0,2})/gi, " ").replace(/\b\d{1,3}\s*(?:x\s*)?(agents?\s+de\s+s[ée]curit[ée]|agents?|ads|aps|ssiap\s*[123]|chefs?\s+d.[ée]quipe|cynophiles?)\b/gi, " ").replace(/\s+/g, " ").replace(/^[\s\-–:·,]+|[\s\-–:·,]+$/g, "").trim();
            while ((q = re.exec(l))) besoins.push({ date: d, debut: h1, fin: h2, poste: (propre || q[2]).slice(0, 80), qualif: normQ(q[2].replace(/maitres?[- ]chiens?/, "cyno")), nombre: +q[1] }); }
          res = { client: "", evenement: "", site: "", besoins }; mode = "texte";
        }
        if (!res) return json({ error: process.env.ANTHROPIC_API_KEY ? "Rien à lire" : "Lecture des photos non activée : ajoute la clé ANTHROPIC_API_KEY dans Netlify (voir le guide), ou téléverse un PDF texte / colle le texte de la commande." }, 400);
        const besoins = (Array.isArray(res.besoins) ? res.besoins : []).slice(0, 400).map(besoinOk);
        const brouillon = { id: uid(), t: new Date().toISOString(), par: me.nom, client: t(res.client || body.client), evenement: t(res.evenement || body.evenement), site: /arena/i.test(res.site || body.site || "") ? "Arena Sud de France" : "Parc des Expositions", besoins, mode };
        const L = await load("commandes", []); L.unshift(brouillon); await save("commandes", L.slice(0, 30));
        await journal("planification", me.nom, `commande client lue (${mode === "ia" ? "lecture automatique" : "texte"}) : ${brouillon.evenement || brouillon.client || "sans titre"} · ${besoins.length} ligne(s)`, "info");
        return json(brouillon);
      }
      if (m === "POST" && r1 === "proposer") {
        const besoins = (Array.isArray(body.besoins) ? body.besoins : []).slice(0, 400).map(besoinOk).filter((b) => b.date && b.debut && b.fin);
        if (!besoins.length) return json({ error: "Aucune ligne complète (date, début, fin)" }, 400);
        const site = /arena/i.test(body.site || "") ? "Arena Sud de France" : "Parc des Expositions", evenement = t(body.evenement, 160);
        const pl = (await load("planning", PLANNING_INITIAL)).filter((v) => v.nom && !/^NON AFFECT/i.test(v.nom) && v.debut && v.fin), users = await load("users", []), ann = await load("sms_annuaire", ANNUAIRE_INITIAL), cle = P.cleAgent;
        const grilles = {}; for (const mo of [...new Set(besoins.map((b) => b.date.slice(0, 7)))]) grilles[mo] = await load("dispo_grille/" + mo, {});
        const d0 = new Date(Date.parse(besoins.map((b) => b.date).sort()[0]) - 150 * 864e5).toISOString().slice(0, 10);
        const C = new Map(), get = (n) => { const k = cle(n); if (!k) return null; if (!C.has(k)) C.set(k, { nom: n, tel: "", rang: -1, vacs: [], postes: {}, sites: {}, evs: {}, qh: {} }); return C.get(k); };
        for (const v of pl) { const c = get(v.nom); if (!c) continue; c.rang = Math.max(c.rang, RANG[P.qualifPaie(v)] ?? 0); if (!c.tel && v.tel) c.tel = v.tel; c.vacs.push(P.vacation(v));
          if (v.date >= d0) { const np = normPoste(v.poste); c.postes[np] = (c.postes[np] || 0) + 1; const qq = P.qualifPaie(v); c.qh[qq] = (c.qh[qq] || 0) + 1; const s = /arena/i.test((v.site || "") + " " + (v.poste || "")) ? "A" : "P"; c.sites[s] = (c.sites[s] || 0) + 1; if (v.evenement) { const e = normPoste(v.evenement); c.evs[e] = (c.evs[e] || 0) + 1; } } }
        for (const u of users) { if (!AGENTS.includes(u.role) || u.actif === false || (await estSmsSeul(u.id))) continue; const c = get(u.nom); if (!c) continue; c.rang = Math.max(c.rang, { ads: 0, ssiap1: 1, ssiap2: 2, ssiap3: 3 }[u.role] ?? 0); if (!c.tel && u.tel) c.tel = u.tel; }
        for (const g of Object.values(grilles)) for (const x of Object.values(g)) { const c = get(x.nom); if (c && c.rang < 0) c.rang = 0; }
        for (const a of ann) { const c = C.get(cle(a.nom)); if (c && !c.tel && a.tel) c.tel = a.tel; }
        const H = 3600e3, sCode = /arena/i.test(site) ? "A" : "P", evN = normPoste(evenement);
        const GEN = new Set(["ADS", "SSIAP", "AGENT", "AGENTS", "SECURITE", "JOUR", "NUIT", "POSTE", "1", "2", "3", "H", "TOUS", "TOUTES"]);
        const toks = (x) => normPoste(x).split(" ").filter((w) => w.length >= 2 && !GEN.has(w));
        const habitude = (c, np0) => { const A = toks(np0); if (!A.length) return c.postes[normPoste(np0)] || 0; let n = 0;
          for (const [p0, k] of Object.entries(c.postes)) { const B = new Set(toks(p0)); const ov = A.filter((w) => B.has(w)).length / A.length; if (ov >= 0.5) n += k * ov; } return Math.round(n); };
        { // v4.94 · chaque commande lue enrichit le catalogue des postes (suggestions des spécialités)
          const PC = await load("postes_commandes", {}), now = new Date().toISOString();
          for (const b of besoins) { const lb = String(b.poste || "").trim(), k = normPoste(lb); if (!k || /^(ADS|SSIAP \d|SSIAP)$/.test(k)) continue;
            const x = (PC[k] ||= { poste: lb, qualif: b.qualif, site, n: 0, evenements: [], premier: now }); x.n++; x.dernier = now; x.qualif = b.qualif || x.qualif; x.site = site;
            if (evenement && !x.evenements.includes(evenement)) x.evenements = [evenement, ...x.evenements].slice(0, 5); }
          const cles = Object.keys(PC); if (cles.length > 400) for (const k of cles.sort((a, b) => String(PC[a].dernier).localeCompare(String(PC[b].dernier))).slice(0, cles.length - 400)) delete PC[k];
          await save("postes_commandes", PC); }
        const absL = await load("absences", []), SPEC = await load("specialites", {}), rythme22 = body.rythme === "22", decouper = body.decouper !== false, repos48 = body.repos48 !== false, comparer = body.comparer !== false;
        // v5.03 · CDI prioritaires : case « CDI » des spécialités, ou contrat CDI en cours dans le registre de la société
        const contrats = ((await load("gestion", {})).contrats || []), d1 = besoins.map((b) => b.date).sort()[0];
        const estCDI = (nom) => { const k = cle(nom); if (k && SPEC[k] && SPEC[k].cdi) return true; return contrats.some((x) => x.type === "CDI" && (!x.fin || x.fin >= d1) && memeAgent({ nom: x.agent }, { nom })); };
        const hm2 = (m) => `${String(Math.floor(((m % 1440) + 1440) % 1440 / 60)).padStart(2, "0")}:${String(((m % 60) + 60) % 60).padStart(2, "0")}`;
        const unites = []; besoins.forEach((b, i) => { const v0 = P.vacation(b);
          if (decouper && v0.heures > 12) { // v4.93 · vacation de plus de 12 h : coupée en deux relèves
            const [h1, m1] = b.debut.split(":").map(Number), dm = h1 * 60 + m1, dur = Math.round(v0.heures * 60), mid = dm + Math.round(dur / 2 / 15) * 15;
            const b1 = { ...b, fin: hm2(mid), poste: b.poste + " (relève 1)", notes: (b.notes ? b.notes + " · " : "") + `vacation ${b.debut}-${b.fin} coupée` }, d2 = mid >= 1440 ? new Date(Date.parse(b.date) + 864e5).toISOString().slice(0, 10) : b.date;
            const b2 = { ...b, date: d2, debut: hm2(mid), poste: b.poste + " (relève 2)", notes: b1.notes };
            for (let k = 0; k < b.nombre; k++) { unites.push({ ...b1, i, k, nombre: 1, vac: P.vacation(b1) }); unites.push({ ...b2, i, k: k + 0.5, nombre: 1, vac: P.vacation(b2) }); }
          } else for (let k = 0; k < b.nombre; k++) unites.push({ ...b, i, k, nombre: 1, vac: v0 }); });
        const jourDe = (ms) => new Date(ms).toISOString().slice(0, 10), decJ = (d, n) => new Date(Date.parse(d) + n * 864e5).toISOString().slice(0, 10);
        unites.sort((a, b) => (RANG[b.qualif] ?? 0) - (RANG[a.qualif] ?? 0) || a.date.localeCompare(b.date) || a.debut.localeCompare(b.debut) || a.i - b.i || a.k - b.k);
        // v5.03 · modification / ajout du client le jour même : on compare avec le planning déjà enregistré (rien en double)
        const deja = [], majs = [], retires = [];
        if (comparer) { const memeSite = (v) => /arena/i.test((v.site || "") + " " + (v.poste || "")) === /arena/i.test(site), dates = new Set(unites.map((x) => x.date)), evK = normPoste(evenement);
          const exist = (await load("planning", PLANNING_INITIAL)).filter((v) => dates.has(v.date) && memeSite(v) && v.debut && v.fin && (v.source === "commande" || (evK && normPoste(v.evenement) === evK))), pris0 = new Set();
          for (const u of unites) { const np0 = normPoste(u.poste), cand = exist.filter((v) => !pris0.has(v.id) && v.date === u.date && normPoste(v.poste) === np0);
            const ex = cand.find((v) => v.debut === u.debut && v.fin === u.fin); if (ex) { pris0.add(ex.id); u.etat = "deja"; u.ex = ex; continue; }
            const mo0 = cand[0]; if (mo0) { pris0.add(mo0.id); u.etat = "maj"; u.ex = mo0; } }
          for (const v of exist) if (!pris0.has(v.id)) retires.push({ id: v.id, date: v.date, debut: v.debut, fin: v.fin, poste: v.poste, nom: /^NON AFFECT/i.test(v.nom || "") ? "" : v.nom }); }
        const pris = new Map(), dernierPoste = new Map(); // agent → vacations proposées ; continuité d'un jour à l'autre
        const repos48ok = (toutes, uv) => { // au moins 48 h de repos d'affilée dans la semaine (lundi → dimanche)
          const d = new Date(uv.debut), ws = Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate() - ((d.getUTCDay() + 6) % 7)), we = ws + 7 * 864e5;
          const iv = [...toutes, uv].filter((x) => x.fin > ws && x.debut < we).map((x) => [Math.max(ws, x.debut), Math.min(we, x.fin)]).sort((a, b) => a[0] - b[0]);
          let cur = ws, max = 0; for (const [a, b] of iv) { max = Math.max(max, a - cur); cur = Math.max(cur, b); } max = Math.max(max, we - cur); return max >= 48 * H; };
        const evaluer = (u, seulsPros) => { const rq = RANG[u.qualif] ?? 0, np = normPoste(u.poste), mo = u.date.slice(0, 7), nuit = u.vac.hNuit > u.vac.heures / 2, sem = P.lundi(u.vac.debut), sc = [];
          const A0 = toks(u.poste.replace(/\(relève \d\)/, ""));
          for (const [k, c] of C) {
            if (c.rang < rq || absenceDe(absL, c.nom, u.date)) continue;
            const sp = specDe(SPEC, c.nom), spOk = sp.find((x) => { const B = toks(x); if (!B.length || !A0.length) return false; const ov = B.filter((w0) => A0.includes(w0)).length / B.length; return ov >= 0.6; });
            if (seulsPros && !spOk) continue;
            const toutes = [...c.vacs, ...(pris.get(k) || [])];
            if (toutes.some((x) => x.debut < u.vac.fin && u.vac.debut < x.fin)) continue;
            const hSem = toutes.filter((x) => P.lundi(x.debut) === sem).reduce((a, x) => a + x.heures, 0); if (hSem + u.vac.heures > 48) continue; // 48 h travaillées par semaine au maximum
            if (toutes.some((x) => (x.fin <= u.vac.debut && u.vac.debut - x.fin < 11 * H) || (x.debut >= u.vac.fin && x.debut - u.vac.fin < 11 * H))) continue; // repos de 11 h entre deux vacations
            if (repos48 && !repos48ok(toutes, u.vac)) continue; // repos hebdomadaire de 48 h d'affilée
            const raisons = [], alertes = []; let s = 0;
            const jt = new Set(toutes.map((x) => jourDe(x.debut))), w = (n) => jt.has(decJ(u.date, -n));
            let suite = 0; while (suite < 7 && w(suite + 1)) suite++; if (suite >= 6) continue; // 6 jours travaillés d'affilée au maximum
            if (rythme22) { if ((w(1) && w(2)) || (!w(1) && w(2) && w(3))) continue; if (w(1) && !w(2)) { s += 45; raisons.push("rythme 2/2 : 2e jour"); } }
            if (spOk) { s += 90; raisons.push("pro du poste : " + spOk); }
            const cdi = estCDI(c.nom); if (cdi) { s += 60; raisons.push("CDI prioritaire"); }
            const dj = grilles[mo]?.[k]?.jours?.[u.date]; if (dj === true || (dj === "nuit" && nuit) || (dj === "jour" && !nuit)) { s += 100; raisons.push("dispo déclarée"); } else if (dj) { s += 30; raisons.push("dispo " + dj); }
            const hp = habitude(c, u.poste); if (hp) { s += Math.min(50, 12 * hp + 6); raisons.push(`habitué du poste (${hp}×)`); }
            if (c.qh[u.qualif]) { s += Math.min(hp ? 8 : 18, 2 * c.qh[u.qualif]); if (!hp) raisons.push(`habitué ${u.qualif} (${c.qh[u.qualif]}×)`); }
            if (evN && c.evs[evN]) { s += Math.min(20, 5 * c.evs[evN]); raisons.push("connaît l'événement"); }
            if (c.sites[sCode]) s += Math.min(15, c.sites[sCode]);
            if (dernierPoste.get(k + "|" + np)) { s += 30; raisons.push("même poste la veille"); }
            if (c.rang === rq) s += 15; else s -= 10 * (c.rang - rq); // pas de surqualifié si possible
            if (hSem + u.vac.heures > 44) { s -= 15; alertes.push(`${Math.round(hSem + u.vac.heures)} h / sem.`); }
            if (!c.tel) alertes.push("pas de numéro");
            s -= Math.round(hSem / 3);
            sc.push({ k, nom: c.nom, tel: c.tel, qualif: ["ADS", "SSIAP 1", "SSIAP 2", "SSIAP 3"][c.rang] || "ADS", score: s, raisons, alertes, pro: !!spOk, cdi });
          }
          return sc.sort((a, b) => b.score - a.score || a.nom.localeCompare(b.nom, "fr")); };
        const prendre = (u, choix) => { (pris.get(choix.k) || pris.set(choix.k, []).get(choix.k)).push(u.vac); dernierPoste.set(choix.k + "|" + normPoste(u.poste), u.date); u.choix = choix; };
        const aPourvoir = unites.filter((u) => u.etat !== "deja" && !(u.etat === "maj" && u.ex && u.ex.nom && !/^NON AFFECT/i.test(u.ex.nom)));
        for (const u of aPourvoir) { const sc = evaluer(u, true); if (sc[0] && sc[0].score > -40) prendre(u, sc[0]); } // 1er passage : les pros de chaque poste (CDI en tête)
        for (const u of aPourvoir) if (!u.choix) { const sc = evaluer(u, false); u.alts = sc; if (sc[0] && sc[0].score > -40) prendre(u, sc[0]); } // 2e passage : le reste, au choix
        const out = [];
        for (const u of unites) { if (u.etat === "deja") { deja.push({ date: u.date, debut: u.debut, fin: u.fin, poste: u.poste, nom: /^NON AFFECT/i.test(u.ex.nom || "") ? "" : u.ex.nom }); continue; }
          const garde = u.etat === "maj" && u.ex && u.ex.nom && !/^NON AFFECT/i.test(u.ex.nom), choix = u.choix, alts = (u.alts || evaluer(u, false)).filter((x) => !choix || x.k !== choix.k).slice(0, 6);
          const l = { date: u.date, debut: u.debut, fin: u.fin, poste: u.poste, qualif: u.qualif, notes: u.notes, action: u.etat === "maj" ? "maj" : "nouveau", ancienId: u.ex ? u.ex.id : undefined, ancien: u.ex ? `${u.ex.debut}–${u.ex.fin}` : undefined,
            nom: garde ? u.ex.nom : choix ? choix.nom : "", tel: choix ? choix.tel : "", score: choix ? choix.score : null, raisons: garde ? ["déjà affecté, horaires mis à jour"] : choix ? choix.raisons : [], alertes: garde ? ["horaires changés : à confirmer avec l'agent"] : choix ? choix.alertes : [],
            alternatives: alts.map(({ nom, qualif, score, raisons, alertes }) => ({ nom, qualif, score, raisons, alertes })) };
          if (u.etat === "maj") majs.push(l); out.push(l); }
        out.sort((a, b) => a.date.localeCompare(b.date) || a.debut.localeCompare(b.debut) || (RANG[b.qualif] ?? 0) - (RANG[a.qualif] ?? 0) || a.poste.localeCompare(b.poste, "fr"));
        return json({ site, evenement, lignes: out, pourvus: out.filter((x) => x.nom).length, total: out.length, rythme: rythme22 ? "22" : "", repos48, coupees: unites.filter((x) => /\(relève 1\)/.test(x.poste)).length,
          deja, majs: majs.length, retires, pros: out.filter((x) => (x.raisons || []).some((r) => /^pro du poste/.test(r))).length, cdi: out.filter((x) => (x.raisons || []).includes("CDI prioritaire")).length });
      }
      if (m === "POST" && r1 === "publier") {
        const site = /arena/i.test(body.site || "") ? "Arena Sud de France" : "Parc des Expositions", evenement = t(body.evenement, 160), ann = await load("sms_annuaire", ANNUAIRE_INITIAL), users = await load("users", []);
        const telDe = (n) => String(ann.find((a) => memeAgent({ nom: a.nom }, { nom: n }))?.tel || users.find((u) => u.tel && memeAgent(u, { nom: n }))?.tel || "").replace(/[^\d+]/g, "");
        const lignes = (Array.isArray(body.lignes) ? body.lignes : []).slice(0, 2000).filter((l) => D8.test(l.date || "") && HM.test(l.debut || "") && HM.test(l.fin || ""))
          .map((l) => { const nom = t(l.nom, 80); return { id: uid(), date: l.date, nom: nom || "NON AFFECTÉ", tel: nom ? telDe(nom) : "", telApproche: false, debut: l.debut, fin: l.fin, poste: t(l.poste) || t(l.qualif, 40), evenement, site, qualif: t(l.qualif, 40), code: "",
            source: "commande", importePar: me.nom, importeLe: new Date().toISOString(), ...(nom ? {} : { nonAffecte: true }) }; });
        const pl = await load("planning", PLANNING_INITIAL); let majees = 0;
        for (const l of (Array.isArray(body.lignes) ? body.lignes : []).filter((l) => l.action === "maj" && l.ancienId)) { // v5.03 · horaires modifiés par le client : mise à jour de la vacation existante
          const v = pl.find((x) => x.id === l.ancienId); if (!v || !HM.test(l.debut || "") || !HM.test(l.fin || "")) continue; const nom = t(l.nom, 80);
          Object.assign(v, { debut: l.debut, fin: l.fin, modifieLe: new Date().toISOString(), modifiePar: me.nom }); if (nom && nom !== v.nom) { v.nom = nom; v.tel = telDe(nom); delete v.nonAffecte; } majees++; }
        const nouvelles = lignes.filter((l, i) => { const src = (Array.isArray(body.lignes) ? body.lignes : []).filter((x) => D8.test(x.date || "") && HM.test(x.debut || "") && HM.test(x.fin || ""))[i]; return !(src && src.action === "maj" && src.ancienId); });
        if (!nouvelles.length && !majees) return json({ error: "Rien à enregistrer" }, 400);
        pl.push(...nouvelles); await save("planning", pl);
        lignes.splice(0, lignes.length, ...nouvelles);
        await journal("planning", me.nom, `planning créé depuis une commande client : ${evenement || "événement"} · ${lignes.length} vacation(s), ${lignes.filter((l) => l.nonAffecte).length} non affectée(s)`, "info", "#/planning");
        return json({ ok: true, ajoutees: lignes.length, majees, nonAffectees: lignes.filter((l) => l.nonAffecte).length });
      }
      return json({ error: "Requête invalide" }, 400);
    }
    if (r0 === "planif") {
      const niveau = await niveauPlanif(me), modif = (await peutPlanif(me)) || niveau === "valideur-pc", redac = niveau === "redacteur-pc" || niveau === "redacteur", lic = await licencePlanif(me);
      const horsSite = (site) => lic && lic.site && lic.site !== "tous" && !(lic.site === "arena" ? /arena/i.test(site || "") : !/arena/i.test(site || "")); // licence limitée à un site
      const tarifOK = (await accesPlanif(me)) && !redac && !sansDevis(me);
      if (sansDevis(me) && (r1 === "devis" || r1 === "tarifs" || r2 === "devis")) return json({ error: "Devis et tarifs : non accessibles pour ton compte" }, 403); // devis et tarifs : planificateurs et administrateurs (pas le PC sécurité)
      if (redac && r1 && !["deverrouiller", "vacation", "brouillon"].includes(r1)) return json({ error: niveau === "redacteur" ? "Licence rédacteur : tu proposes des vacations, un valideur les publie" : "Tu as accès seulement au planning du PC Parc" }, 403);
      if (!modif && !(await voirPlanif(me))) return deny();
      if (niveau === "valideur-pc" && m !== "GET" && !["deverrouiller", "vacation", "brouillon"].includes(r1)) return json({ error: "Tu planifies seulement le planning SSIAP 2 du PC Parc" }, 403);
      if (r1 === "deverrouiller" && m === "POST") {
        const h = (await load("code_planif", null)) || CODE_PLANIF_DEFAUT;
        const locks = await load("locks", {}), k = "planif:" + me.id, lk = locks[k];
        if (lk && lk.n >= 5 && Date.now() - lk.t < 15 * 60e3) return json({ error: "Trop d'essais, réessaie dans 15 min" }, 429);
        if (!checkPin(String(body.code || ""), h)) {
          locks[k] = { n: (lk && Date.now() - lk.t < 15 * 60e3 ? lk.n : 0) + 1, t: Date.now() }; await save("locks", locks);
          await journal("planification", me.nom, "code de la planification incorrect", "attention", "#/planif");
          return json({ error: "Code incorrect" }, 403);
        }
        if (lk) { delete locks[k]; await save("locks", locks); }
        const exp = String(Date.now() + 4 * 3600e3);
        await journal("planification", me.nom, "planification ouverte avec le code", "info", "#/planif");
        return json({ token: exp + "." + planifSig(me.id, exp), exp: Number(exp) });
      }
      if (!planifOuvert()) return json({ error: "Planification verrouillée : entre le code d'accès", verrouPlanif: true }, 423);
      const t = (v, n = 120) => String(v ?? "").trim().slice(0, n), hm = (v) => (/^\d{2}:\d{2}$/.test(v || "") ? v : ""), dte = (v) => (/^\d{4}-\d{2}-\d{2}$/.test(v || "") ? v : "");
      if (m === "GET" && !r1) {
        const du = dte(url.searchParams.get("du")) || new Date().toISOString().slice(0, 10), au = dte(url.searchParams.get("au")) || du;
        const avant = new Date(Date.parse(du) - 90 * 864e5).toISOString().slice(0, 10), apres = new Date(Date.parse(au) + 864e5).toISOString().slice(0, 10);
        const pl = (await load("planning", PLANNING_INITIAL)).filter((v) => v.date >= avant && v.date <= apres);
        const ctrl = globalThis.PLANIF.controles(pl).filter((c) => !c.date || (c.date >= new Date(Date.parse(du) - 7 * 864e5).toISOString().slice(0, 10) && c.date <= au));
        const noms = new Map(); (await load("users", [])).forEach((u) => AGENTS.includes(u.role) && noms.set(u.nom.toUpperCase(), u.nom)); (await load("sms_annuaire", ANNUAIRE_INITIAL)).forEach((a) => a.nom && noms.set(a.nom.toUpperCase(), a.nom));
        // numéros de téléphone : fiches, comptes, annuaire, plannings
        const tels = {}, fiches = await load("fiches", {}), cle = globalThis.PLANIF.cleAgent;
        for (const v of pl) if (v.tel) tels[cle(v.nom)] ||= v.tel;
        for (const a of await load("sms_annuaire", ANNUAIRE_INITIAL)) if (a.nom && a.tel) tels[cle(a.nom)] = a.tel;
        for (const u of await load("users", [])) { const t = (fiches[u.id] || {}).tel || u.tel; if (t) tels[cle(u.nom)] = String(t).replace(/[^\d+]/g, ""); }
        // DPAE : faite (vert) ou non (rouge) pour chaque agent affiché
        const dpaes = await load("dpae", []), dpae = {}, tous = new Set([...noms.values(), ...pl.map((v) => v.nom)]);
        for (const n of tous) { const l = dpaes.filter((d) => d.statut !== "annulée" && memeAgent({ nom: n }, { nom: d.agent })).sort((a, b) => (a.statut === "faite" ? -1 : 1) - (b.statut === "faite" ? -1 : 1) || String(b.t).localeCompare(String(a.t)));
          if (l.length) dpae[globalThis.PLANIF.cleAgent(n)] = { statut: l[0].statut, debut: l[0].debut, numero: l[0].numero }; }
        let brouillons = (await load("planif_brouillons", [])).filter((b) => b.statut !== "validé");
        if (redac) { const okV = (v) => (niveau === "redacteur" ? !horsSite(v.site) : estPostePC(v.poste, v.site)), pcIds = new Set(pl.filter(okV).map((v) => v.id)); brouillons = brouillons.filter((b) => b.parId === me.id);
          return json({ du, au, peutModif: true, niveau, peutDevis: false, pcSeulement: true, redacLicence: niveau === "redacteur", tels: {}, brouillons, controles: ctrl.filter((c) => c.ids.some((i) => pcIds.has(i))), dpae: {}, agents: [...noms.values()].sort((a, b) => a.localeCompare(b, "fr")),
            lignes: pl.filter((v) => okV(v) && v.date >= new Date(Date.parse(du) - 864e5).toISOString().slice(0, 10) && v.date <= au).map(({ tel, telApproche, rappel, ...v }) => v) }); }
        const absences = (await load("absences", [])).filter((a) => a.au >= du && a.du <= au);
        return json({ du, au, peutModif: modif || redac, niveau, peutDevis: tarifOK, sansDevis: sansDevis(me), tels, brouillons, controles: ctrl, dpae, absences, codesAbsence: ABS_CODES, agents: [...noms.values()].sort((a, b) => a.localeCompare(b, "fr")),
          lignes: pl.filter((v) => v.date >= new Date(Date.parse(du) - 864e5).toISOString().slice(0, 10) && v.date <= au).map(({ tel, telApproche, rappel, ...v }) => v) });
      }
      if (r1 === "vacation" && redac) { // rédacteur : enregistré en brouillon, publié après validation
        const br = await load("planif_brouillons", []), pl = await load("planning", PLANNING_INITIAL);
        const ref = r2 ? pl.find((x) => x.id === r2) : null;
        if (r2 && !ref) return json({ error: "Introuvable" }, 404);
        if (ref && ref.source !== "planif") return json({ error: "Vacation téléversée : elle ne peut pas être modifiée ici" }, 403);
        const action = m === "DELETE" ? "supprimer" : r2 ? "modifier" : "ajouter";
        const vac = action === "supprimer" ? { ...ref } : { date: dte(body.date), nom: t(body.nom, 80), debut: hm(body.debut), fin: hm(body.fin), poste: t(body.poste), site: t(body.site, 60), evenement: t(body.evenement), qualif: t(body.qualif, 60) };
        if (action !== "supprimer" && (!vac.date || !vac.nom || !vac.debut || !vac.fin)) return json({ error: "Date, agent, début et fin obligatoires" }, 400);
        if (niveau === "redacteur") { if (horsSite(vac.site) || (ref && horsSite(ref.site))) return json({ error: "Ta licence ne couvre pas ce site" }, 403); }
        else if (!estPostePC(vac.poste, vac.site) || (ref && !estPostePC(ref.poste, ref.site))) return json({ error: "Tu peux modifier seulement le planning du PC Parc (poste SSIAP 2 du PC)" }, 403);
        const b = { id: "b" + uid(), action, ref: ref ? ref.id : null, vac, statut: "en attente", par: me.nom, parId: me.id, t: new Date().toISOString() };
        br.unshift(b); await save("planif_brouillons", br.slice(0, 2000));
        await journal("planification", me.nom, `en attente de validation : ${action} ${vac.nom} ${String(vac.date).split("-").reverse().join("/")} ${vac.debut}-${vac.fin}`, "attention", "#/planif");
        await envoyerPush({ titre: "Planning à valider", texte: `${me.nom} : ${action} ${vac.nom} le ${String(vac.date).split("-").reverse().join("/")}`, url: "/#/planif" }, (u) => peutPlanif(u)).catch(() => 0);
        return json({ brouillon: b, controles: [] }, 201);
      }
      if (r1 === "brouillon" && r2) {
        let br = await load("planif_brouillons", []); const b = br.find((x) => x.id === r2);
        if (!b) return json({ error: "Introuvable" }, 404);
        if (m === "DELETE") { if (!modif && b.parId !== me.id) return deny(); await save("planif_brouillons", br.filter((x) => x.id !== r2)); return json({ ok: true }); }
        if (m === "POST" && (r3 === "valider" || r3 === "refuser")) {
          if (!modif) return json({ error: "Seuls Jérémy Mercher valident" }, 403);
          if (niveau === "valideur-pc" && !estPostePC(b.vac?.poste, b.vac?.site)) return json({ error: "Tu valides seulement le planning du PC Parc" }, 403);
          if (r3 === "refuser") { b.statut = "refusé"; b.motif = t(body.motif, 300); b.par2 = me.nom; b.t2 = new Date().toISOString(); await save("planif_brouillons", br);
            await journal("planification", me.nom, `refusé : ${b.action} ${b.vac.nom} (${b.par})${b.motif ? " · " + b.motif : ""}`, "info", "#/planif"); return json(b); }
          let pl = await load("planning", PLANNING_INITIAL);
          if (b.action === "ajouter") pl.push({ ...b.vac, id: uid(), source: "planif", cree: b.t, par: b.par, validePar: me.nom, valideLe: new Date().toISOString() });
          else if (b.action === "modifier") { if (!pl.some((x) => x.id === b.ref)) return json({ error: "La vacation d'origine n'existe plus" }, 409); pl = pl.map((x) => (x.id === b.ref ? { ...x, ...b.vac, par: b.par, validePar: me.nom, valideLe: new Date().toISOString() } : x)); }
          else pl = pl.filter((x) => x.id !== b.ref);
          await save("planning", pl); br = br.filter((x) => x.id !== r2); await save("planif_brouillons", br);
          await journal("planification", me.nom, `validé et publié : ${b.action} ${b.vac.nom} ${String(b.vac.date).split("-").reverse().join("/")} (saisi par ${b.par})`, "info", "#/planif");
          return json({ ok: true });
        }
      }
      if (r1 === "absences") {
        let abs = await load("absences", []);
        if (m === "GET") { const du = dte(url.searchParams.get("du")) || new Date(Date.now() - 31 * 864e5).toISOString().slice(0, 10); return json({ absences: abs.filter((a) => a.au >= du).sort((a, b) => a.du.localeCompare(b.du) || a.nom.localeCompare(b.nom, "fr")), codes: ABS_CODES }); }
        if (!modif || niveau === "valideur-pc") return json({ error: "Seuls les planificateurs saisissent les absences" }, 403);
        if (m === "POST") {
          const nom = t(body.nom, 80), code = ABS_CODES[body.code] ? body.code : "", du = dte(body.du), au = dte(body.au) || du;
          if (!nom || !code || !du) return json({ error: "Agent, type d'absence et date de début obligatoires" }, 400);
          if (au < du) return json({ error: "La date de fin est avant la date de début" }, 400);
          if ((Date.parse(au) - Date.parse(du)) / 864e5 > 366) return json({ error: "Période trop longue (1 an maximum)" }, 400);
          const a = { id: uid(), nom, code, du, au, note: t(body.note, 200), par: me.nom, t: new Date().toISOString() };
          let pl = await load("planning", PLANNING_INITIAL); const conflits = pl.filter((v) => v.date >= du && v.date <= au && !/^NON AFFECT/i.test(v.nom || "") && memeAgent({ nom }, v));
          if (body.liberer) for (const v of conflits) { if (!v.origine) v.origine = { nom: v.nom, debut: v.debut, fin: v.fin, tel: v.tel || "" };
            Object.assign(v, { nom: "NON AFFECTÉ", tel: "", telApproche: false, nonAffecte: true, rappel: null, modif: { par: me.nom, t: a.t, motif: `${code} — ${ABS_CODES[code]}` } }); }
          if (body.liberer && conflits.length) await save("planning", pl);
          abs.push(a); await save("absences", abs.filter((x) => x.au >= new Date(Date.now() - 400 * 864e5).toISOString().slice(0, 10)));
          await journal("planification", me.nom, `absence ${code} : ${nom} du ${du.split("-").reverse().join("/")} au ${au.split("-").reverse().join("/")}${conflits.length ? ` · ${conflits.length} vacation(s) ${body.liberer ? "passée(s) en non affecté" : "en conflit"}` : ""}`, "info", "#/planif");
          return json({ absence: a, conflits: conflits.map(({ id, date, debut, fin, poste }) => ({ id, date, debut, fin, poste })), liberees: body.liberer ? conflits.length : 0 }, 201);
        }
        if (m === "DELETE" && r2) { const a = abs.find((x) => x.id === r2); if (!a) return json({ error: "Introuvable" }, 404);
          await save("absences", abs.filter((x) => x.id !== r2)); await journal("planification", me.nom, `absence supprimée : ${a.code} ${a.nom} ${a.du} → ${a.au}`, "info", "#/planif"); return json({ ok: true }); }
        return json({ error: "Requête invalide" }, 400);
      }
      if (r1 === "vacation") {
        if (!modif) return json({ error: "Lecture seule : seuls Jérémy Mercher modifient le planning" }, 403);
        let pl = await load("planning", PLANNING_INITIAL);
        if (niveau === "valideur-pc") { const v0 = r2 ? pl.find((x) => x.id === r2) : null;
          if ((m !== "DELETE" && !estPostePC(body.poste ?? v0?.poste, body.site ?? v0?.site)) || (v0 && !estPostePC(v0.poste, v0.site))) return json({ error: "Tu planifies seulement le planning SSIAP 2 du PC Parc (poste SSIAP 2 du PC)" }, 403); }
        if (lic && lic.site !== "tous") { const v0 = r2 ? pl.find((x) => x.id === r2) : null; if (horsSite(body.site ?? v0?.site) || (v0 && horsSite(v0.site))) return json({ error: "Ta licence ne couvre pas ce site" }, 403); }
        if (r2 && body.majConnue) { const v0 = pl.find((x) => x.id === r2); if (v0 && v0.maj && v0.maj !== body.majConnue) return json({ error: `Vacation modifiée entre-temps par ${v0.par || "un autre planificateur"} : recharge le planning`, conflit: true }, 409); }
        if (m === "POST" || (m === "PATCH" && r2)) {
          const v0 = r2 ? pl.find((x) => x.id === r2) : null;
          if (r2 && !v0) return json({ error: "Introuvable" }, 404);
          if (v0 && v0.source !== "planif") return json({ error: "Vacation téléversée : elle ne peut pas être modifiée ici" }, 403);
          const v = { ...(v0 || { id: uid(), source: "planif", cree: new Date().toISOString() }), date: dte(body.date), nom: t(body.nom, 80), debut: hm(body.debut), fin: hm(body.fin), poste: t(body.poste), site: t(body.site, 60), evenement: t(body.evenement), qualif: t(body.qualif, 60), par: me.nom, maj: new Date().toISOString() };
          if (!v.date || !v.nom || !v.debut || !v.fin) return json({ error: "Date, agent, début et fin obligatoires" }, 400);
          { const ab = absenceDe(await load("absences", []), v.nom, v.date); if (ab) return json({ error: `${v.nom} est absent ce jour-là (${ab.code} — ${ABS_CODES[ab.code]}, du ${ab.du.split("-").reverse().join("/")} au ${ab.au.split("-").reverse().join("/")}). Supprime l'absence d'abord si besoin.` }, 409); }
          if (!v.tel) { const a = (await load("sms_annuaire", ANNUAIRE_INITIAL)).find((x) => memeAgent({ nom: v.nom }, { nom: x.nom })); if (a) v.tel = a.tel || ""; }
          pl = v0 ? pl.map((x) => (x.id === v.id ? v : x)) : [...pl, v]; await save("planning", pl);
          await journal("planification", me.nom, `${v0 ? "vacation modifiée" : "vacation ajoutée"} : ${v.nom} ${v.date.split("-").reverse().join("/")} ${v.debut}-${v.fin} ${v.poste}`, "info", "#/planif");
          const ctrl = globalThis.PLANIF.controles(pl.filter((x) => globalThis.PLANIF.cleAgent(x.nom) === globalThis.PLANIF.cleAgent(v.nom))).filter((c) => c.ids.includes(v.id));
          return json({ vacation: v, controles: ctrl }, v0 ? 200 : 201);
        }
        if (m === "DELETE" && r2) { const v0 = pl.find((x) => x.id === r2); if (!v0) return json({ error: "Introuvable" }, 404);
          if (v0.source !== "planif") return json({ error: "Vacation téléversée : elle ne peut pas être supprimée ici" }, 403);
          await save("planning", pl.filter((x) => x.id !== r2)); await journal("planification", me.nom, `vacation supprimée : ${v0.nom} ${v0.date} ${v0.debut}-${v0.fin}`, "info", "#/planif"); return json({ ok: true }); }
      }
      if (r1 === "paie") { // pré-paie : administrateurs et propriétaire seulement (données salariales)
        if (!(me.role === "admin" || estProprio(me))) return json({ error: "Pré-paie réservée aux administrateurs et au propriétaire" }, 403);
        if (m === "PUT") { const tp = (v) => String(v ?? "").trim().slice(0, 10), P = {};
          for (const k of Object.keys(globalThis.PLANIF.PAIE_DEFAUT)) if (k !== "taux" && body[k] !== undefined) P[k] = tp(body[k]);
          P.taux = {}; for (const [k, v] of Object.entries(body.taux || {}).slice(0, 20)) P.taux[String(k).slice(0, 40)] = tp(v);
          P.maj = new Date().toISOString(); P.par = me.nom; await save("paie_params", P);
          await journal("planification", me.nom, "paramètres de pré-paie modifiés", "info", "#/planif"); return json(P); }
        const mois = /^\d{4}-\d{2}$/.test(url.searchParams.get("mois") || "") ? url.searchParams.get("mois") : jourParis().slice(0, 7);
        const [y, mo] = mois.split("-").map(Number), du = new Date(Date.UTC(y, mo - 1, 1) - 7 * 864e5).toISOString().slice(0, 10), au = new Date(Date.UTC(y, mo, 7)).toISOString().slice(0, 10);
        const lignes = (await load("planning", PLANNING_INITIAL)).filter((v) => v.date >= du && v.date <= au);
        return json(globalThis.PLANIF.calcPaie(lignes, mois, await load("paie_params", {})));
      }
      if (r1 === "tarifs") {
        if (m === "GET") return json(await load("planif_tarifs", { taux: {}, majNuit: "", majDimanche: "", majFerie: "", nuitDebut: "21:00", nuitFin: "06:00", tva: "20" }));
        if (m === "PUT") { if (!tarifOK) return deny(); const taux = {}, tauxChef = {};
          for (const [k, v] of Object.entries(body.taux || {}).slice(0, 40)) if (t(k, 60)) taux[t(k, 60)] = t(v, 12);
          for (const [k, v] of Object.entries(body.tauxChef || {}).slice(0, 40)) if (t(k, 60)) tauxChef[t(k, 60)] = t(v, 12);
          const tf = { taux, tauxChef, majNuit: t(body.majNuit, 8), majDimanche: t(body.majDimanche, 8), majFerie: t(body.majFerie, 8), nuitDebut: hm(body.nuitDebut) || "21:00", nuitFin: hm(body.nuitFin) || "06:00", maj: new Date().toISOString(), par: me.nom };
          await save("planif_tarifs", tf); await journal("planification", me.nom, "grille tarifaire modifiée", "info", "#/planif"); return json(tf); }
      }
      if (r1 === "devis") {
        let list = await load("planif_devis", []); const tarifs = await load("planif_tarifs", {});
        if (m === "GET") return json(list.map((d) => ({ ...d, calc: globalThis.PLANIF.calcDevis(d, tarifs) })));
        if (!tarifOK) return json({ error: "Lecture seule" }, 403);
        if (m === "POST") {
          const d0 = body.id ? list.find((x) => x.id === body.id) : null, an = new Date().getFullYear();
          const d = { ...(d0 || { id: uid(), numero: `DEV-${an}-${String(list.filter((x) => String(x.numero).startsWith("DEV-" + an)).length + 1).padStart(4, "0")}`, cree: new Date().toISOString(), creePar: me.nom }),
            client: t(body.client, 120), contact: t(body.contact, 160), evenement: t(body.evenement, 160), site: t(body.site, 80), objet: t(body.objet, 300), validite: t(body.validite, 20), statut: ["brouillon", "envoyé", "accepté", "refusé"].includes(body.statut) ? body.statut : "brouillon",
            remise: t(body.remise, 8), tva: t(body.tva, 6), notes: t(body.notes, 2000),
            mode: body.mode === "mois" ? "mois" : "evenement", mois: /^\d{4}-\d{2}$/.test(body.mois || "") ? body.mois : "",
            lignes: (Array.isArray(body.lignes) ? body.lignes : []).slice(0, 300).map((l) => ({ qualif: t(l.qualif, 60), libelle: t(l.libelle, 120), nb: Math.max(0, parseInt(l.nb) || 0), date: dte(l.date), au: dte(l.au), jours: (Array.isArray(l.jours) ? l.jours : []).map(Number).filter((j) => j >= 0 && j <= 6), debut: hm(l.debut), fin: hm(l.fin), taux: t(l.taux, 12), chef: l.chef === true }))
              .filter((l) => l.debut && l.fin && (l.date || body.mode === "mois")),
            frais: (Array.isArray(body.frais) ? body.frais : []).slice(0, 30).map((f) => ({ libelle: t(f.libelle, 120), montant: t(f.montant, 12) })).filter((f) => f.libelle), maj: new Date().toISOString(), majPar: me.nom };
          list = d0 ? list.map((x) => (x.id === d.id ? d : x)) : [d, ...list]; await save("planif_devis", list.slice(0, 1000));
          await journal("planification", me.nom, `devis ${d.numero} ${d0 ? "modifié" : "créé"} · ${d.client}`, "info", "#/planif");
          return json({ ...d, calc: globalThis.PLANIF.calcDevis(d, tarifs) });
        }
        if (m === "DELETE" && r2) { await save("planif_devis", list.filter((x) => x.id !== r2)); return json({ ok: true }); }
      }
      /* ----- tableau de bord de la planification (période à venir) ----- */
      if (m === "GET" && r1 === "tableau") {
        const P = globalThis.PLANIF, du = dte(url.searchParams.get("du")) || jourParis(), au = dte(url.searchParams.get("au")) || new Date(Date.parse(du) + 13 * 864e5).toISOString().slice(0, 10);
        const pl = await load("planning", PLANNING_INITIAL), postes = (await load("planif_postes", [])).filter((p) => !p.supprime && p.date >= du && p.date <= au);
        const lignes = pl.filter((v) => v.date >= du && v.date <= au && v.debut && v.fin && v.nom && !v.posteId);
        const brouillon = postes.flatMap((p) => p.agents.map((a) => ({ date: p.date, debut: p.debut, fin: p.fin, nom: a.nom, id: p.id })));
        const tout = [...lignes, ...brouillon], heures = tout.reduce((s, v) => s + P.vacation(v).heures, 0);
        const avant = new Date(Date.parse(du) - 21 * 864e5).toISOString().slice(0, 10);
        const ctrl = P.controles([...pl.filter((v) => v.date >= avant && v.date < du && v.nom && v.debut), ...tout]).filter((c) => !c.date || c.date >= du);
        const jours = {}; for (const p of postes) if (p.agents.length < p.nb) jours[p.date] = (jours[p.date] || 0) + p.nb - p.agents.length;
        const lun = P.lundi(Date.now()), charge = {};
        for (const v of [...pl.filter((x) => x.nom && x.debut && x.fin && !x.posteId), ...brouillon]) if (P.lundi(Date.parse(v.date)) === lun) { const k = P.cleAgent(v.nom); (charge[k] ||= { nom: v.nom, h: 0 }).h += P.vacation(v).heures; }
        return json({ du, au, postes: postes.length, complets: postes.filter((p) => p.agents.length >= p.nb).length, manque: postes.reduce((s, p) => s + Math.max(0, p.nb - p.agents.length), 0),
          aPublier: (await load("planif_postes", [])).filter((p) => p.modifie).length, auto: postes.reduce((s, p) => s + p.agents.filter((a) => a.auto).length, 0),
          attente: (await load("planif_brouillons", [])).filter((b) => b.statut === "en attente").length,
          vacations: tout.length, heures: Math.round(heures), agents: new Set(tout.map((v) => P.cleAgent(v.nom))).size,
          rouges: ctrl.filter((c) => c.niveau === "rouge").length, oranges: ctrl.filter((c) => c.niveau === "orange").length, alertes: ctrl.filter((c) => c.niveau === "rouge").slice(0, 6),
          joursRisque: Object.entries(jours).sort((a, b) => a[0].localeCompare(b[0])).map(([date, n]) => ({ date, manque: n })),
          charges: Object.values(charge).sort((a, b) => b.h - a.h).slice(0, 6).map((x) => ({ nom: x.nom, h: Math.round(x.h * 10) / 10 })) });
      }
      /* ----- postes à pourvoir (glisser les agents), brouillon d'équipe, publication par le planificateur ----- */
      if (r1 === "besoins") var postesB = await load("planif_postes", []);
      /* ----- v3.84 · Besoins du client (fiche PDF) → postes du mois + remplissage automatique (administrateurs et propriétaire) ----- */
      if (r1 === "besoins") {
        if (!(me.role === "admin" || estProprio(me))) return json({ error: "Fonction réservée aux administrateurs et au propriétaire" }, 403);
        const MODELES_DEFAUT = [
          { poste: "SSIAP 2 PC sécurité jour", qualif: "SSIAP 2", debut: "07:00", fin: "19:00", site: "" }, { poste: "SSIAP 2 PC sécurité nuit", qualif: "SSIAP 2", debut: "19:00", fin: "07:00", site: "" },
          { poste: "SSIAP 1 ronde jour", qualif: "SSIAP 1", debut: "07:00", fin: "19:00", site: "" }, { poste: "SSIAP 1 ronde nuit", qualif: "SSIAP 1", debut: "19:00", fin: "07:00", site: "" },
          { poste: "Chef d'équipe SSIAP 3", qualif: "SSIAP 3", debut: "08:00", fin: "20:00", site: "" }, { poste: "ADS contrôle d'accès", qualif: "ADS", debut: "08:00", fin: "20:00", site: "" },
          { poste: "ADS filtrage / palpation", qualif: "ADS", debut: "08:00", fin: "20:00", site: "" }, { poste: "ADS gardiennage nuit", qualif: "ADS", debut: "20:00", fin: "08:00", site: "" }];
        if (m === "GET" && !r2) return json({ modeles: await load("planif_modeles", MODELES_DEFAUT), fiches: (await load("planif_fiches", [])).slice(0, 30), jeux: await load("planif_jeux", [BESOINS_FIM26]) });
        if (m === "POST" && r2 === "jeux") { const nom = t(body.nom, 120); if (!nom) return json({ error: "Nom du jeu de besoins" }, 400);
          const jeux = await load("planif_jeux", [BESOINS_FIM26]); const j = { id: "j" + uid(), nom, client: t(body.client, 120), evenement: t(body.evenement, 160), lignes: (Array.isArray(body.lignes) ? body.lignes : []).slice(0, 400), t: new Date().toISOString(), par: me.nom };
          await save("planif_jeux", [j, ...jeux].slice(0, 40)); return json(j); }
        if (m === "PUT" && r2 === "modeles") {
          const out = (Array.isArray(body.modeles) ? body.modeles : []).slice(0, 80).map((x) => ({ poste: t(x.poste, 120), qualif: t(x.qualif, 40), debut: hm(x.debut), fin: hm(x.fin), site: t(x.site, 60) })).filter((x) => x.poste && x.debut && x.fin);
          await save("planif_modeles", out); await journal("planification", me.nom, `postes prédéfinis : ${out.length}`, "info", "#/planif"); return json({ ok: true, modeles: out });
        }
        if (m === "POST" && r2 === "generer") {
          const client = t(body.client, 120), evenement = t(body.evenement, 160), fichier = t(body.fichier, 160), lignes = Array.isArray(body.lignes) ? body.lignes.slice(0, 400) : [];
          const fid = "f" + uid(), crees = [];
          for (const l of lignes) {
            const dates = [...new Set((Array.isArray(l.dates) ? l.dates : [l.date]).map((d) => dte(d)).filter(Boolean))].slice(0, 62);
            const debut = hm(l.debut), fin = hm(l.fin), nb = Math.max(1, Math.min(100, parseInt(l.nb) || 1)), poste = t(l.poste) || t(l.qualif, 60);
            if (!debut || !fin || !poste) continue;
            for (const date of dates) {
              const p = { id: "p" + uid(), cree: new Date().toISOString(), creePar: me.nom, statut: "brouillon", date, debut, fin, poste, site: t(l.site, 60), evenement: evenement || client, qualif: t(l.qualif, 60), nb, agents: [],
                devisId: null, ligne: null, besoinId: fid, modifie: true, maj: new Date().toISOString(), majPar: me.nom + " (besoins client)" };
              postesB.push(p); crees.push(p);
            }
          }
          if (!crees.length) return json({ error: "Aucune ligne exploitable : il faut au moins une date, des horaires et un poste ou une qualification" }, 400);
          const du = crees.reduce((a, p) => (p.date < a ? p.date : a), "9999"), au = crees.reduce((a, p) => (p.date > a ? p.date : a), "0000");
          let res = { pourvus: 0, manquants: crees.reduce((s, p) => s + p.nb, 0) };
          if (body.remplir !== false) res = await autoRemplir(postesB, du, au, me);
          await save("planif_postes", postesB.slice(-6000));
          const places = crees.reduce((s, p) => s + p.nb, 0), pourvues = crees.reduce((s, p) => s + p.agents.length, 0);
          const fiche = { id: fid, t: new Date().toISOString(), par: me.nom, client, evenement, fichier, lignes: lignes.length, postes: crees.length, places, pourvues, manquantes: places - pourvues, du, au };
          const fl = await load("planif_fiches", []); fl.unshift(fiche); await save("planif_fiches", fl.slice(0, 100));
          await journal("planification", me.nom, `besoins client${client ? " " + client : ""}${fichier ? " (" + fichier + ")" : ""} : ${crees.length} poste(s), ${pourvues}/${places} place(s) pourvue(s) du ${du.split("-").reverse().join("/")} au ${au.split("-").reverse().join("/")}`, "info", "#/planif");
          return json({ ok: true, fiche, postes: crees.map((p) => ({ id: p.id, date: p.date, debut: p.debut, fin: p.fin, poste: p.poste, qualif: p.qualif, nb: p.nb, agents: p.agents.map((a) => a.nom) })) });
        }
        if (m === "DELETE" && r2) { // annuler une génération : retire les postes non publiés créés par cette fiche
          const avant = postesB.length; postesB = postesB.filter((p) => !(p.besoinId === r2 && p.statut !== "publié")); await save("planif_postes", postesB);
          await save("planif_fiches", (await load("planif_fiches", [])).filter((f) => f.id !== r2));
          await journal("planification", me.nom, `génération annulée : ${avant - postesB.length} poste(s) retiré(s)`, "attention", "#/planif"); return json({ ok: true, retires: avant - postesB.length });
        }
        return json({ error: "Requête invalide" }, 400);
      }
      if (r1 === "postes") {
        const equipe = modif; let postes = await load("planif_postes", []);
        const nettoie = (b, p0) => ({ ...(p0 || { id: "p" + uid(), cree: new Date().toISOString(), creePar: me.nom, statut: "brouillon" }), date: dte(b.date), debut: hm(b.debut), fin: hm(b.fin), poste: t(b.poste), site: t(b.site, 60), evenement: t(b.evenement), qualif: t(b.qualif, 60),
          nb: Math.max(1, Math.min(200, parseInt(b.nb) || 1)), agents: (Array.isArray(b.agents) ? b.agents : []).slice(0, 200).map((a) => ({ nom: t(a.nom, 80), tel: String(a.tel || "").replace(/[^\d+]/g, "").slice(0, 15) })).filter((a) => a.nom),
          devisId: b.devisId ?? (p0 && p0.devisId) ?? null, ligne: b.ligne ?? (p0 && p0.ligne) ?? null, modifie: true, maj: new Date().toISOString(), majPar: me.nom });
        if (m === "GET" && !r2) {
          const du = dte(url.searchParams.get("du")) || "0000", au = dte(url.searchParams.get("au")) || "9999";
          const devis = (await load("planif_devis", [])).filter((d) => d.statut === "accepté");
          const nonPlanifiees = [];
          for (const d of devis) (d.lignes || []).forEach((l, i) => { for (const date of globalThis.PLANIF.joursLigne(l, d)) if (date >= du && date <= au && !postes.some((p) => p.devisId === d.id && p.ligne === i && p.date === date && !p.supprime)) nonPlanifiees.push({ devisId: d.id, numero: d.numero, client: d.client, evenement: d.evenement, site: d.site, ligne: i, ...l, date }); });
          return json({ postes: postes.filter((p) => p.date >= du && p.date <= au), nonPlanifiees, peutEditer: equipe, peutPublier: modif, aPublier: postes.filter((p) => p.modifie).length });
        }
        if (!equipe) return json({ error: "Seuls Jérémy Mercher modifient les postes" }, 403);
        if (m === "POST" && r2 === "devis" && r3) {
          const d = (await load("planif_devis", [])).find((x) => x.id === r3); if (!d) return json({ error: "Devis introuvable" }, 404);
          const idx = body.ligne != null ? [parseInt(body.ligne)] : (d.lignes || []).map((_, i) => i); let n = 0;
          for (const i of idx) { const l = (d.lignes || [])[i]; if (!l) continue;
            for (const date of globalThis.PLANIF.joursLigne(l, d)) { if ((body.date && date !== body.date) || postes.some((p) => p.devisId === d.id && p.ligne === i && p.date === date && !p.supprime)) continue;
              postes.push(nettoie({ date, debut: l.debut, fin: l.fin, poste: l.libelle || l.qualif + (l.chef ? " chef d'équipe" : ""), site: d.site, evenement: d.evenement, qualif: l.qualif, nb: l.nb, devisId: d.id, ligne: i })); n++; } }
          await save("planif_postes", postes); await journal("planification", me.nom, `${n} poste(s) créé(s) depuis le devis ${d.numero}`, "info", "#/planif"); return json({ ok: true, crees: n });
        }
        // ---- Planification automatique : remplit les postes à pourvoir avec les agents qualifiés, disponibles et en règle (11 h, 48 h, dimanches, 12 h…)
        if (m === "POST" && r2 === "auto") {
          const du = dte(body.du) || jourParis(), au = dte(body.au) || new Date(Date.parse(du) + 13 * 864e5).toISOString().slice(0, 10);
          const { pourvus, manquants, touches } = await autoRemplir(postes, du, au, me);
          await save("planif_postes", postes);
          await journal("planification", me.nom, `remplissage automatique du ${du.split("-").reverse().join("/")} au ${au.split("-").reverse().join("/")} : ${pourvus} affectation(s), ${manquants} place(s) sans agent`, "info", "#/planif");
          return json({ ok: true, pourvus, manquants, postes: touches.size });
        }
        if (m === "POST" && r2 === "publier") {
          if (!modif) return json({ error: "La publication est faite par Jérémy Mercher (planificateur)" }, 403);
          let pl = await load("planning", PLANNING_INITIAL), nbP = 0, nbL = 0; const ann = await load("sms_annuaire", ANNUAIRE_INITIAL);
          for (const p of postes.filter((x) => x.modifie)) {
            pl = pl.filter((v) => v.posteId !== p.id); nbP++;
            if (p.supprime) continue;
            for (const a of p.agents) { const tel = a.tel || (ann.find((x) => memeAgent({ nom: a.nom }, { nom: x.nom })) || {}).tel || "";
              pl.push({ id: uid(), date: p.date, nom: a.nom, tel, debut: p.debut, fin: p.fin, poste: p.poste, site: p.site, evenement: p.evenement, qualif: p.qualif, source: "planif", posteId: p.id, par: p.majPar, validePar: me.nom, valideLe: new Date().toISOString() }); nbL++; }
            p.modifie = false; p.statut = "publié"; p.pub = { t: new Date().toISOString(), par: me.nom };
          }
          postes = postes.filter((x) => !(x.supprime && !x.modifie));
          await save("planning", pl); await save("planif_postes", postes);
          await journal("planification", me.nom, `planning publié : ${nbP} poste(s), ${nbL} vacation(s) visibles par les agents`, "info", "#/planif");
          return json({ ok: true, postes: nbP, vacations: nbL });
        }
        if (m === "POST" && !r2) {
          const p0 = body.id ? postes.find((x) => x.id === body.id) : null; if (body.id && !p0) return json({ error: "Introuvable" }, 404);
          const p = nettoie(body, p0); if (!p.date || !p.debut || !p.fin || !p.poste) return json({ error: "Date, horaires et poste obligatoires" }, 400);
          if (p.agents.length > p.nb) return json({ error: `Ce poste ne prend que ${p.nb} agent(s)` }, 400);
          postes = p0 ? postes.map((x) => (x.id === p.id ? p : x)) : [...postes, p]; await save("planif_postes", postes.slice(-5000)); return json(p, p0 ? 200 : 201);
        }
        if (m === "DELETE" && r2) { const p = postes.find((x) => x.id === r2); if (!p) return json({ error: "Introuvable" }, 404);
          if (p.statut === "publié") { p.supprime = true; p.modifie = true; } else postes = postes.filter((x) => x.id !== r2);
          await save("planif_postes", postes); return json({ ok: true }); }
      }
      if (r1 === "redacteurs") {
        if (m === "GET") return json({ emails: await load("planif_redac_pc", REDAC_PC_DEFAUT) });
        if (m === "PUT") { if (!estProprio(me)) return refusProprio();
          const e = (Array.isArray(body.emails) ? body.emails : []).map((x) => String(x).trim().toLowerCase()).filter((x) => /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(x)).slice(0, 10);
          await save("planif_redac_pc", e); return json({ ok: true, nb: e.length }); }
      }
      if (r1 === "planificateurs") {
        if (m === "GET") return json({ emails: await load("planificateurs", []) });
        if (m === "PUT") { if (!estProprio(me)) return refusProprio();
          const e = (Array.isArray(body.emails) ? body.emails : []).map((x) => String(x).trim().toLowerCase()).filter((x) => /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(x)).slice(0, 10);
          await save("planificateurs", e); return json({ ok: true, nb: e.length }); }
      }
      return json({ error: "Méthode non gérée" }, 405);
    }

    /* ---------- Plan du site interactif : infos par hall + état en direct ---------- */
    if (r0 === "plan") {
      const peutModif = estProprio(me) || me.role === "admin" || (await estCoord(me));
      const infos = await load("plan_infos", {});
      if (m === "GET") {
        const voitMC = isStaff(me) || !!me.perimetre || me.role === "client";
        let mc = [];
        if (voitMC) { mc = (await mcRecents(2)).filter((i) => i.statut !== "clos" && (isStaff(me) || me.role === "client" || dansPerimetre(me, i))).slice(0, 300)
          .map(({ id, numero, categorie, lieu, site, t, heure, gravite, statut }) => ({ id, numero, categorie, lieu, site, t, heure, gravite, statut })); }
        // agents du jour d'après le planning (noms et postes, sans numéros) : PC, responsables, coordinateurs
        let postes = [], arena = null;
        if (isStaff(me) || (await estCoord(me)) || me.coordArena) {
          const auj = jourParis(), hier = jourParis(-1), now = maintenantParis();
          postes = (await load("planning", PLANNING_INITIAL)).filter((v) => v.date === auj || (v.date === hier && v.fin && v.debut && v.fin < v.debut && now <= minutesLocales(auj, v.fin)))
            .map(({ nom, poste, debut, fin, site, date }) => ({ nom, poste: poste || "", debut, fin, site: site || "", date }));
          const jA = postes.some((v) => v.date === hier && /ARENA/i.test(v.site + " " + v.poste)) && !postes.some((v) => v.date === auj && /ARENA/i.test(v.site + " " + v.poste)) ? hier : auj;
          arena = await equipeArenaJour(jA);
        }
        return json({ daePos: await load("plan_dae", {}), infos: { ...PLAN_INFOS_DEFAUT, ...infos }, etat: await load("batiments_etat", {}), mc, voitMC, peutModif, postes, arena });
      }
      if (m === "PUT" && r1 === "dae" && r2) { // placer un DAE sur le plan et / ou enregistrer sa position GPS
        if (!peutModif) return deny();
        const pos = await load("plan_dae", {}), id = String(r2).slice(0, 30), cur = pos[id] || {};
        if (body.x != null || body.y != null) { const x = Number(body.x), y = Number(body.y); if (!Number.isFinite(x) || !Number.isFinite(y)) return json({ error: "Position invalide" }, 400); cur.x = Math.round(x); cur.y = Math.round(y); }
        if (body.gps) { const la = Number(body.gps.lat), lo = Number(body.gps.lon), ac = Number(body.gps.acc);
          if (!Number.isFinite(la) || !Number.isFinite(lo) || Math.abs(la) > 90 || Math.abs(lo) > 180) return json({ error: "Position GPS invalide" }, 400);
          cur.gps = { lat: Math.round(la * 1e6) / 1e6, lon: Math.round(lo * 1e6) / 1e6, acc: Number.isFinite(ac) ? Math.round(ac) : null, t: new Date().toISOString(), par: me.nom }; }
        pos[id] = cur; await save("plan_dae", pos);
        await journal("plan du site", me.nom, `DAE ${id} : ${body.gps ? "position GPS enregistrée" : "placé sur le plan"}`, "info", "#/plan"); return json(pos);
      }
      if (m === "PUT" && r1) {
        if (!peutModif) return deny();
        const t = (v, n = 300) => String(v ?? "").trim().slice(0, n), id = t(r1, 30);
        infos[id] = { effectif: t(body.effectif, 40), ssi: t(body.ssi), dae: t(body.dae), ria: t(body.ria), coupures: t(body.coupures), issues: t(body.issues), rassemblement: t(body.rassemblement), notes: t(body.notes, 1000), maj: new Date().toISOString(), par: me.nom };
        await save("plan_infos", infos); await journal("plan du site", me.nom, `fiche ${id} mise à jour`, "info", "#/plan");
        return json(infos[id]);
      }
      return json({ error: "Méthode non gérée" }, 405);
    }

    /* ---------- Prêt de matériel aux agents (casques anti-bruit, radios, PTI, autres) ---------- */
    if (r0 === "materiel") {
      const liste = await load("materiel", MATERIEL_INITIAL), etat = await load("materiel_etat", {}), hs = await load("materiel_hs", {});
      if (m === "GET" && !r1) return json({ liste, etat, hs });
      if (m === "GET" && r1 === "historique") return json((await load("materiel_mvt", [])).filter((x) => isStaff(me) || estProprio(me) || x.par === me.nom).slice(0, 400));
      const t = (v, n = 120) => String(v ?? "").trim().slice(0, n);
      if (m === "PUT" && !r1) {
        if (!(await estCoord(me))) return json({ error: "Réservé à la coordination" }, 403);
        const vus = new Set();
        const out = (Array.isArray(body.liste) ? body.liste : []).slice(0, 500).map((c) => ({ n: t(c.n, 12), nom: t(c.nom, 120), type: t(c.type, 60) || "Autres" })).filter((c) => c.n && c.nom && !vus.has(c.n) && vus.add(c.n));
        await save("materiel", out); await journal("matériel", me.nom, `liste du matériel modifiée (${out.length})`, "info", "#/materiel");
        return json({ ok: true, nb: out.length });
      }
      const it = liste.find((c) => c.n === r1); if (!it) return json({ error: "Matériel introuvable" }, 404);
      const mvt = await load("materiel_mvt", []);
      if (m === "POST" && r2 === "pret") {
        if (etat[it.n]) return json({ error: `Déjà prêté à ${etat[it.n].nom}` }, 400);
        const e = { nom: t(body.nom), manif: t(body.manif), ok: body.ok === true, remarque: t(body.remarque, 200), t: new Date().toISOString(), par: me.nom };
        if (!e.nom) return json({ error: "Indique le nom de l'agent" }, 400);
        etat[it.n] = e; await save("materiel_etat", etat);
        mvt.unshift({ id: uid(), n: it.n, objet: it.nom, sens: "prêt", ...e }); await save("materiel_mvt", mvt.slice(0, 5000));
        await journal("matériel", me.nom, `📦 ${it.nom} prêté à ${e.nom}${e.ok ? "" : " · ⚠️ état de fonctionnement non confirmé"}`, e.ok ? "info" : "attention", "#/materiel");
        return json({ etat, hs });
      }
      if (m === "POST" && r2 === "retour") {
        const e = etat[it.n]; if (!e) return json({ error: "Ce matériel n'est pas prêté" }, 400);
        delete etat[it.n]; await save("materiel_etat", etat);
        const ok = body.ok === true, remarque = t(body.remarque, 200);
        if (!ok) { hs[it.n] = { t: new Date().toISOString(), par: me.nom, remarque: remarque || "Rendu hors d'état de fonctionnement", nom: e.nom }; await save("materiel_hs", hs); }
        mvt.unshift({ id: uid(), n: it.n, objet: it.nom, sens: "retour", nom: e.nom, ok, remarque, pret: e.t, t: new Date().toISOString(), par: me.nom }); await save("materiel_mvt", mvt.slice(0, 5000));
        await journal("matériel", me.nom, `✅ ${it.nom} rendu par ${e.nom}${ok ? "" : " · ⚠️ HORS SERVICE" + (remarque ? " : " + remarque : "")}`, ok ? "info" : "attention", "#/materiel");
        if (!ok) await mailPC(`⚠️ Matériel hors service — ${it.nom}`, [["Matériel", it.nom], ["Rendu par", e.nom], ["Constaté par", me.nom], ["Heure", fmtParis(new Date())], ["Remarque", remarque]]);
        return json({ etat, hs });
      }
      if (m === "POST" && r2 === "service") { // remis en service après réparation / vérification
        delete hs[it.n]; await save("materiel_hs", hs);
        mvt.unshift({ id: uid(), n: it.n, objet: it.nom, sens: "remise en service", t: new Date().toISOString(), par: me.nom }); await save("materiel_mvt", mvt.slice(0, 5000));
        await journal("matériel", me.nom, `🔧 ${it.nom} remis en service`, "info", "#/materiel");
        return json({ etat, hs });
      }
    }

    /* ---------- Parcours de ronde NFC (pointeaux) : rédaction propriétaire + coordination ---------- */
    if (r0 === "parcours") {
      if (m === "GET") return json(await load("parcours", PARCOURS_INITIAL));
      if (m === "PUT") {
        if (!estProprio(me) || me.apercu) return json({ error: "Seul Rochdi modifie les parcours et les pointeaux" }, 403); // v4.35 · propriétaire uniquement
        const t = (v, n = 120) => String(v ?? "").trim().slice(0, n);
        const out = (Array.isArray(body.parcours) ? body.parcours : []).slice(0, 30).map((pc, i) => ({ id: t(pc.id, 40) || "p" + uid(), nom: t(pc.nom) || "Parcours " + (i + 1), site: t(pc.site, 60),
          dureeMax: Math.max(0, Math.min(600, parseInt(pc.dureeMax) || 0)),
          points: (Array.isArray(pc.points) ? pc.points : []).slice(0, 80).map((x) => ({ uid: normUID(x.uid), nom: t(x.nom, 160), consigne: t(x.consigne, 300) })).filter((x) => x.uid && x.nom) })).filter((pc) => pc.points.length);
        await save("parcours", out); await journal("rondes", me.nom, `parcours de ronde modifiés (${out.length})`, "info", "#/rondes");
        { const rn = await load("rondes_nfc", []); let ch = false; // v4.36 · les rondes en cours prennent tout de suite les nouveaux numéros de pointeaux
          for (const r of rn) if (r.statut === "en cours") { const pc = out.find((x) => x.id === r.parcoursId); if (pc) { r.points = pc.points; ch = true; } } if (ch) await save("rondes_nfc", rn); }
        return json({ ok: true, nb: out.length });
      }
    }

    /* ---------- Rondes NFC : démarrage, pointages, fin + rapport au PC ---------- */
    if (r0 === "ronde") {
      let list = await load("rondes_nfc", []);
      if (m === "GET" && r1 === "actuelle") return json(list.find((x) => x.agentId === me.id && x.statut === "en cours") || null);
      if (m === "GET" && r1 && r2 === "pdf") { const r = list.find((x) => x.id === r1); if (!r) return json({ error: "Ronde introuvable" }, 404); // v4.44 · rapport de ronde en PDF
        if (!(r.agentId === me.id || isStaff(me) || estProprio(me))) return deny();
        return new Response(await pdfRonde(r), { headers: { "content-type": "application/pdf", "content-disposition": `inline; filename="rapport-ronde-${String(r.debut).slice(0, 10)}.pdf"`, "cache-control": "no-store" } }); }
      if (m === "GET") return json((isStaff(me) ? list : list.filter((x) => x.agentId === me.id)).slice(0, 200));
      if (m === "POST" && !r1) {
        if (list.some((x) => x.agentId === me.id && x.statut === "en cours")) return json({ error: "Tu as déjà une ronde en cours : termine-la d'abord" }, 400);
        const pc = (await load("parcours", PARCOURS_INITIAL)).find((x) => x.id === body.parcoursId);
        if (!pc) return json({ error: "Parcours introuvable" }, 404);
        const vac = await vacationDe(me);
        const r = { id: uid(), parcoursId: pc.id, nom: pc.nom, site: pc.site, dureeMax: pc.dureeMax || 0, points: pc.points, agentId: me.id, agent: me.nom,
          poste: vac ? [vac.poste, vac.evenement].filter(Boolean).join(" — ") : "", debut: new Date().toISOString(), fin: null, statut: "en cours", passages: [] };
        list.unshift(r); await save("rondes_nfc", list.slice(0, 3000));
        await journal("rondes", me.nom, `ronde démarrée : ${pc.nom}`, "info", "#/rondes");
        return json(r, 201);
      }
      const r = list.find((x) => x.id === r1);
      if (!r) return json({ error: "Ronde introuvable" }, 404);
      if (r.agentId !== me.id && !estProprio(me)) return deny();
      if (m === "POST" && r2 === "pointage") {
        if (r.statut !== "en cours") return json({ error: "Ronde terminée" }, 400);
        const u = normUID(body.uid), i = r.points.findIndex((x) => x.uid === u);
        if (i < 0) {
          const autre = (await load("parcours", PARCOURS_INITIAL)).flatMap((pc) => pc.points).find((x) => x.uid === u);
          return json({ error: autre ? `Ce pointeau (« ${autre.nom} ») ne fait pas partie de cette ronde` : `Pointeau inconnu (${u || "vide"})` }, 400);
        }
        const photo = typeof body.photo === "string" && body.photo.startsWith("data:image/") && body.photo.length < MAX_PHOTO ? body.photo : null;
        const gps = body.gps && typeof body.gps.lat === "number" && typeof body.gps.lon === "number" ? { lat: +body.gps.lat.toFixed(6), lon: +body.gps.lon.toFixed(6), acc: Math.round(body.gps.acc || 0) } : null;
        const avant = r.passages.find((x) => x.uid === u);
        // v4.37 · pointage à la main (sans scanner le pointeau) : Rochdi et Laurent Hernandez uniquement
        if (body.mode === "manuel" && !avant && !(estProprio(me) || String(me.id || "").toLowerCase() === "courrier.laurent@free.fr")) return json({ error: "Pointage à la main non autorisé : scanne le pointeau (ou son QR de secours)" }, 403);
        let pa;
        if (avant && body.photoSeule) pa = { ...avant }; // simple ajout de photo sur un point déjà pointé
        else {
          pa = { uid: u, nom: r.points[i].nom, ordre: i + 1, t: new Date().toISOString(), ras: body.ras !== false, obs: String(body.obs || "").trim().slice(0, 500),
            mode: ["nfc", "lien", "qr", "manuel"].includes(body.mode) ? body.mode : "nfc", photos: 0, gps };
          if (avant) { pa.t = avant.t; pa.mode = avant.mode; pa.photos = avant.photos || 0; pa.gps = avant.gps || gps; pa.tMaj = new Date().toISOString(); } // une anomalie ajoutée après coup garde l'heure de passage
        }
        if (photo) { if ((pa.photos || 0) >= 3) return json({ error: "3 photos maximum par point" }, 400); await save(`photo/${r.id}-${u}-${pa.photos || 0}`, { d: photo, auteurId: me.id }); pa.photos = (pa.photos || 0) + 1; }
        r.passages = r.passages.filter((x) => x.uid !== u); r.passages.push(pa);
        await save("rondes_nfc", list);
        if (!pa.ras && !body.photoSeule) {
          await journal("rondes", me.nom, `⚠️ Anomalie ronde · ${pa.nom} · ${pa.obs}`, "attention", "#/rondes");
          await mailPC(`⚠️ Anomalie de ronde — ${pa.nom} — ${me.nom}`, [...(await lignesAgent(me)), ["Ronde", r.nom], ["Point", pa.nom], ["Heure", fmtParis(pa.t)], ["Anomalie", pa.obs], ["Pointage", pa.mode],
            ["Position", pa.gps ? `https://maps.google.com/?q=${pa.gps.lat},${pa.gps.lon} (±${pa.gps.acc} m)` : ""]], photo ? [photo] : []);
        }
        return json(r);
      }
      if (m === "POST" && r2 === "fin") {
        if (r.statut !== "en cours") return json(r);
        r.fin = new Date().toISOString(); r.statut = "terminée"; r.obs = String(body.obs || "").trim().slice(0, 1000);
        const faits = new Set(r.passages.map((x) => x.uid)), oublies = r.points.filter((x) => !faits.has(x.uid));
        const ordres = [...r.passages].sort((a, b) => a.t.localeCompare(b.t)).map((x) => x.ordre), ordreOk = ordres.every((o, k) => k === 0 || o > ordres[k - 1]);
        const duree = Math.round((Date.parse(r.fin) - Date.parse(r.debut)) / 60000), anomalies = r.passages.filter((x) => !x.ras), manuels = r.passages.filter((x) => x.mode === "manuel");
        Object.assign(r, { oublies: oublies.length, ordreOk, duree, anomalies: anomalies.length });
        await save("rondes_nfc", list);
        await flammes(me, oublies.length ? 10 : ordreOk ? 30 : 20, oublies.length ? "Ronde terminée" : "Ronde complète, tous les points pointés", { cle: "ronde-" + r.id, stat: "rondes" }).catch(() => 0);
        await journal("rondes", me.nom, `ronde terminée : ${r.nom} · ${faits.size}/${r.points.length} points${oublies.length ? ` · ${oublies.length} oublié(s)` : ""}${anomalies.length ? ` · ${anomalies.length} anomalie(s)` : ""}`, oublies.length || anomalies.length ? "attention" : "info", "#/rondes");
        await mailPC(`${oublies.length || anomalies.length ? "⚠️" : "✅"} Rapport de ronde — ${r.nom} — ${me.nom}`, [...(await lignesAgent(me)), ["Ronde", r.nom], ["Début", fmtParis(r.debut)], ["Fin", fmtParis(r.fin)],
          ["Durée", duree + " min" + (r.dureeMax && duree > r.dureeMax ? ` (dépasse ${r.dureeMax} min)` : "")], ["Points pointés", `${faits.size} / ${r.points.length}`], ["Ordre respecté", ordreOk ? "Oui" : "Non"],
          ["Points oubliés", oublies.map((x) => "✖ " + x.nom).join("\n")], ["Anomalies", anomalies.map((x) => `⚠️ ${x.nom} : ${x.obs}`).join("\n")],
          ["Pointés à la main (sans pointeau)", manuels.map((x) => x.nom).join("\n")],
          ["Détail", [...r.passages].sort((a, b) => a.t.localeCompare(b.t)).map((x) => `${fmtParis(x.t).slice(-5)} ${x.ras ? "✔" : "⚠️"} ${x.nom}${x.mode !== "nfc" ? " (" + x.mode + ")" : ""}${x.photos ? ` · ${x.photos} photo(s)` : ""}${x.gps ? ` · https://maps.google.com/?q=${x.gps.lat},${x.gps.lon}` : ""}`).join("\n")],
          ["Observations", r.obs], ["Rapport PDF", "en pièce jointe (avec les photos)"]], [], [{ name: `rapport-ronde-${String(r.debut).slice(0, 10)}-${String(r.nom).replace(/[^A-Za-z0-9]+/g, "-").slice(0, 40)}.pdf`, content: (await pdfRonde(r)).toString("base64") }]);
        return json(r);
      }
    }

    /* ---------- Check-lists (ouverture, stands, spectacle, fermeture…) ---------- */
    if (r0 === "checklists") {
      let list = await load("checklists", []);
      if (m === "GET") {
        if (!isStaff(me)) list = list.filter((c) => c.agentId === me.id);
        return json(list.slice(0, 300));
      }
      if (m === "POST") {
        const items = Array.isArray(body.items) ? body.items.slice(0, 80).map((x) => ({
          label: String(x.label || "").slice(0, 200), ok: x.ok === true, nc: x.nc === true })) : [];
        const c = { id: uid(), t: new Date().toISOString(), agentId: me.id, agent: me.nom,
          modele: String(body.modele || "").slice(0, 80), evenement: String(body.evenement || "").slice(0, 120),
          lieu: String(body.lieu || "").slice(0, 120), obs: String(body.obs || "").slice(0, 2000), items,
          conforme: items.every((x) => !x.nc) };
        list.unshift(c);
        await save("checklists", list.slice(0, 3000));
        const nc = items.filter((x) => x.nc).length;
        await mailPC(`${nc ? "⚠️ " : "✅ "}Check-list — ${c.modele}${c.lieu ? " — " + c.lieu : ""} — ${me.nom}`, [...(await lignesAgent(me)), ["Envoyée le", fmtParis(c.t)],
          ["Événement", c.evenement], ["Lieu", c.lieu], ["Résultat", nc ? `${nc} non-conformité(s)` : "Conforme"],
          ["Non conforme", items.filter((x) => x.nc).map((x) => "✖ " + x.label).join("\n")], ["Conforme", items.filter((x) => x.ok).map((x) => "✔ " + x.label).join("\n")],
          ["Non vérifié", items.filter((x) => !x.ok && !x.nc).map((x) => "• " + x.label).join("\n")], ["Observations", c.obs]]);
        await journal("check-list", me.nom, `${c.modele}${c.evenement ? " · " + c.evenement : ""}${nc ? ` · ${nc} non-conformité(s)` : " · conforme"}`, nc ? "attention" : "info", "#/site");
        return json(c, 201);
      }
    }

    /* ---------- Compteur de jauge (entrées / sorties par porte) ---------- */
    if (r0 === "jauge") {
      const j = await load("jauge", { evenement: "", max: 0, portes: {}, maj: null });
      const total = () => Object.values(j.portes).reduce((a, p) => a + p.in - p.out, 0);
      if (m === "POST") {
        const porte = String(body.porte || "Porte").slice(0, 40);
        const d = Math.max(-50, Math.min(50, parseInt(body.delta, 10) || 0));
        const p = (j.portes[porte] ||= { in: 0, out: 0 });
        if (body.sens === "sortie") p.out += d; else p.in += d;
        p.in = Math.max(0, p.in); p.out = Math.max(0, p.out);
        j.maj = new Date().toISOString();
        await save("jauge", j);
      }
      if (m === "PUT") {
        if (!isStaff(me)) return deny();
        if (body.reset) j.portes = {};
        if (body.evenement !== undefined) j.evenement = String(body.evenement).slice(0, 120);
        if (body.max !== undefined) j.max = Math.max(0, parseInt(body.max, 10) || 0);
        j.maj = new Date().toISOString();
        await save("jauge", j);
      }
      const t = total();
      return json({ evenement: j.evenement, max: j.max, total: t, maj: j.maj,
        portes: isStaff(me) ? j.portes : undefined, pct: j.max ? Math.round((t / j.max) * 100) : null });
    }

    /* ---------- Sites et zones ---------- */
    if (r0 === "zones" && m === "GET") {
      if (SITE_COURANT() === SITE_ORIGINE) return json(await load("zones", DEFAULT_ZONES));
      // v5.85 · site client : les zones viennent du paramétrage du site et de son plan (une seule saisie pour toute l'appli)
      const cfg = await load("site_config", {}), plan = await load("plan_site", {}), nomS = cfg.nom || (SITE_CFG() || {}).nom || "Site", sec = {};
      if ((cfg.secteurs || []).length) sec["Secteurs"] = cfg.secteurs;
      if ((plan.zones || []).length) sec["Zones du plan"] = plan.zones.map((z) => z.nom);
      if ((plan.points || []).length) sec["Accès et points"] = plan.points.map((q) => q.nom);
      return json({ [nomS]: sec });
    }
    if (r0 === "prestataires" && m === "GET") return json(await load("prestataires", DEFAULT_PRESTATAIRES));

    /* ---------- Rapports libres avec photos (envoyés au mail du PC) ---------- */
    if (r0 === "rapports") {
      let list = await load("rapports", []);
      if (m === "GET" && me.role === "client") return json(anonyme(list).slice(0, 300));
      if (m === "GET") return json((isStaff(me) ? list : list.filter((r) => r.auteurId === me.id)).slice(0, 300));
      if (m === "POST") {
        const t = (v, n = 120) => String(v ?? "").trim().slice(0, n);
        const photos = (Array.isArray(body.photos) ? body.photos : []).filter((d) => typeof d === "string" && d.startsWith("data:image/") && d.length < MAX_PHOTO).slice(0, 4);
        const r = { id: uid(), t: new Date().toISOString(), auteurId: me.id, auteur: me.nom, titre: t(body.titre) || "Rapport", site: t(body.site, 60), lieu: t(body.lieu),
          texte: t(body.texte, 6000), gps: body.gps && typeof body.gps.lat === "number" ? { lat: body.gps.lat, lon: body.gps.lon } : null, photos: photos.length };
        if (!r.texte && !photos.length) return json({ error: "Écris un texte ou ajoute une photo" }, 400);
        for (let i = 0; i < photos.length; i++) await save(`photo/${r.id}-${i}`, { d: photos[i], auteurId: me.id });
        list.unshift(r); await save("rapports", list.slice(0, 3000));
        await mailPC(`📝 Rapport — ${r.titre}`, [...(await lignesAgent(me)), ["Heure", fmtParis(r.t)], ["Site", ERP(r.site)], ["Lieu", r.lieu], ["Rapport", r.texte],
          ["Position", r.gps ? `https://maps.google.com/?q=${r.gps.lat},${r.gps.lon}` : ""]], photos);
        await journal("rapport", me.nom, `${r.titre}${r.lieu ? " · " + r.lieu : ""}${photos.length ? ` · ${photos.length} photo(s)` : ""}`, "info", "#/rapports");
        return json(r, 201);
      }
    }

    /* ---------- Rapports terrain (DI, malaise, incident, rixe, intrusion…) : photo + mail direct au PC ---------- */
    if (r0 === "rap" || r0 === "di") {
      let list = await load("rap", null);
      if (!list) list = (await load("di", [])).map((d) => ({ ...d, kind: "di", details: { "Type de défaut": d.type }, statut: d.statut === "traitée" ? "clos" : d.statut === "à traiter" ? "ouvert" : d.statut }));
      if (m === "GET" && me.role === "client") return json(anonyme(list).slice(0, 800));
      if (m === "GET") return json((isStaff(me) ? list : list.filter((r) => r.auteurId === me.id || (me.perimetre === "arena" && /arena/i.test(r.site || "")))).slice(0, 800));
      if (m === "POST") {
        const t = (v, n = 120) => String(v ?? "").trim().slice(0, n);
        const K = TYPES_RAPPORT[body.kind] || TYPES_RAPPORT.autre;
        const kind = TYPES_RAPPORT[body.kind] ? body.kind : "autre";
        if (K.ssi) { // v4.61 · rapports SSI : PC Parc / SSIAP 2 (zone parc), SSIAP 2 PCS Arena (zone arena), propriétaire et admins
          const zone = (globalThis.RAP_CATS.find((c) => c.types.includes(K)) || {}).ssi;
          const ok = estProprio(me) || me.role === "admin" || (me.perimetre === "arena" ? zone === "arena" : (me.role === "pc" || me.perimetre === "pcparc" || me.role === "ssiap2" || me.roleAgent === "ssiap2"));
          if (!ok || me.role === "client" || me.role === "responsable") return json({ error: "Rapport SSI réservé au PC sécurité et aux SSIAP 2" }, 403);
        }
        const photos = (Array.isArray(body.photos) ? body.photos : []).filter((d) => typeof d === "string" && d.startsWith("data:image/") && d.length < MAX_PHOTO).slice(0, 4);
        const details = {};
        for (const [k, v] of Object.entries(body.details && typeof body.details === "object" ? body.details : {}).slice(0, 20)) { const x = Array.isArray(v) ? v.map((y) => t(y, 60)).join(", ") : t(v, 300); if (x) details[t(k, 60)] = x; }
        const vac = await vacationDe(me);
        const d = { id: uid(), t: new Date().toISOString(), kind, label: K.lb, auteurId: me.id, auteur: me.nom,
          poste: vac ? [vac.poste, vac.evenement].filter(Boolean).join(" — ") : "", heure: /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}/.test(body.heure || "") ? body.heure.slice(0, 16) : null,
          urgence: body.urgence === "urgente" ? "urgente" : "normale", site: t(body.site, 60), lieu: t(body.lieu), prestataire: t(body.prestataire, 80),
          details, texte: t(body.texte, 4000), securise: t(body.securise, 500), intervenants: (Array.isArray(body.intervenants) ? body.intervenants : []).map((x) => t(x, 40)).slice(0, 10).join(", "),
          gps: body.gps && typeof body.gps.lat === "number" ? { lat: body.gps.lat, lon: body.gps.lon } : null, photos: photos.length, statut: "ouvert", suivi: [] };
        if (!d.lieu) return json({ error: "Indique la zone" }, 400);
        if (!d.texte) return json({ error: "Décris ce qui s'est passé" }, 400);
        const year = new Date().getFullYear(), cpt = await load("rap_compteur", {});
        cpt[K.pre + year] = (cpt[K.pre + year] || 0) + 1; await save("rap_compteur", cpt);
        d.numero = `${K.pre}-${year}-${String(cpt[K.pre + year]).padStart(4, "0")}`;
        for (let i = 0; i < photos.length; i++) await save(`photo/${d.id}-${i}`, { d: photos[i], auteurId: me.id });
        list.unshift(d); await save("rap", list.slice(0, 8000));
        // trace automatique dans la main courante
        const mc = await load("mc_compteur", {});
        mc[year] = (mc[year] || 0) + 1; await save("mc_compteur", mc);
        await mcAjouter({ id: uid(), numero: `MC-${year}-${String(mc[year]).padStart(4, "0")}`, t: d.t, heure: d.heure, auteurId: me.id, auteur: me.nom, role: me.role,
          evenementId: null, evenement: vac?.evenement || "", categorie: K.lb, gravite: d.urgence === "urgente" ? "urgente" : K.grav || "info",
          site: d.site, lieu: d.lieu, description: `Rapport ${d.numero} : ${d.texte}`, intervenants: d.intervenants, actions: d.securise, prestataire: d.prestataire,
          gps: d.gps, statut: "ouvert", suivi: [], photo: false, rapport: d.numero });
        await mailPC(`${d.urgence === "urgente" ? "🚨 URGENT — " : ""}${K.ic} ${d.numero} — ${K.lb} — ${d.lieu} — ${me.nom}`, [["Rapport", `${K.lb} · ${d.numero}`],
          ...(await lignesAgent(me)), ["Heure du fait", fmtHeure(d.heure)], ["Envoyé le", fmtParis(d.t)],
          ["Urgence", d.urgence === "urgente" ? "URGENTE" : "Normale"], ["Site", ERP(d.site)], ["Zone", d.lieu], ...Object.entries(d.details),
          ["Constat / déroulé", d.texte], ["Mesures prises", d.securise], ["Intervenants", d.intervenants], ["Prestataire concerné", d.prestataire],
          ["Position", d.gps ? `https://maps.google.com/?q=${d.gps.lat},${d.gps.lon}` : ""]], photos);
        await journal("rapport", me.nom, `${d.numero} · ${K.lb} · ${d.lieu}${photos.length ? ` · ${photos.length} photo(s)` : ""}`, d.urgence === "urgente" ? "urgent" : "attention", "#/rap");
        return json(d, 201);
      }
      if (m === "PATCH" && r1) {
        if (!isStaff(me)) return deny();
        const d = list.find((x) => x.id === r1); if (!d) return json({ error: "Rapport introuvable" }, 404);
        if (["ouvert", "en cours", "clos"].includes(body.statut)) d.statut = body.statut;
        const note = String(body.note || "").trim().slice(0, 500);
        d.suivi.push({ t: new Date().toISOString(), qui: me.nom, note: note || "statut : " + d.statut });
        await save("rap", list); await journal("rapport", me.nom, `${d.numero} → ${d.statut}`, "info", "#/rap");
        return json(d);
      }
    }

    /* ---------- Alertes en cours (enfant perdu…) : visibles par tous, disparaissent au bout d'1 h ---------- */
    /* ---------- v4.89 · Retour d'expérience (RETEX) après chaque événement / vacation → traité par le SSIAP 3 ---------- */
    if (r0 === "retex") {
      if (me.role === "client" || me.role === "sms") return deny();
      const TYPES = { anomalie: "Anomalie", amelioration: "Amélioration", faille: "Faille de sécurité", autre: "Autre", test: "Avis phase de test" }, STATUTS = ["nouveau", "en cours", "traité", "classé"];
      const t = (v, n = 160) => String(v ?? "").trim().slice(0, n), list = await load("retex", []), traite = estSSIAP3(me);
      if (m === "GET") { const v = await vacationDe(me).catch(() => null);
        return json({ peutTraiter: traite, types: TYPES, statuts: STATUTS, vacation: v ? { date: v.date, poste: v.poste || "", evenement: v.evenement || "", site: v.site || "" } : null,
          items: (traite ? list : list.filter((x) => x.auteurId === me.id)).slice(0, 300) }); }
      if (m === "POST" && !r1) {
        if (body.ras) { const n = await flammes(me, 5, "Retour d'expérience : rien à signaler", { cle: "retexras-" + jourParis(), stat: "retexras" }); return json({ ok: true, flammes: n }); }
        if (!TYPES[body.type]) return json({ error: "Choisis le type de retour" }, 400);
        const texte = t(body.texte, 3000); if (texte.length < 5) return json({ error: "Décris ton retour en quelques mots" }, 400);
        const v = await vacationDe(me).catch(() => null), year = new Date().getFullYear(), cpt = await load("retex_compteur", {}); cpt[year] = (cpt[year] || 0) + 1; await save("retex_compteur", cpt);
        const x = { id: uid(), numero: `RX-${year}-${String(cpt[year]).padStart(4, "0")}`, t: new Date().toISOString(), type: body.type, titre: t(body.titre, 140), texte, lieu: t(body.lieu, 120),
          evenement: t(body.evenement, 160) || (v && v.evenement) || "", vacation: v ? { date: v.date, poste: v.poste || "", site: v.site || "", debut: v.debut, fin: v.fin } : null,
          auteurId: me.id, auteur: me.nom, poste: posteDe(me), statut: "nouveau", suivi: [], reponse: "" };
        list.unshift(x); await save("retex", list.slice(0, 2000));
        await journal("retex", me.nom, x.type === "faille" ? `${x.numero} · nouveau retour d'expérience (faille de sécurité) transmis au SSIAP 3` : `${x.numero} · retour d'expérience ${TYPES[x.type]}${x.titre ? " · " + x.titre : ""}`, x.type === "faille" ? "attention" : "info", "#/retex");
        await envoyerPush({ titre: `Retour d'expérience · ${TYPES[x.type]}`, texte: `${me.nom}${x.poste ? " (" + x.poste + ")" : ""}${x.type === "faille" ? "" : " : " + (x.titre || x.texte).slice(0, 120)}`, url: "/#/retex" }, (u) => estSSIAP3(u) && u.id !== me.id).catch(() => 0);
        const n = await flammes(me, 20, `Retour d'expérience ${TYPES[x.type].toLowerCase()} (${x.numero})`, { capJour: 3, stat: "retex" });
        return json({ ...x, flammes: n }, 201);
      }
      if (m === "PATCH" && r1) {
        if (!traite) return json({ error: "Traitement réservé au SSIAP 3" }, 403);
        const x = list.find((y) => y.id === r1); if (!x) return json({ error: "Retour introuvable" }, 404);
        const st = STATUTS.includes(body.statut) ? body.statut : x.statut, rp = body.reponse != null ? t(body.reponse, 2000) : x.reponse;
        x.suivi = [...(x.suivi || []), { t: new Date().toISOString(), par: me.nom, statut: st, texte: body.reponse != null && rp !== x.reponse ? rp : "" }].slice(-30);
        x.statut = st; x.reponse = rp; if (st === "traité" || st === "classé") x.traitePar = me.nom;
        await save("retex", list);
        await journal("retex", me.nom, `${x.numero} · ${st}${x.type !== "faille" && rp ? " · " + rp.slice(0, 120) : ""}`, "info", "#/retex");
        await envoyerPush({ titre: `Ton retour ${x.numero} : ${st}`, texte: rp ? rp.slice(0, 140) : `Pris en charge par ${me.nom}`, url: "/#/retex" }, (u) => u.id === x.auteurId).catch(() => 0);
        if (st === "traité" && !x.bonus && (x.type === "faille" || x.type === "amelioration") && body.utile) { x.bonus = true; await save("retex", list); const au = (await load("users", [])).find((u) => u.id === x.auteurId) || { id: x.auteurId, nom: x.auteur, role: "ads" }; await flammes(au, 50, `Retour d'expérience jugé utile par le SSIAP 3 (${x.numero})`, { cle: "retexutile-" + x.id, stat: "retexutile" }); }
        return json(x);
      }
      return json({ error: "Requête invalide" }, 400);
    }
    /* ---------- v4.89 · Flammes, badges, médailles de vaillant, missions ---------- */
    if (r0 === "flammes") {
      if (me.role === "client" || me.role === "sms") return deny();
      const F = await load("flammes", {}), users = await load("users", []), traite = estSSIAP3(me);
      // v4.96 · les agents ne voient pas les activités des badges Or et All accès (eux voient tout) ; ces badges ne sont pas désignés agent du mois automatiquement
      const hauts = new Set(); for (const id of Object.keys(F)) { const u = users.find((x) => x.id === id) || (estProprio({ id }) ? { id, role: "admin" } : { id, nom: F[id].nom, role: "ads" }); if (["or", "allaccess"].includes(await badgeDe(u))) hauts.add(id); }
      const voitTout = traite || ["diamant", "or", "allaccess", "admin"].includes(await badgeDe(me));
      const FV = voitTout ? F : Object.fromEntries(Object.entries(F).filter(([id]) => !hauts.has(id) || id === me.id)), FA = Object.fromEntries(Object.entries(F).filter(([id]) => !hauts.has(id)));
      if (m === "GET" && (!r1 || r1 === "moi")) { const f = F[me.id] || { nom: me.nom, total: 0, hist: [], medailles: [], stats: {}, depuis: me.cree };
        const classement = Object.entries(FV).map(([id, x]) => ({ id, nom: x.nom, total: x.total || 0, badge: niveauNom(Math.floor((x.total || 0) / 1000)), medailles: (x.medailles || []).length, med: (x.medailles || []).map(({ type, titre, motif, t }) => ({ type, titre, motif, t })), serie: x.serie || 0 })).sort((a, b) => b.total - a.total);
        const rang = classement.findIndex((x) => x.id === me.id) + 1;
        const out = { moi: { ...profilFlammes(f, users.find((u) => u.id === me.id) || me), hist: (f.hist || []).slice(0, 40), rang, sur: classement.length }, niveaux: NIVEAUX, medaillesTypes: MEDAILLES, missionsTypes: MISSIONS,
          honneur: classement.slice(0, 15).map(({ id, ...x }) => x), medaillesRecentes: Object.values(FV).flatMap((x) => (x.medailles || []).map((md) => ({ nom: x.nom, ...md }))).sort((a, b) => b.t.localeCompare(a.t)).slice(0, 12), peutValider: traite };
        { const A = await load("agent_du_mois", {}), pm = moisPrec(jourParis().slice(0, 7)); out.agentDuMois = A[pm] && (voitTout || !hauts.has(A[pm].id)) ? { mois: pm, nom: A[pm].nom } : null; }
        out.moi.annonceVue = !!(F[me.id] && F[me.id].annonceVue); out.voitActivite = voitTout;
        { const PR = await load("protocole", { phase: "test", debut: null }); out.phase = PR.phase || "test"; out.peutPhase = estProprio(me) && !me.apercu; out.promo = (await load("promo_victoire", { actif: true })).actif !== false; }
        out.moi.pas = { jour: ((f.pas || {}).jours || {})[jourParis()] || 0, total: (f.pas || {}).total || 0 };
        { const j = jourParis(), mo = j.slice(0, 7), top = (fn) => Object.values(FV).map((x) => ({ nom: x.nom, pas: fn((x.pas || {})) })).filter((x) => x.pas > 0).sort((a, b) => b.pas - a.pas).slice(0, 15);
          out.marcheurs = { jour: top((P) => (P.jours || {})[j] || 0), mois: top((P) => Object.entries(P.jours || {}).filter(([k]) => k.startsWith(mo)).reduce((t, [, v]) => t + v, 0)), total: top((P) => P.total || 0) }; }
        if (traite) { out.missions = (await load("missions", [])).filter((x) => x.statut === "créditée" || x.statut === "à valider").slice(0, 40); out.agents = users.filter((u) => u.actif !== false && AGENTS.concat(["ssiap3"]).includes(u.role)).map((u) => ({ id: u.id, nom: u.nom })).sort((a, b) => a.nom.localeCompare(b.nom, "fr")); }
        return json(out); }
      if (m === "GET" && r1 === "mois") { // v4.92 · tableau d'honneur « agent du mois »
        const { A, prev } = await agentDuMois(FA), cur = jourParis().slice(0, 7), sc = scoresMois(FV, cur, 1), w0 = A[prev], w = w0 && (voitTout || !hauts.has(w0.id)) ? w0 : null;
        const enrichir = async (x) => { if (!x) return null; const f = F[x.id] || {}, u = users.find((v) => v.id === x.id), av = await load(`avatar/${x.id}`, null);
          return { mois: x.mois, nom: x.nom, poste: u ? u.fonction || ROLE_POSTE[u.role] || "" : "", scores: x.scores, mot: x.mot || "", par: x.auto ? "" : x.par || "", photo: av ? av.d : null, badge: niveauNom(Math.floor((f.total || 0) / 1000)), medailles: (f.medailles || []).map(({ type, titre, motif, t }) => ({ type, titre, motif, t })) }; };
        const top = (k) => sc.filter((x) => x.vacations >= 3).slice().sort((a, b) => b[k] - a[k] || b.vacations - a.vacations).slice(0, 3).map(({ nom, vacations, ...r }) => ({ nom, note: r[k] }));
        return json({ phase: (await load("protocole", { phase: "test" })).phase || "test", criteres: CRITERES, prev, cur, agent: await enrichir(w ? { ...w, mois: prev } : null), peutDesigner: traite,
          course: sc.slice(0, 12).map(({ id, ...x }) => ({ ...x, moi: id === me.id })), moi: (() => { const i = sc.findIndex((x) => x.id === me.id); return i < 0 ? null : { rang: i + 1, ...sc[i], id: undefined }; })(),
          meilleurs: Object.fromEntries(Object.keys(CRITERES).map((k) => [k, top(k)])),
          archives: Object.entries(A).filter(([, x]) => voitTout || !hauts.has(x.id)).sort((a, b) => b[0].localeCompare(a[0])).slice(0, 12).map(([mo, x]) => ({ mois: mo, nom: x.nom, global: x.scores ? x.scores.global : null, mot: x.mot || "" })),
          agents: traite ? users.filter((u) => u.actif !== false && AGENTS.concat(["ssiap3"]).includes(u.role)).map((u) => ({ id: u.id, nom: u.nom })).sort((a, b) => a.nom.localeCompare(b.nom, "fr")) : undefined });
      }
      if (m === "GET" && r1 === "activite") { // v4.97 · tableau de bord « Activité agents » (Or, All accès, admins, SSIAP 3)
        if (!voitTout) return json({ error: "Réservé aux badges Or, All accès et à l'encadrement" }, 403);
        const j = jourParis(), mo = j.slice(0, 7), sc = Object.fromEntries(scoresMois(F, mo, 1).map((x) => [x.id, x])), RX = await load("retex", []), MI = await load("missions", []);
        const lignes = new Map();
        for (const [id, f] of Object.entries(F)) { const ms = (f.mois || {})[mo] || {}, P = f.pas || {};
          lignes.set(id, { id, nom: f.nom, total: f.total || 0, niveau: niveauNom(Math.floor((f.total || 0) / 1000)), haut: hauts.has(id), medailles: (f.medailles || []).map(({ type, titre, motif, t }) => ({ type, titre, motif, t })), serie: f.serie || 0,
            pasJour: (P.jours || {})[j] || 0, pasMois: Object.entries(P.jours || {}).filter(([k]) => k.startsWith(mo)).reduce((t0, [, v]) => t0 + v, 0), mois: ms, score: sc[id] || null,
            flammesMois: (f.hist || []).filter((h) => String(h.t).startsWith(mo)).reduce((t0, h) => t0 + (h.n || 0), 0), derniere: (f.hist || []).find((h) => h.n) || null, hist: (f.hist || []).slice(0, 15) }); }
        for (const u of users) if (u.actif !== false && AGENTS.concat(["ssiap3"]).includes(u.role) && !lignes.has(u.id)) lignes.set(u.id, { id: u.id, nom: u.nom, total: 0, niveau: niveauNom(0), haut: false, medailles: [], serie: 0, pasJour: 0, pasMois: 0, mois: {}, score: null, flammesMois: 0, derniere: null, hist: [] });
        const L = [...lignes.values()], flux = Object.values(F).flatMap((f) => (f.hist || []).slice(0, 30).map((h) => ({ nom: f.nom, ...h }))).sort((a, b) => String(b.t).localeCompare(String(a.t))).slice(0, 60);
        return json({ mois: mo, phase: (await load("protocole", { phase: "test" })).phase || "test", agents: L.map(({ id, ...x }) => ({ cle: id, ...x })), flux,
          kpi: { participants: L.filter((x) => x.total > 0).length, inscrits: L.length, flammesMois: L.reduce((t0, x) => t0 + x.flammesMois, 0), pasJour: L.reduce((t0, x) => t0 + x.pasJour, 0),
            medailles: L.reduce((t0, x) => t0 + x.medailles.length, 0), missionsMois: MI.filter((x) => String(x.t).startsWith(mo) && x.statut !== "annulée").length,
            retexNouveaux: RX.filter((x) => x.statut === "nouveau").length, retexMois: RX.filter((x) => String(x.t).startsWith(mo)).length, arriveMois: L.reduce((t0, x) => t0 + (x.mois.arrive || 0), 0),
            prisesMois: L.reduce((t0, x) => t0 + (x.mois.prise || 0), 0), ponctuelMois: L.reduce((t0, x) => t0 + (x.mois.ponctuel || 0), 0) } });
      }
      if (m === "GET" && r1 === "promo") { // v4.99 · contenu de la publicité : photo de Rochdi + bulle
        const PR = await load("promo_victoire", { actif: true }), att = await load("avatars_attente", {});
        const ph = (await load("avatar/__admin", null)) || (await load(`avatar/${PROPRIO()}`, null)), d = ph ? ph.d : att["mecheti rochdi"] || null;
        return json({ photo: d, nom: process.env.OWNER_NOM || "Rochdi Mecheti", texte: PR.texte || PROMO_TEXTE }); }
      if (m === "POST" && r1 === "promo") { // v4.99 · publicité VICTOIRE à l'ouverture de l'appli (propriétaire)
        if (!estProprio(me) || me.apercu) return deny(); const PR0 = await load("promo_victoire", { actif: true });
        await save("promo_victoire", { ...PR0, actif: body.actif == null ? PR0.actif !== false : !!body.actif, ...(body.texte != null ? { texte: String(body.texte).trim().slice(0, 400) } : {}), par: me.nom, t: new Date().toISOString() });
        if (body.actif == null) return json({ ok: true });
        await journal("flammes", me.nom, `publicité VICTOIRE ${body.actif ? "activée" : "désactivée"}`, "info", "#/flammes"); return json({ ok: true, actif: !!body.actif }); }
      if (m === "POST" && r1 === "phase") { // v4.96 · phase de test → lancement officiel (propriétaire) : remise à zéro des compteurs
        if (!estProprio(me) || me.apercu) return deny();
        if (body.phase === "officiel") {
          if (body.raz) { await save("flammes", {}); await save("agent_du_mois", {}); await save("missions", []); }
          await save("protocole", { phase: "officiel", debut: new Date().toISOString(), par: me.nom });
          await journal("flammes", me.nom, `lancement officiel du protocole de motivation${body.raz ? " (compteurs remis à zéro)" : ""}`, "info", "#/flammes");
          return json({ ok: true, phase: "officiel" }); }
        await save("protocole", { phase: "test", debut: new Date().toISOString(), par: me.nom }); return json({ ok: true, phase: "test" });
      }
      if (m === "POST" && r1 === "annonce") { // v4.95 · présentation du protocole vue (une fois par agent, tous appareils)
        const F2 = await load("flammes", {}); const f = (F2[me.id] ||= { nom: me.nom, total: 0, hist: [], cles: [], jours: {}, medailles: [], stats: {}, depuis: me.cree || new Date().toISOString() });
        f.annonceVue = new Date().toISOString(); await save("flammes", F2); return json({ ok: true }); }
      if (m === "POST" && r1 === "pas") { // v4.90 · podomètre (appli ouverte) : lots envoyés toutes les 1 à 2 minutes
        const F2 = await load("flammes", {}), j = jourParis(), now = Date.now();
        const f = (F2[me.id] ||= { nom: me.nom, total: 0, hist: [], cles: [], jours: {}, medailles: [], stats: {}, depuis: me.cree || new Date().toISOString() });
        const P = (f.pas ||= { total: 0, jours: {}, dernier: 0, reste: 0 });
        const min = Math.max(0.5, Math.min(30, (now - (P.dernier || now - 60e3)) / 60e3)), n = Math.max(0, Math.min(parseInt(body.pas) || 0, Math.round(min * 200))); // 200 pas / min max (anti-triche)
        const deja = P.jours[j] || 0;
        // v5.25 · appli Android : total du jour mesuré par le capteur du téléphone (compte aussi en veille) ; plafond 200 pas / minute écoulée depuis minuit
        const hp = new Intl.DateTimeFormat("fr-FR", { timeZone: "Europe/Paris", hour: "2-digit", minute: "2-digit", hour12: false }).format(new Date(now)).split(":").map(Number), depuisMinuit = (hp[0] % 24) * 60 + hp[1] + 1;
        const natif = body.natif ? Math.max(0, Math.min(parseInt(body.jourPas) || 0, depuisMinuit * 200, PAS_MAX_JOUR)) : 0;
        const compte = body.natif ? Math.max(0, natif - deja) : Math.max(0, Math.min(n, PAS_MAX_JOUR - deja));
        P.jours[j] = deja + compte; P.total += compte; P.dernier = now; for (const k of Object.keys(P.jours)) if (k < new Date(now - 40 * 864e5).toISOString().slice(0, 10)) delete P.jours[k];
        const avant = Math.floor(deja / PAS_FLAMME), apres = Math.floor(P.jours[j] / PAS_FLAMME); await save("flammes", F2);
        if (apres > avant) await flammes(me, (apres - avant) * PAS_GAIN, `Podomètre : ${flNbS(apres * PAS_FLAMME)} pas aujourd'hui`, { stat: "pas" });
        return json({ jour: P.jours[j], total: P.total, compte });
      }
      if (!traite) return json({ error: "Réservé au SSIAP 3" }, 403);
      const cible = (id) => users.find((u) => u.id === id) || (F[id] ? { id, nom: F[id].nom, role: "ads" } : null);
      if (m === "POST" && r1 === "mission" && r2) { const MI = await load("missions", []), x = MI.find((y) => y.id === r2); if (!x) return json({ error: "Mission introuvable" }, 404);
        if (body.annuler && x.statut === "créditée") { const k = await flammesRetirer(x.auteurId, x.points || 0, `Mission annulée par le SSIAP 3 (${x.numero})${body.note ? " : " + String(body.note).slice(0, 120) : ""}`, "missions");
          Object.assign(x, { statut: "annulée", par: me.nom, tValid: new Date().toISOString(), note: String(body.note || "").slice(0, 300), retire: k }); await save("missions", MI);
          await journal("flammes", me.nom, `mission ${x.numero} de ${x.nom} annulée (−${k} flammes)`, "info", "#/flammes"); return json(x); }
        if (body.medaille && MEDAILLES[body.medaille] && x.statut === "créditée") { const u = cible(x.auteurId); if (u) await medaille(u, body.medaille, `${x.categorie} · ${x.numero}`); x.medaille = body.medaille; await save("missions", MI); return json(x); }
        if (x.statut !== "à valider") return json(x);
        if (body.refuser) { Object.assign(x, { statut: "refusée", par: me.nom, tValid: new Date().toISOString(), note: String(body.note || "").slice(0, 300) }); await save("missions", MI); return json(x); }
        const pts = Math.max(0, Math.min(1000, parseInt(body.points) || MISSIONS[x.type][1])), u = cible(x.auteurId); if (!u) return json({ error: "Agent introuvable" }, 404);
        Object.assign(x, { statut: "validée", points: pts, par: me.nom, tValid: new Date().toISOString(), note: String(body.note || "").slice(0, 300) }); await save("missions", MI);
        await flammes(u, pts, `Mission validée : ${MISSIONS[x.type][0]} (${x.numero})`, { cle: "mission-" + x.id, stat: "missions" });
        if (MEDAILLES[body.medaille]) await medaille(u, body.medaille, x.note || `${x.categorie} · ${x.numero}`);
        await envoyerPush({ titre: `🔥 Mission validée : +${pts} flammes`, texte: `${MISSIONS[x.type][0]} · validée par ${me.nom}`, url: "/#/flammes" }, (v) => v.id === u.id).catch(() => 0);
        return json(x); }
      if (m === "POST" && r1 === "mois") { // v4.92 · le SSIAP 3 désigne l'agent du mois (ou ajoute un mot)
        const mo = /^\d{4}-\d{2}$/.test(body.mois || "") ? body.mois : moisPrec(jourParis().slice(0, 7)), A = await load("agent_du_mois", {}), mot = String(body.mot || "").trim().slice(0, 300);
        if (body.userId && (!A[mo] || A[mo].id !== body.userId)) { const u = cible(body.userId); if (!u) return json({ error: "Agent introuvable" }, 404);
          const sc = scoresMois(F, mo, 0).find((x) => x.id === u.id) || null; A[mo] = { id: u.id, nom: u.nom, scores: sc, auto: false, par: me.nom, mot, t: new Date().toISOString() };
          await save("agent_du_mois", A); await flammes(u, 200, `🏆 Agent du mois (${mo})`, { cle: "adm-" + mo, stat: "agentmois" });
          await journal("flammes", me.nom, `🏆 ${u.nom} désigné agent du mois (${mo})`, "info", "#/honneur");
          await envoyerPush({ titre: "🏆 Tu es l'agent du mois !", texte: mot || `Désigné par ${me.nom}. Bravo !`, url: "/#/honneur" }, (x) => x.id === u.id).catch(() => 0);
          return json(A[mo]); }
        if (!A[mo]) return json({ error: "Aucun agent du mois pour ce mois" }, 404);
        A[mo].mot = mot; A[mo].par = me.nom; await save("agent_du_mois", A); return json(A[mo]);
      }
      if (m === "POST" && r1 === "medaille") { const u = cible(body.userId); if (!u) return json({ error: "Agent introuvable" }, 404); if (!MEDAILLES[body.type]) return json({ error: "Médaille inconnue" }, 400);
        const motif = String(body.motif || "").trim().slice(0, 300); if (!motif) return json({ error: "Indique le motif" }, 400);
        await medaille(u, body.type, motif); return json({ ok: true }); }
      return json({ error: "Requête invalide" }, 400);
      async function medaille(u, type, motif) {
        const F2 = await load("flammes", {}); const f = (F2[u.id] ||= { nom: u.nom, total: 0, hist: [], cles: [], jours: {}, medailles: [], stats: {}, depuis: u.cree || new Date().toISOString() });
        f.medailles = [...(f.medailles || []), { type, titre: MEDAILLES[type], motif, par: me.nom, t: new Date().toISOString() }]; await save("flammes", F2);
        await flammes(u, 300, `🎖️ Médaille ${MEDAILLES[type]}`, { cle: "med-" + uid(), stat: "medaille" });
        await journal("flammes", me.nom, `🎖️ ${u.nom} reçoit la médaille ${MEDAILLES[type]} : ${motif}`, "info", "#/flammes");
        await envoyerPush({ titre: "🎖️ Médaille de vaillant", texte: `${MEDAILLES[type]} — ${motif.slice(0, 120)}`, url: "/#/flammes" }, (v) => v.id === u.id).catch(() => 0);
      }
    }
    if (r0 === "alertes") {
      let list = await load("alertes", []); const now = Date.now();
      const actives = () => list.filter((a) => !a.fin && Date.parse(a.exp) > now);
      if (m === "GET" && me.role === "client") return json({ actives: actives().map(({ id, nature, texte, lieu, site, t, exp }) => ({ id, nature, texte, lieu, site, t, exp, auteur: "", vus: [] })), recentes: [] });
      if (m === "GET") return json({ actives: actives(), recentes: isStaff(me) ? list.filter((a) => Date.parse(a.t) > now - 24 * 3600e3).slice(0, 50) : [] });
      const t = (v, n = 120) => String(v ?? "").trim().slice(0, n);
      if (m === "POST" && !r1) {
        const NATURES = ["Enfant perdu", "Personne recherchée", "Personne vulnérable / malaise", "Objet suspect", "Comportement suspect", "Véhicule recherché", "Évacuation / mise à l'abri", "Alerte météo", "Autre"];
        const a = { id: uid(), t: new Date().toISOString(), exp: new Date(now + 3600e3).toISOString(), nature: NATURES.includes(body.nature) ? body.nature : "Autre",
          texte: t(body.texte, 1000), site: t(body.site, 60), lieu: t(body.lieu), auteur: me.nom, auteurId: me.id, auteurPoste: posteDe(me), fin: null,
          gps: gpsOk(body.gps), forcee: body.forcee !== false, vus: [{ id: me.id, nom: me.nom, t: new Date().toISOString() }], relances: 0, derniereRelance: new Date().toISOString() };
        if (!a.texte) return json({ error: "Ajoute une description" }, 400);
        list.unshift(a); await save("alertes", list.slice(0, 500));
        await envoyerPush({ titre: `${a.forcee ? "ALERTE FORCÉE" : "ALERTE"} — ${a.nature}`, texte: `${a.lieu ? a.lieu + " · " : ""}${a.texte.slice(0, 160)}${a.forcee ? " — confirme la réception dans l'appli" : ""}`, url: "/#/alertes", alerte: true }, enService).catch(() => 0);
        await journal("alerte", me.nom, `🚨 ${a.nature}${a.lieu ? " · " + a.lieu : ""}${a.gps ? " · 📍 position jointe" : ""} · ${a.texte.slice(0, 120)}`, "urgent", "#/alertes");
        await mailPC(`🚨 ALERTE — ${a.nature}${a.lieu ? " — " + a.lieu : ""}`, [...(await lignesAgent(me)), ["Nature", a.nature], ["Site", ERP(a.site)], ["Lieu", a.lieu], ["Description", a.texte], ["Heure", fmtParis(a.t)], ["Fin automatique", fmtParis(a.exp)]]);
        return json(a, 201);
      }
      if (m === "POST" && r2 === "reponse") { // v4.88 · « J'arrive » / « Plus de détails ? » / « Ne te mets pas en danger ! »
        if (me.role === "client") return deny();
        const a = list.find((x) => x.id === r1); if (!a || a.fin || Date.parse(a.exp) <= now) return json({ error: "Alerte terminée" }, 404);
        if (a.auteurId === me.id) return json({ error: "C'est ton alerte : ajoute plutôt une précision" }, 400);
        const r = ajouterReponse(a, me, body.type); if (!r) return json({ error: "Réponse inconnue" }, 400);
        if (r.type === "arrive") await flammes(me, 15, `Réactivité : « J'arrive » sur l'alerte ${a.nature}`, { cle: "rep-" + a.id, stat: "arrive" }).catch(() => 0);
        a.vus ||= []; if (!a.vus.some((v) => v.id === me.id)) a.vus.push({ id: me.id, nom: me.nom, t: r.t });
        await save("alertes", list);
        await journal("alerte", me.nom, `↪ ${me.nom}${r.poste ? " (" + r.poste + ")" : ""} : ${REPONSES[r.type]} — alerte ${a.nature}`, r.type === "arrive" ? "attention" : "info", "#/alertes");
        await envoyerPush({ titre: `${me.nom}${r.poste ? " · " + r.poste : ""}`, texte: `${REPONSES[r.type]} — ${a.nature}${a.lieu ? " · " + a.lieu : ""}`, url: "/#/alertes", alerte: r.type !== "danger" }, (u) => u.id === a.auteurId || isStaff(u) || estProprio(u)).catch(() => 0);
        return json(a);
      }
      if (m === "POST" && r2 === "precision") { // v4.88 · l'auteur (ou le PC) répond aux demandes de détails : diffusé à tous
        const a = list.find((x) => x.id === r1); if (!a || a.fin || Date.parse(a.exp) <= now) return json({ error: "Alerte terminée" }, 404);
        if (a.auteurId !== me.id && !isStaff(me) && !estProprio(me)) return deny();
        const tx = t(body.texte, 600); if (!tx) return json({ error: "Écris la précision" }, 400);
        a.precisions ||= []; a.precisions.push({ id: me.id, nom: me.nom, poste: posteDe(me), texte: tx, t: new Date().toISOString() }); a.precisions = a.precisions.slice(-30);
        await save("alertes", list);
        await journal("alerte", me.nom, `ℹ️ Précision sur l'alerte ${a.nature} : ${tx.slice(0, 160)}`, "attention", "#/alertes");
        await envoyerPush({ titre: `Précision — ${a.nature}`, texte: `${me.nom} : ${tx.slice(0, 160)}`, url: "/#/alertes", alerte: true }, enService).catch(() => 0);
        return json(a);
      }
      if (m === "POST" && r2 === "vu") { // accusé de réception d'une alerte forcée
        const a = list.find((x) => x.id === r1); if (!a) return json({ error: "Alerte introuvable" }, 404);
        a.vus ||= []; if (!a.vus.some((v) => v.id === me.id)) { a.vus.push({ id: me.id, nom: me.nom, t: new Date().toISOString() }); await save("alertes", list); }
        return json({ ok: true, vus: a.vus.length });
      }
      if (m === "POST" && r2 === "fin") {
        const a = list.find((x) => x.id === r1); if (!a) return json({ error: "Alerte introuvable" }, 404);
        if (a.auteurId !== me.id && !isStaff(me)) return deny();
        a.fin = { t: new Date().toISOString(), par: me.nom, note: t(body.note, 300) }; await save("alertes", list);
        await journal("alerte", me.nom, `✅ Alerte levée : ${a.nature}${a.fin.note ? " · " + a.fin.note : ""}`, "info", "#/alertes");
        return json({ ok: true });
      }
    }

    /* ---------- Fil de l'eau général Parc / Arena (responsables, PC, propriétaire) ---------- */
    if (r0 === "fil" && m === "GET") {
      if (!isStaff(me) && me.role !== "client") return deny();
      const du = url.searchParams.get("du") || new Date(Date.now() - 7 * 864e5).toISOString().slice(0, 10), au = url.searchParams.get("au") || "9999";
      const dans = (t) => { const d = String(t || "").slice(0, 10); return d >= du && d <= au; };
      const siteDe = (x) => (/arena/i.test(x || "") ? "Arena" : /parc/i.test(x || "") ? "Parc" : "");
      const out = [];
      for (const i of await mcEntre(du, au)) if (dans(i.t) && !i.rapport) out.push({ t: i.t, fait: i.heure, type: i.categorie === "Prise de service" || i.categorie === "Fin de service" ? "Service" : "Main courante",
        titre: `${i.numero || ""} · ${i.categorie}`, texte: [i.famille && "[" + i.famille + "]", i.description, i.societe && "Société : " + i.societe, i.immat && "Immat. : " + i.immat, i.intervenants && "Intervenants : " + i.intervenants, i.actions && "Actions : " + i.actions].filter(Boolean).join(" — "),
        auteur: i.auteur, site: siteDe(i.site), lieu: i.lieu, niveau: i.gravite, lien: "#/mc", statut: i.statut });
      for (const r of (await load("rap", null)) || []) if (dans(r.t)) out.push({ t: r.t, fait: r.heure, type: "Rapport", titre: `${r.numero} · ${r.label}`,
        texte: [r.texte, ...Object.entries(r.details || {}).map(([k, v]) => `${k} : ${v}`), r.securise && "Mesures : " + r.securise].filter(Boolean).join(" — "),
        auteur: r.auteur + (r.poste ? " (" + r.poste + ")" : ""), site: siteDe(r.site), lieu: r.lieu, niveau: r.urgence === "urgente" ? "urgente" : "moyenne", lien: "#/rap", statut: r.statut, photos: r.photos });
      for (const r of await load("rapports", [])) if (dans(r.t)) out.push({ t: r.t, type: "Rapport", titre: "Rapport libre · " + r.titre, texte: r.texte, auteur: r.auteur, site: siteDe(r.site), lieu: r.lieu, lien: "#/rapports", photos: r.photos });
      for (const r of await load("rondes_nfc", [])) for (const x of r.passages || []) if (!x.ras && dans(x.tMaj || x.t)) // v4.44 · chaque anomalie de pointeau, à l'heure où elle est rédigée
        out.push({ t: x.tMaj || x.t, type: "Ronde", titre: `Anomalie pointeau · ${x.nom}`, texte: `${x.obs || "Anomalie"} — ${r.nom}${x.photos ? ` · ${x.photos} photo(s)` : ""}`, auteur: r.agent, site: siteDe(r.site), lieu: x.nom, niveau: "moyenne", lien: "#/rondes" });
      for (const r of await load("rondes_nfc", [])) if (dans(r.debut)) { const fait = new Set(r.passages.map((x) => x.uid)).size;
        out.push({ t: r.debut, type: "Ronde", titre: `Ronde · ${r.nom}`, texte: `${fait}/${r.points.length} points${r.statut === "en cours" ? " · en cours" : ` · ${r.duree} min`}${r.oublies ? ` · oubliés : ${r.points.filter((p) => !r.passages.some((x) => x.uid === p.uid)).map((p) => p.nom).join(", ")}` : ""}${r.passages.filter((x) => !x.ras).map((x) => ` · ⚠️ ${x.nom} : ${x.obs}`).join("")}${r.obs ? " · " + r.obs : ""}`,
          auteur: r.agent, site: siteDe(r.site), niveau: r.oublies || r.anomalies ? "moyenne" : "info", lien: "#/rondes" }); }
      for (const c of await load("checklists", [])) if (dans(c.t)) { const nc = c.items.filter((x) => x.nc);
        out.push({ t: c.t, type: "Check-list", titre: "Check-list · " + c.modele, texte: (nc.length ? "Non conforme : " + nc.map((x) => x.label).join(", ") : "Conforme") + (c.obs ? " — " + c.obs : ""), auteur: c.agent, site: siteDe(c.lieu + " " + c.modele), lieu: c.lieu, niveau: nc.length ? "moyenne" : "info", lien: "#/site" }); }
      for (const x of await load("cles_mvt", [])) if (dans(x.t)) out.push({ t: x.t, type: "Clés", titre: `${x.type === "sortie" ? "Clé remise" : "Clé rendue"} · ${x.n} ${x.cle}`,
        texte: x.type === "sortie" ? `À ${x.nom}${x.societe ? " (" + x.societe + ")" : ""}${x.motif ? " · " + x.motif : ""}` : `Par ${x.nom}${x.obs ? " · " + x.obs : ""}`, auteur: x.par, site: /arena/i.test(x.cle) ? "Arena" : "", lien: "#/cles" });
      for (const x of await load("materiel_mvt", [])) if (dans(x.t)) out.push({ t: x.t, type: "Matériel", titre: `${x.sens === "prêt" ? "Prêt" : x.sens === "retour" ? "Retour" : "Remise en service"} · ${x.objet}`,
        texte: x.nom ? `${x.sens === "prêt" ? "À" : "Par"} ${x.nom}${x.ok === false ? " · ⚠️ hors service" : ""}${x.remarque ? " · " + x.remarque : ""}` : "", auteur: x.par, site: "", niveau: x.ok === false ? "moyenne" : "info", lien: "#/materiel" });
      for (const b of await load("batiments_mvt", [])) if (dans(b.t)) out.push({ t: b.t, type: "Bâtiment", titre: `🏢 ${b.libelle}`, texte: `${b.halls.join(", ")} · à la demande : ${({ prestataire: "Prestataire", organisateur: "Organisateur", sploe: "SPL OE", pc: "PC sécurité", autre: "Autre" })[b.dem.type]}${b.dem.societe ? " " + b.dem.societe : ""}${b.dem.nom ? " (" + b.dem.nom + ")" : ""}${b.commentaire ? " — " + b.commentaire : ""}`,
        auteur: b.par, site: b.halls.every((h) => /arena/i.test(h)) ? "Arena" : b.halls.some((h) => !/arena/i.test(h)) ? "Parc" : "", lien: "#/batiments" });
      for (const a of await load("alertes", [])) if (dans(a.t)) out.push({ t: a.t, type: "Alerte", titre: `🚨 Alerte · ${a.nature}`, texte: a.texte + (a.fin ? ` — levée par ${a.fin.par}${a.fin.note ? " : " + a.fin.note : ""}` : ""), auteur: a.auteur, site: siteDe(a.site), lieu: a.lieu, niveau: "urgente", lien: "#/alertes" });
      for (const o of await load("objets", [])) { if (dans(o.t)) out.push({ t: o.t, type: "Objet trouvé", titre: `${o.numero} · ${o.categorie}`, texte: o.description + (o.stockage ? " — rangé : " + o.stockage : ""), auteur: o.auteur, site: siteDe(o.site), lieu: o.lieu, lien: "#/objets", photos: o.photo ? 1 : 0 });
        if (o.restitution && dans(o.restitution.t)) out.push({ t: o.restitution.t, type: "Objet trouvé", titre: `${o.numero} · restitué`, texte: `Rendu à ${o.restitution.nom}${o.restitution.piece ? " (pièce : " + o.restitution.piece + ")" : ""}`, auteur: o.restitution.par, site: siteDe(o.site), lien: "#/objets" }); }
      for (const d of await load("docs", [])) if (dans(d.t)) out.push({ t: d.t, type: "Document", titre: "Document · " + d.titre, texte: [d.categorie, d.evenement].filter(Boolean).join(" · "), auteur: d.par, site: siteDe(d.site), lien: "#/docs" });
      out.sort((a, b) => String(b.t).localeCompare(String(a.t)));
      if (me.role === "client") { // client : aucun nom d'agent, ni planning (prises de service), ni boîte à clés
        return json(out.filter((x) => !["Clés", "Service"].includes(x.type)).map((x) => ({ ...x, auteur: "",
          texte: x.type === "Objet trouvé" && /^Rendu à /.test(x.texte || "") ? "Restitué à son propriétaire" : x.type === "Matériel" ? (/hors service/.test(x.texte || "") ? "⚠️ hors service" : "") : String(x.texte || "").replace(/ — Intervenants : [^—]*/g, "").replace(/ — levée par [^:]*(?: : )?/g, " — levée : ") })).slice(0, 2000));
      }
      return json(out.slice(0, 2000));
    }

    /* ---------- En direct (responsables, PC, admin) ---------- */
    if (r0 === "direct" && m === "GET") {
      if (!isStaff(me)) return deny();
      const inc = await mcRecents(2), rap = await load("rapports", []), dis = (await load("rap", null)) || [];
      const etat = {};
      for (const i of [...inc].reverse()) {
        if (i.categorie === "Prise de service") etat[i.auteurId] = { nom: i.auteur, depuis: i.t, site: i.site, lieu: i.lieu, evenement: i.evenement };
        if (i.categorie === "Fin de service") delete etat[i.auteurId];
      }
      const depuis = Date.now() - 24 * 3600e3;
      const fil = [...inc.filter((i) => Date.parse(i.t) > depuis).map((i) => ({ type: "mc", ...i })),
        ...rap.filter((r) => Date.parse(r.t) > depuis).map((r) => ({ type: "rapport", ...r })),
        ...dis.filter((r) => Date.parse(r.t) > depuis || r.statut !== "clos").map((r) => ({ ...r, type: "rap" }))].sort((a, b) => b.t.localeCompare(a.t)).slice(0, 80);
      return json({ enService: Object.values(etat).filter((e) => Date.now() - Date.parse(e.depuis) < 20 * 3600e3), fil,
        ouverts: inc.filter((i) => i.statut !== "clos" && !/service/i.test(i.categorie)).length, maj: new Date().toISOString() });
    }

    /* ---------- Planning des vacations (protégé par le code PIN) ---------- */
    /* ---------- Évaluation des risques par événement (rédaction : propriétaire + coordinateur PC ; lecture : tous) ---------- */
    if (r0 === "risques") {
      let list = await load("risques", []);
      if (m === "GET") return json(r1 ? list.find((x) => x.id === r1) || null : list.map(({ risques, ...e }) => ({ ...e, nb: risques.length,
        max: Math.max(0, ...risques.map((r) => r.p * r.g)), critiques: risques.filter((r) => r.p * r.g >= 12).length })));
      if (!(await estCoord(me))) return json({ error: "Seuls le propriétaire et le coordinateur PC rédigent les évaluations des risques" }, 403);
      if (m === "DELETE" && r1) { list = list.filter((x) => x.id !== r1); await save("risques", list); await journal("risques", me.nom, "évaluation supprimée", "info", "#/risques"); return json({ ok: true }); }
      if (m === "POST" || m === "PUT") {
        const t = (v, n = 120) => String(v ?? "").trim().slice(0, n), n4 = (v) => Math.min(4, Math.max(1, parseInt(v) || 1));
        const e = { id: m === "PUT" && r1 ? r1 : uid(), maj: new Date().toISOString(), auteur: me.nom, titre: t(body.titre) || "Événement", site: t(body.site, 60),
          date: /^\d{4}-\d{2}-\d{2}$/.test(body.date || "") ? body.date : "", type: t(body.type, 60), effectif: t(body.effectif, 20), organisateur: t(body.organisateur),
          statut: body.statut === "validee" ? "validee" : "brouillon", obs: t(body.obs, 3000),
          risques: (Array.isArray(body.risques) ? body.risques : []).slice(0, 60).map((r) => ({ fam: t(r.fam, 40), r: t(r.r, 160), p: n4(r.p), g: n4(r.g), mesures: t(r.mesures, 800), resp: t(r.resp, 80) })).filter((r) => r.r) };
        const old = list.find((x) => x.id === e.id); e.cree = old?.cree || e.maj;
        list = [e, ...list.filter((x) => x.id !== e.id)].slice(0, 300); await save("risques", list);
        await journal("risques", me.nom, `${e.titre} · ${e.statut === "validee" ? "validée" : "brouillon"}`, "info", "#/risques");
        if (e.statut === "validee" && old?.statut !== "validee") {
          const tri = [...e.risques].sort((a, b) => b.p * b.g - a.p * a.g);
          await mailPC(`⚠️ Évaluation des risques — ${e.titre}${e.date ? " — " + e.date.split("-").reverse().join("/") : ""}`, [["Événement", e.titre], ["Site", ERP(e.site)], ["Type", e.type],
            ["Effectif attendu", e.effectif], ["Organisateur", e.organisateur], ["Validée par", me.nom],
            ["Risques", tri.map((r) => `[${r.p * r.g}] ${r.r}${r.mesures ? " → " + r.mesures : ""}${r.resp ? " (" + r.resp + ")" : ""}`).join("\n")], ["Observations", e.obs]]);
        }
        return json(e, m === "POST" ? 201 : 200);
      }
    }

    /* ---------- Disponibilités des agents (CDD…) : saisie par l'agent, traitement par la coordination ---------- */
    /* ---------- Recherche globale (PC, administrateurs, coordination, propriétaire) ---------- */
    if (r0 === "recherche" && m === "GET") {
      if (!(isStaff(me) || estProprio(me) || (await estCoord(me)))) return deny();
      const q = String(url.searchParams.get("q") || "").trim().toLowerCase(); if (q.length < 2) return json({ q, res: [] });
      const has = (...x) => x.filter(Boolean).join(" ").toLowerCase().includes(q), res = [];
      for (const i of await mcRecents(3)) if (has(i.numero, i.categorie, i.lieu, i.description, i.auteur, i.societe, i.immat, i.evenement)) res.push({ type: "Main courante", titre: `${i.numero || ""} · ${i.categorie}`, sous: [i.lieu, i.site, i.auteur].filter(Boolean).join(" · "), t: i.t, lien: "#/mc" });
      for (const o of await load("objets", [])) if (has(o.numero, o.categorie, o.description, o.lieu, o.stockage, o.statut)) res.push({ type: "Objet trouvé", titre: `${o.numero || ""} · ${o.categorie || ""}`, sous: [o.description, o.lieu, o.statut].filter(Boolean).join(" · "), t: o.t, lien: "#/objets" });
      const cl = await load("cles", CLES_INITIAL), ce = await load("cles_etat", {});
      for (const c of cl) if (has(c.n, c.nom, c.boite, ce[c.n]?.nom, ce[c.n]?.societe)) res.push({ type: "Clé", titre: `${c.n} · ${c.nom}`, sous: ce[c.n] ? `sortie · ${ce[c.n].nom}${ce[c.n].societe ? " · " + ce[c.n].societe : ""}` : c.boite, lien: "#/cles" });
      const d1 = jourParis(-1), d2 = new Date(Date.now() + 14 * 864e5).toISOString().slice(0, 10);
      for (const v of (await load("planning", PLANNING_INITIAL)).filter((x) => x.date >= d1 && x.date <= d2)) if (has(v.nom, v.poste, v.evenement)) res.push({ type: "Planning", titre: `${v.nom} · ${v.poste}`, sous: `${v.date.split("-").reverse().join("/")} ${v.debut}–${v.fin}${v.site ? " · " + v.site : ""}`, t: v.date, lien: "#/plangen" });
      for (const e of await load("evenements", [])) if (has(e.nom, e.site, e.organisateur, e.lieux)) res.push({ type: "Événement", titre: e.nom, sous: [e.site, e.statut].filter(Boolean).join(" · "), t: e.cree, lien: "#/mc" });
      for (const r of (await load("rap", null)) || []) if (has(r.numero, r.label, r.texte, r.lieu, r.auteur)) res.push({ type: "Rapport", titre: `${r.numero || ""} · ${r.label || ""}`, sous: [r.lieu, r.auteur].filter(Boolean).join(" · "), t: r.t, lien: "#/rap" });
      return json({ q, res: res.slice(0, 120) });
    }
    /* ---------- Ma paie (estimation) : chaque agent voit ses heures, la grille réglementaire et son brut estimé ---------- */
    /* ---------- v4.15 · Ma vacation (accueil agent) : vacation en cours ou prochaine, prise / fin de service ---------- */
    if (r0 === "monservice" && m === "GET") {
      if (me.role === "client" || me.role === "sms") return json({ vac: null, prochaine: null });
      const u = estProprio(me) ? { ...me, nom: process.env.OWNER_NOM || "Rochdi Mecheti" } : ((await load("users", [])).find((x) => x.id === me.id) || me);
      const now = maintenantParis(), lignes = [];
      for (const d of [jourParis(-1), jourParis()]) for (const l of await presencesDu(d)) if (memeAgent(u, l)) lignes.push({ ...l, date: d });
      const borne = (l) => { const a = minutesLocales(l.date, l.debut); let b = minutesLocales(l.date, l.fin); if (b <= a) b += 1440; return [a, b]; };
      const vac = lignes.filter((l) => { const [a, b] = borne(l); return now >= a - 60 && now <= b + 60; }).sort((x, y) => borne(x)[0] - borne(y)[0])[0] || null;
      const proch = vac ? null : (await planningDe(u)).find((v) => v.debut && minutesLocales(v.date, v.debut) > now) || null;
      const net = (l) => l && { date: l.date, debut: l.debut, fin: l.fin, poste: l.poste || "", evenement: l.evenement || "", site: l.site || "", arrivee: l.arrivee || "", depart: l.depart || "", statut: l.statut || "" };
      return json({ vac: net(vac), prochaine: net(proch), maintenant: now });
    }
    /* ---------- v4.14 · Relevé d'heures mensuel + compteur (CDI : 151,67 h / mois, au-delà = heures sup ; CDD : compteur du contrat) ---------- */
    if (r0 === "releve-heures" && m === "GET") {
      if (me.role === "client" || me.role === "sms") return deny();
      const P = globalThis.PLANIF, mois = /^\d{4}-\d{2}$/.test(url.searchParams.get("mois") || "") ? url.searchParams.get("mois") : jourParis().slice(0, 7);
      const voitTous = isStaff(me) || estProprio(me) || (await peutPlanif(me)) || (await estCoord(me)), users = await load("users", []), pl = await load("planning", PLANNING_INITIAL);
      if (url.searchParams.get("liste")) { if (!voitTous) return deny();
        return json([...new Set(pl.filter((v) => String(v.date).startsWith(mois) && v.nom && !/^NON AFFECT/i.test(v.nom)).map((v) => v.nom))].sort((a, b) => a.localeCompare(b, "fr"))); }
      const qn = String(url.searchParams.get("agent") || "").trim().slice(0, 80);
      let u; if (qn && qn !== me.nom) { if (!voitTous) return deny(); u = users.find((x) => memeAgent(x, { nom: qn })) || { id: "", nom: qn }; }
      else u = me.id === "__admin" || estProprio(me) ? { ...me, nom: process.env.OWNER_NOM || "Rochdi Mecheti" } : (users.find((x) => x.id === me.id) || me);
      const perso = (await load("paie_perso", {}))[u.id] || {}, adm = await load("paie_params", {});
      const ct = ((await load("gestion", {})).contrats || []).filter((c) => memeAgent({ nom: c.agent }, u)).sort((a, b) => String(b.debut).localeCompare(String(a.debut)))[0]; // registre du propriétaire en priorité
      const contrat = ct ? (/^CDI$/.test(ct.type) ? "CDI" : "CDD") : perso.contrat || "CDI", debutC = (ct && ct.debut) || perso.debutContrat || "", finC = (ct && ct.fin) || perso.finContrat || "";
      const base = Number((ct && ct.heures) || perso.heuresContrat) || (contrat === "CDI" ? 151.67 : 0);
      const seuil = Number(adm.hsSeuil) || 35, s25 = Number(adm.hs25Jusqua) || 43;
      const siens = pl.filter((v) => v.debut && v.fin && memeAgent(u, v)).map((v) => ({ v, ...P.vacation(v) })).sort((a, b) => a.debut - b.debut);
      const duMois = siens.filter((x) => x.v.date.startsWith(mois)), r2 = (x) => Math.round(x * 100) / 100;
      const lignes = duMois.map((x) => ({ date: x.v.date, poste: x.v.poste || "", evenement: x.v.evenement || "", site: x.v.site || "", debut: x.v.debut, fin: x.v.fin, heures: r2(x.heures), nuit: r2(x.hNuit), dim: r2(x.hDim), ferie: r2(x.hFer) }));
      const tot = (k) => r2(lignes.reduce((s, l) => s + l[k], 0)), heures = tot("heures");
      // décompte légal des heures sup à la semaine (lundi-dimanche), semaines rattachées au mois de leur dimanche
      const sem = {}; for (const x of siens) { const l = P.lundi(x.debut); (sem[l] ||= { lundi: l, h: 0 }).h += x.heures; }
      const semaines = Object.values(sem).filter((w) => new Date(Date.parse(w.lundi) + 6 * 864e5).toISOString().slice(0, 7) === mois).sort((a, b) => a.lundi.localeCompare(b.lundi))
        .map((w) => ({ lundi: w.lundi, heures: r2(w.h), hs25: r2(Math.min(Math.max(0, w.h - seuil), s25 - seuil)), hs50: r2(Math.max(0, w.h - s25)) }));
      const compteur = { contrat, base: r2(base), heures, ecart: base ? r2(heures - base) : null, hs25: r2(semaines.reduce((s, w) => s + w.hs25, 0)), hs50: r2(semaines.reduce((s, w) => s + w.hs50, 0)), seuil, s25, debutContrat: debutC, finContrat: finC, source: ct ? "registre" : "agent" };
      if (contrat === "CDD") { const d0 = debutC || mois + "-01", d1 = [finC, new Date(Date.UTC(+mois.slice(0, 4), +mois.slice(5, 7), 0)).toISOString().slice(0, 10)].filter(Boolean).sort()[0];
        const cdd = siens.filter((x) => x.v.date >= d0 && x.v.date <= d1); compteur.cumulContrat = r2(cdd.reduce((s, x) => s + x.heures, 0)); compteur.vacationsContrat = cdd.length; compteur.du = d0; compteur.au = d1; }
      const fm = new Date(Date.UTC(+mois.slice(0, 4), +mois.slice(5, 7), 0)).toISOString().slice(0, 10), absM = {};
      for (const a of (await load("absences", [])).filter((x) => x.au >= mois + "-01" && x.du <= fm && memeAgent({ nom: x.nom }, u))) { const d1 = a.du > mois + "-01" ? a.du : mois + "-01", d2 = a.au < fm ? a.au : fm; absM[a.code] = (absM[a.code] || 0) + Math.round((Date.parse(d2) - Date.parse(d1)) / 864e5) + 1; }
      const absences = Object.entries(absM).map(([code, jours]) => ({ code, libelle: ABS_CODES[code], jours }));
      return json({ mois, nom: u.nom, lignes, totaux: { heures, nuit: tot("nuit"), dim: tot("dim"), ferie: tot("ferie"), vacations: lignes.length }, semaines, compteur, absences });
    }
    if (r0 === "mapaie" && m === "PUT") { // paramètres personnels de l'agent : contrat, taux (brut ou net), primes, majorations
      if (me.role === "client") return deny();
      const perso = await load("paie_perso", {}), tp = (v) => String(v ?? "").trim().replace(",", ".").slice(0, 10), x = {};
      for (const k of ["tauxPerso", "panier", "habillage", "chien", "majNuit", "majDimanche", "majFerie", "maj25", "maj50", "precarite", "cp"]) { const v = tp(body[k]); if (v === "" || /^\d+(\.\d+)?$/.test(v)) x[k] = v; }
      x.mode = body.mode === "net" ? "net" : "brut"; x.contrat = body.contrat === "CDD" ? "CDD" : "CDI"; x.maj = new Date().toISOString();
      { const hc = tp(body.heuresContrat); if (hc === "" || /^\d+(\.\d+)?$/.test(hc)) x.heuresContrat = hc; } // compteur d'heures (v4.14)
      for (const k of ["debutContrat", "finContrat"]) x[k] = /^\d{4}-\d{2}-\d{2}$/.test(body[k] || "") ? body[k] : "";
      perso[me.id] = x; await save("paie_perso", perso); return json({ ok: true, perso: x });
    }
    if (r0 === "mapaie" && m === "GET") {
      if (me.role === "client") return deny();
      const mois = /^\d{4}-\d{2}$/.test(url.searchParams.get("mois") || "") ? url.searchParams.get("mois") : jourParis().slice(0, 7);
      const [y, mo] = mois.split("-").map(Number), du = new Date(Date.UTC(y, mo - 1, 1) - 7 * 864e5).toISOString().slice(0, 10), au = new Date(Date.UTC(y, mo, 7)).toISOString().slice(0, 10);
      const u = me.id === "__admin" ? { ...me, nom: process.env.OWNER_NOM || "Rochdi Mecheti" } : ((await load("users", [])).find((x) => x.id === me.id) || me);
      const lignes = (await load("planning", PLANNING_INITIAL)).filter((v) => v.date >= du && v.date <= au && memeAgent(u, v));
      const admin = await load("paie_params", {}), perso = (await load("paie_perso", {}))[me.id] || {}, fus = { ...admin, perso: true };
      for (const [k, v] of Object.entries(perso)) if (v !== "" && k !== "maj") fus[k] = v;
      const R = globalThis.PLANIF.calcPaie(lignes, mois, fus);
      const P = R.params, grille = ["ADS", "SSIAP 1", "SSIAP 2", "SSIAP 3", "Cynophile", "Chef d'équipe"].map((q) => ({ qualif: q, taux: P.taux[q] || "", smic: !P.taux[q] }));
      return json({ mois, nom: u.nom, agent: R.agents[0] || null, grille, regles: { smic: P.smic, majNuit: P.majNuit, nuitDebut: P.nuitDebut, nuitFin: P.nuitFin, majDimanche: P.majDimanche, majFerie: P.majFerie,
        hsSeuil: P.hsSeuil, hs25Jusqua: P.hs25Jusqua, maj25: P.maj25, maj50: P.maj50, panier: P.panier, panierMinH: P.panierMinH, chien: P.chien, habillage: P.habillage, mode: P.mode, contrat: P.contrat, precarite: P.precarite, cp: P.cp, tauxPerso: P.tauxPerso }, perso });
    }
    /* ---------- Grille des disponibilités (centralisée) : adjoint planification (SMS), PC, administrateurs, propriétaire ---------- */
    if (r0 === "dispo-grille") {
      if (!(isStaff(me) || estProprio(me) || adjPlanif(me) || (await estCoord(me)))) return deny();
      const mois = /^\d{4}-\d{2}$/.test(url.searchParams.get("mois") || body.mois || "") ? (url.searchParams.get("mois") || body.mois) : jourParis().slice(0, 7);
      const key = "dispo_grille/" + mois, g = await load(key, {}), cle = globalThis.PLANIF.cleAgent;
      if (m === "GET") {
        const noms = new Map(), add = (n, q = "") => { const k = cle(n); if (n && k && !/^NON AFFECT/i.test(n) && !noms.has(k)) noms.set(k, { nom: n, qualif: q }); else if (q && noms.get(k) && !noms.get(k).qualif) noms.get(k).qualif = q; };
        (await load("planning", PLANNING_INITIAL)).filter((v) => String(v.date).startsWith(mois)).forEach((v) => add(v.nom, globalThis.PLANIF.qualifPaie(v)));
        (await load("users", [])).filter((u) => AGENTS.includes(u.role) && u.actif !== false).forEach((u) => add(u.nom, { ads: "ADS", ssiap1: "SSIAP 1", ssiap2: "SSIAP 2", ssiap3: "SSIAP 3" }[u.role]));
        (await load("sms_annuaire", ANNUAIRE_INITIAL)).forEach((a) => add(a.nom));
        Object.values(g).forEach((x) => add(x.nom));
        const agents = [...noms.entries()].map(([k, a]) => ({ ...a, cle: k, jours: g[k]?.jours || {}, indispo: g[k]?.indispo || {}, note: g[k]?.note || "", maj: g[k]?.maj || "", par: g[k]?.par || "" })).sort((a, b) => a.nom.localeCompare(b.nom, "fr"));
        const dpk = crypto.createHmac("sha256", (process.env.APP_SECRET || "change-moi-dans-netlify") + ":dispo").update(mois).digest("base64url").slice(0, 16);
        return json({ mois, agents, peutModifier: true, k: dpk, ferme: (await load("dispo_public_ferme", {}))[mois] === true });
      }
      if (m === "PATCH") { // une case : agent + jour
        const nom = String(body.nom || "").trim().slice(0, 80), k = cle(nom), d = String(body.jour || "");
        if (!nom || !k) return json({ error: "Agent manquant" }, 400);
        if (!d.startsWith(mois + "-") || !/^\d{4}-\d{2}-\d{2}$/.test(d)) return json({ error: "Date invalide" }, 400);
        const x = (g[k] ||= { nom, jours: {} });
        x.indispo ||= {}; delete x.jours[d]; delete x.indispo[d];
        if (body.dispo === "indispo") x.indispo[d] = true; else if (body.dispo) x.jours[d] = body.dispo === "nuit" || body.dispo === "jour" ? body.dispo : true;
        if (body.note !== undefined) x.note = String(body.note).slice(0, 200);
        x.maj = new Date().toISOString(); x.par = me.nom; await save(key, g);
        return json({ ok: true, jours: x.jours });
      }
      if (m === "PUT") { const f = await load("dispo_public_ferme", {}); if (body.ferme) f[mois] = true; else delete f[mois]; await save("dispo_public_ferme", f); await journal("disponibilités", me.nom, `lien des disponibilités ${mois} ${body.ferme ? "fermé" : "rouvert"}`); return json({ ok: true, ferme: !!body.ferme }); }
      if (m === "DELETE") { if (!(me.role === "admin" || estProprio(me))) return deny(); await save(key, {}); await journal("disponibilités", me.nom, `grille des disponibilités ${mois} remise à zéro`, "attention"); return json({ ok: true }); }
      return json({ error: "Requête invalide" }, 400);
    }
    if (r0 === "dispos") {
      const moisOk = (x) => /^\d{4}-\d{2}$/.test(x || "");
      const mois = moisOk(url.searchParams.get("mois")) ? url.searchParams.get("mois") : moisOk(body.mois) ? body.mois : new Date().toISOString().slice(0, 7);
      const key = "dispos/" + mois, all = await load(key, {});
      const QUALIFS = ["ADS", "SSIAP 1", "SSIAP 2", "SSIAP 3"], CRENEAUX = ["jour", "nuit", "jn", "indispo"];
      if (m === "GET" && url.searchParams.get("tous")) {
        if (!(await planningComplet(me))) return deny();
        const coordo = await estCoord(me), users = await load("users", []);
        return json(Object.entries(all).map(([id, d]) => { const u = users.find((x) => x.id === id) || {}; return { id, nom: u.nom || d.nom || id, tel: coordo ? u.tel || "" : undefined, ...d }; })
          .sort((a, b) => a.nom.localeCompare(b.nom)));
      }
      if (m === "GET") return json(all[me.id] || { qualifs: [], jours: {}, note: "", retenus: {} });
      if (m === "PUT") {
        const [y, mo] = mois.split("-").map(Number), maintenant = new Date(), lim = new Date(maintenant.getFullYear(), maintenant.getMonth() + 4, 1);
        if (new Date(y, mo - 1, 1) > lim || new Date(y, mo, 0) < new Date(maintenant.getFullYear(), maintenant.getMonth(), 1)) return json({ error: "Mois non ouvert à la saisie" }, 400);
        const jours = {};
        for (const [d, v] of Object.entries(body.jours || {})) if (d.startsWith(mois + "-") && /^\d{4}-\d{2}-\d{2}$/.test(d) && CRENEAUX.includes(v)) jours[d] = v;
        const old = all[me.id] || {};
        all[me.id] = { nom: me.nom, qualifs: (Array.isArray(body.qualifs) ? body.qualifs : []).filter((q) => QUALIFS.includes(q)), jours,
          note: String(body.note || "").trim().slice(0, 500), retenus: old.retenus || {}, maj: new Date().toISOString() };
        await save(key, all);
        const n = Object.values(jours).filter((v) => v !== "indispo").length;
        await journal("disponibilités", me.nom, `${mois} · ${n} jour(s) disponible(s) · ${all[me.id].qualifs.join(", ") || "qualification non précisée"}`, "info", "#/dispos-admin");
        await envoyerPush({ titre: "Disponibilités reçues", texte: `${me.nom} a envoyé ses disponibilités ${mois} (${n} jour(s) disponible(s))`, url: "/#/dispogrille" }, DEST_DISPOS).catch(() => {});
        return json(all[me.id]);
      }
      if (m === "PATCH") { // la coordination retient (ou non) un agent sur une date
        if (!(await peutPlanif(me))) return json({ error: "Réservé à Jérémy Mercher" }, 403);
        const d = all[body.agentId]; if (!d) return json({ error: "Agent introuvable" }, 404);
        if (!String(body.jour || "").startsWith(mois + "-")) return json({ error: "Date invalide" }, 400);
        d.retenus = d.retenus || {};
        if (body.retenu) d.retenus[body.jour] = { par: me.nom, t: new Date().toISOString() }; else delete d.retenus[body.jour];
        await save(key, all); await journal("disponibilités", me.nom, `${d.nom} ${body.retenu ? "retenu" : "non retenu"} le ${body.jour.split("-").reverse().join("/")}`, "info", "#/dispos-admin");
        return json(d);
      }
    }

    /* ---------- Mon planning : chaque agent voit uniquement ses vacations ---------- */
    if (r0 === "mesabsences" && m === "GET") { const u = (await load("users", [])).find((x) => x.id === me.id) || me, d0 = jourParis(-1);
      return json((await load("absences", [])).filter((a) => a.au >= d0 && memeAgent({ nom: a.nom }, u)).map(({ code, du, au }) => ({ code, libelle: ABS_CODES[code], du, au }))); }
    if (r0 === "monplanning" && m === "GET") {
      return json(await planningDe((await load("users", [])).find((x) => x.id === me.id) || me));
    }

    /* ---------- Planning général (responsables, PC, propriétaire) : lecture seule, sans numéros, sans code ---------- */
    // v4.13 · Télécharger le planning général (mois)
    if (r0 === "plangen" && r1 === "export" && m === "GET") {
      if (!(await peutDLPlanning(me))) return json({ error: "Téléchargement du planning général réservé à Rochdi, Jérémy Mercher, Laurent Hernandez et au PCS Parc" }, 403);
      const mois = /^\d{4}-\d{2}$/.test(url.searchParams.get("mois") || "") ? url.searchParams.get("mois") : jourParis().slice(0, 7), P = globalThis.PLANIF;
      const l = (await load("planning", PLANNING_INITIAL)).filter((v) => String(v.date).startsWith(mois)).sort((a, b) => (a.date + (a.site || "") + (a.evenement || "") + a.debut + a.nom).localeCompare(b.date + (b.site || "") + (b.evenement || "") + b.debut + b.nom))
        .map((v) => ({ date: v.date, site: v.site || "", evenement: v.evenement || "", poste: v.poste || "", nom: /^NON AFFECT/i.test(v.nom || "") ? "" : v.nom, qualif: v.qualif || P.qualifPaie(v), debut: v.debut || "", fin: v.fin || "", heures: v.debut && v.fin ? Math.round(P.vacation(v).heures * 100) / 100 : 0 }));
      await journal("planning", me.nom, `planning général ${mois} téléchargé (${l.length} vacations)`, "info");
      return json({ mois, lignes: l });
    }
    // v4.13 · Feuille de route du jour : un événement par feuille, SSIAP 3 en premier, postes non affectés laissés vides
    if (r0 === "feuille-route") {
      if (!peutFeuilleRoute(me)) return json({ error: "Feuille de route réservée au PCS (SSIAP 2), aux SSIAP 3 et à l'adjoint planification" }, 403);
      const d = /^\d{4}-\d{2}-\d{2}$/.test(url.searchParams.get("date") || body.date || "") ? (url.searchParams.get("date") || body.date) : jourParis(), P = globalThis.PLANIF;
      const FR = await load("feuilles_route", {});
      if (m === "PUT") { // v4.26 · feuille modifiée à la main (le planning n'est pas changé)
        const t = (v, n = 120) => String(v ?? "").trim().slice(0, n), HM = (x) => (/^([01]\d|2[0-3]):[0-5]\d$/.test(x || "") ? x : "");
        const evs = (Array.isArray(body.evenements) ? body.evenements : []).slice(0, 40).map((e) => ({ evenement: t(e.evenement, 160) || "Exploitation courante", site: t(e.site, 60) || "Parc des Expositions", organisateur: t(e.organisateur, 120), effectif: t(e.effectif, 40), note: t(e.note, 600),
          agents: (Array.isArray(e.agents) ? e.agents : []).slice(0, 300).map((a) => ({ poste: t(a.poste, 100), nom: t(a.nom, 80), qualif: t(a.qualif, 40), debut: HM(a.debut), fin: HM(a.fin), ...(a.mission ? { mission: t(a.mission, 400) } : {}) })).filter((a) => a.poste || a.nom) }));
        FR[d] = { evenements: evs, par: me.nom, t: new Date().toISOString() };
        for (const k of Object.keys(FR).sort().slice(0, -120)) delete FR[k]; await save("feuilles_route", FR);
        await journal("feuille de route", me.nom, `feuille de route du ${d.split("-").reverse().join("/")} modifiée à la main (${evs.length} événement(s))`, "info", "#/feuille");
        return json({ date: d, evenements: evs, modifiee: { par: me.nom, t: FR[d].t } });
      }
      if (m === "DELETE") { delete FR[d]; await save("feuilles_route", FR); await journal("feuille de route", me.nom, `feuille de route du ${d.split("-").reverse().join("/")} : retour au planning`, "info", "#/feuille"); return json({ ok: true }); }
      if (m !== "GET") return json({ error: "Requête invalide" }, 400);
      if (FR[d]) return json({ date: d, evenements: FR[d].evenements, modifiee: { par: FR[d].par, t: FR[d].t }, peutModifier: true });
      const out = await construireFeuille(d, await load("planning", PLANNING_INITIAL), await load("evenements", []));
      return json({ date: d, evenements: out, peutModifier: true });
    }
    if (r0 === "plangen" && m === "GET") {
      if (!isStaff(me) && !(await accesPlanif(me))) return deny();
      let d1 = url.searchParams.get("du") || "", d2 = url.searchParams.get("au") || d1;
      if (!(await accesPlanif(me))) { // PC Parc : planning du mois en lecture (62 jours maximum)
        if (!/^\d{4}-\d{2}-\d{2}$/.test(d1)) d1 = jourParis(); if (!/^\d{4}-\d{2}-\d{2}$/.test(d2) || d2 < d1) d2 = d1;
        if ((Date.parse(d2) - Date.parse(d1)) / 864e5 > 62) d2 = new Date(Date.parse(d1) + 62 * 864e5).toISOString().slice(0, 10); }
      if (!(await planningComplet(me)) && (await estRedacPC(me))) { const pl0 = await load("planning", PLANNING_INITIAL); // Laurent : planning du PC Parc
        return json(pl0.filter((v) => v.date >= d1 && v.date <= d2 && estPostePC(v.poste, v.site)).map(({ date, nom, debut, fin, poste, evenement, site, qualif, code }) => ({ date, nom, debut, fin, poste, evenement, site, qualif, code })).sort((a, b) => (a.date + a.debut + a.nom).localeCompare(b.date + b.debut + b.nom))); }
      const pl = await load("planning", PLANNING_INITIAL);
      return json(pl.filter((v) => v.date >= d1 && v.date <= d2).map(({ date, nom, debut, fin, poste, evenement, site, qualif, code }) => ({ date, nom, debut, fin, poste, evenement, site, qualif, code }))
        .sort((a, b) => (a.date + a.debut + a.nom).localeCompare(b.date + b.debut + b.nom)));
    }

    /* ---------- Documents PC sécurité (plans, consignes, brief, feuille de route…) : seuls le propriétaire et les rédacteurs téléversent ---------- */
    if (r0 === "docs") {
      let docs = await load("docs", []);
      if (m === "GET" && !r1) return json(docs);
      if (m === "GET" && r1) {
        const f = await load("doc/" + r1, null);
        return f ? json(f) : json({ error: "Document introuvable" }, 404);
      }
      if (!(await estRedac(me))) return json({ error: "Seul le responsable PC sécurité peut téléverser des documents" }, 403);
      if (m === "POST") {
        const t = (v, n = 120) => String(v ?? "").trim().slice(0, n);
        const d = String(body.data || "");
        if (!/^data:(application\/pdf|image\/(jpeg|png|webp));base64,/.test(d)) return json({ error: "Format accepté : PDF, JPG ou PNG" }, 400);
        if (d.length > MAX_DOC) return json({ error: "Fichier trop lourd (4 Mo maximum). Compresse le PDF ou découpe-le." }, 413);
        const doc = { id: uid(), t: new Date().toISOString(), titre: t(body.titre) || t(body.nom) || "Document", categorie: t(body.categorie, 60) || "Autre",
          site: t(body.site, 60), evenement: t(body.evenement, 120), date: /^\d{4}-\d{2}-\d{2}$/.test(body.date || "") ? body.date : "",
          nom: t(body.nom, 120), type: d.slice(5, d.indexOf(";")), taille: Math.round((d.length * 3) / 4), par: me.nom };
        await save("doc/" + doc.id, { d, nom: doc.nom, type: doc.type });
        docs.unshift(doc); await save("docs", docs.slice(0, 500));
        await journal("document", me.nom, `${doc.categorie} · ${doc.titre}`, "info", "#/docs");
        return json(doc, 201);
      }
      if (m === "DELETE" && r1) {
        const doc = docs.find((x) => x.id === r1); if (!doc) return json({ error: "Document introuvable" }, 404);
        docs = docs.filter((x) => x.id !== r1); await save("docs", docs); await save("doc/" + r1, null);
        await journal("document", me.nom, `supprimé : ${doc.titre}`, "info", "#/docs");
        return json({ ok: true });
      }
    }

    if (r0 === "planning") {
      if (!isStaff(me) && !adjPlanif(me) && !(await accesPlanif(me))) return deny();
      let pl = await load("planning", PLANNING_INITIAL); const planif = adjPlanif(me) || (await planningComplet(me));
      if (m === "GET" && r2 !== "remplacants" && r1 !== "pdf") {
        let d1 = url.searchParams.get("du") || "", d2 = url.searchParams.get("au") || "9999";
        if (!planif) { const a = jourParis(-1), b = jourParis(1); d1 = d1 > a ? d1 : a; d2 = d2 < b ? d2 : b; } // PC sécurité : hier, aujourd'hui, demain seulement
        return json(pl.filter((v) => v.date >= d1 && v.date <= d2).sort((a, b) => (a.date + a.debut).localeCompare(b.date + b.debut)));
      }
      // v4.75 · planning mensuel d'un agent : PDF (imprimer / partager) et envoi par mail à une adresse saisie
      if ((m === "GET" && r1 === "pdf") || (m === "POST" && r1 === "envoyer")) {
        if (!adjPlanif(me) && !isStaff(me) && !estProprio(me) && !(await estCoord(me)) && !(await peutPlanif(me))) return deny();
        const nom = String((m === "GET" ? url.searchParams.get("nom") : body.nom) || "").trim().slice(0, 80), mois = String((m === "GET" ? url.searchParams.get("mois") : body.mois) || "");
        if (!nom || !/^\d{4}-\d{2}$/.test(mois)) return json({ error: "Agent ou mois manquant" }, 400);
        const cle = globalThis.PLANIF.cleAgent, k = cle(nom), vacs = pl.filter((v) => v.date.startsWith(mois) && cle(v.nom) === k).sort((a, b) => (a.date + a.debut).localeCompare(b.date + b.debut));
        const buf = pdfPlanningAgent(vacs[0]?.nom || nom, mois, vacs), fic = `planning-${nom.replace(/[^\w]+/g, "-").toLowerCase()}-${mois}.pdf`;
        if (m === "GET") return new Response(buf, { headers: { "content-type": "application/pdf", "content-disposition": `inline; filename="${fic}"` } });
        const email = String(body.email || "").trim().toLowerCase().slice(0, 120);
        if (!/^[^\s@]+@[^\s@]+\.[a-z]{2,}$/.test(email)) return json({ error: "Adresse e-mail invalide" }, 400);
        const lb = new Date(mois + "-15T12:00:00").toLocaleDateString("fr-FR", { month: "long", year: "numeric" });
        await sendMail([{ email }], `Kaelum e-PCS — Planning de ${vacs[0]?.nom || nom} — ${lb}`, `<p>Bonjour,</p><p>Vous trouverez ci-joint le planning de <b>${escH(vacs[0]?.nom || nom)}</b> pour ${lb} (${vacs.length} vacation(s)).</p><p>Le PC sécurité · Parc des Expositions / Arena Sud de France<br>04 67 17 68 68</p><p style="color:#888;font-size:12px">Envoyé par ${escH(me.nom)} depuis Kaelum e-PCS.</p>`, [{ name: fic, content: buf.toString("base64") }]);
        await journal("planning", me.nom, `planning de ${vacs[0]?.nom || nom} (${mois}) envoyé par mail à ${email}`, "info", "#/planmois");
        return json({ ok: true, n: vacs.length });
      }
      // v4.76 · ajouter une vacation depuis le tableau du mois (adjoint planification, coordination, planificateurs)
      if (m === "POST" && r1 === "verifier") { // v5.18 · contrôle avant « Créer un poste » : repos 11 h, 48 h / semaine, 6 jours d'affilée, chevauchement, absence
        if (!adjPlanif(me) && !(await estCoord(me)) && !(await peutPlanif(me))) return deny();
        const HM = /^([01]\d|2[0-3]):[0-5]\d$/, nom = String(body.nom || "").trim(), date = String(body.date || "");
        if (!nom || /^NON AFFECT/i.test(nom) || !/^\d{4}-\d{2}-\d{2}$/.test(date) || !HM.test(body.debut || "") || !HM.test(body.fin || "")) return json({ alertes: [] });
        const P = globalThis.PLANIF, H = 3600e3, nv = P.vacation({ date, debut: body.debut, fin: body.fin }), alertes = [];
        const fmtV = (v) => `${new Date(v.date + "T12:00:00").toLocaleDateString("fr-FR", { weekday: "short", day: "2-digit", month: "2-digit" })} ${v.debut}–${v.fin}${v.poste ? " (" + v.poste + ")" : ""}`;
        const siennes = (await load("planning", PLANNING_INITIAL)).filter((v) => v.debut && v.fin && v.date && memeAgent({ nom }, { nom: v.nom })).map((v) => { try { return { v, x: P.vacation(v) }; } catch { return null; } }).filter(Boolean);
        for (const { v, x } of siennes) if (x.debut < nv.fin && nv.debut < x.fin) alertes.push({ niveau: "rouge", texte: `Déjà planifié sur ce créneau : ${fmtV(v)}` });
        for (const { v, x } of siennes) { const ecart = x.fin <= nv.debut ? nv.debut - x.fin : x.debut >= nv.fin ? x.debut - nv.fin : null;
          if (ecart !== null && ecart < 11 * H) alertes.push({ niveau: "rouge", texte: `Repos de 11 h non respecté (${Math.round(ecart / H * 10) / 10} h) avec : ${fmtV(v)}` }); }
        const sem = P.lundi(nv.debut), hSem = siennes.filter(({ x }) => P.lundi(x.debut) === sem && !(x.debut < nv.fin && nv.debut < x.fin)).reduce((a, { x }) => a + x.heures, 0) + nv.heures;
        if (hSem > 48) alertes.push({ niveau: "rouge", texte: `${Math.round(hSem * 10) / 10} h sur la semaine : plus de 48 h` }); else if (hSem > 44) alertes.push({ niveau: "orange", texte: `${Math.round(hSem * 10) / 10} h sur la semaine (proche des 48 h)` });
        const jours = new Set(siennes.map(({ v }) => v.date)); jours.add(date); const dec = (n) => new Date(Date.parse(date) + n * 864e5).toISOString().slice(0, 10);
        let av = 0; while (av < 14 && jours.has(dec(-(av + 1)))) av++; let ap = 0; while (ap < 14 && jours.has(dec(ap + 1))) ap++;
        if (av + ap + 1 > 6) alertes.push({ niveau: "rouge", texte: `${av + ap + 1} jours de travail d'affilée : 6 maximum (repos hebdomadaire)` });
        const ab = absenceDe(await load("absences", []), nom, date); if (ab) alertes.push({ niveau: "rouge", texte: `Absent ce jour : ${ABS_CODES[ab.code] || ab.code || "absence"}${ab.du ? ` (du ${ab.du} au ${ab.au})` : ""}` });
        if (nv.heures > 12) alertes.push({ niveau: "orange", texte: `Vacation de ${Math.round(nv.heures * 10) / 10} h : plus de 12 h` });
        return json({ alertes, heuresSemaine: Math.round(hSem * 10) / 10 });
      }
      if (m === "POST" && r1 === "ajouter") {
        if (!adjPlanif(me) && !(await estCoord(me)) && !(await peutPlanif(me))) return deny();
        const t = (x, n = 120) => String(x ?? "").trim().replace(/\s+/g, " ").slice(0, n), HM = /^([01]\d|2[0-3]):[0-5]\d$/;
        const v = { id: uid(), date: t(body.date, 10), nom: t(body.nom, 80) || "NON AFFECTÉ", poste: t(body.poste), debut: t(body.debut, 5), fin: t(body.fin, 5),
          site: SITE_COURANT() !== SITE_ORIGINE ? t(body.site, 60) || infosSite().nom : /arena/i.test(body.site || "") ? "Arena Sud de France" : "Parc des Expositions", evenement: t(body.evenement, 160), qualif: t(body.qualif, 60), mission: t(body.mission, 400), tel: "", telApproche: false, source: "ajout", ajoutPar: me.nom, ajoutLe: new Date().toISOString() };
        if (!v.mission) delete v.mission;
        if (!/^\d{4}-\d{2}-\d{2}$/.test(v.date)) return json({ error: "Date invalide" }, 400);
        if (!v.poste) return json({ error: "Indique l'intitulé du poste" }, 400);
        if (!HM.test(v.debut) || !HM.test(v.fin)) return json({ error: "Horaires invalides (format 08:00)" }, 400);
        if (/^NON AFFECT/i.test(v.nom)) { v.nom = "NON AFFECTÉ"; v.nonAffecte = true; }
        else { const ab = absenceDe(await load("absences", []), v.nom, v.date); if (ab) return json({ error: `${v.nom} est absent ce jour-là (${ab.code} — ${ABS_CODES[ab.code]})` }, 409);
          const ann = await load("sms_annuaire", ANNUAIRE_INITIAL), N = v.nom.toUpperCase(); v.tel = String(ann.find((x) => String(x.nom || "").toUpperCase() === N)?.tel || pl.find((x) => x.tel && String(x.nom || "").toUpperCase() === N)?.tel || "").replace(/\s/g, ""); }
        pl.push(v); pl.sort((a, b) => a.date.localeCompare(b.date)); await save("planning", pl);
        const FR = await load("feuilles_route", {}); if (FR[v.date]) { const e = (FR[v.date].evenements || []).find((x) => (x.site || "") === v.site && (!v.evenement || x.evenement === v.evenement)) || (FR[v.date].evenements || [])[0];
          if (e) { (e.agents ||= []).push({ poste: v.poste, nom: v.nom, qualif: v.qualif, debut: v.debut, fin: v.fin, ...(v.mission ? { mission: v.mission } : {}) }); await save("feuilles_route", FR); } }
        await journal("planning", me.nom, `vacation ajoutée : ${v.date} ${v.debut}-${v.fin} · ${v.poste} · ${v.nom}`, "info", "#/planmois");
        return json(v, 201);
      }
      // v4.11 · Remplacement express : agents libres et qualifiés, classés (dispo déclarée, repos 11 h, 48 h / semaine, connaissance du poste)
      if (m === "GET" && r1 && r2 === "remplacants") {
        if (!(await estCoord(me)) && !adjPlanif(me) && !(await peutPlanif(me))) return deny();
        const v = pl.find((x) => x.id === r1); if (!v) return json({ error: "Vacation introuvable" }, 404);
        const P = globalThis.PLANIF, cle = P.cleAgent, RANG = { "ADS": 0, "Cynophile": 0, "SSIAP 1": 1, "Chef d'équipe": 1, "SSIAP 2": 2, "SSIAP 3": 3 }, NOMQ = ["ADS", "SSIAP 1", "SSIAP 2", "SSIAP 3"];
        const requis = P.qualifPaie(v), rq = RANG[requis] ?? 0, V0 = P.vacation(v), nuit = V0.hNuit > V0.heures / 2, sem = P.lundi(V0.debut);
        const grille = await load("dispo_grille/" + v.date.slice(0, 7), {}), users = await load("users", []), ann = await load("sms_annuaire", ANNUAIRE_INITIAL);
        const d0 = new Date(Date.parse(v.date) - 30 * 864e5).toISOString().slice(0, 10), d1 = new Date(Date.parse(v.date) + 8 * 864e5).toISOString().slice(0, 10);
        const C = new Map(), get = (n) => { const k = cle(n); if (!n || !k || /^NON AFFECT/i.test(n)) return null; if (!C.has(k)) C.set(k, { nom: n, tel: "", rang: -1, vacs: [], postes: new Set() }); return C.get(k); };
        for (const w of pl) { if (w.id === v.id || w.date < d0 || w.date > d1) continue; const c = get(w.nom); if (!c) continue;
          c.rang = Math.max(c.rang, RANG[P.qualifPaie(w)] ?? 0); if (!c.tel && w.tel) c.tel = w.tel; c.postes.add(String(w.poste || "").toUpperCase()); if (w.debut && w.fin) c.vacs.push(P.vacation(w)); }
        for (const u of users) { if (!AGENTS.includes(u.role) || u.actif === false || (await estSmsSeul(u.id))) continue; const c = get(u.nom); if (!c) continue; c.rang = Math.max(c.rang, { ads: 0, ssiap1: 1, ssiap2: 2, ssiap3: 3 }[u.role] ?? 0); if (!c.tel && u.tel) c.tel = u.tel; }
        for (const a of ann) { const c = C.get(cle(a.nom)); if (c && !c.tel && a.tel) c.tel = a.tel; }
        for (const g of Object.values(grille)) { if (g.jours && g.jours[v.date]) { const c = get(g.nom); if (c && c.rang < 0) c.rang = 0; } }
        const absent = cle(v.origine && !/^NON AFFECT/i.test(v.origine.nom) ? v.origine.nom : v.nom), H = 3600e3, out = [];
        const absL = await load("absences", []);
        for (const [k, c] of C) {
          if (k === absent || k === cle(v.nom) || c.rang < rq || absenceDe(absL, c.nom, v.date)) continue;
          if (c.vacs.some((x) => x.debut < V0.fin && V0.debut < x.fin)) continue; // déjà en poste sur ce créneau
          const raisons = [], alertes = []; let score = 0;
          const dj = grille[k]?.jours?.[v.date];
          if (dj === true || (dj === "nuit" && nuit) || (dj === "jour" && !nuit)) { score += 100; raisons.push("dispo déclarée"); } else if (dj) { score += 30; raisons.push(`dispo ${dj}`); }
          const repos = c.vacs.filter((x) => (x.fin <= V0.debut && V0.debut - x.fin < 11 * H) || (x.debut >= V0.fin && x.debut - V0.fin < 11 * H));
          if (repos.length) { score -= 60; alertes.push("repos < 11 h"); }
          const hSem = c.vacs.filter((x) => P.lundi(x.debut) === sem).reduce((a, x) => a + x.heures, 0);
          if (hSem + V0.heures > 48) { score -= 80; alertes.push(`${Math.round(hSem + V0.heures)} h / semaine`); } else if (hSem + V0.heures > 44) { score -= 15; alertes.push(`${Math.round(hSem + V0.heures)} h / semaine`); }
          if (c.postes.has(String(v.poste || "").toUpperCase())) { score += 25; raisons.push("connaît le poste"); }
          if (c.rang === rq) score += 15;
          if (c.tel) score += 10; else alertes.push("pas de numéro");
          score -= Math.round(hSem / 4);
          out.push({ nom: c.nom, tel: c.tel, qualif: NOMQ[c.rang] || "ADS", score, raisons, alertes, heuresSemaine: Math.round(hSem * 10) / 10 });
        }
        out.sort((a, b) => b.score - a.score || a.heuresSemaine - b.heuresSemaine || a.nom.localeCompare(b.nom, "fr"));
        return json({ requis, nuit, candidats: out.slice(0, 15) });
      }
      // Modifier une vacation au dernier moment : agent, téléphone, horaires — ou pourvoir un poste non affecté (administrateurs, propriétaire, compte SMS)
      if (m === "POST" && r1 && r2 === "affecter") {
        if (!(await estCoord(me)) && !adjPlanif(me) && !(await peutPlanif(me))) return deny();
        const v = pl.find((x) => x.id === r1);
        if (!v) return json({ error: "Vacation introuvable" }, 404);
        const avantFR = { nom: v.nom, poste: v.poste, debut: v.debut, fin: v.fin };
        const HM = /^([01]\d|2[0-3]):[0-5]\d$/;
        const debut = body.debut === undefined ? v.debut : String(body.debut).trim(), fin = body.fin === undefined ? v.fin : String(body.fin).trim();
        if (!HM.test(debut) || !HM.test(fin)) return json({ error: "Horaires invalides (format 08:00)" }, 400);
        if (!v.origine) v.origine = { nom: v.nom, debut: v.debut, fin: v.fin, tel: v.tel || "" }; // vacation d'origine (planification), gardée pour l'historique
        const avant = `${v.nom} ${v.debut}-${v.fin}`;
        const nom = String(body.nom ?? v.nom).trim().replace(/\s+/g, " ").slice(0, 80);
        // v4.74 · intitulé du poste modifiable (adjoint planification, coordination, planificateurs)
        const nvPoste = body.poste === undefined ? v.poste : String(body.poste).trim().replace(/\s+/g, " ").slice(0, 120);
        if (!nvPoste) return json({ error: "L'intitulé du poste ne peut pas être vide" }, 400);
        if (nvPoste !== v.poste) { if (!v.posteOrigine) v.posteOrigine = v.poste; await journal("planning", me.nom, `intitulé du poste modifié : « ${v.poste} » → « ${nvPoste} » · ${v.date} · ${v.nom}`, "info", "#/planning"); v.poste = nvPoste; }
        if (!nom || /^NON AFFECT/i.test(nom)) { // agent absent sans remplaçant : le poste repasse en « non affecté »
          Object.assign(v, { nom: "NON AFFECTÉ", tel: "", telApproche: false, nonAffecte: true, rappel: null, debut, fin, modif: { par: me.nom, t: new Date().toISOString() } }); delete v.affecteManuel; delete v.affecte;
          await save("planning", pl); await syncFeuille(v.date, avantFR, { nom: "NON AFFECTÉ", poste: v.poste, debut, fin }); await journal("planning", me.nom, `vacation libérée (${avant}) : ${v.date} · ${v.poste} → non affecté`, "attention", "#/planning");
          return json(v);
        }
        { const ab = absenceDe(await load("absences", []), nom, v.date); if (ab) return json({ error: `${nom} est absent ce jour-là (${ab.code} — ${ABS_CODES[ab.code]})` }, 409); }
        let tel = String(body.tel || "").replace(/[^\d+]/g, ""); if (/^\+33\d{9}$/.test(tel)) tel = "0" + tel.slice(3);
        if (tel && !/^0[1-9]\d{8}$/.test(tel) && !/^\+\d{8,14}$/.test(tel)) return json({ error: "Numéro invalide (ex. 06 12 34 56 78)" }, 400);
        const ann = await load("sms_annuaire", ANNUAIRE_INITIAL), N = nom.toUpperCase(), changeNom = N !== String(v.nom || "").toUpperCase();
        const users = await load("users", []);
        const telConnu = () => String(ann.find((x) => String(x.nom || "").toUpperCase() === N)?.tel || users.find((u) => u.tel && String(u.nom || "").toUpperCase() === N)?.tel || pl.find((x) => x.tel && String(x.nom || "").toUpperCase() === N)?.tel || "").replace(/[^\d+]/g, "");
        if (tel) { const a = ann.find((x) => String(x.nom || "").toUpperCase() === N); if (a) a.tel = tel; else ann.push({ nom, tel }); await save("sms_annuaire", ann.slice(0, 2000)); }
        else tel = changeNom ? telConnu() : (v.tel || telConnu());
        const etaitNA = !!v.nonAffecte, changeH = debut !== v.debut || fin !== v.fin;
        Object.assign(v, { nom, tel, telApproche: false, debut, fin, modif: { par: me.nom, t: new Date().toISOString() } });
        if (etaitNA || v.affecteManuel) { v.affecteManuel = true; v.affecte = { par: me.nom, t: v.modif.t }; }
        delete v.nonAffecte;
        if (changeNom || changeH || avantFR.poste !== v.poste) v.rappel = null; // nouvel agent, horaires ou poste : le rappel SMS est à (re)envoyer
        await save("planning", pl); await syncFeuille(v.date, avantFR, { nom: v.nom, poste: v.poste, debut: v.debut, fin: v.fin });
        await journal("planning", me.nom, etaitNA ? `poste non affecté pourvu : ${nom} · ${v.date} ${debut}-${fin} · ${v.poste}` : `vacation modifiée : ${avant} → ${nom} ${debut}-${fin} · ${v.date} · ${v.poste}`, etaitNA ? "info" : "attention", "#/planning");
        return json(v);
      }
      if ((m === "PUT" || (m === "DELETE" && !((adjPlanif(me) || (await estCoord(me))) && r1 && pl.some((x) => x.id === r1)))) && !(await peutPlanif(me))) return json({ error: "Seuls Jérémy Mercher modifient le planning" }, 403);
      if (m === "PUT" && Array.isArray(body.lignes)) {
        const t = (v, n = 120) => String(v ?? "").trim().slice(0, n);
        const lignes = body.lignes.slice(0, 8000).map((l) => ({ id: uid(), date: t(l.date, 10), nom: t(l.nom, 80), tel: String(l.tel || "").replace(/[^\d+]/g, "").slice(0, 15),
          telApproche: l.telApproche === true, debut: t(l.debut, 5), fin: t(l.fin, 5), poste: t(l.poste), evenement: t(l.evenement),
          site: t(l.site, 60), qualif: t(l.qualif, 60), code: t(l.code, 10), source: "import", importePar: me.nom, importeLe: new Date().toISOString() })).filter((l) => /^\d{4}-\d{2}-\d{2}$/.test(l.date) && l.nom);
        const dates = new Set(lignes.map((l) => l.date));
        const sites = new Set(lignes.map((l) => l.site));
        if (body.mode === "remplacer") pl = pl.filter((v) => v.source === "planif" || !(dates.has(v.date) && sites.has(v.site || ""))); // remplace les jours importés, site par site
        pl = [...pl, ...lignes].sort((a, b) => a.date.localeCompare(b.date));
        const limite = new Date(Date.now() - 400 * 864e5).toISOString().slice(0, 10);
        await save("planning", pl.filter((v) => v.date >= limite));
        await journal("planning", me.nom, `${lignes.length} vacation(s) importée(s) sur ${dates.size} jour(s)`, "info", "#/planning");
        return json({ ok: true, importees: lignes.length, jours: dates.size });
      }
      if (m === "PATCH" && r1) { // rappel SMS envoyé (visible par tout le PC)
        const v = pl.find((x) => x.id === r1);
        if (!v) return json({ error: "Introuvable" }, 404);
        v.rappel = body.rappel === false ? null : { t: new Date().toISOString(), qui: me.nom };
        await save("planning", pl);
        if (v.rappel) await journal("sms", me.nom, `rappel de vacation → ${v.nom} (${v.date} ${v.debut}, ${v.site || ""})`, "info", "#/planning");
        return json(v);
      }
      if (m === "DELETE" && r1) {
        const vd = pl.find((x) => x.id === r1);
        await save("planning", pl.filter((v) => v.id !== r1 && v.date !== r1));
        if (vd) await syncFeuille(vd.date, vd, null);
        await journal("planning", me.nom, vd ? `vacation supprimée : ${vd.date} ${vd.debut}-${vd.fin} · ${vd.poste} · ${vd.nom}` : `suppression ${r1}`, "attention", "#/planning");
        return json({ ok: true });
      }
    }
    /* ---------- Consignes par poste (ajoutées aux SMS de rappel) ---------- */
    if (r0 === "postes") {
      if (!isStaff(me) && !(adjPlanif(me) && (m === "GET" || (m === "POST" && r1 === "ajouter")))) return deny();
      if (m === "GET" && r1 === "horaires") return json(await load("postes_horaires", {})); // v5.15 · horaires habituels des postes de la liste
      if (m === "GET") return json(await load("postes_consignes", {}));
      if (m === "POST" && r1 === "ajouter") { // v5.12 · liste des postes : l'adjoint planification ajoute un poste (et sa mission)
        const k = String(body.poste || "").toUpperCase().replace(/\s+/g, " ").trim().slice(0, 160), mi = String(body.mission || "").trim().slice(0, 300);
        if (k.length < 2) return json({ error: "Nom du poste manquant" }, 400);
        const c = await load("postes_consignes", {}), existait = Object.prototype.hasOwnProperty.call(c, k);
        if (existait && c[k] && !mi) return json({ ok: true, poste: k, mission: c[k], existait });
        if (!existait && Object.keys(c).length >= 2000) return json({ error: "Liste des postes pleine" }, 400);
        c[k] = mi || c[k] || ""; await save("postes_consignes", c);
        const hm0 = (v) => (/^([01]\d|2[0-3]):[0-5]\d$/.test(String(v || "")) ? String(v) : "");
        if (hm0(body.debut) && hm0(body.fin)) { const H = await load("postes_horaires", {}); H[k] = { debut: hm0(body.debut), fin: hm0(body.fin) }; await save("postes_horaires", H); }
        await journal("planning", me.nom, `${existait ? "mission modifiée" : "poste ajouté à la liste"} : ${k}`, "info", "#/postesliste");
        return json({ ok: true, poste: k, mission: c[k], existait });
      }
      if (m === "PUT" && !estProprio(me)) return refusProprio();
      if (m === "PUT" && body.consignes && typeof body.consignes === "object") {
        const c = {};
        for (const [k, v] of Object.entries(body.consignes).slice(0, 2000))
          if (typeof v === "string" && String(k).trim()) c[String(k).toUpperCase().trim().slice(0, 160)] = v.trim().slice(0, 300); // v5.12 · un poste sans mission reste dans la liste
        await save("postes_consignes", c);
        await journal("planning", me.nom, `consignes par poste mises à jour (${Object.keys(c).length})`, "info", "#/planning");
        return json({ ok: true, nb: Object.keys(c).length });
      }
    }
    if (r0 === "sms" && r1 === "journal" && m === "POST") {
      if (!isStaff(me) && !adjPlanif(me)) return deny();
      await journal("sms", me.nom, String(body.detail || "").slice(0, 200), "info", "#/sms");
      return json({ ok: true });
    }

    /* ---------- Notifications / historique (administrateurs) ---------- */
    if (r0 === "notifs") {
      if (!isRH(me)) return deny();
      const lus = await load("notifs_lu", {});
      if (m === "GET") {
        const j = await load("journal", []);
        const depuis = lus[me.id] || "";
        return json({ nonLues: j.filter((x) => x.t > depuis && x.qui !== me.nom).length, dernier: j[0]?.t || null, lu: depuis,
          items: url.searchParams.get("compte") ? [] : j.slice(0, 1000) });
      }
      if (m === "POST") { lus[me.id] = new Date().toISOString(); await save("notifs_lu", lus); return json({ ok: true }); }
    }

    /* ---------- Météo ---------- */
    if (r0 === "meteo") {
      let cache = await load("meteo_cache", null);
      if (!cache || Date.now() - cache.at > 10 * 60e3) {
        const fc = SITE_CFG() || {}, data = SITE_COURANT() !== SITE_ORIGINE && fc.lat && fc.lon ? await fetchPrevisions(fc.lat, fc.lon) : await fetchPrevisions();
        const dep = SITE_COURANT() !== SITE_ORIGINE ? (String((SITE_CFG() || {}).adresse || "").match(/\b(\d{2})\d{3}\b/) || [])[1] : null, mf = await (dep ? vigilanceMF(dep, "département " + dep) : vigilanceMF()).catch(() => []); // département tiré du code postal du site
        const h = data.hourly;
        cache = { at: Date.now(), site: SITE_COURANT() !== SITE_ORIGINE ? (SITE_CFG() || {}).nom || "Site" : SITE.nom, alertes: [...mf, ...analyser(data)],
          heures: h.time.map((t, i) => ({ h: t.slice(11, 16), temp: h.temperature_2m[i], ress: h.apparent_temperature[i],
            pluie: h.precipitation[i], rafales: h.wind_gusts_10m[i], vent: h.wind_speed_10m[i], code: h.weather_code[i] })) };
        await save("meteo_cache", cache);
      }
      return json(cache);
    }

    /* ---------- Prise de poste SMS (PC / admin) ---------- */
    // Ajouter / corriger le numéro d'un agent (administrateurs, propriétaire, compte SMS)
    if (r0 === "sms" && r1 === "numero" && m === "POST") {
      if (!(await estCoord(me)) && !adjPlanif(me)) return deny();
      const nom = String(body.nom || "").trim().replace(/\s+/g, " ").slice(0, 60);
      let tel = String(body.tel || "").replace(/[^\d+]/g, "");
      if (/^\+33\d{9}$/.test(tel)) tel = "0" + tel.slice(3);
      if (!nom || /^NON AFFECT/i.test(nom)) return json({ error: "Nom de l'agent manquant" }, 400);
      if (!/^0[1-9]\d{8}$/.test(tel) && !/^\+\d{8,14}$/.test(tel)) return json({ error: "Numéro invalide (ex. 06 12 34 56 78)" }, 400);
      const ann = await load("sms_annuaire", ANNUAIRE_INITIAL), N = nom.toUpperCase();
      const a = ann.find((x) => String(x.nom || "").toUpperCase() === N);
      const ancien = a ? a.tel : "";
      if (a) a.tel = tel; else ann.push({ nom, tel });
      await save("sms_annuaire", ann.slice(0, 2000));
      const pl = await load("planning", PLANNING_INITIAL), auj = jourParis(-1); let maj = 0;
      for (const v of pl) if (v.date >= auj && String(v.nom || "").toUpperCase() === N) { v.tel = tel; v.telApproche = false; maj++; }
      if (maj) await save("planning", pl);
      await journal("sms", me.nom, `numéro ${ancien ? "modifié" : "ajouté"} : ${nom}`, "info", "#/sms");
      return json({ ok: true, nom, tel, vacations: maj });
    }
    if (r0 === "sms" && m === "GET") {
      if (!isStaff(me) && !adjPlanif(me)) return deny();
      const users = await load("users", []);
      return json({
        agents: users.filter((u) => u.actif !== false && u.tel).map(({ id, nom, role, tel }) => ({ id, nom, role, tel })),
        annuaire: await load("sms_annuaire", ANNUAIRE_INITIAL),
        modeleVacation: await load("sms_modele_vacation", null),
        modele: (await load("sms_modele", "Bonjour {prenom}, rappel prise de poste {date} à {heure} — {lieu}. Merci de confirmer.\nNuméro PCS sécurité\nJoignable 24/24" + (TENANT() ? "" : "\n0467176868"))).replace(/\nLe PC Sécurité( Parc des Expositions \/ Arena\n04 67 17 68 68)?\s*$/, "\nNuméro PCS sécurité\nJoignable 24/24" + (TENANT() ? "" : "\n0467176868")),
      });
    }
    if (r0 === "sms" && m === "PUT") {
      if (!(await estCoord(me)) && !adjPlanif(me)) return refusProprio();
      if (!estProprio(me)) { delete body.modele; delete body.modeleVacation; } // le coordinateur ne gère que les numéros
      if (body.modele !== undefined) await save("sms_modele", String(body.modele).slice(0, 500));
      if (body.modeleVacation !== undefined) await save("sms_modele_vacation", String(body.modeleVacation).slice(0, 500));
      if (Array.isArray(body.annuaire)) await save("sms_annuaire", body.annuaire.slice(0, 2000).map((a) => ({
        nom: String(a.nom || "").slice(0, 60), tel: String(a.tel || "").replace(/[^\d+]/g, "").slice(0, 15) })).filter((a) => a.tel));
      if (Array.isArray(body.annuaire)) await journal("sms", me.nom, `annuaire SMS mis à jour (${body.annuaire.length} numéro(s))`, "info", "#/sms");
      return json({ ok: true });
    }

    /* ---------- Administration ---------- */
    /* ---------- Centre de commandement (écran mural du PC) ---------- */
    /* ---------- v5.35 · Photos preuve : envoyées au PC, effacées automatiquement après 24 h ---------- */
    if (r0 === "theme" && m === "POST") { // v5.48 · seul le propriétaire change le thème de toute l'application (utilisateurs et PCS)
      if (!estProprio(me) || me.apercu) return deny();
      if (body.auto !== undefined) { const j = [0, 1, 7, 30].includes(+body.auto) ? +body.auto : 0; await save("theme_auto", { jours: j }); await journal("admin", me.nom, `rotation des couleurs : ${j ? "tous les " + j + " jour(s)" : "désactivée"}`, "info"); return json({ ok: true, auto: j }); }
      const BR = ["kaelum", "mmanager", "or", "emeraude", "violet"]; if (!BR.includes(body.brand)) return json({ error: "Thème inconnu" }, 400);
      await save("theme_brand", body.brand); await save("theme_auto", { jours: 0 }); await journal("admin", me.nom, `thème de l'application : ${body.brand}`, "info"); return json({ ok: true, brand: body.brand }); }
    if (r0 === "lettres") { // v5.45 · lettres de reconnaissance (PDF généré sur le téléphone) : le PC / la coordination remercie un agent
      if (me.role === "client" || me.role === "sms") return deny();
      const peut = estProprio(me) || estSSIAP3(me) || (await estCoord(me)), L = await load("lettres", []), T = (v, n = 80) => String(v ?? "").trim().slice(0, n);
      const MOTIFS = ["intervention", "ponctualite", "sangfroid", "equipe", "autre"];
      if (m === "GET") { const recues = L.filter((x) => x.aId === me.id).map(({ id, t, motif, message, deNom, deFonction, aNom }) => ({ id, t, motif, message, deNom, deFonction, aNom }));
        if (!peut) return json({ peut: false, recues });
        const us = (await load("users", [])).filter((u) => u.id && u.nom && u.actif !== false && !u.bloque && !estBloque(u) && !["client", "sms"].includes(u.role) && u.id !== "__admin" && !estProprio(u) && !u.apercu).map((u) => ({ id: u.id, nom: u.nom })).sort((a, b) => a.nom.localeCompare(b.nom, "fr"));
        return json({ peut: true, recues, agents: us, moi: { nom: me.nom, fonction: posteDe(me) }, emises: L.filter((x) => x.deId === me.id || estProprio(me)).slice(0, 60).map(({ id, t, motif, message, deNom, deFonction, aNom, aId }) => ({ id, t, motif, message, deNom, deFonction, aNom, aId })) }); }
      if (m === "POST") { if (!peut) return deny();
        const us = await load("users", []), a = us.find((u) => u.id === body.agentId); if (!a || estBloque(a)) return json({ error: "Agent introuvable" }, 404);
        if (!MOTIFS.includes(body.motif)) return json({ error: "Motif invalide" }, 400);
        const x = { id: uid(), t: new Date().toISOString(), aId: a.id, aNom: a.nom, motif: body.motif, message: T(body.message, 700), deNom: me.nom, deId: me.id, deFonction: T(body.fonction, 60) || posteDe(me) };
        await save("lettres", [x, ...L].slice(0, 600));
        await envoyerPush({ titre: "🏅 Lettre de reconnaissance", texte: "Le PC sécurité t'a adressé une lettre de remerciement", url: "/#/lettres" }, (u) => u.id === a.id).catch(() => 0);
        await journal("lettre", me.nom, `lettre de reconnaissance remise à ${a.nom}`, "info");
        return json({ ok: true, id: x.id }); }
      if (m === "DELETE" && r1) { const x = L.find((q) => q.id === r1); if (!x || !(estProprio(me) || (peut && x.deId === me.id))) return deny(); await save("lettres", L.filter((q) => q.id !== r1)); return json({ ok: true }); }
      return json({ error: "Méthode non gérée" }, 405);
    }

    if (r0 === "preuves") {
      if (me.role === "client" || me.role === "sms") return deny();
      await purgerEphemeres();
      const voit = isStaff(me) || estProprio(me) || ["ssiap2", "ssiap3"].includes(me.role) || (await estCoord(me)), P = await storeNomme("preuves"), liste = await load("preuves_liste", []);
      const accessible = (x) => voit || x.deId === me.id, T = (v, n = 80) => String(v ?? "").trim().slice(0, n);
      if (m === "GET" && r1) { const x = liste.find((q) => q.id === r1); if (!x || !accessible(x)) return json({ error: "Introuvable ou expirée" }, 404); const a = await P.get(r1); return a ? json({ d: a.d }) : json({ error: "Expirée" }, 404); }
      if (m === "GET") return json({ peutVoirTout: voit, photos: liste.filter(accessible).map((x) => ({ id: x.id, t: x.t, expire: new Date(Date.parse(x.t) + 864e5).toISOString(), lieu: x.lieu, legende: x.legende, gps: x.gps, hash: x.hash, de: voit ? x.de : "", moi: x.deId === me.id })) });
      if (m === "POST") { const d = String(body.d || ""); if (!/^data:image\/jpeg;base64,/.test(d) || d.length > MAX_PHOTO) return json({ error: "Photo invalide ou trop lourde" }, 400);
        if (liste.filter((x) => x.deId === me.id).length >= 30) return json({ error: "30 photos en 24 h au maximum" }, 429);
        const id = uid(), x = { id, t: new Date().toISOString(), de: me.nom, deId: me.id, lieu: T(body.lieu), legende: T(body.legende), hash: T(body.hash, 12), gps: body.gps && typeof body.gps.lat === "number" ? { lat: body.gps.lat, lon: body.gps.lon } : null };
        await P.set(id, { d }); await save("preuves_liste", [x, ...liste].slice(0, 400));
        await envoyerPush({ titre: "📸 Photo preuve", texte: x.lieu ? "Nouvelle photo · " + x.lieu : "Nouvelle photo", url: "/#/preuve" }, (u) => u.id !== me.id && (isStaff(u) || estProprio(u))).catch(() => 0);
        return json({ ok: true, id, expire: new Date(Date.parse(x.t) + 864e5).toISOString() }); }
      if (m === "DELETE" && r1) { const x = liste.find((q) => q.id === r1); if (!x || !accessible(x)) return json({ error: "Introuvable" }, 404); await P.del(r1).catch(() => {}); await save("preuves_liste", liste.filter((q) => q.id !== r1)); return json({ ok: true }); }
      return json({ error: "Méthode non gérée" }, 405);
    }

    if (r0 === "ecran" && m === "GET") {
      if (!(isStaff(me) || estProprio(me) || me.role === "client" || (await estCoord(me)))) return deny();
      const now = Date.now(), auj = jourParis();
      const mcAll = await mcRecents(1), mcAuj = mcAll.filter((i) => new Intl.DateTimeFormat("fr-CA", { timeZone: "Europe/Paris" }).format(new Date(i.t)) === auj);
      const raps = ((await load("rap", null)) || []).filter((r) => new Intl.DateTimeFormat("fr-CA", { timeZone: "Europe/Paris" }).format(new Date(r.t)) === auj);
      const alertes = (await load("alertes", [])).filter((a) => !a.fin && Date.parse(a.exp) > now).map(({ nature, texte, lieu, site, t, forcee }) => ({ nature, texte, lieu, site, t, forcee }));
      const cr = (await load("crise", { active: null })).active;
      const rondes = (await load("rondes_nfc", [])).filter((r) => r.statut === "en cours").map((r) => ({ nom: r.nom, agent: r.agent, debut: r.debut, faits: new Set(r.passages.map((x) => x.uid)).size, total: r.points.length }));
      const clesEtat = await load("cles_etat", {}), cles = (await load("cles", CLES_INITIAL));
      const sorties = Object.entries(clesEtat).map(([n, e]) => ({ n, cle: (cles.find((c) => c.n === n) || {}).nom || n, nom: e.nom, societe: e.societe || "", t: e.t, retour: e.retour || "" })).sort((a, b) => String(a.t).localeCompare(String(b.t)));
      const jauge = await load("jauge", { evenement: "", max: 0, portes: {} }), presents = Object.values(jauge.portes || {}).reduce((a, p) => a + p.in - p.out, 0);
      const enVac = await agentsEnVacation();
      const cons = (await load("consignes", [])).filter((c) => !c.archive && (!c.fin || c.fin >= auj) && (!c.debut || c.debut <= auj)).map(({ titre, texte, importante, cible }) => ({ titre, texte, importante, cible }));
      const met = await load("meteo_cache", null);
      if (me.role === "client") { // client : activité du site sans aucune information sur les agents
        const cl = await load("cles", CLES_INITIAL);
        return json({ t: new Date().toISOString(), crise: cr ? { type: cr.type, zone: cr.zone, t: cr.t } : null, alertes, agents: [],
          mc: anonyme(mcAuj.filter((i) => !/^(Prise|Fin) de service$/.test(i.categorie || "")).slice(0, 14).map(({ numero, categorie, lieu, site, t, heure, gravite, statut, description }) => ({ numero, categorie, lieu, site, t, heure, gravite, statut, description: String(description || "").slice(0, 120) }))),
          compteurs: { mcJour: mcAuj.filter((i) => !/^(Prise|Fin) de service$/.test(i.categorie || "")).length, ouvertes: mcAll.filter((i) => i.statut !== "clos").length, urgentes: mcAuj.filter((i) => i.gravite === "urgente").length, rapportsJour: raps.length },
          rondes: (await load("rondes_nfc", [])).filter((r) => r.statut === "en cours").map((r) => ({ nom: r.nom, debut: r.debut, faits: new Set(r.passages.map((x) => x.uid)).size, total: r.points.length })), cles: [], jauge: { evenement: jauge.evenement, max: jauge.max || 0, presents }, consignes: cons.filter((c) => !c.cible || c.cible === "tous").map(({ titre, texte, importante }) => ({ titre, texte, importante })),
          meteo: met ? { alertes: (met.alertes || []).slice(0, 3), heures: (met.heures || []).slice(0, 48) } : null });
      }
      // v5.27 · radar des halls : moyens de secours (anomalies, dernière ronde) + bâtiments ouverts / éclairés
      const ms = await load("moyens_secours", { items: [], rondes: [] }), batEtat = await load("batiments_etat", {});
      const hallsRadar = [...new Set((ms.items || []).map((i) => i.hall))].map((h) => { const it = ms.items.filter((i) => i.hall === h), der = (ms.rondes || []).find((r) => r.hall === h);
        return { hall: h, equip: it.length, anomalies: it.filter((i) => i.etat === "anomalie").length, derniere: der ? der.t : null }; });
      const bats = Object.values(batEtat);
      return json({ t: new Date().toISOString(), crise: cr ? { type: cr.type, zone: cr.zone, t: cr.t, reponses: Object.values(cr.reponses || {}).length, aide: Object.values(cr.reponses || {}).filter((r) => r.statut === "besoin d'aide").length } : null,
        alertes, agents: enVac.map(({ nom, poste, site }) => ({ nom, poste, site })),
        mc: mcAuj.slice(0, 14).map(({ numero, categorie, lieu, site, t, heure, gravite, statut, auteur, description }) => ({ numero, categorie, lieu, site, t, heure, gravite, statut, auteur, description: String(description || "").slice(0, 120) })),
        compteurs: { mcJour: mcAuj.length, ouvertes: mcAll.filter((i) => i.statut !== "clos").length, urgentes: mcAuj.filter((i) => i.gravite === "urgente").length, rapportsJour: raps.length, objets: (await load("objets", [])).filter((o) => o.statut === "en stock").length },
        rondes, cles: sorties, jauge: { evenement: jauge.evenement, max: jauge.max || 0, presents }, consignes: cons,
        radar: hallsRadar, bats: { ouverts: bats.filter((b) => b && b.ouvert).length, eclaires: bats.filter((b) => b && b.eclairage).length },
        meteo: met ? { alertes: (met.alertes || []).slice(0, 3), heures: (met.heures || []).slice(0, 48) } : null });
    }

    /* ---------- Habilitations ---------- */
    if (r0 === "habilitations") {
      if (m === "GET") { if (!(isStaff(me) || estProprio(me) || (await estCoord(me)))) return deny(); return json({ modules: HAB_MODULES.map(([k, l]) => ({ k, l })), roles: HAB_ROLES, valeurs: await habilitations(), peutModifier: estProprio(me) }); }
      if (m === "PUT") { if (!estProprio(me)) return refusProprio();
        const v = {}; for (const r of HAB_ROLES) { v[r] = {}; for (const [k] of HAB_MODULES) v[r][k] = !!(body.valeurs && body.valeurs[r] && body.valeurs[r][k]); }
        await save("habilitations", v); await journal("admin", me.nom, "habilitations des agents modifiées", "attention", "#/habilitations"); return json({ ok: true, valeurs: v }); }
      return json({ error: "Méthode non gérée" }, 405);
    }

    /* ---------- Consignes du jour avec accusé de lecture ---------- */
    if (r0 === "consignes") {
      let list = await load("consignes", []); const t = (v, n = 200) => String(v ?? "").trim().slice(0, n);
      const pc = isStaff(me) || estProprio(me), auj = jourParis();
      const actives = list.filter((c) => !c.archive && (!c.fin || c.fin >= auj) && (!c.debut || c.debut <= auj));
      const concerne = (c) => c.cible === "tous" || !c.cible || (c.cible === "arena" ? /arena/i.test(me.postePlanning || "") || me.perimetre === "arena" : !/arena/i.test(me.postePlanning || ""));
      if (m === "GET" && !r1) {
        if (!pc) return json(actives.filter(concerne).map(({ lus, ...c }) => ({ ...c, lu: !!(lus || {})[me.id] })));
        const enVac = await agentsEnVacation();
        return json(list.filter((c) => !c.archive).slice(0, 60).map((c) => ({ ...c, nbLus: Object.keys(c.lus || {}).length, nonLus: enVac.filter((a) => a.id && !(c.lus || {})[a.id] && (c.cible === "tous" || !c.cible || (c.cible === "arena") === /arena/i.test(a.site + " " + a.poste))).map((a) => a.nom) })));
      }
      if (m === "POST" && !r1) {
        if (!pc) return deny();
        const c = { id: uid(), t: new Date().toISOString(), par: me.nom, titre: t(body.titre, 120) || "Consigne", texte: t(body.texte, 3000), cible: ["tous", "parc", "arena"].includes(body.cible) ? body.cible : "tous",
          importante: body.importante === true, debut: /^\d{4}-\d{2}-\d{2}$/.test(body.debut || "") ? body.debut : auj, fin: /^\d{4}-\d{2}-\d{2}$/.test(body.fin || "") ? body.fin : auj, lus: {} };
        if (!c.texte) return json({ error: "Écris la consigne" }, 400);
        list.unshift(c); await save("consignes", list.slice(0, 500));
        await journal("consignes", me.nom, `${c.titre} (${c.cible})`, "info", "#/consignes");
        await envoyerPush({ titre: `Consigne${c.importante ? " IMPORTANTE" : ""} — ${c.titre}`, texte: c.texte.slice(0, 140), url: "/#/consignes", alerte: c.importante }, enService).catch(() => 0);
        return json(c, 201);
      }
      const c = list.find((x) => x.id === r1); if (!c) return json({ error: "Introuvable" }, 404);
      if (m === "POST" && r2 === "lu") { c.lus = c.lus || {}; if (!c.lus[me.id]) { c.lus[me.id] = { nom: me.nom, t: new Date().toISOString() }; await save("consignes", list); await flammes(me, 5, "Consigne lue et confirmée", { cle: "cons-" + c.id, stat: "consignes" }).catch(() => 0); } return json({ ok: true }); }
      if (m === "DELETE") { if (!pc) return deny(); c.archive = true; await save("consignes", list); return json({ ok: true }); }
      return json({ error: "Méthode non gérée" }, 405);
    }

    /* ---------- Mode crise : évacuation, confinement… avec appel des agents en temps réel ---------- */
    if (r0 === "crise") {
      const st = await load("crise", { active: null, historique: [] }), pc = isStaff(me) || estProprio(me), t = (v, n = 300) => String(v ?? "").trim().slice(0, n);
      const a = st.active;
      if (m === "GET") {
        if (!a) return json({ active: null, historique: pc ? st.historique.slice(0, 20) : [] });
        const pub = { id: a.id, type: a.type, zone: a.zone, message: a.message, t: a.t, par: a.par, instructions: a.instructions || [], maReponse: (a.reponses || {})[me.id] || null };
        if (me.role === "client") return json({ active: { id: a.id, type: a.type, zone: a.zone, message: a.message, t: a.t, par: "PC sécurité", instructions: [], maReponse: null } });
        if (!pc) return json({ active: pub });
        const enVac = await agentsEnVacation(), rep = a.reponses || {};
        const agents = enVac.map((x) => ({ ...x, reponse: x.id ? rep[x.id] || null : null }));
        for (const [id, r] of Object.entries(rep)) if (!agents.some((x) => x.id === id)) agents.push({ id, nom: r.nom, poste: r.poste || "", site: "", reponse: r });
        return json({ active: { ...pub, agents }, historique: st.historique.slice(0, 20) });
      }
      if (m === "POST" && !r1) {
        if (!pc || me.role === "responsable") return deny(); if (a) return json({ error: "Une crise est déjà en cours" }, 400);
        const types = ["Évacuation", "Mise à l'abri / confinement", "Alerte attentat / intrusion", "Incendie", "Malaise collectif / afflux de victimes", "Autre"];
        const c = { id: uid(), t: new Date().toISOString(), par: me.nom, type: types.includes(body.type) ? body.type : "Autre", zone: t(body.zone, 160), message: t(body.message, 600), instructions: [], reponses: {} };
        const inc = await mcSysteme(me, "Évacuation", `MODE CRISE déclenché : ${c.type}${c.zone ? " — " + c.zone : ""}${c.message ? ". " + c.message : ""}`, "urgente"); c.mcId = inc.id;
        st.active = c; await save("crise", st);
        await journal("crise", me.nom, `MODE CRISE : ${c.type}${c.zone ? " — " + c.zone : ""}`, "urgent", "#/crise");
        await envoyerPush({ titre: `MODE CRISE — ${c.type}`, texte: `${c.zone ? c.zone + " · " : ""}${c.message || "Ouvre l'appli et indique ta situation"}`.slice(0, 160), url: "/#/", alerte: true }, enService).catch(() => 0);
        return json(c, 201);
      }
      if (!a) return json({ error: "Aucune crise en cours" }, 400);
      if (m === "POST" && r1 === "reponse") {
        const s = ["reçu", "en position", "zone évacuée", "besoin d'aide"].includes(body.statut) ? body.statut : null; if (!s) return json({ error: "Statut inconnu" }, 400);
        a.reponses = a.reponses || {}; a.reponses[me.id] = { nom: me.nom, poste: me.postePlanning || "", statut: s, note: t(body.note, 200), t: new Date().toISOString(), gps: body.gps && typeof body.gps.lat === "number" ? { lat: body.gps.lat, lon: body.gps.lon } : null };
        await save("crise", st);
        if (s === "besoin d'aide") { await journal("crise", me.nom, `BESOIN D'AIDE${body.note ? " : " + t(body.note, 120) : ""}`, "urgent", "#/crise");
          await envoyerPush({ titre: `BESOIN D'AIDE — ${me.nom}`, texte: `${me.postePlanning || ""} ${t(body.note, 100)}`.trim() || "Mode crise", url: "/#/crise", alerte: true }, (u) => isStaff(u) || estProprio(u)).catch(() => 0); }
        return json({ ok: true });
      }
      if (!pc || me.role === "responsable") return deny();
      if (m === "POST" && r1 === "message") {
        const txt = t(body.texte, 400); if (!txt) return json({ error: "Message vide" }, 400);
        a.instructions = [...(a.instructions || []), { t: new Date().toISOString(), par: me.nom, texte: txt }]; await save("crise", st);
        await envoyerPush({ titre: `MODE CRISE — consigne du PC`, texte: txt.slice(0, 160), url: "/#/", alerte: true }, enService).catch(() => 0);
        return json({ ok: true });
      }
      if (m === "POST" && r1 === "fin") {
        const rep = Object.values(a.reponses || {}), duree = Math.round((Date.now() - Date.parse(a.t)) / 60000);
        const resume = `FIN DU MODE CRISE (${a.type}) après ${duree} min. Réponses : ${rep.length} agent(s) — ${["en position", "zone évacuée", "reçu", "besoin d'aide"].map((s) => `${rep.filter((r) => r.statut === s).length} ${s}`).join(", ")}.${body.bilan ? " Bilan : " + t(body.bilan, 1500) : ""}`;
        await mcSysteme(me, "Évacuation", resume, "urgente", { statut: "clos" });
        st.historique.unshift({ ...a, fin: { t: new Date().toISOString(), par: me.nom, bilan: t(body.bilan, 1500), duree } }); st.active = null; await save("crise", { ...st, historique: st.historique.slice(0, 100) });
        await journal("crise", me.nom, `fin du mode crise (${duree} min)`, "info", "#/crise");
        await envoyerPush({ titre: "Fin du mode crise", texte: `${a.type} terminé. Reprise normale du service.`, url: "/#/" }, enService).catch(() => 0);
        return json({ ok: true, duree });
      }
      return json({ error: "Méthode non gérée" }, 405);
    }

    /* ---------- Objets trouvés : enregistrement (photo), stockage, restitution signée ---------- */
    if (r0 === "objets") {
      let list = await load("objets", []);
      if (list.some((o) => o.stockage === "Grande boîte en plastique")) { list.forEach((o) => { if (o.stockage === "Grande boîte en plastique") o.stockage = "Bac de rangement en plastique"; }); await save("objets", list); } const t = (v, n = 120) => String(v ?? "").trim().slice(0, n);
      const gere = isStaff(me) || estProprio(me);
      if (m === "GET" && !r1 && me.role === "client") return json(anonyme(list).slice(0, 1500));
      if (me.role === "client" && m !== "GET") return deny();
      if (m === "GET" && !r1) return json((gere ? list : list.filter((o) => o.auteurId === me.id)).slice(0, 1500));
      if (r1 === "bilan" || r1 === "remise" || r1 === "rappel") {
        if (!gere && !(await estCoord(me))) return deny();
        const mm = /^\d{4}-\d{2}$/.test(url.searchParams.get("mois") || "") ? url.searchParams.get("mois") : moisDe();
        if (m === "GET" && r1 === "rappel") { const rp = await load("objets_rappel", null), rem = (await load("objets_remises", [])).find((r) => moisDe(r.t) === moisDe());
          const nb = list.filter((o) => o.statut === "en stock").length; return json({ du: !!(rp && rp.mois === moisDe() && !rem && nb), nb, receveur: RECEVEUR_OBJETS }); }
        if (m === "GET" && r1 === "bilan" && !r2) { const b = await bilanObjets(mm); return json({ ...b, restants: b.restants, restitues: b.restitues.map(({ restitution, ...o }) => ({ ...o, restitution: { t: restitution.t, nom: restitution.nom, par: restitution.par } })) }); }
        if (m === "GET" && r1 === "bilan" && r2 === "pdf") { const pdf = pdfObjets(await bilanObjets(mm)); return json({ nom: `objets-trouves-${mm}.pdf`, pdf: pdf.toString("base64") }); }
        if (m === "GET" && r1 === "remise" && r2 && parts[3] === "pdf") { const r = (await load("objets_remises", [])).find((x) => x.id === r2); if (!r) return json({ error: "Bordereau introuvable" }, 404);
          const b = await bilanObjets(moisDe(r.t)); return json({ nom: `bordereau-${r.numero}.pdf`, pdf: pdfObjets(b, { ...r, objets: list.filter((o) => r.ids.includes(o.id)) }).toString("base64") }); }
        if (m === "GET" && r1 === "remise") return json((await load("objets_remises", [])).slice(0, 36).map(({ ids, ...r }) => ({ ...r, nb: ids.length })));
        if (m === "POST" && r1 === "remise") {
          if (!gere) return deny();
          const enStock = list.filter((o) => o.statut === "en stock"); if (!enStock.length) return json({ error: "Aucun objet en stock à remettre" }, 400);
          const sig = body.signature; if (typeof sig !== "string" || !sig.startsWith("data:image/png") || sig.length > 400000) return json({ error: "Signature de M. Malvezin manquante" }, 400);
          const an = new Date().getFullYear(), rem = await load("objets_remises", []), nbAn = rem.filter((r) => r.numero.startsWith(`RM-${an}-`)).length + 1;
          const r = { id: uid(), numero: `RM-${an}-${String(nbAn).padStart(3, "0")}`, t: new Date().toISOString(), par: me.nom, parId: me.id, receveur: t(body.receveur, 80) || RECEVEUR_OBJETS.nom, fonction: RECEVEUR_OBJETS.fonction, ids: enStock.map((o) => o.id), numeros: enStock.map((o) => o.numero), note: t(body.note, 300) };
          await save("photo/remise-" + r.id + "-sig", { d: sig, auteurId: me.id, objet: true });
          for (const o of enStock) { o.statut = "remis à la SPL OE"; o.remise = { id: r.id, numero: r.numero, t: r.t }; o.suivi = [...(o.suivi || []), { t: r.t, par: me.nom, statut: "remis à la SPL OE", note: `Bordereau ${r.numero} — M. ${r.receveur}` }]; }
          await save("objets", list); rem.unshift(r); await save("objets_remises", rem.slice(0, 120));
          await mcSysteme(me, "Objets trouvés", `Remise ${r.numero} : ${enStock.length} objet(s) remis en sac à M. ${r.receveur} (${r.fonction}) : ${r.numeros.join(", ")}.`, "info", { statut: "clos" });
          await journal("objets trouvés", me.nom, `remise ${r.numero} : ${enStock.length} objet(s) à M. ${r.receveur}`, "info", "#/objets");
          try { const b = await bilanObjets(moisDe(r.t)); await sendMail(DIFFUSION_SITE(), `Kaelum e-PCS — Bordereau ${r.numero} — ${enStock.length} objet(s) remis à M. ${r.receveur}`, `<div style="font-family:Arial,sans-serif"><p>Remise des objets trouvés effectuée par ${escH(me.nom)} le ${frJ(r.t)} : <b>${enStock.length}</b> objet(s) remis à M. ${escH(r.receveur)}, ${escH(r.fonction)}.</p><p>Bordereau signé en pièce jointe.</p></div>`, [{ name: `bordereau-${r.numero}.pdf`, content: pdfObjets(b, { ...r, objets: enStock }).toString("base64") }]); } catch {}
          return json({ ok: true, id: r.id, numero: r.numero, nb: enStock.length });
        }
        if (m === "POST" && r1 === "bilan" && r2 === "essai") { if (!(estProprio(me) || me.role === "admin")) return deny(); return json(await objetsMensuel({ essai: true })); }
        return json({ error: "Requête invalide" }, 400);
      }
      // v4.19 · Retour des consignes : objets non récupérés à la fermeture du service accueil / consigne, rangés au bac, au coffre ou ailleurs
      if (m === "POST" && r1 === "consigne") {
        if (me.role === "client") return deny();
        const service = t(body.service, 80) || "Consigne", remisPar = t(body.remisPar, 120), site = /arena/i.test(body.site || service) ? "Arena Sud de France" : "Parc des Expositions";
        const lignes = (Array.isArray(body.lignes) ? body.lignes : []).slice(0, 200).map((l) => ({ ticket: t(l.ticket, 30), categorie: t(l.categorie, 60) || "Autre", description: t(l.description, 500), stockage: t(l.stockage, 120), photo: l.photo })).filter((l) => l.description || l.ticket);
        if (!lignes.length) return json({ error: "Ajoute au moins un objet (n° de ticket ou description)" }, 400);
        const an = new Date().getFullYear(), cpt = await load("consignes_compteur", {}), cree = [], tt = new Date().toISOString(); // v4.59 · numérotation propre : RC-AAAA-NNNN
        for (const l of lignes) { cpt[an] = (cpt[an] || 0) + 1;
          const o = { id: uid(), numero: `RC-${an}-${String(cpt[an]).padStart(4, "0")}`, t: tt, auteurId: me.id, auteur: me.nom, categorie: l.categorie, description: l.description || `Objet de consigne, ticket ${l.ticket}`,
            site, lieu: service, rapportePar: `Retour consigne${remisPar ? " — remis par " + remisPar : ""}`, stockage: l.stockage || rangementObjet(l.categorie), statut: "en stock", photo: false, origine: "consigne", ticket: l.ticket, service };
          if (typeof l.photo === "string" && l.photo.startsWith("data:image/") && l.photo.length < MAX_PHOTO) { await save("photo/" + o.id, { d: l.photo, auteurId: me.id, objet: true }); o.photo = true; }
          cree.push(o); }
        await save("consignes_compteur", cpt); list.unshift(...cree); await save("objets", list.slice(0, 5000));
        const resume = cree.map((o) => `${o.numero}${o.ticket ? " (ticket " + o.ticket + ")" : ""} → ${o.stockage}`).join(", ");
        await mcSysteme(me, "Retour de consignes", `Retour de consignes — ${service}${remisPar ? ", remis par " + remisPar : ""} : ${cree.length} objet(s) non récupéré(s) : ${resume}.`.slice(0, 4000), "info", { statut: "clos", site, lieu: service });
        await journal("retour de consignes", me.nom, `retour de consignes · ${service} · ${cree.length} objet(s)`, "info", "#/consignesretour");
        return json({ ok: true, objets: cree }, 201);
      }
      if (m === "POST" && !r1) {
        const desc = t(body.description, 500); if (!desc) return json({ error: "Décris l'objet" }, 400);
        const an = new Date().getFullYear(), cpt = await load("objets_compteur", {}); cpt[an] = (cpt[an] || 0) + 1; await save("objets_compteur", cpt);
        const o = { id: uid(), numero: `OT-${an}-${String(cpt[an]).padStart(4, "0")}`, t: new Date().toISOString(), auteurId: me.id, auteur: me.nom, categorie: t(body.categorie, 60) || "Autre",
          description: desc, site: t(body.site, 60), lieu: t(body.lieu), rapportePar: t(body.rapportePar, 120), stockage: t(body.stockage, 120) || rangementObjet(body.categorie), statut: "en stock", photo: false };
        const ph = body.photo; if (typeof ph === "string" && ph.startsWith("data:image/") && ph.length < MAX_PHOTO) { await save("photo/" + o.id, { d: ph, auteurId: me.id, objet: true }); o.photo = true; }
        list.unshift(o); await save("objets", list.slice(0, 5000));
        await journal("objets trouvés", me.nom, `${o.numero} · ${o.categorie} · ${desc.slice(0, 60)}${o.lieu ? " · " + o.lieu : ""}`, "info", "#/objets");
        return json(o, 201);
      }
      const o = list.find((x) => x.id === r1); if (!o) return json({ error: "Introuvable" }, 404);
      if (m === "POST" && r2 === "restitution") {
        if (!gere) return deny(); if (o.statut === "restitué") return json({ error: "Déjà restitué" }, 400);
        const nom = t(body.nom); if (!nom) return json({ error: "Nom de la personne obligatoire" }, 400);
        const sig = body.signature; if (typeof sig !== "string" || !sig.startsWith("data:image/png") || sig.length > 400000) return json({ error: "Signature manquante" }, 400);
        await save("photo/" + o.id + "-sig", { d: sig, auteurId: me.id, objet: true });
        o.statut = "restitué"; o.restitution = { t: new Date().toISOString(), par: me.nom, nom, tel: t(body.tel, 20), piece: t(body.piece, 80), note: t(body.note, 300) };
        await save("objets", list); await journal("objets trouvés", me.nom, `${o.numero} restitué à ${nom}`, "info", "#/objets"); return json(o);
      }
      if (m === "POST" && r2 === "statut") {
        if (!gere) return deny(); const s = ["en stock", "remis à la police", "remis à l'organisateur", "remis à la SPL OE", "détruit"].includes(body.statut) ? body.statut : null; if (!s) return json({ error: "Statut inconnu" }, 400);
        o.statut = s; o.suivi = [...(o.suivi || []), { t: new Date().toISOString(), par: me.nom, statut: s, note: t(body.note, 300) }];
        await save("objets", list); await journal("objets trouvés", me.nom, `${o.numero} → ${s}`, "info", "#/objets"); return json(o);
      }
      return json({ error: "Méthode non gérée" }, 405);
    }

    /* ---------- Présences : planning du jour comparé aux prises et fins de service (émargement) ---------- */
    if (r0 === "presences" && m === "GET") {
      if (!(isStaff(me) || estProprio(me) || (await estCoord(me)))) return deny();
      const d = /^\d{4}-\d{2}-\d{2}$/.test(url.searchParams.get("date") || "") ? url.searchParams.get("date") : jourParis();
      const lignes = await presencesDu(d);
      const n = (s) => lignes.filter((l) => l.statut.startsWith(s)).length;
      return json({ date: d, lignes, compte: { prevus: lignes.length, presents: n("présent"), retards: n("présent (retard)"), termines: n("terminé"), absents: n("absent") + n("non pointé"), attendus: n("attendu") + n("à venir") } });
    }

    /* ---------- Bilan mensuel ---------- */
    if (r0 === "bilan" && m === "GET") {
      if (!(isStaff(me) || estProprio(me) || me.role === "client" || (await estCoord(me)))) return deny();
      const mm = /^\d{4}-\d{2}$/.test(url.searchParams.get("mois") || "") ? url.searchParams.get("mois") : moisDe();
      const b = await bilanMois(mm);
      if (me.role === "client") { delete b.personnel; delete b.moyens.clesSorties; } // client : ni planning ni boîte à clés
      return json(url.searchParams.get("format") === "html" ? { html: htmlBilan(b) } : b);
    }

    /* ---------- v3.87 · Brief d'événement : horaires, consignes par poste, listes d'accès (contrôle à l'entrée) ---------- */
    if (r0 === "briefs") {
      const ecrit = me.role === "admin" || estProprio(me), t = (v, n = 200) => String(v ?? "").trim().slice(0, n);
      let list = await load("briefs", null); if (!list && TENANT()) list = []; if (!list) { const b0 = JSON.parse(JSON.stringify(BRIEF_FIM26)); b0.alertes = [...FIM26_EXPLOIT.alertes, ...(b0.alertes || [])]; b0.consignes = [...FIM26_EXPLOIT.consignes, ...(b0.consignes || []).map((c) => ({ ...c, poste: /montage|frigo|SSIAP|volants/i.test(c.poste) ? c.poste : c.poste + " (montage)" }))]; list = [b0]; await save("briefs", list); }
      if (m === "GET" && !r1) return json({ briefs: list, peutModifier: ecrit && me.role !== "client", peutControler: !["responsable", "client"].includes(me.role) });
      const b = list.find((x) => x.id === r1);
      if (m === "POST" && b && r2 === "acces") { // décision à l'entrée, notée en main courante
        if (me.role === "responsable") return deny();
        const L = (b.acces || [])[+body.liste]; if (!L) return json({ error: "Liste introuvable" }, 400);
        const nom = t(body.nom, 120); if (!nom) return json({ error: "Nom de la société obligatoire" }, 400);
        const ok = body.decision === "autorise", listee = !!body.listee, info = t(body.info, 160), immat = t(body.immat, 20).toUpperCase(), note = t(body.note, 300);
        const inc = await mcSysteme(me, "Contrôle d'accès", `${ok ? "Entrée autorisée" : "Entrée refusée"} · ${nom}${info ? " (" + info + ")" : ""}${listee ? "" : " · non listé"} · ${L.titre}${immat ? " · immat. " + immat : ""}${note ? " · " + note : ""}`, ok ? "info" : "moyenne",
          { site: b.site || "", lieu: L.poste || "", immat, statut: "clos", poste: me.postePlanning || "" });
        if (!ok || !listee) await journal("contrôle d'accès", me.nom, `${ok ? "autorisé hors liste" : "refusé"} : ${nom} · ${L.titre}`, ok ? "attention" : "info", "#/brief");
        return json({ ok: true, numero: inc.numero });
      }
      if (!ecrit) return json({ error: "Modification réservée aux administrateurs et au propriétaire" }, 403);
      if (m === "PUT" && r1) { // enregistre (ou crée) un brief complet
        const net = (s) => String(s ?? "").trim();
        const nb = { id: b ? b.id : "br" + uid(), titre: t(body.titre, 160) || "Événement", du: /^\d{4}-\d{2}-\d{2}$/.test(body.du || "") ? body.du : "", au: /^\d{4}-\d{2}-\d{2}$/.test(body.au || "") ? body.au : "", site: t(body.site, 80),
          alertes: (Array.isArray(body.alertes) ? body.alertes : []).map((x) => t(x, 500)).filter(Boolean).slice(0, 20),
          horaires: (Array.isArray(body.horaires) ? body.horaires : []).slice(0, 20).map((h) => ({ titre: t(h.titre, 120), lignes: (h.lignes || []).map((x) => t(x, 300)).filter(Boolean).slice(0, 30) })).filter((h) => h.titre),
          consignes: (Array.isArray(body.consignes) ? body.consignes : []).slice(0, 60).map((c) => ({ poste: t(c.poste, 100), cles: (c.cles || []).map((x) => t(x, 40)).filter(Boolean).slice(0, 10), texte: net(c.texte).slice(0, 4000) })).filter((c) => c.poste && c.texte),
          acces: (Array.isArray(body.acces) ? body.acces : []).slice(0, 10).map((a) => ({ titre: t(a.titre, 120), poste: t(a.poste, 60), colonnes: (a.colonnes || []).map((x) => t(x, 40)).slice(0, 6), lignes: (a.lignes || []).slice(0, 800).map((l) => (Array.isArray(l) ? l : [l]).map((x) => t(x, 160)).slice(0, 6)).filter((l) => l[0]) })).filter((a) => a.titre),
          maj: new Date().toISOString(), majPar: me.nom };
        list = b ? list.map((x) => (x.id === b.id ? nb : x)) : [nb, ...list]; await save("briefs", list.slice(0, 30));
        await journal("brief", me.nom, `brief ${b ? "modifié" : "créé"} : ${nb.titre}`, "info", "#/brief"); return json(nb);
      }
      if (m === "DELETE" && b) { await save("briefs", list.filter((x) => x.id !== b.id)); await journal("brief", me.nom, `brief supprimé : ${b.titre}`, "attention", "#/brief"); return json({ ok: true }); }
      return json({ error: "Requête invalide" }, 400);
    }

    /* ---------- v3.86 · Protection de l'écran : tentatives de capture / copie notées pour le propriétaire ---------- */
    if (r0 === "securite" && m === "POST") {
      const T = { capture: "tentative de capture d'écran (touche Impr. écran)", copie: "tentative de copie de contenu", impression: "tentative d'impression de l'écran", outil: "outil de capture ou d'enregistrement d'écran détecté" };
      const ty = T[body.type] ? body.type : "capture", page = String(body.page || "").slice(0, 40);
      if (!estProprio(me)) { const lk = await load("locks", {}), k = "sec:" + me.id, now = Date.now(); if (!(lk[k] && now - lk[k] < 30e3)) { lk[k] = now; await save("locks", lk);
        await journal("sécurité", me.nom, `${T[ty]}${page ? " · page " + page : ""}`, "attention", "#/notifs"); } }
      return json({ ok: true });
    }

    /* ---------- v3.85 · Relevé des postes : photos + géolocalisation, carte du site ---------- */
    if (r0 === "sitepostes") {
      const ecrit = me.role === "admin" || me.role === "pc" || estProprio(me), t = (v, n = 120) => String(v ?? "").trim().slice(0, n);
      let list = await load("site_postes", null); if (!list && TENANT()) list = [];
      if (!list) { // liste de départ : portails, accès, accueils et portes du site (complétable)
        const z = await load("zones", DEFAULT_ZONES); list = [];
        for (const [site, groupes] of Object.entries(z)) for (const [groupe, lieux] of Object.entries(groupes)) {
          if (!/portail|acc[eè]s|accueil|porte|pc|backstage|mail/i.test(groupe)) continue;
          for (const lieu of lieux) if (!/^(A|B)\d$|Centre de conf/i.test(lieu)) list.push({ id: "sp" + uid(), nom: lieu, site, zone: groupe, consigne: "", gps: null, photos: [], pos: null });
        }
        await save("site_postes", list);
      }
      if (!TENANT() && !(await load("site_postes_plan_v1", false))) { // postes des plans d'accès officiels, placés sur le plan du site (une seule fois)
        let n = 0;
        for (const q of POSTES_PLAN) {
          const k = normPoste(q.nom), ex = list.find((x) => normPoste(x.nom) === k);
          if (ex) { if (!ex.pos) { ex.pos = q.pos; n++; } if (q.intitules.length) ex.intitules = [...new Set([...(ex.intitules || []), ...q.intitules])]; if (!q.site) ex.site = ""; }
          else { list.push({ id: "sp" + uid(), nom: q.nom, site: q.site, zone: q.zone, consigne: "", gps: null, photos: [], pos: q.pos, intitules: q.intitules, source: "plans d'accès" }); n++; }
        }
        await save("site_postes", list.slice(0, 400)); await save("site_postes_plan_v1", true);
        await journal("postes", "Kaelum e-PCS", `${n} poste(s) placés sur le plan d'après les plans d'accès aux postes`, "info", "#/plan");
      }
      if (!TENANT() && !(await load("site_postes_arena_v1", false))) { // v4.32 · postes de l'Arena (portes 1 à 8 et postes des plannings), une seule fois
        const AR = [...[1, 2, 3, 4, 5, 6, 7, 8].map((n) => ["Porte " + n, "Portes"]), ["Porte arrière backstage", "Cour de service"], ["Passage accréd. backstage", "Cour de service"], ["Entrée cour de service", "Cour de service"], ["Cour de service", "Cour de service"], ["Portail pompiers", "Cour de service"],
          ["Porte grise aéroport", "Portes grises"], ["Porte grise côté cour", "Portes grises"], ["Parvis", "Parvis et parkings"], ["Billetterie / consigne", "Parvis et parkings"], ["Parking VIP média", "Parvis et parkings"], ["Parking loges / portail VIP", "Parvis et parkings"], ["P3 / ronde de nuit et fermeture", "Parvis et parkings"],
          ["Parking A (accueil, placement, cynophile)", "Parkings extérieurs"], ["Parking B", "Parkings extérieurs"], ["Parking Pailletrice / RFT patte d'oie", "Parkings extérieurs"],
          ["Terrain / FOP", "Salle"], ["Parterre", "Salle"], ["Devant de scène / crash", "Salle"], ["Régie", "Salle"], ["Gradin haut", "Salle"], ["Côté cour", "Salle"], ["Côté jardin", "Salle"],
          ["Salle des médias (niv. 1)", "Étages"], ["Salon VIP réception (niv. 1)", "Étages"], ["Ascenseur / accréd. loges (niv. 2)", "Étages"], ["Zone mixte", "Zones sportives"], ["Warming zone", "Zones sportives"],
          ["PC Arena · SSIAP", "Sécurité incendie"], ["SSIAP 2 représentation", "Sécurité incendie"], ["ADS volants / coordinateur", "Volants"]];
        let n = 0; for (const [nom, zone] of AR) { if (list.some((x) => /arena/i.test(x.site || "") && normPoste(x.nom) === normPoste(nom))) continue; list.push({ id: "sp" + uid(), nom, site: "Arena Sud de France", zone, consigne: "", gps: null, photos: [], pos: null, source: "postes Arena" }); n++; }
        await save("site_postes", list.slice(0, 400)); await save("site_postes_arena_v1", true);
        await journal("postes", "Kaelum e-PCS", `${n} poste(s) de l'Arena ajoutés à la carte des postes`, "info", "#/postes-site");
      }
      const num = (v) => (Number.isFinite(+v) ? +v : null);
      if (m === "GET" && r1 === "agents") { // agents au poste maintenant (selon le planning et la prise de service)
        if (!(isStaff(me) || estProprio(me) || (await estCoord(me)) || me.role === "ssiap3")) return json({ agents: [], hors: [] });
        // ?date=AAAA-MM-JJ&heure=HH:MM : voir les agents prévus à n'importe quelle vacation (sinon : maintenant)
        const qd = url.searchParams.get("date") || "", qh = url.searchParams.get("heure") || "";
        const choisi = /^\d{4}-\d{2}-\d{2}$/.test(qd) && /^\d{2}:\d{2}$/.test(qh), now = choisi ? minutesLocales(qd, qh) : maintenantParis();
        const auj = choisi ? qd : jourParis(), hier = new Date(Date.parse(auj) - 864e5).toISOString().slice(0, 10), enDirect = Math.abs(now - maintenantParis()) < 20, agents = [], hors = [];
        for (const d of [hier, auj]) for (const l of await presencesDu(d)) {
          const deb = minutesLocales(d, l.debut); let fin = minutesLocales(d, l.fin); if (fin <= deb) fin += 1440;
          if (now < deb - (enDirect ? 30 : 0) || now > fin + (enDirect ? 15 : -1) || (enDirect && l.statut === "terminé") || /^NON AFFECT/i.test(l.nom)) continue;
          const p = posteCarteDe(l, list), a = { nom: l.nom, poste: l.poste, site: l.site, qualif: l.qualif || "", evenement: l.evenement || "", debut: l.debut, fin: l.fin, statut: enDirect ? l.statut : "prévu", arrivee: l.arrivee, posteId: p ? p.id : null };
          (p ? agents : hors).push(a);
        }
        return json({ agents, hors, date: auj, heure: choisi ? qh : "", enDirect });
      }
      if (m === "GET" && !r1) return json({ postes: list, peutModifier: ecrit });
      if (!ecrit) return json({ error: "Relevé réservé au PC sécurité, aux administrateurs et au propriétaire" }, 403);
      if (m === "POST" && !r1) { const nom = t(body.nom, 80); if (!nom) return json({ error: "Nom du poste obligatoire" }, 400);
        const p = { id: "sp" + uid(), nom, site: t(body.site, 60) || "Parc des Expositions", zone: t(body.zone, 60) || "Autres postes", consigne: t(body.consigne, 400), gps: null, photos: [], pos: null,
          demande: t(body.demande, 120), du: /^\d{4}-\d{2}-\d{2}$/.test(body.du || "") ? body.du : "", au: /^\d{4}-\d{2}-\d{2}$/.test(body.au || "") ? body.au : "", cree: new Date().toISOString(), creePar: me.nom };
        if (body.gps) { const lat = num(body.gps.lat), lon = num(body.gps.lon);
          if (lat !== null && lon !== null && Math.abs(lat) <= 90 && Math.abs(lon) <= 180) p.gps = { lat: +lat.toFixed(7), lon: +lon.toFixed(7), acc: num(body.gps.acc) !== null ? Math.round(+body.gps.acc) : null, alt: num(body.gps.alt) !== null ? Math.round(+body.gps.alt) : null, t: new Date().toISOString(), par: me.nom }; }
        list.push(p); await save("site_postes", list.slice(0, 400)); await journal("postes", me.nom, `poste ajouté : ${nom}${p.demande ? " · demande : " + p.demande : ""}${p.gps ? ` · GPS ±${p.gps.acc ?? "?"} m` : ""}`, "info", "#/postes-site"); return json(p, 201); }
      const p = list.find((x) => x.id === r1); if (!p) return json({ error: "Poste introuvable" }, 404);
      if (m === "PUT" && !r2) {
        if (body.nom !== undefined) p.nom = t(body.nom, 80) || p.nom; if (body.consigne !== undefined) p.consigne = t(body.consigne, 400);
        if (body.site !== undefined) p.site = t(body.site, 60); if (body.zone !== undefined) p.zone = t(body.zone, 60);
        if (body.demande !== undefined) p.demande = t(body.demande, 120);
        if (body.intitules !== undefined) p.intitules = (Array.isArray(body.intitules) ? body.intitules : String(body.intitules).split(/[,;\n]/)).map((x) => t(x, 60)).filter(Boolean).slice(0, 10);
        for (const k of ["du", "au"]) if (body[k] !== undefined) p[k] = /^\d{4}-\d{2}-\d{2}$/.test(body[k] || "") ? body[k] : "";
        if (body.gps === null) p.gps = null;
        else if (body.gps) { const lat = num(body.gps.lat), lon = num(body.gps.lon); if (lat === null || lon === null || Math.abs(lat) > 90 || Math.abs(lon) > 180) return json({ error: "Coordonnées invalides" }, 400);
          p.gps = { lat: +lat.toFixed(7), lon: +lon.toFixed(7), acc: num(body.gps.acc) !== null ? Math.round(+body.gps.acc) : null, alt: num(body.gps.alt) !== null ? Math.round(+body.gps.alt) : null, t: new Date().toISOString(), par: me.nom };
          await journal("postes", me.nom, `position relevée : ${p.nom} (${p.gps.lat}, ${p.gps.lon}${p.gps.acc ? " ±" + p.gps.acc + " m" : ""})`, "info", "#/postes-site"); }
        if (body.pos === null) p.pos = null; else if (body.pos && num(body.pos.x) !== null && num(body.pos.y) !== null) p.pos = { x: +(+body.pos.x).toFixed(1), y: +(+body.pos.y).toFixed(1) };
        p.maj = new Date().toISOString(); p.majPar = me.nom; await save("site_postes", list); return json(p);
      }
      if (m === "POST" && r2 === "photo") {
        const ph = body.photo; if (typeof ph !== "string" || !ph.startsWith("data:image/") || ph.length > MAX_PHOTO) return json({ error: "Photo invalide ou trop lourde" }, 400);
        if ((p.photos || []).length >= 4) return json({ error: "4 photos maximum par poste" }, 400);
        const pid = "sp-" + p.id + "-" + uid(); await save("photo/" + pid, { d: ph, auteurId: me.id, poste: true });
        p.photos = [...(p.photos || []), pid]; p.maj = new Date().toISOString(); p.majPar = me.nom; await save("site_postes", list);
        await journal("postes", me.nom, `photo ajoutée : ${p.nom}`, "info", "#/postes-site"); return json(p);
      }
      if (m === "DELETE" && r2 === "photo" && parts[3]) { p.photos = (p.photos || []).filter((x) => x !== parts[3]); await save("site_postes", list); return json(p); }
      if (m === "DELETE" && !r2) { await save("site_postes", list.filter((x) => x.id !== p.id)); await journal("postes", me.nom, `poste supprimé : ${p.nom}`, "attention", "#/postes-site"); return json({ ok: true }); }
      return json({ error: "Requête invalide" }, 400);
    }

    /* ---------- v3.79 · Codes d'accès des cadenas (chiffrés ; enregistrés par les administrateurs) ---------- */
    /* ---------- v4.53 · Permis de feu : date, heure, photo du document → enregistré + diffusé par mail ---------- */
    if (r0 === "permis-feu") {
      if (me.role === "client") return json({ error: "Non disponible" }, 403);
      const gereDiff = estProprio(me) || String(me.id || "").toLowerCase() === "courrier.laurent@free.fr", t = (v, n) => String(v ?? "").trim().slice(0, n);
      let list = await load("permis_feu", []); const dest = await load("diffusion_permis_feu", []);
      if (m === "GET") return json({ items: list.slice(0, 150), dest: gereDiff ? dest : dest.length, gereDiff, defaut: DIFFUSION_SITE().map((d) => d.nom) });
      if (m === "PUT" && r1 === "diffusion") { if (!gereDiff) return json({ error: "Seuls Rochdi et Laurent Hernandez gèrent la liste de diffusion" }, 403);
        const L = [...new Set((Array.isArray(body.emails) ? body.emails : String(body.emails || "").split(/[\s,;]+/)).map((x) => String(x).trim().toLowerCase()).filter((x) => /^[^@\s]+@[^@\s]+\.[a-z]{2,}$/.test(x)))].slice(0, 40);
        await save("diffusion_permis_feu", L); await journal("permis de feu", me.nom, `liste de diffusion des permis de feu : ${L.length} adresse(s)`, "info", "#/permisfeu"); return json({ dest: L }); }
      if (m === "POST" && !r1) {
        const date = /^\d{4}-\d{2}-\d{2}$/.test(body.date || "") ? body.date : "", heure = /^([01]\d|2[0-3]):[0-5]\d$/.test(body.heure || "") ? body.heure : "", fin = /^([01]\d|2[0-3]):[0-5]\d$/.test(body.fin || "") ? body.fin : "";
        const photos = (Array.isArray(body.photos) ? body.photos : []).filter((x) => typeof x === "string" && x.startsWith("data:image/") && x.length < MAX_PHOTO).slice(0, 4);
        if (!date || !heure) return json({ error: "Date et heure obligatoires" }, 400); if (!photos.length) return json({ error: "Prends le permis de feu en photo" }, 400);
        const year = date.slice(0, 4), cpt = await load("permis_feu_cpt", {}); cpt[year] = (cpt[year] || 0) + 1; await save("permis_feu_cpt", cpt);
        const pf = { id: uid(), numero: `PF-${year}-${String(cpt[year]).padStart(4, "0")}`, date, heure, fin, info: t(body.info, 300), t: new Date().toISOString(), auteurId: me.id, auteur: me.nom, photos: photos.length };
        for (let k = 0; k < photos.length; k++) await save(`photo/pf-${pf.id}-${k}`, { d: photos[k], auteurId: me.id, pf: true });
        list.unshift(pf); await save("permis_feu", list.slice(0, 1000));
        const quand = `${date.split("-").reverse().join("/")} à ${heure.replace(":", "h")}${fin ? " → " + fin.replace(":", "h") : ""}`;
        const mc = await mcSysteme(me, "Permis de feu", `Permis de feu ${pf.numero} — ${quand}${pf.info ? " — " + pf.info : ""} (document photographié, ${photos.length} photo(s))`, "info");
        const vers = dest.length ? dest.join(",") : DIFFUSION_SITE().map((d) => d.email).join(",");
        await mailVers(vers, `🔥 Permis de feu ${pf.numero} — ${quand}`, [...(await lignesAgent(me)), ["Permis", pf.numero], ["Date", date.split("-").reverse().join("/")], ["Heure", heure.replace(":", "h")], ["Fin", fin ? fin.replace(":", "h") : ""], ["Précisions", pf.info], ["Main courante", mc.numero]], photos, "Diffusion permis de feu");
        await journal("permis de feu", me.nom, `permis de feu ${pf.numero} enregistré (${quand}) et diffusé à ${dest.length || DIFFUSION_SITE().length} adresse(s)`, "info", "#/permisfeu");
        return json({ ...pf, diffuse: dest.length || DIFFUSION_SITE().length }, 201);
      }
      return json({ error: "Requête invalide" }, 400);
    }
    /* ---------- v4.51 · Ascenseurs et monte-charges (OTIS) : répertoire, pannes, personnes bloquées ---------- */
    if (r0 === "ascenseurs") {
      if (me.role === "client") return json({ error: "Non disponible" }, 403);
      if (TENANT() && m === "GET") return json({ liste: [], etat: {}, hist: [], otis: "", interventions: { texte: "" }, restreint: false });
      const etat = await load("ascenseurs_etat", {}), A = ASCENSEURS.liste.find((x) => x.id === r1), t = (v, n) => String(v ?? "").trim().slice(0, n);
      if (m === "GET") { const bas = !estProprio(me) && ["ads", "ssiap1"].includes(me.role); // v4.57 · ADS / SSIAP 1 : pas les numéros des prestataires (OTIS, SPIE)
        const A = bas ? { ...ASCENSEURS, otis: "", interventions: { texte: ASCENSEURS.interventions.texte } } : ASCENSEURS; return json({ ...A, etat, hist: (await load("ascenseurs_hist", [])).slice(0, 60), restreint: bas }); }
      if (!A) return json({ error: "Appareil introuvable" }, 404);
      const nomA = `${A.type} ${A.numero ? A.numero + " · " : ""}${A.lieu} (${A.site})`, hist = await load("ascenseurs_hist", []);
      if (m === "POST" && (r2 === "panne" || r2 === "bloque")) {
        const note = t(body.note, 600), otis = body.otis === true, bloque = r2 === "bloque";
        const mc = await mcSysteme(me, "Ascenseur", `${bloque ? "PERSONNE(S) BLOQUÉE(S)" : "Panne / arrêt"} — ${nomA}${A.ref ? " · réf. " + A.ref : ""}${note ? " — " + note : ""}${otis ? " — OTIS prévenu" : ""}`, bloque ? "urgente" : "moyenne", { site: A.site === "Arena" ? "Arena Sud de France" : "Parc des Expositions", lieu: A.lieu });
        etat[A.id] = { statut: bloque ? "bloque" : "panne", t: new Date().toISOString(), par: me.nom, note, otis, mc: mc.numero };
        hist.unshift({ id: A.id, t: etat[A.id].t, par: me.nom, quoi: bloque ? "Personne(s) bloquée(s)" : "Panne / arrêt", note, mc: mc.numero }); await save("ascenseurs_hist", hist.slice(0, 300)); await save("ascenseurs_etat", etat);
        await journal("ascenseurs", me.nom, `${bloque ? "personne(s) bloquée(s)" : "panne"} : ${nomA}`, bloque ? "urgente" : "attention", "#/ascenseurs");
        if (bloque) await mailPC(`🚨 Personne(s) bloquée(s) — ${nomA}`, [...(await lignesAgent(me)), ["Appareil", nomA], ["Référence OTIS", A.ref], ["Téléphone cabine", A.tel], ["OTIS prévenu", otis ? "Oui" : "Non"], ["Précisions", note], ["Main courante", mc.numero]]);
        return json({ etat, mc: mc.numero });
      }
      if (m === "POST" && r2 === "otis") { if (etat[A.id]) { etat[A.id].otis = true; etat[A.id].otisT = new Date().toISOString(); await save("ascenseurs_etat", etat); }
        hist.unshift({ id: A.id, t: new Date().toISOString(), par: me.nom, quoi: "OTIS prévenu", note: t(body.note, 300) }); await save("ascenseurs_hist", hist.slice(0, 300)); return json({ etat }); }
      if (m === "POST" && r2 === "remis") {
        const note = t(body.note, 600), avant = etat[A.id]; delete etat[A.id]; await save("ascenseurs_etat", etat);
        const mc = await mcSysteme(me, "Ascenseur", `Remis en service — ${nomA}${note ? " — " + note : ""}${avant && avant.mc ? " (suite " + avant.mc + ")" : ""}`, "info", { site: A.site === "Arena" ? "Arena Sud de France" : "Parc des Expositions", lieu: A.lieu });
        hist.unshift({ id: A.id, t: new Date().toISOString(), par: me.nom, quoi: "Remis en service", note, mc: mc.numero }); await save("ascenseurs_hist", hist.slice(0, 300));
        await journal("ascenseurs", me.nom, `remis en service : ${nomA}`, "info", "#/ascenseurs"); return json({ etat });
      }
      return json({ error: "Requête invalide" }, 400);
    }
    /* ---------- v4.41 · Impression : PC, SSIAP 2, administrateurs, responsables et Rochdi, avec le code (empreinte seulement) ---------- */
    if (r0 === "impression" && r1 === "deverrouiller" && m === "POST") {
      if (me.role === "client") return json({ error: "Impression non disponible pour le client" }, 403); // v4.47 · seule restriction : le code
      const hP = await load("code_planif", null), hI = await load("code_impression", null);
      const locks = await load("locks", {}), k = "impr:" + me.id, lk = locks[k], dans = lk && Date.now() - lk.t < 15 * 60e3;
      if (dans && lk.n >= 5) return json({ error: "Trop d'essais, réessaie dans 15 min" }, 429);
      const cIn = String(body.code || "").trim();
      if (![hI, hP, CODE_PLANIF_DEFAUT].filter(Boolean).some((h) => checkPin(cIn, h))) { locks[k] = { n: (dans ? lk.n : 0) + 1, t: dans ? lk.t : Date.now() }; await save("locks", locks); return json({ error: "Code incorrect" }, 403); }
      delete locks[k]; await save("locks", locks); await journal("impression", me.nom, "impression déverrouillée", "info");
      return json({ ok: true, exp: Date.now() + 12 * 3600e3 });
    }
    /* ---------- v4.30 · Contacts SPL Occitanie Events (liste chiffrée, jamais dans le code) ---------- */
    if (r0 === "annuaire-spl") {
      if (!peutAnnuaireSPL(me)) return json({ error: "Contacts SPL réservés au PC sécurité, aux SSIAP 2, à Rochdi, Jérémy Mercher et Laurent Hernandez" }, 403);
      const cle = crypto.createHash("sha256").update((process.env.APP_SECRET || "change-moi-dans-netlify") + ":annuaire-spl").digest();
      const chiffrer = (o) => { const iv = crypto.randomBytes(12), c = crypto.createCipheriv("aes-256-gcm", cle, iv), d = Buffer.concat([c.update(JSON.stringify(o), "utf8"), c.final()]); return [iv, c.getAuthTag(), d].map((b) => b.toString("base64")).join("."); };
      const dechiffrer = (s) => { try { const [iv, tag, d] = String(s).split(".").map((b) => Buffer.from(b, "base64")), c = crypto.createDecipheriv("aes-256-gcm", cle, iv); c.setAuthTag(tag); return JSON.parse(Buffer.concat([c.update(d), c.final()]).toString("utf8")); } catch { return []; } };
      const st = await load("contacts_spl", null), t = (v, n) => String(v ?? "").trim().slice(0, n);
      if (m === "GET") {
        const vus = await load("contacts_spl_vus", {}), k = String(me.id); // historique : une ligne par personne et par heure maxi
        if (!vus[k] || Date.now() - vus[k] > 3600e3) { vus[k] = Date.now(); await save("contacts_spl_vus", vus); await journal("contacts", me.nom, (TENANT() ? "contacts du site consultés" : "contacts SPL consultés"), "info"); }
        return json({ items: st ? dechiffrer(st.d) : [], maj: st?.maj || null, par: st?.par || "", peutModifier: editAnnuaireSPL(me) });
      }
      if (m === "PUT") {
        if (!editAnnuaireSPL(me)) return json({ error: "Seuls Rochdi et Laurent Hernandez mettent à jour les contacts SPL" }, 403);
        const L = (Array.isArray(body.items) ? body.items : []).slice(0, 400).map((x) => ({ nom: t(x.nom, 60), prenom: t(x.prenom, 60), fonction: t(x.fonction, 120), fixe: t(x.fixe, 30).replace(/[^\d +]/g, ""), mobile: t(x.mobile, 30).replace(/[^\d +]/g, ""), groupe: x.groupe === "postes" ? "postes" : "" })).filter((x) => x.nom && (x.fixe || x.mobile));
        if (!L.length) return json({ error: "Aucune ligne « NOM ; Prénom ; Fonction ; Fixe ; Mobile » reconnue" }, 400);
        const maj = new Date().toISOString(); await save("contacts_spl", { d: chiffrer(L), maj, par: me.nom });
        await journal("contacts", me.nom, `contacts SPL mis à jour (${L.length} contacts)`, "attention");
        return json({ ok: true, n: L.length, maj });
      }
      return json({ error: "Méthode non gérée" }, 405);
    }
    if (r0 === "cadenas") {
      if (!(isStaff(me) || estProprio(me))) return deny();
      const ecrit = me.role === "admin" || estProprio(me), t = (v, n = 120) => String(v ?? "").trim().slice(0, n);
      const cle = crypto.createHash("sha256").update((process.env.APP_SECRET || "change-moi-dans-netlify") + ":cadenas").digest();
      const chiffrer = (txt) => { const iv = crypto.randomBytes(12), c = crypto.createCipheriv("aes-256-gcm", cle, iv), d = Buffer.concat([c.update(String(txt), "utf8"), c.final()]); return [iv, c.getAuthTag(), d].map((b) => b.toString("base64")).join("."); };
      const dechiffrer = (s) => { try { const [iv, tag, d] = String(s).split(".").map((b) => Buffer.from(b, "base64")), c = crypto.createDecipheriv("aes-256-gcm", cle, iv); c.setAuthTag(tag); return Buffer.concat([c.update(d), c.final()]).toString("utf8"); } catch { return ""; } };
      let list = await load("cadenas", []);
      const pub = (x) => ({ id: x.id, nom: x.nom, lieu: x.lieu, site: x.site, note: x.note, maj: x.maj, par: x.par });
      if (m === "GET" && !r1) return json({ items: list.map(pub), peutModifier: ecrit });
      // v4.29 · code PIN obligatoire pour afficher un code (cadenas, bornes, téléphones du PC) — même code que la planification par défaut
      const codesSig = (uid, exp) => crypto.createHmac("sha256", (process.env.APP_SECRET || "change-moi-dans-netlify") + ":codes").update(uid + "." + exp).digest("base64url");
      if (m === "POST" && r1 === "deverrouiller") {
        const locks = await load("locks", {}), k = "codes:" + me.id, lk = locks[k];
        if (lk && lk.n >= 5 && Date.now() - lk.t < 15 * 60e3) return json({ error: "Trop d'essais, réessaie dans 15 min" }, 429);
        if (!checkPin(String(body.code || ""), (await load("code_cadenas", null)) || CODE_PLANIF_DEFAUT)) { locks[k] = { n: (lk && Date.now() - lk.t < 15 * 60e3 ? lk.n : 0) + 1, t: lk && Date.now() - lk.t < 15 * 60e3 ? lk.t : Date.now() }; await save("locks", locks);
          await journal("cadenas", me.nom, "code PIN des codes d'accès erroné", "attention", "#/cadenas"); return json({ error: "Code PIN incorrect" }, 403); }
        delete locks[k]; await save("locks", locks); const exp = Date.now() + 15 * 60e3;
        let importe = 0; // v4.49 · au premier PIN correct : les codes du PDF sont déchiffrés avec le PIN puis rangés (chiffrés) dans la liste
        if (!(await load("codes_initiaux_v1", false))) { try { const B = CODES_INITIAUX, key = crypto.scryptSync(String(body.code || ""), Buffer.from(B.salt, "base64"), 32, { N: 2 ** 17, r: 8, p: 1, maxmem: 512 * 1024 * 1024 });
            const dc = crypto.createDecipheriv("aes-256-gcm", key, Buffer.from(B.iv, "base64")); dc.setAuthTag(Buffer.from(B.tag, "base64"));
            const L = JSON.parse(Buffer.concat([dc.update(Buffer.from(B.data, "base64")), dc.final()]).toString("utf8")), now = new Date().toISOString();
            list = L.map((x) => ({ id: uid(), nom: x.nom, lieu: x.lieu, site: x.site, note: "", code: chiffrer(x.code), maj: now, par: "Kaelum e-PCS (liste du PDF)" }));
            await save("cadenas", list); await save("codes_initiaux_v1", true); importe = L.length;
            await journal("cadenas", me.nom, `${importe} codes (cadenas, bornes, téléphones PC) installés depuis la liste officielle`, "attention", "#/cadenas"); } catch (er) { console.error("codes initiaux", er.message); } }
        return json({ token: exp + "." + codesSig(me.id, exp), exp, importe });
      }
      const codesOuverts = () => { const [exp, sig] = String(req.headers.get("x-codes") || "").split("."); return exp && Number(exp) > Date.now() && sig === codesSig(me.id, exp); };
      if (m === "POST" && r1 && r2 === "voir" && !codesOuverts()) return json({ error: "Entre le code PIN pour afficher les codes", verrouCodes: true }, 423);
      if (m === "POST" && r1 && r2 === "voir") {
        const x = list.find((y) => y.id === r1); if (!x) return json({ error: "Cadenas introuvable" }, 404);
        await journal("cadenas", me.nom, `code du cadenas consulté : ${x.nom}${x.lieu ? " · " + x.lieu : ""}`, "attention", "#/cadenas");
        return json({ code: dechiffrer(x.code) });
      }
      if (!ecrit) return json({ error: "Seuls les administrateurs enregistrent les codes des cadenas" }, 403);
      const lire = () => { const nom = t(body.nom, 80), code = t(body.code, 40); return { nom, code, lieu: t(body.lieu, 120), site: /arena/i.test(body.site || "") ? "Arena" : /parc/i.test(body.site || "") ? "Parc" : t(body.site, 60), note: t(body.note, 300) }; };
      if (m === "POST" && r1 === "import") { // v4.27 · mise à jour en masse (liste collée) : met à jour les codes existants, ajoute les nouveaux
        const L = (Array.isArray(body.lignes) ? body.lignes : []).slice(0, 300).map((l) => ({ nom: t(l.nom, 80), code: t(l.code, 60), lieu: t(l.lieu, 120), site: /borne/i.test(l.site || "") ? "Bornes" : /t[ée]l[ée]phone/i.test(l.site || "") ? "Téléphones PC" : /arena/i.test(l.site || "") ? "Arena" : "Parc" })).filter((l) => l.nom && l.code);
        if (!L.length) return json({ error: "Aucune ligne « nom ; code » reconnue" }, 400);
        const cle0 = (n) => String(n).normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().replace(/[^a-z0-9]+/g, " ").trim();
        let maj = 0, ajout = 0; const vus = new Set();
        for (const l of L) { const x = list.find((y) => cle0(y.nom) === cle0(l.nom)); vus.add(cle0(l.nom));
          if (x) { x.code = chiffrer(l.code); if (l.lieu) x.lieu = l.lieu; x.site = l.site; x.maj = new Date().toISOString(); x.par = me.nom; maj++; }
          else { list.push({ id: uid(), nom: l.nom, lieu: l.lieu, site: l.site, note: "", code: chiffrer(l.code), maj: new Date().toISOString(), par: me.nom }); ajout++; } }
        let suppr = 0; if (body.remplacer) { const avant = list.length; list = list.filter((y) => vus.has(cle0(y.nom))); suppr = avant - list.length; }
        await save("cadenas", list.slice(0, 500)); await journal("cadenas", me.nom, `codes des cadenas mis à jour en masse : ${maj} modifié(s), ${ajout} ajouté(s)${suppr ? `, ${suppr} retiré(s)` : ""}`, "attention", "#/cadenas");
        return json({ maj, ajout, suppr, items: list.map(pub) });
      }
      if (m === "POST" && !r1) {
        const v = lire(); if (!v.nom || !v.code) return json({ error: "Nom du cadenas et code obligatoires" }, 400);
        const x = { id: uid(), ...v, code: chiffrer(v.code), maj: new Date().toISOString(), par: me.nom }; list.push(x); await save("cadenas", list.slice(0, 500));
        await journal("cadenas", me.nom, `cadenas enregistré : ${x.nom}${x.lieu ? " · " + x.lieu : ""}`, "info", "#/cadenas"); return json(pub(x), 201);
      }
      const x = list.find((y) => y.id === r1); if (!x) return json({ error: "Cadenas introuvable" }, 404);
      if (m === "PUT") {
        const v = lire(); if (!v.nom) return json({ error: "Nom du cadenas obligatoire" }, 400);
        Object.assign(x, { nom: v.nom, lieu: v.lieu, site: v.site, note: v.note, maj: new Date().toISOString(), par: me.nom }); if (v.code) x.code = chiffrer(v.code);
        await save("cadenas", list); await journal("cadenas", me.nom, `cadenas modifié : ${x.nom}${v.code ? " (nouveau code)" : ""}`, "info", "#/cadenas"); return json(pub(x));
      }
      if (m === "DELETE") { await save("cadenas", list.filter((y) => y.id !== x.id)); await journal("cadenas", me.nom, `cadenas supprimé : ${x.nom}`, "attention", "#/cadenas"); return json({ ok: true }); }
      return json({ error: "Requête invalide" }, 400);
    }

    /* ---------- v3.81 · Statistiques en direct : client uniquement ---------- */
    if (r0 === "stats" && m === "GET") { if (me.role !== "client") return json({ error: "Statistiques réservées au client" }, 403); return json(await statsClient()); }

    /* ---------- v3.75 · Brief de relève automatique ---------- */
    if (r0 === "releve") {
      const voit = isStaff(me) || estProprio(me) || (await estCoord(me));
      if (!voit) return deny();
      const hist = await load("releves", []), der = hist[0] || null, now = Date.now();
      const depuis = der && now - Date.parse(der.t) < 24 * 3600e3 ? der.t : new Date(now - 12 * 3600e3).toISOString();
      if (m === "GET") {
        const recents = (await mcRecents(2)).filter((i) => now - Date.parse(i.t) < 4 * 864e5);
        const ouverts = recents.filter((i) => i.statut !== "clos" && !/^(Prise|Fin) de service$|^Relève$/.test(i.categorie)).slice(0, 25)
          .map((i) => ({ id: i.id, numero: i.numero, categorie: i.categorie, lieu: i.lieu, site: /arena/i.test(i.site) ? "Arena" : /parc/i.test(i.site) ? "Parc" : "", gravite: i.gravite, t: i.t, texte: String(i.description || "").slice(0, 140) }));
        const periode = recents.filter((i) => i.t >= depuis && !/^(Prise|Fin) de service$/.test(i.categorie));
        const etat = await load("cles_etat", {}), hm = new Intl.DateTimeFormat("fr-FR", { timeZone: "Europe/Paris", hour: "2-digit", minute: "2-digit" }).format(new Date());
        const cles = Object.entries(etat).map(([n, e]) => ({ n, nom: e.nom, societe: e.societe || "", t: e.t, retour: e.retour || "", retard: !!(e.retour && e.retour < hm && now - Date.parse(e.t) < 20 * 3600e3) || now - Date.parse(e.t) > 20 * 3600e3 }));
        const objets = (await load("objets", [])).filter((o) => !o.restitution && now - Date.parse(o.t) < 90 * 864e5);
        const alertes = (await load("alertes", [])).filter((a) => !a.fin && Date.parse(a.exp) > now).map((a) => ({ nature: a.nature, lieu: a.lieu, t: a.t }));
        const crise = (await load("crise", { active: null })).active, auj = jourParis();
        const consignes = (await load("consignes", [])).filter((c) => !c.archive && (!c.fin || c.fin >= auj) && (!c.debut || c.debut <= auj)).map((c) => ({ titre: c.titre || String(c.texte || "").slice(0, 80), importante: !!c.importante, cible: c.cible || "tous" }));
        const rondes = (await load("rondes_nfc", [])).filter((r) => r.debut >= depuis && (r.oublies || r.anomalies)).map((r) => ({ nom: r.nom, oublies: r.oublies || 0, anomalies: r.anomalies || 0 }));
        const reg = registreCalc(await load("registre", null) || (TENANT() ? [] : REGISTRE_DEFAUT())).filter((x) => x.etat === "retard" || x.etat === "bientot").map((x) => ({ nom: x.nom, site: x.site, etat: x.etat, prochaine: x.prochaine }));
        const enPoste = await agentsEnVacation();
        return json({ depuis, derniere: der, genere: new Date().toISOString(), ouverts, urgences: periode.filter((i) => i.gravite === "urgente").length, saisies: periode.length,
          signalements: periode.filter((i) => /^Signalement (public|anomalie)/.test(i.categorie || "")).length, secours: periode.filter((i) => i.categorie === "Appel secours").length,
          cles, objets: { nb: objets.length, liste: objets.slice(0, 6).map((o) => ({ numero: o.numero, categorie: o.categorie, stockage: o.stockage || "" })) },
          alertes, crise: crise ? { type: crise.type, zone: crise.zone, t: crise.t } : null, consignes, rondes, registre: reg, enPoste: enPoste.length, peutPrendre: isStaff(me) && me.role !== "responsable" || estProprio(me) });
      }
      if (m === "POST" && r1 === "prise") {
        if (!(isStaff(me) || estProprio(me))) return deny();
        const note = String(body.note || "").trim().slice(0, 600), res = body.resume && typeof body.resume === "object" ? body.resume : {};
        const n = (v) => Math.max(0, Math.min(999, parseInt(v, 10) || 0));
        const txt = `Relève prise par ${me.nom}. Brief : ${n(res.ouverts)} événement(s) ouvert(s), ${n(res.cles)} clé(s) dehors, ${n(res.objets)} objet(s) en attente, ${n(res.alertes)} alerte(s) active(s), ${n(res.consignes)} consigne(s) du jour.${note ? " Note : " + note : ""}`;
        const inc = await mcSysteme(me, "Relève", txt, "info", { statut: "clos" });
        hist.unshift({ t: new Date().toISOString(), par: me.nom, parId: me.id, note, numero: inc.numero }); await save("releves", hist.slice(0, 300));
        await journal("relève", me.nom, `🔄 relève prise${note ? " · " + note.slice(0, 80) : ""}`, "info", "#/releve");
        return json({ ok: true, numero: inc.numero });
      }
      return json({ error: "Requête invalide" }, 400);
    }

    /* ---------- v3.75 · Registre de sécurité numérique (vérifications périodiques) ---------- */
    if (r0 === "registre") {
      if (!(isStaff(me) || estProprio(me) || me.role === "client" || (await estCoord(me)))) return deny();
      let reg = (await load("registre", null)) || (TENANT() ? [] : REGISTRE_DEFAUT());
      if (me.role === "client") return m === "GET" ? json({ items: registreCalc(reg), peutModifier: false, peutParametrer: false }) : deny();
      const ecrit = (me.role === "admin" || me.role === "pc" || estProprio(me));
      const t = (v, n = 200) => String(v ?? "").trim().slice(0, n);
      if (m === "GET") return json({ items: registreCalc(reg), peutModifier: ecrit, peutParametrer: me.role === "admin" || estProprio(me) });
      if (!ecrit) return deny();
      if (m === "POST" && r1 && r2 === "verif") {
        const it = reg.find((x) => x.id === r1); if (!it) return json({ error: "Installation introuvable" }, 404);
        const date = /^\d{4}-\d{2}-\d{2}$/.test(body.date || "") ? body.date : jourParis();
        if (date > jourParis()) return json({ error: "La date ne peut pas être dans le futur" }, 400);
        const v = { date, organisme: t(body.organisme, 80), obs: t(body.obs, 400), conforme: body.conforme !== false, par: me.nom, t: new Date().toISOString() };
        it.historique = [v, ...(it.historique || [])].slice(0, 40);
        const plusRecente = it.historique.reduce((a, b) => (b.date > a.date ? b : a));
        Object.assign(it, { derniere: plusRecente.date, organisme: plusRecente.organisme, obs: plusRecente.obs, conforme: plusRecente.conforme });
        await save("registre", reg);
        await journal("registre", me.nom, `📘 ${it.nom} (${/arena/i.test(it.site) ? "Arena" : "Parc"}) vérifié le ${date}${v.conforme ? "" : " — NON CONFORME"}${v.organisme ? " · " + v.organisme : ""}`, v.conforme ? "info" : "attention", "#/registre");
        if (!v.conforme) await mcSysteme(me, "Registre de sécurité", `${it.nom} — ${it.site} : vérification du ${date} NON CONFORME.${v.obs ? " " + v.obs : ""}`, "moyenne", { site: it.site });
        return json({ ok: true, items: registreCalc(reg) });
      }
      if (m === "PUT" && !r1) {
        if (!(me.role === "admin" || estProprio(me))) return deny();
        const vus = new Set(), anciens = new Map(reg.map((x) => [x.id, x]));
        const out = (Array.isArray(body.items) ? body.items : []).slice(0, 120).map((x) => {
          const nom = t(x.nom, 80), site = /arena/i.test(x.site) ? "Arena Sud de France" : "Parc des Expositions", mois = Math.max(1, Math.min(120, parseInt(x.mois, 10) || 12));
          const id = x.id && anciens.has(x.id) ? x.id : (site[0] + nom).toLowerCase().normalize("NFD").replace(/[^a-z0-9]+/g, "-").slice(0, 40) + "-" + uid().slice(-4);
          return nom ? { ...(anciens.get(id) || { derniere: "", organisme: "", obs: "", conforme: null, historique: [] }), id, site, nom, mois } : null; })
          .filter((x) => x && !vus.has(x.id) && vus.add(x.id));
        await save("registre", out); await journal("registre", me.nom, `registre de sécurité paramétré (${out.length} installations)`, "info", "#/registre");
        return json({ ok: true, items: registreCalc(out) });
      }
      return json({ error: "Requête invalide" }, 400);
    }

    /* ---------- v3.75 · Assistant d'appel des secours : consigne l'appel et prévient le PC ---------- */
    if (r0 === "secours" && m === "POST") {
      const t = (v, n = 120) => String(v ?? "").trim().slice(0, n);
      const numero = ["18", "15", "17", "112", "114"].includes(String(body.numero)) ? String(body.numero) : "112";
      const NAT = ["Incendie / fumée", "Malaise / victime", "Accident / chute", "Agression / rixe", "Fuite de gaz / odeur", "Personne bloquée (ascenseur)", "Autre"];
      const nature = NAT.includes(body.nature) ? body.nature : "Autre", site = /arena/i.test(body.site) ? "Arena Sud de France" : "Parc des Expositions", lieu = t(body.lieu), rdv = t(body.rdv);
      const victimes = Math.max(0, Math.min(500, parseInt(body.victimes, 10) || 0)), etat = t(body.etat, 200);
      const desc = `Appel au ${numero} — ${nature} · ${lieu || "lieu à préciser"}${victimes ? ` · ${victimes} victime(s)` : ""}${etat ? " · " + etat : ""}${rdv ? ` · accueil des secours : ${rdv}` : ""}`;
      const inc = await mcSysteme(me, "Appel secours", desc, "urgente", { site, lieu });
      await envoyerPush({ titre: `APPEL ${numero} EN COURS — ${nature}`, texte: `${lieu || site}${rdv ? " · accueil secours : " + rdv : ""} · par ${me.nom}`, url: "/#/mc", alerte: true }, (u) => isStaff(u) || estProprio(u) || u.role === "admin");
      await journal("secours", me.nom, `🚑 ${desc}`, "urgent", "#/mc");
      try { await mailPC(`🚑 APPEL ${numero} — ${nature} — ${lieu || site}`, [...(await lignesAgent(me)), ["Numéro appelé", numero], ["Nature", nature], ["Site", ERP(site)], ["Lieu", lieu], ["Victimes", String(victimes)], ["État", etat], ["Accueil des secours", rdv], ["Main courante", inc.numero], ["Heure", fmtParis(inc.t)]]); } catch {}
      return json({ ok: true, numero: inc.numero, t: inc.t }, 201);
    }

    /* ---------- v3.75 · QR codes de signalement : génération et réglage ---------- */
    if (r0 === "signal-qr") {
      if (!(isStaff(me) || estProprio(me))) return deny();
      const sigZ = (s, l) => crypto.createHmac("sha256", (process.env.APP_SECRET || "change-moi-dans-netlify") + ":signal").update(String(s) + "|" + String(l)).digest("base64url").slice(0, 16);
      if (m === "GET") {
        const out = SIGNAL_LIEUX.map(([site, lieu]) => ({ site, groupe: "Bâtiments privés (personnel)", lieu, k: sigZ(site, lieu) }));
        return json({ actif: (await load("signal_reglages", { actif: true })).actif !== false, zones: out, libre: null, peutRegler: me.role === "admin" || estProprio(me) });
      }
      if (m === "PUT") { if (!(me.role === "admin" || estProprio(me))) return deny();
        await save("signal_reglages", { actif: body.actif !== false }); await journal("signalement", me.nom, `signalement public par QR ${body.actif !== false ? "ouvert" : "fermé"}`, "attention", "#/signalqr");
        return json({ ok: true, actif: body.actif !== false }); }
      return json({ error: "Requête invalide" }, 400);
    }

    /* ---------- v5.09 · Santé de l'appli (propriétaire) : versions, sauvegardes, tâches automatiques, erreurs, connexions refusées ---------- */
    if (r0 === "sante") {
      if (!estProprio(me) || me.apercu) return refusProprio();
      if (m === "GET" && !r1) { const SV = await storeNomme(NOM_SAUV()), users = await load("users", []), locks = await load("locks", {}), J = await load("journal", []);
        return json({ version: VERSION_SERVEUR, deploiements: await load("deploiements", []), deployId: process.env.DEPLOY_ID || "", commit: process.env.COMMIT_REF || "", site: process.env.SITE_NAME || "",
          sauvegardes: (await SV.get("index")) || [], taches: await load("taches_etat", {}), erreurs: (await load("erreurs_app", [])).slice(0, 40),
          refus: Object.entries(locks).filter(([, x]) => x && x.n).map(([id, x]) => ({ id: id.replace(/^(ro|planif):/, ""), type: id.startsWith("ro:") ? "réinitialisation" : id.startsWith("planif:") ? "code planification" : "connexion", n: x.n, t: new Date(x.t).toISOString() })).sort((a, b) => b.t.localeCompare(a.t)).slice(0, 30),
          alertes: J.filter((x) => x.niveau === "attention" || x.niveau === "urgent").slice(0, 10).map((x) => ({ t: x.t, mod: x.type || "", qui: x.qui || "", texte: x.detail || "" })),
          comptes: { total: users.length, actifs: users.filter((u) => u.actif !== false && !u.bloque).length, aReinitialiser: users.filter((u) => u.resetOuvert && Date.parse(u.resetOuvert) > Date.now()).map((u) => u.nom) },
          mail: !!process.env.BREVO_API_KEY, ia: !!process.env.ANTHROPIC_API_KEY, secret: !!process.env.APP_SECRET }); }
      if (m === "POST" && r1 === "sauvegarder") return json(await sauvegarder(me.nom || "Rochdi Mecheti", body.mail !== false));
      if (m === "POST" && r1 === "restaurer") { if (body.confirm !== "RESTAURER") return json({ error: "Tape RESTAURER pour confirmer" }, 400);
        try { return json(await restaurer(String(body.k || ""), me.nom || "Rochdi Mecheti")); } catch (e) { return json({ error: e.message }, 404); } }
      if (m === "DELETE" && r1 === "erreurs") { await save("erreurs_app", []); return json({ ok: true }); }
      if (m === "DELETE" && r1 === "refus") { const L = await load("locks", {}), id = String(body.id || ""); for (const k of Object.keys(L)) if (k === id || k.endsWith(":" + id)) delete L[k]; await save("locks", L); return json({ ok: true }); }
      return json({ error: "Requête invalide" }, 400);
    }
    /* ---------- Sauvegarde complète des données (propriétaire uniquement) ---------- */
    if (r0 === "sauvegarde" && m === "GET") {
      if (!estProprio(me)) return refusProprio();
      const EXCLUS = new Set(["vapid", "resets"]); // clé privée des notifications et codes de réinitialisation : jamais exportés
      if (!r1) { const cles = (await listeCles()).filter((k) => !EXCLUS.has(k)).sort();
        await journal("admin", me.nom, `sauvegarde complète des données téléchargée (${cles.length} éléments)`); return json({ cles, version: VERSION_SERVEUR, t: new Date().toISOString() }); }
      if (r1 === "valeur") { const k = url.searchParams.get("k") || ""; if (!k || EXCLUS.has(k)) return json({ error: "Introuvable" }, 404); return json({ k, v: await load(k, null) }); }
    }

    /* ---------- Historique : suppression complète et exemples de présentation (propriétaire et administrateurs seulement) ---------- */
    if (r0 === "historique") {
      if (!(estProprio(me) || me.role === "admin" || (await estAdminPC(me.id)))) return json({ error: "Réservé au propriétaire et aux administrateurs" }, 403);
      const STORES_L = ["rap", "di", "rapports", "rondes_nfc", "checklists", "cles_mvt", "materiel_mvt", "batiments_mvt", "alertes", "incidents", "objets", "consignes"];
      if (m === "GET") { const idx = await mcIndex(); let mc = 0, demo = 0; for (const mm of idx) { const l = await load("mc/" + mm, []); mc += l.length; demo += l.filter((x) => x.demo).length; }
        const n = {}; for (const k of STORES_L) { const l = (await load(k, [])) || []; n[k] = l.length; demo += l.filter((x) => x.demo).length; }
        return json({ mc, ...n, demo }); }
      if (m === "POST" && r1 === "purger") {
        if (body.confirmation !== "SUPPRIMER") return json({ error: "Tape SUPPRIMER pour confirmer" }, 400);
        for (const mm of await mcIndex()) await save("mc/" + mm, []);
        await save("mc_index", []); await save("mc_migre", true); await save("mc_compteur", {}); await save("rap_compteur", {}); await save("objets_compteur", {});
        for (const k of STORES_L) await save(k, []);
        await save("cles_etat", {}); await save("materiel_etat", {}); await save("crise", { active: null, historique: [] }); await save("journal", []); await save("push_dernier", null);
        const fils = await load("msg_fils", {}); for (const id of Object.keys(fils)) await save("msg/" + id, []); await save("msg_fils", {});
        await journal("admin", me.nom, "historique entièrement supprimé (fil de l'eau, main courante, rapports, rondes, clés, alertes)", "attention");
        return json({ ok: true });
      }
      if (m === "POST" && r1 === "notifications") { await save("journal", []); await save("push_dernier", null); await save("push_log", []); return json({ ok: true }); }
      if (m === "POST" && r1 === "exemples-retirer") {
        let n = 0;
        for (const mm of await mcIndex()) { const l = await load("mc/" + mm, []), k = l.filter((x) => !x.demo); if (k.length !== l.length) { n += l.length - k.length; await save("mc/" + mm, k); } }
        for (const k of STORES_L) { const l = (await load(k, [])) || [], g = l.filter((x) => !x.demo); if (g.length !== l.length) { n += l.length - g.length; await save(k, g); } }
        await journal("admin", me.nom, `${n} exemple(s) de présentation retiré(s)`); return json({ ok: true, n });
      }
      if (m === "POST" && r1 === "exemples") { try { return json(await genererExemples(me)); } catch (e) { return json({ error: e.message }, 400); } }
      return json({ error: "Méthode non gérée" }, 405);
    }

    if (r0 === "admin") {
      if (!estProprio(me) && !(COORD_ADMIN.includes(r1) && (await estCoord(me)))) return refusProprio();
      if (r1 === "users") {
        const users = await load("users", []);
        if (m === "POST" && r2 && url.pathname.endsWith("/reset-ouvert")) { const u = users.find((x) => x.id === decodeURIComponent(r2)); if (!u) return json({ error: "Compte introuvable" }, 404);
          u.resetOuvert = new Date(Date.now() + 72 * 3600e3).toISOString(); await save("users", users);
          await journal("compte", me.nom, `mot de passe de ${u.nom} réinitialisé : nouveau mot de passe à choisir à la prochaine connexion (72 h)`, "info"); return json({ ok: true, jusqua: u.resetOuvert }); }
        if (m === "GET") { const F = await load("flammes", {}); return json(users.map(({ pin, ...u }) => { const f = F[u.id]; return { ...u, honneur: f ? { total: f.total || 0, badge: niveauNom(Math.floor((f.total || 0) / 1000)), medailles: (f.medailles || []).map(({ type, titre, motif, t, par }) => ({ type, titre, motif, t, par })) } : null }; })); }
        if (m === "PUT") {
          const id = String(body.email || body.id || "").trim().toLowerCase();
          if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(id)) return json({ error: "Adresse e-mail valide requise" }, 400);
          if (!ROLES.includes(body.role)) return json({ error: "Rôle invalide" }, 400);
          let u = users.find((x) => x.id === id), nouveau = false, mdpGen = null;
          if (!u) { u = { id, cree: new Date().toISOString() }; users.push(u); nouveau = true; if (!body.mdp) mdpGen = genMdp(); }
          u.nom = String(body.nom || id).slice(0, 60);
          u.role = body.role;
          u.tel = String(body.tel || "").slice(0, 20);
          u.fonction = ["ADS", "SSIAP 1", "SSIAP 2", "SSIAP 3", "CDP (chef de poste)", "Responsable"].includes(body.fonction) ? body.fonction : "";
          u.actif = body.actif !== false;
          u.horsPlanning = body.horsPlanning === true || body.horsPlanning === "on";
          if (body.mdp) {
            if (String(body.mdp).length < 6) return json({ error: "Mot de passe : 6 caractères minimum" }, 400);
            u.pin = hashPin(String(body.mdp));
          }
          if (mdpGen) u.pin = hashPin(mdpGen);
          await save("users", users);
          await journal("compte", me.nom, `compte ${id} ${nouveau ? "créé" : "modifié"} (${u.role})`, "info", "#/admin");
          if (mdpGen) {
            try { await mailMdp(u, mdpGen, true, url.origin); return json({ ok: true, envoye: true }); }
            catch (e) { return json({ ok: true, envoye: false, mdp: mdpGen, erreur: e.message }); } // mail impossible : on montre le mot de passe à l'admin
          }
          return json({ ok: true });
        }
        if (m === "POST" && r2 && parts[3] === "renvoyer") {
          const u = users.find((x) => x.id === decodeURIComponent(r2));
          if (!u) return json({ error: "Introuvable" }, 404);
          const mdp = genMdp(); u.pin = hashPin(mdp); await save("users", users);
          await journal("compte", me.nom, `nouveau mot de passe envoyé à ${u.id}`, "info", "#/admin");
          try { await mailMdp(u, mdp, false, url.origin); return json({ ok: true, envoye: true }); }
          catch (e) { return json({ ok: true, envoye: false, mdp, erreur: e.message }); }
        }
        if (m === "DELETE" && r2) {
          const rid = decodeURIComponent(r2);
          await save("users", users.filter((x) => x.id !== rid));
          const fiches = await load("fiches", {}); delete fiches[rid]; await save("fiches", fiches);
          await journal("admin", me.nom, `compte ${r2} supprimé`);
          return json({ ok: true });
        }
      }
      const simple = { contacts: DEFAULT_CONTACTS, destinataires: DEFAULT_RECIPIENTS, "rondes-points": DEFAULT_RONDES };
      if (r1 in simple) {
        const key = r1 === "rondes-points" ? "rondes_points" : r1;
        if (m === "GET") return json(await load(key, simple[r1]));
        if (m === "PUT" && Array.isArray(body.items)) {
          await save(key, body.items.slice(0, 100));
          await journal("admin", me.nom, `${r1} modifiés`);
          return json({ ok: true });
        }
      }
      if (r1 === "journal") return json(await load("journal", []));
      if (r1 === "code-resp" && m === "GET") return json({ defini: !!(await load("code_resp", null)) });
      if (r1 === "code-resp" && m === "PUT") {
        if (body.fermer) { await save("code_resp", null); await journal("admin", me.nom, "code PIN responsables supprimé"); return json({ ok: true }); }
        if (String(body.code || "").trim().length < 6) return json({ error: "Code responsable : 6 caractères minimum" }, 400);
        await save("code_resp", hashPin(String(body.code).trim()));
        await journal("admin", me.nom, "code PIN responsables modifié", "attention");
        return json({ ok: true });
      }
      if (r1 === "prestataires" && m === "PUT") {
        const z = body.prestataires;
        if (!z || typeof z !== "object" || Array.isArray(z)) return json({ error: "Format invalide" }, 400);
        const out = {};
        for (const [grp, noms] of Object.entries(z).slice(0, 20))
          out[String(grp).slice(0, 60)] = (Array.isArray(noms) ? noms : []).map((x) => String(x).trim().slice(0, 80)).filter(Boolean).slice(0, 100);
        await save("prestataires", out); await journal("admin", me.nom, "liste des prestataires modifiée");
        return json({ ok: true });
      }
      if (r1 === "zones" && m === "PUT") {
        const z = body.zones;
        if (!z || typeof z !== "object" || Array.isArray(z)) return json({ error: "Format invalide" }, 400);
        const out = {};
        for (const [site, secs] of Object.entries(z).slice(0, 10)) {
          out[String(site).slice(0, 60)] = {};
          for (const [sec, zs] of Object.entries(secs || {}).slice(0, 40))
            out[String(site).slice(0, 60)][String(sec).slice(0, 60)] = (Array.isArray(zs) ? zs : []).map((x) => String(x).trim().slice(0, 60)).filter(Boolean).slice(0, 80);
        }
        await save("zones", out); await journal("admin", me.nom, "sites et zones modifiés");
        return json({ ok: true });
      }
      if (r1 === "redacteurs" && m === "GET") return json({ emails: await load("redacteurs", REDAC_DEFAUT) });
      if (r1 === "redacteurs" && m === "PUT") {
        const emails = [...new Set((Array.isArray(body.emails) ? body.emails : []).map((e) => String(e).trim().toLowerCase()).filter((e) => /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(e)))].slice(0, 10);
        await save("redacteurs", emails); await journal("admin", me.nom, `rédacteurs documents : ${emails.length}`, "attention");
        const us = await load("users", []); let ch = false;
        us.forEach((u) => { if (emails.includes(u.id) && AGENTS.includes(u.role)) { u.role = "responsable"; ch = true; } }); if (ch) await save("users", us);
        return json({ ok: true, nb: emails.length });
      }
      if (r1 === "acces24" && m === "GET") return json({ emails: await load("acces24", ACCES24_DEFAUT) });
      if (r1 === "acces24" && m === "PUT") {
        const emails = [...new Set((Array.isArray(body.emails) ? body.emails : []).map((e) => String(e).trim().toLowerCase()).filter((e) => /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(e) && e !== PROPRIO()))].slice(0, 200);
        await save("acces24", emails);
        // les comptes déjà créés avec ces adresses passent en lecture 24h/24
        const us = await load("users", []); let n = 0;
        for (const u of us) if (emails.includes(u.id) && AGENTS.includes(u.role)) { u.role = "responsable"; n++; }
        if (n) await save("users", us);
        await journal("admin", me.nom, `accès 24h/24 : ${emails.length} adresse(s)`);
        return json({ ok: true, nb: emails.length });
      }
      if (r1 === "admins-pc" && m === "GET") return json({ emails: await load("admins_pc", ADMINS_DEFAUT) });
      if (r1 === "admins-pc" && m === "PUT") {
        if (!estProprio(me)) return refusProprio();
        const emails = [...new Set((Array.isArray(body.emails) ? body.emails : []).map((e) => String(e).trim().toLowerCase()).filter((e) => /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(e) && e !== PROPRIO()))].slice(0, 20);
        await save("admins_pc", emails); await journal("admin", me.nom, `administrateurs : ${emails.join(", ") || "aucun"}`, "attention"); return json({ ok: true, nb: emails.length });
      }
      if (r1 === "mail-pc" && m === "GET") return json({ email: await load("mail_pc", MAIL_PC_DEFAUT) });
      if (r1 === "mail-pc" && m === "PUT") {
        const e = String(body.email || "").trim().slice(0, 300);
        if (e && !e.split(/[,;\s]+/).filter(Boolean).every((x) => /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(x))) return json({ error: "Adresse e-mail invalide" }, 400);
        await save("mail_pc", e); await journal("admin", me.nom, "adresse mail du PC modifiée");
        return json({ ok: true });
      }
      if (r1 === "code-agents" && m === "GET") return json({ defini: !!(await load("code_agents", null)), mode: await load("inscription_mode", "libre") });
      if (r1 === "inscription-mode" && m === "PUT") {
        const md = ["libre", "code", "ferme"].includes(body.mode) ? body.mode : "libre";
        await save("inscription_mode", md); await journal("admin", me.nom, `inscriptions : ${md}`);
        return json({ ok: true });
      }
      if (r1 === "code-agents" && m === "PUT") {
        if (body.fermer) { await save("code_agents", null); await journal("admin", me.nom, "inscriptions des agents fermées"); return json({ ok: true }); }
        if (String(body.code || "").trim().length < 4) return json({ error: "Code : 4 caractères minimum" }, 400);
        await save("code_agents", hashPin(String(body.code).trim()));
        await journal("admin", me.nom, "code d'inscription des agents modifié");
        return json({ ok: true });
      }
      if (r1 === "licences") { if (!estProprio(me)) return refusProprio();
        if (m === "GET") { const users = await load("users", []); return json((await load("licences_planif", [])).map((l) => ({ ...l, compte: !!users.find((u) => u.id === l.id), nomCompte: users.find((u) => u.id === l.id)?.nom || "" }))); }
        if (m === "PUT") { const tt = (v, n = 80) => String(v ?? "").trim().slice(0, n), vus = new Set(), avant = await load("licences_planif", []);
          const L = (Array.isArray(body.licences) ? body.licences : []).slice(0, 100).map((l) => { const id = tt(l.id, 120).toLowerCase(), a = avant.find((x) => x.id === id);
            return { id, nom: tt(l.nom), niveau: ["valideur", "redacteur", "lecture"].includes(l.niveau) ? l.niveau : "redacteur", site: ["tous", "parc", "arena"].includes(l.site) ? l.site : "tous",
              fin: /^\d{4}-\d{2}-\d{2}$/.test(l.fin || "") ? l.fin : "", actif: l.actif !== false, cree: a?.cree || new Date().toISOString(), derniere: a?.derniere || "" }; })
            .filter((l) => /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(l.id) && !vus.has(l.id) && vus.add(l.id));
          await save("licences_planif", L); await journal("admin", me.nom, `licences planificateur : ${L.filter((l) => l.actif).length} active(s) sur ${L.length}`, "attention"); return json({ ok: true, nb: L.length }); }
      }
      if (r1 === "planificateurs" && m === "GET") { // Jérémy Mercher… : planning + accès à tout
        const liste = await load("planificateurs", []), noms = ["Jérémy Mercher"];
        const suggestions = (await load("users", [])).filter((u) => u.actif !== false && !liste.includes(String(u.id).toLowerCase()) && noms.some((n) => memeAgent({ nom: u.nom }, { nom: n }))).map((u) => ({ id: u.id, nom: u.nom, cree: u.cree || "", inscrit: !!u.inscrit }));
        return json({ emails: liste, suggestions }); }
      if (r1 === "planificateurs" && m === "PUT") { if (!estProprio(me)) return refusProprio();
        const e = [...new Set((Array.isArray(body.emails) ? body.emails : []).map((x) => String(x).trim().toLowerCase()).filter((x) => /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(x)))].slice(0, 10);
        await save("planificateurs", e); await journal("admin", me.nom, `planificateurs (accès à tout) : ${e.join(", ") || "aucun"}`, "attention"); return json({ ok: true, nb: e.length }); }
      if (r1 === "code-planif" && m === "PUT") {
        if (!estProprio(me)) return refusProprio();
        if (!/^\d{4,10}$/.test(String(body.code || ""))) return json({ error: "Code : 4 à 10 chiffres" }, 400);
        await save("code_planif", hashPin(String(body.code))); await journal("admin", me.nom, "code de la planification modifié"); return json({ ok: true });
      }
      if (r1 === "code-contacts" && m === "GET") return json({ defini: !!(await load("code_contacts", null)) });
      if (r1 === "code-contacts" && m === "PUT") {
        if (String(body.code || "").length < 4) return json({ error: "Code PIN : 4 caractères minimum" }, 400);
        await save("code_contacts", hashPin(String(body.code)));
        await journal("admin", me.nom, "code d'accès aux contacts modifié");
        return json({ ok: true });
      }
      if (r1 === "textes" && m === "PUT") {
        const t = {};
        for (const [k, v] of Object.entries(body.textes || {})) if (/^[a-z0-9.]{2,40}$/.test(k) && typeof v === "string" && v.trim()) t[k] = v.slice(0, 300);
        await save("textes", t);
        await journal("admin", me.nom, "intitulés modifiés");
        return json({ ok: true });
      }
      if (r1 === "test-mail" && m === "POST") {
        const dest = DIFFUSION_SITE();
        await sendMail(dest, "Kaelum e-PCS — test de la liste de diffusion",
          `<p>Test envoyé par ${me.nom}. Si tu reçois ce mail, les alertes météo et incidents urgents arriveront bien.</p>`);
        return json({ ok: true, envoyes: dest.length });
      }
    }
    return json({ error: "Route inconnue" }, 404);
  } catch (e) {
    return json({ error: e.message }, 500);
  }
};

/* ================= v5.85 · MULTI-SITES : registre des sites et aiguillage de chaque requête ================= */
// Registre (stocké dans le site d'origine) : code de site → fiche du site. Le site d'origine (Arena) et la démo existent toujours.
const SITES_BASE = {
  "176868": { id: "arena", nom: "Parc des Expositions · Arena Sud de France", adresse: "Pérols (34470)", actif: true },
  "000222": { id: "demo", nom: "Centre Hospitalier Les Oliviers (site fictif de démonstration)", adresse: "Avenue des Oliviers, 34970 Lattes", lat: 43.5667, lon: 3.9333, demo: true, actif: true },
  "000333": { id: "vide", nom: "Site vierge · à configurer par le client", adresse: "", actif: true, vierge: true },
};
async function registreSites() {
  const R = await listeSites();
  let change = false;
  for (const [c, f] of Object.entries(SITES_BASE)) if (!R[c]) { R[c] = { ...f, cree: new Date().toISOString() }; change = true; }
  if (change) await siteRun(SITE_ORIGINE, () => save("sites", R));
  return R;
}
let demoEnCours = false;
const idSite = (nom) => String(nom || "site").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 24) || "site";
export default async (req) => {
  try {
    const url = new URL(req.url), r0w = url.pathname.replace(/^\/api\/?/, "").split("/").filter(Boolean)[0];
    const p = verifyToken((req.headers.get("authorization") || "").replace(/^Bearer /, ""));
    const R = await registreSites();
    let site = SITE_ORIGINE;
    if (p && p.s) site = p.s; // le site vient du jeton signé
    else if (["login", "reset", "reset-ouvert"].includes(r0w) && req.method === "POST") {
      const b = await req.clone().json().catch(() => ({})), brut = String(b.site ?? "").trim();
      if (brut) { const f = R[brut.replace(/\D/g, "")]; if (!f) return json({ error: "Code du site incorrect" }, 403); site = f.id; }
    }
    const fiche = Object.entries(R).map(([code, f]) => ({ ...f, code })).find((f) => f.id === site) || null;
    if (site !== SITE_ORIGINE && (!fiche || fiche.actif === false)) return json({ error: "Ce site est suspendu ou introuvable : contacte Kaelum.", ferme: true }, 403);
    return await siteRun(site, async () => {
      if (site === "demo" && !demoEnCours && !(await load("demo_seed", null))) { // premier passage dans la démo : remplissage avec les données fictives
        demoEnCours = true;
        try { await seedDemo({ load, save, hashPin, mcSysteme, journal, aujourdhui: jourParis(), uid }); } finally { demoEnCours = false; }
      }
      if (site === "demo" && !clientDemoFait) { // v5.94 · accès client de démonstration (une seule fois ; ensuite le mot de passe peut être changé)
        const us = await load("users", []);
        if (!(await load("demo_client001", false))) { if (!us.some((x) => x.id === "client001")) { us.push({ id: "client001", nom: "Client001", role: "client", fonction: "", tel: "", actif: true, pin: hashPin("123456789"), cree: new Date().toISOString(), horsPlanning: false }); await save("users", us); } await save("demo_client001", true); }
        clientDemoFait = true;
      }
      return traiter(req);
    }, fiche);
  } catch (e) {
    return json({ error: e.message }, 500);
  }
};

// v5.85 · tâches automatiques : exécutées pour le site d'origine puis pour chaque site client actif qui a des comptes (hors démonstration)
export async function pourChaqueSite(fn) {
  const res = [await fn()];
  for (const f of Object.values(await listeSites())) {
    if (f.id === SITE_ORIGINE || f.actif === false || f.demo) continue;
    try { res.push(await siteRun(f.id, async () => ((await load("users", [])).length ? fn() : null), f)); } catch (e) { console.error("tâche site " + f.id, e); }
  }
  return res.every((x) => x == null || typeof x === "number") ? res.reduce((a, b) => a + (b || 0), 0) : res;
}
