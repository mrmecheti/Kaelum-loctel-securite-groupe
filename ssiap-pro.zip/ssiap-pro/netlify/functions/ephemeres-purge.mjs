// Kaelum e-PCS — effacement des photos preuve de plus de 24 h (toutes les heures)
// Application créée par Rochdi Mecheti
import { purgerEphemeres, pourChaqueSite } from "./api.mjs";
import { battement } from "../lib/core.mjs";

export const config = { schedule: "5 * * * *" };

export default async () => {
  const n = await pourChaqueSite(purgerEphemeres); await battement("ephemeres-purge", `${n} effacé(s)`);
  return new Response(JSON.stringify({ effaces: n }), { headers: { "content-type": "application/json" } });
};
