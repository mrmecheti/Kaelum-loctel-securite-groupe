// Kaelum e-PCS — chaque matin, lecture réglementaire des dossiers des agents :
// diplômes, recyclages, carte pro, secourisme, habilitation électrique, visite médicale.
// Mail au PC sécurité et au coordinateur PC quand un document approche de son échéance (J-150/90/60/30/15/7, puis chaque semaine si expiré).
// Application créée par Rochdi Mecheti
import { alertesDossiers, pourChaqueSite } from "./api.mjs";

export const config = { schedule: "40 5 * * *" }; // vers 7 h 40 à Montpellier

import { battement } from "../lib/core.mjs";
export default async () => {
  await battement("dossiers-alertes");
  const r = await pourChaqueSite(alertesDossiers);
  return new Response(JSON.stringify({ nb: r.nb, envoyes: r.envoyes }), { headers: { "content-type": "application/json" } });
};
