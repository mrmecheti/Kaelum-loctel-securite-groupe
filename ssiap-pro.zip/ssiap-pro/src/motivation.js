// Kaelum e-PCS — mot de motivation pour les agents (signé Kaelum e-PCS). Utilisé par l'appli ET par le serveur.
// Application créée par Rochdi Mecheti
(function () {
globalThis.MOTIVATION = [
  "Collaboratrices, collaborateurs, on compte sur votre professionnalisme. Votre vigilance fait la sécurité de tous.",
  "Collaboratrices, collaborateurs, chaque poste compte : merci pour votre engagement et votre rigueur.",
  "Collaboratrices, collaborateurs, soyez fiers de votre mission : vous êtes le premier rempart du site.",
  "Collaboratrices, collaborateurs, professionnalisme, vigilance et courtoisie : c'est vous qui faites la différence.",
  "Collaboratrices, collaborateurs, une équipe soudée, c'est un site en sécurité. On compte sur vous !",
  "Collaboratrices, collaborateurs, votre sérieux est notre meilleure carte de visite. Bonne vacation à tous.",
  "Collaboratrices, collaborateurs, anticiper, protéger, intervenir : merci d'incarner ces valeurs à chaque vacation.",
];
globalThis.MOTIVATION_SIGNE = "Kaelum e-PCS";
globalThis.motivationDuJour = (d = new Date()) => { const j = Math.floor((Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()) - Date.UTC(d.getFullYear(), 0, 0)) / 864e5); return globalThis.MOTIVATION[j % globalThis.MOTIVATION.length]; };
})();
