// Kaelum e-PCS — plan de masse du site (Parc des Expositions + Arena Sud de France), redessiné d'après le plan de masse SPLOE
// Coordonnées dans le repère du plan (viewBox). Application créée par Rochdi Mecheti
(function () {
  const R = (x1, y1, x2, y2) => `${x1},${y1} ${x2},${y1} ${x2},${y2} ${x1},${y2}`;
  // id, nom, type, points, infos de base. mc = libellé de zone de la main courante, bat = libellé de l'écran Bâtiments
  const Z = [
    // ---- Zone B (jaune)
    { id: "accB", nom: "Accueil B", type: "accueil", grp: "B", pts: R(603, 557, 668, 592), surface: 1025, mc: "Accueil B", bat: "Accueil B", extra: "Salles B1 (102 m²) et B2 (106 m²) · Parvis B" },
    { id: "B1", nom: "Hall B1", type: "hall", grp: "B", pts: "673.0,597.3 617.7,597.3 616.7,601.0 609.0,601.0 606.3,603.7 606.7,610.7 603.0,612.0 603.3,653.7 607.0,655.3 605.7,664.3 607.7,666.3 617.0,664.3 620.0,668.3 638.7,666.3 666.7,667.7 670.3,661.0 673.7,660.3", surface: 3500, mc: "B1", bat: "Hall B1" },
    { id: "B2", nom: "Hall B2", type: "hall", grp: "B", pts: "709.0,586.0 709.0,714.7 779.3,714.7 779.3,586.0", surface: 6480, mc: "B2", bat: "Hall B2" },
    { id: "B3", nom: "Hall B3", type: "hall", grp: "B", pts: "597.3,728.7 597.7,774.0 607.3,773.7 605.3,768.7 611.3,769.3 608.7,774.0 643.7,774.0 649.0,768.3 657.7,774.3 691.7,774.0 690.3,768.3 696.0,769.3 695.3,774.0 779.0,773.3 779.0,728.3", surface: 6100, mc: "B3", bat: "Hall B3" },
    { id: "B4", nom: "Hall B4", type: "hall", grp: "B", pts: "557.7,679.7 557.7,769.3 560.7,771.3 557.7,773.7 595.0,774.3 596.0,751.3 591.7,748.0 591.7,685.3 586.0,679.7", surface: 2400, mc: "B4", bat: "Hall B4" },
    { id: "B5", nom: "Hall B5", type: "hall", grp: "B", pts: "472.0,644.3 472.0,736.3 524.3,736.3 524.0,644.3", surface: 3500, mc: "B5", bat: "Hall B5" },
    { id: "cc", nom: "Centre de conférences", type: "hall", grp: "B", pts: "453.7,749.3 454.3,774.3 514.7,774.0 521.0,769.7 524.0,764.3 524.7,748.0 489.7,748.0 489.0,750.0 488.0,747.3 463.0,747.7", surface: 1300, mc: "Centre de conférence", bat: "Centre de conférences" },
    // ---- Zone A (rouge)
    { id: "A1", nom: "Hall A1", type: "hall", grp: "A", pts: "384.3,824.7 384.7,837.7 397.0,838.7 397.0,878.7 385.0,879.3 385.3,887.0 516.0,885.0 515.0,819.0 394.3,819.0 393.7,823.7", surface: 4800, mc: "A1", bat: "Hall A1" },
    { id: "arena", nom: "Arena Sud de France", type: "arena", grp: "L", pts: "383,884 517,884 517,1000 383,1000", surface: 0, mc: "", bat: "Arena Sud de France", site: "Arena Sud de France", extra: "portes 1 à 8 + PMR" },
    { id: "A2", nom: "Hall A2", type: "hall", grp: "A", pts: "559.3,816.3 557.3,820.3 546.3,825.7 547.3,830.3 539.3,838.3 543.0,873.3 541.7,913.0 594.0,913.3 597.0,908.0 593.0,876.7 594.3,833.7 588.7,831.0 582.3,835.0 591.0,827.3 578.7,820.3 577.3,816.7 564.7,818.7", surface: 3500, mc: "A2", bat: "Hall A2" },
    { id: "A3", nom: "Hall A3", type: "hall", grp: "A", pts: "612.0,817.3 612.3,894.3 718.0,894.0 717.7,817.0", surface: 5600, mc: "A3", bat: "Hall A3" },
    { id: "A4", nom: "Hall A4", type: "hall", grp: "A", pts: "741.7,801.7 741.0,982.3 777.3,982.7 780.7,805.7 776.3,801.7", surface: 4800, mc: "A4", bat: "Hall A4", extra: "Salle A4 (90 m²)" },
    { id: "A6", nom: "Hall A6", type: "hall", grp: "A", pts: "707.0,910.3 701.3,907.7 697.7,910.3 623.0,910.0 622.0,938.0 706.3,938.7", surface: 1800, mc: "A6", bat: "Hall A6", extra: "Salles A5 (44 m²) et A6 (125 m²)" },
    { id: "A5", nom: "Hall A5", type: "hall", grp: "A", pts: "613.0,948.3 613.0,983.0 638.3,982.7 643.0,985.3 648.0,982.7 698.3,983.0 698.0,985.3 703.3,985.3 703.7,983.0 707.0,982.7 706.3,948.3", surface: 2400, mc: "A5", bat: "Hall A5" },
    { id: "accA", nom: "Accueil A", type: "accueil", grp: "A", pts: "533,925 607,922 612,985 602,1035 572,996 545,968", surface: 1500, mc: "Accueil A", bat: "Accueil A", extra: "Parvis A" },
    // ---- Bâtiments techniques
    { id: "expl", nom: "Service Exploitation", type: "tech", pts: R(393, 740, 440, 776), mc: "" },
    { id: "tech", nom: "Bâtiment technique", type: "tech", pts: "402,707 448,716 444,731 398,722", mc: "" },
    // ---- Parkings
    { id: "pk1B", nom: "Parking 1B", type: "parking", pts: "585,372 640,340 700,335 790,345 800,500 560,500 560,410", surface: 19000, places: 920, mc: "Parking B (accès P6 Rond-point)" },
    { id: "pk3B", nom: "Parking 3B — Est", type: "parking", pts: R(500, 528, 598, 556), surface: 3300, places: 129 },
    { id: "pk2B", nom: "Parking 2B — Ouest", type: "parking", pts: R(700, 518, 800, 556), surface: 4600, places: 241 },
    { id: "pk4A", nom: "Parking 4A — Exposants", type: "parking", pts: R(615, 1000, 742, 1036), surface: 3200, places: 126 },
    { id: "pk3A", nom: "Parking 3A — VIP Arena", type: "parking", pts: R(345, 1040, 540, 1092), surface: 5000, places: 232 },
    { id: "pk2A", nom: "Parking 2A — Est", type: "parking", pts: "330,1098 540,1098 540,1250 345,1240 325,1200", surface: 18000, places: 743, mc: "Parking A (Parc)" },
    { id: "pk1A", nom: "Parking 1A — Ouest", type: "parking", pts: R(572, 1050, 700, 1262), surface: 23000, places: 1053, mc: "Parking A (Parc)" },
    { id: "pkTAM", nom: "Parking TAM", type: "parking", pts: R(710, 1052, 800, 1228), surface: 11000, places: 431 },
  ];
  // Repères (non cliquables, ou cliquables pour info simple)
  const REP = [
    { t: "ENTRÉE B", x: 585, y: 250, c: "entree" }, { t: "ENTRÉE A", x: 522, y: 1350, c: "entree" },
    { t: "Portail 3 (P3)", x: 404, y: 794, c: "portail", id: "p3", mc: "P3 (par l'avenue des Levades)" },
    { t: "Place Fugger", x: 556, y: 634, c: "rue" }, { t: "Place Jacques Cœur", x: 650, y: 690, c: "rue" },
    { t: "Allée Jacques Savary", x: 470, y: 801, c: "rue" }, { t: "Allée Mercure", x: 655, y: 805, c: "rue" }, { t: "Allée Médicis", x: 655, y: 903, c: "rue" },
    { t: "Allée Turgot", x: 691, y: 610, c: "rue", r: -90 }, { t: "Allée F. de Lesseps", x: 541, y: 728, c: "rue", r: -90 },
    { t: "Allée J. Monnet", x: 527, y: 866, c: "rue", r: -90 }, { t: "Allée Marco Polo", x: 607, y: 866, c: "rue", r: -90 }, { t: "Allée Frères Pereire", x: 731, y: 862, c: "rue", r: -90 },
    { t: "Station TAM Parc Expo", x: 818, y: 1352, c: "rue", r: -90 }, { t: "Porcelanosa", x: 740, y: 1288, c: "voisin" },
  ];
  // Défibrillateurs (DAE) : x / y sur le plan (null = emplacement à placer)
  const DAE = [
    { id: "dae-pcs", lieu: "PC sécurité (PCS)", detail: "Couloir du PC sécurité, au fond de l'accueil à gauche, au mur près du déclencheur manuel", photo: "img/dae-pcs.jpg", x: null, y: null },
    { id: "dae-expl", lieu: "Service d'exploitation", detail: "Dans le bâtiment du service d'exploitation", x: 432, y: 748 },
    { id: "dae-accB", lieu: "Accueil B", detail: "À l'accueil B", x: 663, y: 587 },
  ];
  globalThis.PLAN_SITE = {
    dae: DAE,
    vb: [255, 80, 670, 1500],
    zones: Z, reperes: REP,
    // contour du site, voiries et lac (décor)
    contour: "268,1265 290,1100 330,860 380,650 440,525 560,385 700,255 860,100 905,95 836,1558 268,1558",
    verts: ["711,1374 707,1385 712,1387 717,1394 719,1395 725,1402 733,1408 734,1410 737,1411 739,1415 796,1468 794,1427 792,1424 735,1389 735,1386 733,1387 727,1384 723,1380", "626,1335 624,1342 627,1342 633,1347 651,1355 659,1361 663,1362 664,1363 680,1372 684,1373 696,1380 700,1381 702,1371 700,1367 693,1362 687,1360 686,1358 660,1347 658,1346 660,1343 658,1343 658,1345 647,1342 648,1338 646,1338 646,1340 644,1340 629,1334", "538,1319 548,1322 552,1322 560,1325 577,1328 581,1330 585,1330 587,1332 611,1336 616,1339 617,1332 616,1326 613,1323 595,1318 589,1314 579,1312 578,1310 575,1310 573,1308 567,1307 566,1305 562,1305 561,1304 550,1305 544,1308 539,1316 539,1318", "481,1280 480,1288 476,1291 478,1295 486,1298 487,1300 491,1302 492,1304 497,1305 497,1306 500,1307 502,1309 505,1310 505,1311 516,1316 519,1319 523,1318 526,1301 525,1300 526,1298 524,1296 518,1295 517,1294 513,1293 508,1290 505,1290 503,1288 497,1287 496,1285 494,1285 493,1283 489,1283 486,1280", "376,1250 374,1255 377,1257 377,1259 375,1262 394,1269 399,1269 400,1271 415,1274 417,1276 424,1276 471,1291 469,1276 467,1274 461,1274 459,1277 448,1275 380,1252 380,1249", "702,1245 702,1273 700,1286 694,1294 670,1307 668,1321 672,1324 672,1326 680,1328 680,1330 675,1330 672,1327 668,1328 704,1347 704,1344 706,1343 702,1344 698,1342 698,1339 702,1338", "703,1235 799,1236 793,1353 772,1371 753,1371 751,1376 757,1374 757,1378 762,1376 759,1380 765,1378 781,1389 795,1389 798,1329 802,1326 799,1323 799,1310 803,1312 799,1302 802,1233 797,1236", "322,1152 319,1170 320,1187 328,1200 340,1210 383,1232 438,1249 452,1248 367,1218 337,1200 328,1189 324,1180 326,1153", "806,854 803,973 800,860 799,994 732,997 800,998 803,992 807,1197", "361,802 355,805 292,1247 318,1229 309,1196 310,1160", "804,576 799,578 796,638 799,846 804,749 806,850 808,578", "554,478 480,504 439,543 418,583 395,642 360,783 366,781 387,687 436,641 486,549 539,501", "836,339 835,1251", "707,322 708,332 721,338 748,339 763,327 780,331 802,417 801,555 794,562 804,564 807,570 809,454 804,366 801,366 788,322 775,309 762,325 743,333 724,331", "745,241 715,268 708,278 704,291 704,298 710,313 719,322 730,326 731,328 744,327 755,323 763,315 768,305 768,300 766,300 764,296 767,296 769,299 769,287 759,264 757,261 761,287 758,286 751,251 748,248 739,248", "861,236 842,347 849,1412 844,1398 839,1408 860,1424 846,379 854,282 875,239", "739,230 579,359 497,441 428,544 385,652 415,574 439,533 478,498 570,460 634,370 662,300 740,236", "781,215 762,227 757,234 789,290 796,306 798,302 801,303 798,311 814,366 819,311 830,238 828,231 802,215", "853,152 847,148 843,143 824,160 750,220 752,223 778,205 794,202 810,205 828,218 835,219 839,212 842,189 852,164", "909,107 888,141 867,192 863,220 871,221 878,221"],
    eau: ["502,503 475,515 443,549 419,593 390,678 439,629 467,583 480,555 481,547 494,529 503,507"],
    lac: "392,690 410,640 445,585 478,530 500,505 505,520 485,565 455,620 425,670 402,700",
    voies: [
      "M275,1262 C300,1000 340,760 395,620 C450,500 560,390 700,265 C770,205 830,150 895,95",
      "M820,95 C815,500 812,1000 818,1560",
      "M330,1255 C440,1270 560,1280 700,1300 C780,1320 820,1340 900,1430",
      "M556,1040 L556,1262",
    ],
    // v3.98 — barrières, portails, portes de l'Arena et délimitations (d'après les plans d'accès aux postes)
    acces: {"delims": [{"t": "Enceinte du site", "style": "enceinte", "pts": "318.0,1208.1 323.1,1104.1 388.0,738.9 397.3,705.2 560.0,402.3 585.8,363.5 642.4,330.9 704.2,325.8 796.9,336.0 807.2,494.1 807.2,1236.7 626.7,1316.1 539.3,1322.1 338.6,1248.9"}, {"t": "Parvis Arena", "style": "parvis", "pts": "354.9,992.4 542.7,993.4 543.1,1050.1 355.3,1049.1"}, {"t": "Cour de service", "style": "service", "pts": "339.3,819.7 374.4,819.9 375.8,1038.6 340.7,1038.4"}, {"t": "Parking frigorifiques", "style": "service", "pts": "784.4,523.0 802.5,523.1 805.6,995.9 787.4,995.8"}], "barrieres": [{"t": "Sortie cour de service", "x": 385.3, "y": 813.7, "type": "portail"}, {"t": "Portail 400", "x": 536.9, "y": 1032.6, "type": "portail"}, {"t": "PKG Porcelanosa", "x": 624.7, "y": 1305.9, "type": "portail"}, {"t": "PKG Pailletrice", "x": 539.9, "y": 1311.8, "type": "portail"}, {"t": "Patte d'oie", "x": 333.4, "y": 1216.0, "type": "barriere"}, {"t": "P8 inter", "x": 792.9, "y": 525.3, "type": "barriere"}, {"t": "P7 inter", "x": 683.8, "y": 528.1, "type": "barriere"}, {"t": "P6 rond-point", "x": 730.0, "y": 355.3, "type": "barriere"}, {"t": "P6 inter", "x": 594.5, "y": 574.0, "type": "barriere"}, {"t": "P5 inter", "x": 547.2, "y": 571.9, "type": "barriere"}, {"t": "P4 inter", "x": 503.6, "y": 575.0, "type": "barriere"}, {"t": "P3", "x": 401.9, "y": 767.9, "type": "portail"}, {"t": "P1 inter", "x": 730.5, "y": 993.0, "type": "barriere"}, {"t": "Mail central", "x": 538.4, "y": 1266.1, "type": "barriere"}, {"t": "Entrée cour de service", "x": 346.6, "y": 1017.5, "type": "portail"}], "portesArena": [{"n": 1, "x": 267.9, "y": 1030.1}, {"n": 2, "x": 306.7, "y": 1030.3}, {"n": 3, "x": 341.8, "y": 1030.5}, {"n": 4, "x": 380.6, "y": 1030.7}, {"n": 5, "x": 414.5, "y": 1030.8}, {"n": 6, "x": 449.7, "y": 1031.0}, {"n": 7, "x": 486.0, "y": 1031.2}, {"n": 8, "x": 521.2, "y": 1031.4}]},
    infosType: { hall: "Hall d'exposition — ERP type T", accueil: "Accueil / hall d'entrée — ERP type T", arena: "Salle de spectacle — ERP type L", parking: "Parking", tech: "Bâtiment technique — accès réservé" },
  };
})();
