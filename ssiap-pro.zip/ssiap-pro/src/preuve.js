/* Photo preuve : photo prise avec l'appli, avec date, heure (Paris), lieu, position GPS, code de traçabilité de l'agent et empreinte incrustés dans l'image */
(() => {
  const esc = (x) => String(x ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const heure = () => new Intl.DateTimeFormat("fr-FR", { timeZone: "Europe/Paris", day: "2-digit", month: "2-digit", year: "numeric", hour: "2-digit", minute: "2-digit", second: "2-digit" }).format(new Date()).replace(",", "");
  const position = () => new Promise((ok) => { if (!navigator.geolocation) return ok(null); navigator.geolocation.getCurrentPosition((p) => ok({ lat: p.coords.latitude, lon: p.coords.longitude, pr: Math.round(p.coords.accuracy) }), () => ok(null), { enableHighAccuracy: true, timeout: 7000, maximumAge: 15000 }); });
  const empreinte = async (f) => { try { const h = await crypto.subtle.digest("SHA-256", await f.arrayBuffer()); return [...new Uint8Array(h)].slice(0, 4).map((b) => b.toString(16).padStart(2, "0")).join(""); } catch { return "--------"; } };
  const charger = (f) => new Promise((ok, ko) => { const img = new Image(), u = URL.createObjectURL(f); img.onload = () => { URL.revokeObjectURL(u); ok(img); }; img.onerror = ko; img.src = u; });
  // o : { lieu, code, gps (déjà connue ou null), legende }
  window.estampPhoto = async (file, o = {}) => {
    const [img, pos, hash] = await Promise.all([charger(file), o.gps && o.gps.lat != null ? Promise.resolve({ lat: o.gps.lat, lon: o.gps.lon, pr: o.gps.pr }) : position(), empreinte(file)]);
    const k = Math.min(1, 1400 / Math.max(img.width, img.height)), W = Math.round(img.width * k), Hh = Math.round(img.height * k), fs = Math.max(14, Math.round(W / 32));
    const lignes = [`${heure()} · ${o.lieu || "lieu non précisé"}`, pos ? `GPS ${pos.lat.toFixed(5)}, ${pos.lon.toFixed(5)}${pos.pr ? " (±" + pos.pr + " m)" : ""}` : "GPS indisponible", ...(o.legende ? [o.legende] : [])];
    const bande = Math.round(fs * (lignes.length + 1.6)), c = document.createElement("canvas"); c.width = W; c.height = Hh; const g = c.getContext("2d");
    g.drawImage(img, 0, 0, W, Hh); g.fillStyle = "rgba(0,0,0,.62)"; g.fillRect(0, Hh - bande, W, bande);
    g.fillStyle = "#fff"; g.font = `600 ${fs}px system-ui, sans-serif`; g.textBaseline = "top"; lignes.forEach((l, i) => g.fillText(l.slice(0, 90), Math.round(fs * 0.6), Hh - bande + Math.round(fs * 0.5) + i * fs * 1.15));
    g.textAlign = "right"; g.font = `500 ${Math.round(fs * 0.8)}px ui-monospace, monospace`; g.fillStyle = "#9fd8ff"; g.fillText(`Kaelum e-PCS · NM-${o.code || "------"} · ${hash}`, W - Math.round(fs * 0.6), Hh - Math.round(fs * 1.5));
    let q = 0.82, d = c.toDataURL("image/jpeg", q); while (d.length > 850000 && q > 0.4) { q -= 0.08; d = c.toDataURL("image/jpeg", q); }
    return { d, gps: pos, hash };
  };
  window.lancerPreuve = (view, H) => {
    let res = null;
    const accueil = () => { view.innerHTML = `<div class="card"><div class="psur">Main courante · constat</div><h2 style="margin:2px 0 6px">Photo preuve</h2><p class="mut" style="margin-top:0">La date, l'heure, le lieu, ta position GPS et un code de traçabilité sont inscrits sur la photo. Tu peux ensuite la joindre à une main courante.</p>
      <label>Lieu</label><input id="pvlieu" list="pvzones" placeholder="ex. Hall B1, porte 4" autocomplete="off"><datalist id="pvzones">${H.zones.map((z) => `<option value="${esc(z)}">`).join("")}</datalist>
      <label>Légende (facultatif)</label><input id="pvleg" maxlength="80" placeholder="ex. porte forcée, fuite d'eau">
      <label class="btn red" style="margin-top:12px;text-align:center">📷 Prendre la photo<input type="file" accept="image/*" capture="environment" id="pvf" hidden></label><div id="pvst" class="mut" style="margin-top:8px"></div></div><div class="card"><h2 style="margin:0 0 4px">Photos des dernières 24 h</h2><p class="mut" style="margin:0 0 8px">Effacées automatiquement au bout de 24 h : elles ne prennent pas de place.</p><div id="pvlist"><p class="mut">Chargement…</p></div></div>`;
      liste();
      view.querySelector("#pvf").onchange = async (e) => { const f = e.target.files[0]; if (!f) return; view.querySelector("#pvst").textContent = "Position GPS et horodatage en cours…";
        try { const lieu = view.querySelector("#pvlieu").value.trim(), legende = view.querySelector("#pvleg").value.trim(); res = { ...(await window.estampPhoto(f, { lieu, legende, code: H.code })), lieu, legende }; resultat(); } catch (er) { view.querySelector("#pvst").textContent = "Photo illisible, recommence."; } }; };
    const liste = async () => { const box = view.querySelector("#pvlist"); if (!box) return; let L; try { L = await H.api("preuves"); } catch (e) { box.innerHTML = `<p class="mut">${esc(e.message)}</p>`; return; }
      const reste = (t) => { const m = Math.max(0, Math.round((Date.parse(t) - Date.now()) / 60000)); return m >= 60 ? `${Math.floor(m / 60)} h ${String(m % 60).padStart(2, "0")}` : `${m} min`; };
      box.innerHTML = L.photos.map((p) => `<div class="item" data-id="${p.id}"><b>${esc(p.lieu || "Lieu non précisé")}</b>${p.legende ? " · " + esc(p.legende) : ""}<br><span class="mut" style="font-size:.82rem">${new Date(p.t).toLocaleString("fr-FR", { day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit" })}${p.de ? " · " + esc(p.de) : p.moi ? " · toi" : ""} · s'efface dans ${reste(p.expire)}</span>
        <div><button type="button" class="btn sm" data-v="${p.id}" style="width:auto;margin-top:6px">Voir</button> <button type="button" class="btn sm" data-x="${p.id}" style="width:auto;margin-top:6px">Supprimer</button></div><div class="pvimg"></div></div>`).join("") || `<p class="mut">Aucune photo en ce moment.</p>`;
      box.onclick = async (e) => { const v = e.target.closest("[data-v]"), x = e.target.closest("[data-x]");
        if (v) { try { const r = await H.api("preuves/" + v.dataset.v); v.closest(".item").querySelector(".pvimg").innerHTML = `<img src="${r.d}" alt="" style="width:100%;border-radius:10px;margin-top:8px">`; } catch (er) { H.toast(er.message); } }
        if (x && confirm("Supprimer cette photo maintenant ?")) { try { await H.api("preuves/" + x.dataset.x, { method: "DELETE" }); liste(); } catch (er) { H.toast(er.message); } } }; };
    const resultat = () => { const nom = `preuve-${new Date().toISOString().slice(0, 19).replace(/[:T]/g, "-")}.jpg`, partage = !!(navigator.canShare && navigator.share);
      view.innerHTML = `<div class="card"><h2 style="margin:0 0 8px">Photo horodatée</h2><img src="${res.d}" alt="" style="width:100%;border-radius:10px">
        <p class="mut" style="margin:8px 0">${res.gps ? "📍 Position enregistrée" : "⚠️ Position GPS indisponible (autorise la localisation pour l'appli)"} · empreinte ${esc(res.hash)}</p>
        <button class="btn red" id="pvpc">Envoyer au PC · effacée après 24 h</button><button class="btn" id="pvmc" style="margin-top:8px">Joindre à une main courante</button><a class="btn" id="pvdl" download="${nom}" href="${res.d}" style="text-align:center;text-decoration:none;display:block;margin-top:8px">Enregistrer sur le téléphone</a>
        ${partage ? `<button class="btn" id="pvsh" style="margin-top:8px">Partager</button>` : ""}<button class="btn" id="pvre" style="margin-top:8px">Recommencer</button></div>`;
      view.querySelector("#pvpc").onclick = async (e) => { e.target.disabled = true; try { await H.api("preuves", { method: "POST", body: { d: res.d, lieu: res.lieu, legende: res.legende, hash: res.hash, gps: res.gps ? { lat: res.gps.lat, lon: res.gps.lon } : null } }); H.toast("✅ Photo envoyée au PC · effacée automatiquement dans 24 h", 5000); accueil(); } catch (er) { H.toast(er.message); e.target.disabled = false; } };
      view.querySelector("#pvmc").onclick = () => H.versMC(res);
      if (partage) view.querySelector("#pvsh").onclick = async () => { try { const b = await (await fetch(res.d)).blob(), f = new File([b], nom, { type: "image/jpeg" }); if (navigator.canShare({ files: [f] })) await navigator.share({ files: [f], title: "Photo preuve" }); } catch {} };
      view.querySelector("#pvre").onclick = accueil; };
    accueil();
  };
})();
