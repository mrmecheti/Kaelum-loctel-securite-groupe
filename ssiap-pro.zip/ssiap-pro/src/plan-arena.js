// Kaelum e-PCS — plan de masse RDC de l'Arena Sud de France (d'après le plan de Laurent Hernandez), redessiné en plan technique interactif
// Application créée par Rochdi Mecheti
(function () {
const S = (cx, cy, w, h) => ({ x: cx - w / 2, y: cy - h / 2, w, h });
globalThis.PLAN_ARENA = {
  vb: [0, 20, 1323, 1851],
  parking: { pts: "25,70 1215,70 1215,92 25,92", nom: "Parking loges partners" },
  parvis: "25,92 1215,92 985,470 180,470 15,170",
  rayons: [[130, 335, 175, 92], [290, 335, 345, 92], [410, 335, 510, 92], [520, 335, 670, 92], [645, 335, 835, 92], [760, 335, 1000, 92], [880, 335, 1160, 92], [1045, 335, 1215, 92],
    [130, 335, 210, 465], [290, 335, 330, 465], [410, 335, 445, 465], [520, 335, 545, 465], [645, 335, 640, 465], [760, 335, 735, 465], [880, 335, 830, 465], [1045, 335, 960, 465]],
  palmiers: [87, 188, 278, 348, 420, 488, 555, 620, 688, 757, 827, 898, 990, 1090].map((x) => [x, 188]),
  billetterie: S(590, 102, 100, 22),
  portes: [[8, 130, 335], [7, 290, 335], [6, 410, 335], [5, 520, 335], [4, 645, 335], [3, 760, 335], [2, 880, 335], [1, 1045, 335]],
  filtrages: [[401, 205, 318], [402, 350, 318], [403, 465, 318], [404, 588, 318], [405, 708, 318], [406, 825, 318], [407, 965, 318]],
  points: [
    { id: "408", nom: "408", t: "acces", x: 1065, y: 425 }, { id: "pompiers", nom: "Portail pompiers", t: "pompiers", x: 1290, y: 150 },
    { id: "entree", nom: "Entrée (cour de service)", t: "acces", x: 1235, y: 380 }, { id: "sortie", nom: "Sortie", t: "acces", x: 1010, y: 1660 },
    { id: "p3", nom: "P3", t: "portail", x: 965, y: 1775 }, { id: "ria", nom: "Vanne RIA", t: "ria", x: 807, y: 1222 },
  ],
  zones400: [{ id: "400", pts: "110,440 157,438 117,477", lx: 118, ly: 425 }, { id: "409", pts: "62,478 102,486 92,515 48,520", lx: 85, ly: 545 }],
  vertEst: "1238,145 1302,138 1292,352 1238,355",
  bulle: { cx: 888, cy: 483, r: 40 },
  batiment: "175,462 1000,462 1000,1602 175,1602",
  bowl: { cx: 590, cy: 985, r: 505 },
  sections: [
    ["C3", 527, 625, 52, 62], ["C2", 590, 625, 62, 62], ["C1", 650, 625, 52, 62], ["D1", 465, 632, 64, 66], ["D2", 393, 658, 82, 60], ["D3", 340, 700, 86, 54], ["D4", 308, 752, 96, 46],
    ["B4", 713, 636, 64, 66], ["B3", 785, 660, 82, 60], ["B2", 840, 700, 86, 54], ["B1", 870, 752, 96, 46],
    ["E1", 305, 808, 92, 44], ["E2", 305, 866, 92, 52], ["E3", 305, 930, 92, 52], ["E4", 305, 990, 92, 52], ["E5", 305, 1043, 92, 26],
    ["A5", 873, 808, 92, 44], ["A4", 873, 866, 92, 52], ["A3", 873, 928, 92, 52], ["A2", 873, 990, 92, 52], ["A1", 873, 1043, 92, 26],
    ["G5", 489, 720, 34, 38], ["G4", 530, 720, 40, 38], ["G3", 590, 720, 52, 38], ["G2", 645, 720, 40, 38], ["G1", 690, 720, 34, 38],
    ["H9", 428, 773, 48, 30], ["H8", 428, 820, 48, 40], ["H7", 428, 873, 48, 40], ["H6", 420, 915, 36, 28], ["H5", 430, 955, 50, 34], ["H4", 422, 1003, 40, 28], ["H3", 430, 1046, 50, 30], ["H2", 430, 1087, 50, 30], ["H1", 422, 1122, 40, 26],
    ["F9", 746, 773, 48, 30], ["F8", 757, 820, 48, 40], ["F7", 749, 873, 48, 40], ["F6", 757, 914, 36, 28], ["F5", 749, 955, 50, 34], ["F4", 760, 1003, 40, 28], ["F3", 746, 1046, 50, 30], ["F2", 747, 1087, 50, 30], ["F1", 760, 1122, 40, 26],
  ].map(([id, cx, cy, w, h]) => ({ id, ...S(cx, cy, w, h), groupe: /^[ABCDE]/.test(id) ? "tribune" : /^[GHF]/.test(id) ? "telescopique" : "parterre" })),
  parterre: [["M3", 527, 843], ["M2", 570, 843], ["M1", 612, 843], ["L3", 653, 843], ["K2", 527, 922], ["K3", 570, 922], ["L1", 612, 925], ["L2", 653, 925], ["K1", 527, 998], ["J3", 570, 998], ["J2", 612, 998], ["J1", 653, 998]].map(([id, cx, cy]) => ({ id, ...S(cx, cy, 30, 52) })),
  sport: { pts: "465,760 715,760 715,1150 465,1150", lx: 593, ly: 1088 },
  bande8: { x: 178, y: 1163, w: 822, h: 57 },
  expo: [{ id: "Z4", x: 300, y: 1220, w: 253, h: 176 }, { id: "Z2", x: 553, y: 1220, w: 252, h: 176 }, { id: "Z5", x: 178, y: 1396, w: 222, h: 204 }, { id: "Z3", x: 400, y: 1396, w: 312, h: 204 }, { id: "Z1", x: 712, y: 1396, w: 213, h: 204 }],
  locaux: { x: 925, y: 1225, w: 75, h: 245 },
  escaliers: [[8, 428, 578], [7, 742, 575], [4, 215, 828], [1, 965, 828], [5, 210, 985], [2, 960, 983], [6, 210, 1138], [3, 965, 1143], [10, 985, 1452], [9, 970, 1583]],
  acces: [[16, 407, 535], [15, 470, 522], [14, 553, 527], [12, 628, 527], [11, 705, 522], [10, 762, 535], [9, 807, 550], [8, 847, 580], [7, 886, 620], [6, 910, 660],
    [17, 369, 555], [18, 325, 583], [19, 288, 625], [20, 262, 665], [21, 222, 872], [22, 222, 915], [23, 220, 953], [24, 218, 1038], [25, 218, 1088],
    ["5e", 955, 875], ["4e", 955, 912], ["3e", 955, 949], ["2e", 955, 1035], ["1e", 953, 1090]],
  courService: "1000,470 1045,468 1228,418 1078,1598 1000,1600",
  herisson: "1005,740 1050,745 1085,800 1078,900 1086,1000 1070,1100 1040,1200 1005,1200",
  route: ["M1228,418 L1078,1598", "M970,1660 L1055,1660 M970,1660 L970,1820 Q985,1840 1005,1868"],
  textes: [["OUEST · côté cour", 80, 960], ["(Parc Expo)", 80, 990], ["EST · côté jardin", 1215, 960], ["(Aéroport)", 1215, 990], ["Cour de service", 1115, 680]],
  boussole: { x: 577, y: 1745 },
  // v4.32 · postes de l'Arena (d'après les plannings) : ordre = priorité de reconnaissance. Sans x/y : poste hors plan RDC (étages, parkings, volants)
  postes: [
    { id: "backstage", nom: "Porte arrière backstage", re: /PORTE\s*ARR|ARRIERE\s*BACKSTAGE/, x: 1030, y: 780, g: "Cour de service" },
    { id: "accred", nom: "Passage accréd. backstage", re: /ACCRED\w*\s*BACKSTAGE|PASSAGE\s*ACCRED/, x: 1030, y: 640, g: "Cour de service" },
    { id: "gaero", nom: "Porte grise aéroport", re: /PORTE\s*GRISE\s*A[EÉ]RO/, x: 1035, y: 1330, g: "Portes grises" },
    { id: "gcour", nom: "Porte grise côté cour", re: /PORTE\s*GRISE/, x: 120, y: 1500, g: "Portes grises" },
    { id: "entreecour", nom: "Entrée cour de service", re: /ENTR[EÉ]E\s*COUR\s*DE\s*SERVICE/, x: 1235, y: 400, g: "Cour de service" },
    { id: "cour", nom: "Cour de service", re: /COUR\s*DE\s*SERVICE/, x: 1120, y: 560, g: "Cour de service" },
    { id: "ascloges", nom: "Ascenseur / accréd. loges (niv. 2)", re: /ASC\w*\s*(NIV|LOGE)|ACCRED\w*\s*ASC|LOGES?\s*NIV/, g: "Étages" },
    { id: "medias", nom: "Salle des médias (niv. 1)", re: /SALLE\s*DES\s*M[EÉ]DIA/, g: "Étages" },
    { id: "salonvip", nom: "Salon VIP réception (niv. 1)", re: /SALON\s*VIP/, g: "Étages" },
    { id: "pkvip", nom: "Parking VIP média", re: /PARKING\s*VIP|VIP\s*M[EÉ]DIA/, x: 380, y: 60, g: "Parvis et parkings" },
    { id: "pkloges", nom: "Parking loges / portail VIP", re: /PARKING\s*LOGE|PORTAIL\s*VIP|PKG\s*LOGE/, x: 820, y: 60, g: "Parvis et parkings" },
    { id: "pailletrice", nom: "Parking Pailletrice / RFT patte d'oie", re: /PAILLETRICE|PATTE\s*D/, g: "Parkings extérieurs" },
    { id: "pka", nom: "Parking A (accueil, placement, cynophile)", re: /P(AR)?K(IN)?G\s*A\b|ACCUEIL\s*A\b/, g: "Parkings extérieurs" },
    { id: "pkb", nom: "Parking B", re: /P(AR)?K(IN)?G\s*B\b/, g: "Parkings extérieurs" },
    { id: "parvis", nom: "Parvis", re: /PARVIS/, x: 600, y: 395, g: "Parvis et parkings" },
    { id: "billetterie", nom: "Billetterie / consigne", re: /BILLETTERIE|CONSIGNE/, x: 590, y: 118, g: "Parvis et parkings" },
    { id: "p3", nom: "P3 / ronde de nuit et fermeture", re: /\bP\s?3\b|NUIT\s*FERMETURE/, x: 965, y: 1735, g: "Parvis et parkings" },
    { id: "pompiers", nom: "Portail pompiers", re: /POMPIER/, x: 1265, y: 175, g: "Cour de service" },
    { id: "crash", nom: "Devant de scène / crash", re: /DEVANT\s*(DE\s*)?SC|CRASH/, x: 590, y: 1135, g: "Salle" },
    { id: "fop", nom: "Terrain / FOP", re: /TERRAIN|\bFOP\b/, x: 590, y: 785, g: "Salle" },
    { id: "regie", nom: "Régie", re: /R[EÉ]GIE/, x: 590, y: 905, g: "Salle" },
    { id: "parterre", nom: "Parterre", re: /PARTERRE|FOSSE/, x: 590, y: 1020, g: "Salle" },
    { id: "gradin", nom: "Gradin haut", re: /GRADIN/, x: 590, y: 560, g: "Salle" },
    { id: "ccour", nom: "Côté cour", re: /\bCOURT?\b/, x: 245, y: 1425, g: "Salle" },
    { id: "cjardin", nom: "Côté jardin", re: /JARDIN/, x: 935, y: 1270, g: "Salle" },
    { id: "mixte", nom: "Zone mixte", re: /MIXTE/, g: "Zones sportives" },
    { id: "warming", nom: "Warming zone", re: /WARMING/, g: "Zones sportives" },
    { id: "repr", nom: "SSIAP 2 représentation", re: /REPR[EÉ]SENTATION/, x: 820, y: 1192, g: "Sécurité incendie" },
    { id: "volants", nom: "ADS volants / coordinateur", re: /VOLANT|COORDINATEUR\s*VOLANT|ADS\s*COORDINATEUR/, g: "Volants" },
    { id: "pc", nom: "PC Arena · SSIAP", re: /SSIAP|PC\s*ARENA|PCS|CHEF|COORD/, x: 300, y: 1182, g: "Sécurité incendie", gen: true },
  ],
};
// poste du planning → emplacement : on lit d'abord le début (« ADS PORTE 1 / PUIS CRASH » → porte 1), puis tout l'intitulé
globalThis.posteArena = (txt) => { const A = globalThis.PLAN_ARENA, full = String(txt || "").toUpperCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
  for (const [p, gen] of [[full.split("/")[0], false], [full, false], [full, true]]) {
    const m = !gen && p.match(/PORTE\s*(\d)\b/);
    if (m && !/ARR|GRISE/.test(p)) { const d = A.portes.find((x) => x[0] === +m[1]); if (d) return { x: d[1], y: d[2] + 40, k: "porte" + d[0], lb: "Porte " + d[0], g: "Portes" }; }
    const q = A.postes.find((x) => !!x.gen === gen && x.re.test(p)); if (q) return { x: q.x, y: q.y, k: q.id, lb: q.nom, g: q.g, hors: q.x == null };
  }
  return null; };
})();
