package fr.mmanager.app;

import android.Manifest;
import android.content.Context;
import android.content.SharedPreferences;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import com.getcapacitor.JSObject;
import com.getcapacitor.PermissionState;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.annotation.Permission;
import com.getcapacitor.annotation.PermissionCallback;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * Podomètre natif : le capteur matériel TYPE_STEP_COUNTER compte les pas en continu,
 * même écran verrouillé et appli fermée. On lit simplement son total quand l'appli s'ouvre
 * et on en déduit les pas du jour.
 */
@CapacitorPlugin(
    name = "Steps",
    permissions = { @Permission(alias = "activity", strings = { Manifest.permission.ACTIVITY_RECOGNITION }) }
)
public class StepsPlugin extends Plugin {

    @PluginMethod
    public void collect(PluginCall call) {
        if (Build.VERSION.SDK_INT >= 29 && getPermissionState("activity") != PermissionState.GRANTED) {
            requestPermissionForAlias("activity", call, "permCb");
            return;
        }
        lire(call);
    }

    @PermissionCallback
    private void permCb(PluginCall call) {
        if (getPermissionState("activity") == PermissionState.GRANTED) lire(call);
        else call.reject("permission refusée");
    }

    private void lire(final PluginCall call) {
        final Context ctx = getContext();
        final SensorManager sm = (SensorManager) ctx.getSystemService(Context.SENSOR_SERVICE);
        final Sensor capteur = sm.getDefaultSensor(Sensor.TYPE_STEP_COUNTER);
        if (capteur == null) {
            call.reject("capteur de pas absent");
            return;
        }
        final boolean[] fini = { false };
        final SensorEventListener ecoute = new SensorEventListener() {
            @Override
            public void onSensorChanged(SensorEvent e) {
                if (fini[0]) return;
                fini[0] = true;
                sm.unregisterListener(this);
                float v = e.values[0];
                SharedPreferences p = ctx.getSharedPreferences("mm_pas", Context.MODE_PRIVATE);
                float dernier = p.getFloat("dernier", -1f);
                String jour = new SimpleDateFormat("yyyy-MM-dd", Locale.FRANCE).format(new Date());
                long nb = p.getString("jour", "").equals(jour) ? p.getLong("nb", 0) : 0;
                long delta = dernier < 0 ? 0 : (v >= dernier ? (long) (v - dernier) : (long) v); // v < dernier : le téléphone a redémarré
                nb += delta;
                p.edit().putFloat("dernier", v).putString("jour", jour).putLong("nb", nb).apply();
                JSObject r = new JSObject();
                r.put("jour", nb);
                r.put("date", jour);
                r.put("ajoutes", delta);
                call.resolve(r);
            }

            @Override
            public void onAccuracyChanged(Sensor s, int a) {}
        };
        sm.registerListener(ecoute, capteur, SensorManager.SENSOR_DELAY_FASTEST);
        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
            @Override
            public void run() {
                if (!fini[0]) {
                    fini[0] = true;
                    sm.unregisterListener(ecoute);
                    call.reject("pas de mesure du capteur");
                }
            }
        }, 5000);
    }
}
