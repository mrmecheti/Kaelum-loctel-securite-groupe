// M Manager — vide l'ancienne version (cache + service worker) puis relance l'appli. Les connexions et réglages sont gardés.
(async () => {
  const m = document.getElementById("m");
  try { const regs = (await navigator.serviceWorker?.getRegistrations?.()) || []; await Promise.all(regs.map((r) => r.unregister())); } catch {}
  try { const k = await caches.keys(); await Promise.all(k.filter((x) => x !== "ssiap-auth").map((x) => caches.delete(x))); } catch {}
  m.textContent = "C'est réparé ✅ Ouverture de la dernière version…";
  setTimeout(() => location.replace("/?v=" + Date.now()), 1200);
})();
