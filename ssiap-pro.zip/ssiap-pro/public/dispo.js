(function () {
  const $ = (s) => document.querySelector(s), app = $("#app"), q = new URLSearchParams(location.search), mois = q.get("m") || "", k = q.get("k") || "";
  const esc = (x) => String(x).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
  const SYM = { jour: "JOUR", nuit: "NUIT", jn: "24h", indispo: "✖" };
  const OUTILS = [["jour", "☀️", "Jour"], ["nuit", "🌙", "Nuit"], ["jn", "⏱️", "24h/24"], ["indispo", "🚫", "Pas dispo"], ["", "🧽", "Effacer"]];
  let outil = "jn", jours = {}, envoi = false;
  function fin(titre, texte, ok) { app.innerHTML = `<div class="card ${ok ? "ok" : ""}">${ok ? '<div class="big">✓</div>' : ""}<h1>${titre}</h1><p>${texte}</p></div>`; }
  async function init() {
    if (!/^\d{4}-\d{2}$/.test(mois) || !k) return fin("Lien incomplet", "Demande le lien complet au PC sécurité ou à ton responsable.");
    let info; try { info = await (await fetch(`/api/dispo-public?m=${encodeURIComponent(mois)}&k=${encodeURIComponent(k)}`)).json(); } catch { return fin("Pas de réseau", "Réessaie dans un instant."); }
    if (!info.ok) return fin("Lien non reconnu", "Ce lien n'est pas valide. Demande-le à nouveau au PC sécurité ou à ton responsable.");
    if (info.ferme) return fin("Recueil clos", "Les disponibilités de ce mois ne sont plus acceptées. Contacte ton responsable.");
    dessiner();
  }
  function dessiner() {
    const [y, m] = mois.split("-").map(Number), nbj = new Date(y, m, 0).getDate(), dec = (new Date(y, m - 1, 1).getDay() + 6) % 7;
    const lbl = new Date(y, m - 1, 15).toLocaleDateString("fr-FR", { month: "long", year: "numeric" });
    const nom0 = app.querySelector("#nom")?.value || "", pre0 = app.querySelector("#pre")?.value || "", note0 = app.querySelector("#note")?.value || "";
    const cases = ["L", "M", "M", "J", "V", "S", "D"].map((j) => `<div class="dw">${j}</div>`).join("") + Array(dec).fill('<div class="dd v"></div>').join("")
      + [...Array(nbj)].map((_, i) => { const d = `${mois}-${String(i + 1).padStart(2, "0")}`, v = jours[d]; return `<button type="button" class="dd ${v || ""}" data-d="${d}"><b>${i + 1}</b><i>${v ? SYM[v] : ""}</i></button>`; }).join("");
    const nd = Object.values(jours).filter((v) => v !== "indispo").length, ni = Object.values(jours).filter((v) => v === "indispo").length;
    app.innerHTML = `<div class="card"><div class="sur">Disponibilités</div><h1>${esc(lbl)}</h1><p>Renseigne ton nom, puis touche les jours pour indiquer quand tu peux travailler (ou non).</p>
      <div class="two"><div><label>Nom</label><input id="nom" autocomplete="family-name" value="${esc(nom0)}"></div><div><label>Prénom</label><input id="pre" autocomplete="given-name" value="${esc(pre0)}"></div></div></div>
    <div class="card"><div class="sur">1 · Choisis, 2 · touche les jours</div>
      <div class="tools">${OUTILS.map(([v, ic, t]) => `<button type="button" data-o="${v}" class="${outil === v ? "on" : ""}"><b>${ic}</b>${t}</button>`).join("")}</div>
      <div class="cal">${cases}</div>
      <div class="rac"><button type="button" data-r="tout">Tout le mois en 24h/24</button><button type="button" data-r="we">Week-ends en ${esc(OUTILS.find((o) => o[0] === outil)?.[2] || "…")}</button><button type="button" data-r="reste">Le reste en pas dispo</button><button type="button" data-r="raz">Tout effacer</button></div>
      <div class="leg"><span style="--c:#f5c400">Jour</span><span style="--c:#2d63d6">Nuit</span><span style="--c:#1fa66a">24h/24 (jour ou nuit)</span><span style="--c:#ff6b7f">Pas dispo</span></div></div>
    <div class="card"><label style="margin-top:0">Remarque (facultatif)</label><textarea id="note" rows="2" maxlength="200" placeholder="ex. pas avant 8 h, dispo dernière minute…">${esc(note0)}</textarea>
      <button class="go" id="go">📤 Envoyer (${nd} dispo · ${ni} pas dispo)</button><div class="err" id="err"></div>
      <p style="font-size:.8rem;margin-top:8px">Tu peux renvoyer le formulaire : ton dernier envoi remplace le précédent.</p></div>`;
  }
  function plage(fn) { const [y, m] = mois.split("-").map(Number), nbj = new Date(y, m, 0).getDate(); for (let i = 1; i <= nbj; i++) { const d = `${mois}-${String(i).padStart(2, "0")}`, w = new Date(y, m - 1, i).getDay(); fn(d, w); } dessiner(); }
  document.addEventListener("click", async (e) => {
    const o = e.target.closest("[data-o]"), d = e.target.closest("[data-d]"), r = e.target.closest("[data-r]");
    if (o) { outil = o.dataset.o; return dessiner(); }
    if (d) { if (outil) jours[d.dataset.d] = outil; else delete jours[d.dataset.d]; return dessiner(); }
    if (r) { const t = r.dataset.r;
      if (t === "tout") return plage((j) => { jours[j] = "jn"; });
      if (t === "we") return plage((j, w) => { if (w === 0 || w === 6) { if (outil) jours[j] = outil; else delete jours[j]; } });
      if (t === "reste") return plage((j) => { if (!jours[j]) jours[j] = "indispo"; });
      if (t === "raz") { jours = {}; return dessiner(); } }
    if (e.target.id === "go" && !envoi) {
      const nom = $("#nom").value.trim(), pre = $("#pre").value.trim(), err = $("#err"); err.textContent = "";
      if (nom.length < 2 || pre.length < 2) { err.textContent = "Indique ton nom et ton prénom"; $("#nom").focus(); return; }
      if (!Object.keys(jours).length) { err.textContent = "Touche au moins un jour du calendrier"; return; }
      envoi = true; e.target.disabled = true; e.target.textContent = "Envoi…";
      try {
        const r2 = await fetch("/api/dispo-public", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ m: mois, k, nom, prenom: pre, jours, note: $("#note").value }) }), j = await r2.json();
        if (!r2.ok) throw new Error(j.error || "Erreur");
        fin("Merci " + esc(pre) + " !", `Tes disponibilités sont enregistrées (${j.nd} jour(s) disponible, ${j.ni} pas dispo). Tu peux fermer cette page, ou rouvrir le lien pour les modifier.`, true);
      } catch (er) { envoi = false; dessiner(); $("#err").textContent = er.message || "Pas de réseau, réessaie"; }
    }
  });
  init();
})();
