/* supprimé en v5.39 */
