// Kaelum e-PCS — Application créée par Rochdi Mecheti
const V = "ssiap-pro-v311";
const SHELL = ["/", "/index.html", "/theme-init.js", "/app.css", "/app.js", "/textes.js", "/memo.js", "/site.js", "/rapports-types.js", "/risques.js", "/motivation.js", "/mc-postes.js", "/plan.js", "/plan-arena.js", "/sst.js", "/preuve.js", "/planif-calc.js", "/img/fond-mmanager.jpg", "/favicon.ico", "/img/brand/kaelum-192.png", "/img/brand/kaelum-512.png", "/img/brand/kaelum-maskable-512.png", "/img/brand/kaelum-180.png", "/img/brand/kaelum-64.png", "/img/dae-pcs.jpg", "/manifest.webmanifest"];
// v4.31 : installation tolérante (un fichier en échec ne bloque plus la mise à jour) et toujours depuis le réseau (jamais le cache du navigateur)
self.addEventListener("install", (e) => { self.skipWaiting(); e.waitUntil(caches.open(V).then((c) => Promise.all(SHELL.map((f) => fetch(f, { cache: "reload" }).then((r) => r.ok ? c.put(f, r) : null).catch(() => null))))); });
self.addEventListener("activate", (e) => {
  e.waitUntil(caches.keys().then((k) => Promise.all(k.filter((x) => x !== V).map((x) => caches.delete(x)))));
  self.clients.claim();
});
self.addEventListener("fetch", (e) => {
  const u = new URL(e.request.url);
  if (e.request.method !== "GET" || u.pathname.startsWith("/api/") || u.pathname.startsWith("/.netlify/") || u.pathname.startsWith("/doc/") || e.request.headers.has("range") || u.origin !== location.origin) return; // v5.93 : vidéo et documents hors cache du service worker
  // v4.15 : affichage instantané depuis le cache, mise à jour en arrière-plan (une nouvelle version déclenche le bandeau « Mettre à jour »)
  e.respondWith(caches.open(V).then(async (c) => {
    const hit = await c.match(e.request, { ignoreSearch: e.request.mode === "navigate" });
    const net = fetch(e.request).then((r) => { if (r.ok && r.type === "basic") c.put(e.request, r.clone()); return r; }).catch(() => hit || c.match("/index.html"));
    return hit || net;
  }));
});

// Notifications push : le téléphone reçoit un « réveil » et vient chercher le message (avec le jeton de l'agent)
self.addEventListener("push", (e) => {
  e.waitUntil((async () => {
    let d = { titre: "Kaelum e-PCS", texte: "Nouvelle notification", url: "/#/" };
    try {
      const r = await (await caches.open("ssiap-auth")).match("/jeton"); const tok = r ? await r.text() : "";
      const x = await fetch("/api/push/dernier", { headers: tok ? { authorization: "Bearer " + tok } : {} }); if (x.ok) d = await x.json();
    } catch {}
    await self.registration.showNotification(d.titre, { body: d.texte, icon: "/img/brand/kaelum-192.png", badge: "/img/brand/kaelum-64.png", tag: "ssiap-" + (d.t || Date.now()),
      renotify: true, requireInteraction: !!d.alerte, vibrate: d.alerte ? [400, 150, 400, 150, 800] : [200, 100, 200], data: { url: d.url || "/#/" } });
  })());
});
self.addEventListener("notificationclick", (e) => {
  e.notification.close();
  const url = (e.notification.data && e.notification.data.url) || "/#/";
  e.waitUntil(self.clients.matchAll({ type: "window", includeUncontrolled: true }).then((l) => { const c = l.find((x) => "focus" in x); if (c) { c.navigate(url).catch(() => {}); return c.focus(); } return self.clients.openWindow(url); }));
});
