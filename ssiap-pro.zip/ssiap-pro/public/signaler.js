// M Manager — page de signalement d'anomalie (QR code des bâtiments privés SPL, accès direct sans compte). Application créée par Rochdi Mecheti
(function () {
  const q = new URLSearchParams(location.search), s = q.get("s") || "", l = q.get("l") || "", k = q.get("k") || "";
  const app = document.getElementById("app"), esc = (t) => String(t ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  let nature = "", photo = "";
  const info = (t) => { app.innerHTML = `<div class="card"><h1>Signalement indisponible</h1><p>${esc(t)}</p></div>`; };
  const compacte = (file) => new Promise((ok, ko) => { const u = URL.createObjectURL(file), i = new Image();
    i.onload = () => { const m = 1280, r = Math.min(1, m / Math.max(i.width, i.height)), c = document.createElement("canvas"); c.width = Math.round(i.width * r); c.height = Math.round(i.height * r);
      c.getContext("2d").drawImage(i, 0, 0, c.width, c.height); URL.revokeObjectURL(u); let q2 = 0.78, d = c.toDataURL("image/jpeg", q2); while (d.length > 850000 && q2 > 0.4) { q2 -= 0.1; d = c.toDataURL("image/jpeg", q2); } ok(d); };
    i.onerror = () => { URL.revokeObjectURL(u); ko(new Error("Image illisible")); }; i.src = u; });
  fetch(`/api/signal/info?s=${encodeURIComponent(s)}&l=${encodeURIComponent(l)}&k=${encodeURIComponent(k)}`).then((r) => r.json()).then((d) => {
    if (!d.ok) return info("Ce QR code n'est pas reconnu ou a été remplacé. Prévenez le PC sécurité.");
    if (!d.actif) return info("Le signalement en ligne est momentanément fermé. Prévenez le PC sécurité.");
    const btns = (l2) => l2.map((n) => `<button type="button" data-n="${esc(n)}">${esc(n)}</button>`).join("");
    app.innerHTML = `<div class="card"><div class="lieu">${esc(d.lieu)} · ${/arena/i.test(d.site) ? "Arena Sud de France" : "Parc des Expositions"}</div>
      <h1>Signaler une anomalie</h1><p>Sûreté ou sécurité du bâtiment : le PC sécurité reçoit votre signalement immédiatement, avec le lieu.</p>
      <div class="gt">Sûreté</div><div class="grid">${btns(d.surete)}</div>
      <div class="gt">Sécurité</div><div class="grid">${btns(d.securite)}<button type="button" data-n="Autre anomalie">Autre anomalie</button></div>
      <label for="tx">Votre message <span id="cpt">0 / ${d.max}</span></label><textarea id="tx" maxlength="${d.max}" placeholder="Ce que vous constatez, l'endroit exact, depuis quand…"></textarea>
      <label>Photo (facultatif)</label><label class="ph"><input type="file" id="ph" accept="image/*" hidden><span id="phl">📷 Prendre ou choisir une photo</span></label><img id="phv" alt="" hidden>
      <label for="qui">Votre nom ou service (facultatif)</label><input id="qui" maxlength="80" placeholder="Ex. Atelier — M. Dupont">
      <label for="tel">Téléphone pour vous rappeler (facultatif)</label><input id="tel" type="tel" inputmode="tel" maxlength="20" placeholder="06 …">
      <button class="go" id="go" disabled>Envoyer au PC sécurité</button><div class="err" id="err"></div></div>`;
    const go = document.getElementById("go"), tx = document.getElementById("tx"), maj = () => { go.disabled = !nature; document.getElementById("cpt").textContent = `${tx.value.length} / ${d.max}`; };
    app.querySelectorAll(".grid").forEach((g) => (g.onclick = (e) => { const b = e.target.closest("[data-n]"); if (!b) return; nature = b.dataset.n; app.querySelectorAll("[data-n]").forEach((x) => x.classList.toggle("on", x === b)); maj(); }));
    tx.oninput = maj;
    document.getElementById("ph").onchange = async (e) => { const f = e.target.files[0]; if (!f) return; const lb = document.getElementById("phl"); lb.textContent = "Préparation de la photo…";
      try { photo = await compacte(f); const v = document.getElementById("phv"); v.src = photo; v.hidden = false; lb.textContent = "📷 Changer la photo"; } catch (er) { photo = ""; lb.textContent = er.message; } };
    go.onclick = async () => {
      const err = document.getElementById("err"); go.disabled = true; go.textContent = "Envoi…"; err.textContent = "";
      try {
        const r = await fetch("/api/signal", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ s, l, k, nature, texte: tx.value, photo, qui: document.getElementById("qui").value, tel: document.getElementById("tel").value }) });
        const d2 = await r.json().catch(() => ({})); if (!r.ok) throw new Error(d2.error || "Envoi impossible, réessayez");
        app.innerHTML = `<div class="card ok"><div class="big">Reçu</div><h1>Merci, le PC sécurité est prévenu</h1><p>Référence ${esc(d2.numero)}.</p><button class="go" id="encore" style="margin-top:16px">Faire un autre signalement</button></div>`; document.getElementById("encore").onclick = () => location.reload();
      } catch (e) { err.textContent = e.message; go.disabled = false; go.textContent = "Envoyer au PC sécurité"; }
    };
  }).catch(() => info("Connexion impossible. Vérifiez le réseau ou prévenez le PC sécurité."));
})();
