// Kaelum e-PCS — applique le thème, la marque (couleurs + logo) et la taille du texte avant l'affichage (pas de flash). Application créée par Rochdi Mecheti
var BRANDS = { kaelum: ["Kaelum", "#070b16"], mmanager: ["Rouge", "#0c0f14"], or: ["Or", "#0a0a0a"], emeraude: ["Émeraude", "#030a07"], violet: ["Violet", "#05040f"] };
window.BRANDS = BRANDS;
window.brandIcon = function (sz) { return "img/brand/" + (document.documentElement.dataset.brand || "kaelum") + "-" + (sz || 192) + ".png"; };
window.appliquerBrand = function (b) {
  if (!BRANDS[b]) b = "kaelum"; var r = document.documentElement; r.dataset.brand = b;
  try { localStorage.setItem("ssiap-brand", b); } catch (e) {}
  try {
    document.querySelectorAll("img[data-bi]").forEach(function (i) { i.src = window.brandIcon(+i.dataset.bi); });
    var ic = document.querySelector('link[rel="icon"]'); if (ic) ic.href = "img/brand/" + b + "-64.png";
    var ap = document.querySelector('link[rel="apple-touch-icon"]'); if (ap) ap.href = "img/brand/" + b + "-180.png";
    var mt = document.querySelector('meta[name="theme-color"]'); if (mt && r.dataset.theme !== "light") mt.content = BRANDS[b][1];
  } catch (e) {}
};
try { var c = JSON.parse(localStorage.getItem("ssiap-confort") || "{}"), l = c.theme === "clair" || (c.theme === "auto" && matchMedia("(prefers-color-scheme: light)").matches);
  document.documentElement.dataset.theme = l ? "light" : "dark"; document.documentElement.dataset.texte = c.texte || "normal"; } catch (e) {}
try { document.documentElement.dataset.brand = BRANDS[localStorage.getItem("ssiap-brand")] ? localStorage.getItem("ssiap-brand") : "kaelum"; } catch (e) { document.documentElement.dataset.brand = "kaelum"; }
document.addEventListener("DOMContentLoaded", function () { window.appliquerBrand(document.documentElement.dataset.brand); });
