#!/bin/sh
# Sources lisibles dans src/ → fichiers allégés dans public/ (à lancer avant de zipper)
E=${ESBUILD:-/opt/npm-tools/node_modules/.bin/esbuild}
cd "$(dirname "$0")"
for f in app textes memo rapports-types risques motivation mc-postes plan plan-arena sst planif-calc site preuve; do $E src/$f.js --minify --charset=utf8 --log-level=warning --outfile=public/$f.js --allow-overwrite || exit 1; done
$E src/app.css --minify --charset=utf8 --log-level=warning --outfile=public/app.css --allow-overwrite || exit 1
