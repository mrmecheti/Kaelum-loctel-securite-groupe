# SSIAP Pro

Application créée par Rochdi Mecheti.

Appli mobile (installable sur Android et iPhone) pour agents SSIAP / ADS, PC sécurité et administrateurs.

## v5.61 — Mode testeur

- Comptes marqués `testeur` : accès **24 h / 24**, tout consultable (lecture comme un responsable) et saisies comme un agent ; **planification** (planning général, planif, SMS, disponibilités grille, feuille de route, affectations) et **codes d'accès** (cadenas) refusés. Badge « 🧪 TESTEUR ».
- Activé pour Touzani Ludivine, Henry Samantha, Duguet Johan, Zgorski Anthony (comptes existants) avec notification « Bienvenue dans le mode testeur 24/24 heures » (push + message). Gestion dans Espace propriétaire → Mode testeur.

## v5.60 — Rochbot sans intelligence artificielle

- Rochbot ne fait plus **aucun appel à une IA** : aucun coût, aucune clé nécessaire. Il cherche dans une base d'aide intégrée (« comment faire… »), dans les procédures guidées, dans le menu de l'appli, et lit les données que la personne peut déjà voir (prochain service, consignes du jour, agents en poste, alertes en cours, points d'attention pour l'encadrement).
- Suppression : photo → analyse IA, actions préparées par IA, bouton « Tester Rochbot ».
- Le quiz SSIAP utilise une banque de 35 questions (plus de génération par IA).
- Seule fonction qui peut encore utiliser l'IA : la lecture d'une photo de commande (si la clé ANTHROPIC_API_KEY est présente) ; retirer la clé la désactive.

## v5.59 — Rochbot : diagnostic et modèle de secours

- Bouton « Tester Rochbot » dans l’Espace propriétaire ; messages d’erreur précis pour le propriétaire (clé refusée, crédit épuisé, modèle introuvable) ; essai automatique d’un autre modèle si le premier est introuvable.

## v5.58 — Créateur d'avatar

- **Créer mon avatar** (Menu → Mon espace, ou depuis « Ma photo de profil ») : genre, morphologie, couleur de peau, coiffure et couleur, barbe, lunettes, coiffe, tenue SSIAP / ADS / costume sans logo, épaulettes (grade), matériel (radio, oreillette, lampe, badge, gilet haute visibilité), fond. Bouton « Au hasard ».
- Dessiné en SVG ; « Utiliser comme ma photo de profil » le range comme photo de profil (visible par l'équipe seulement).

## v5.57 — Pour l'agent : quiz, mot du jour, photo → Rochbot

- **Quiz SSIAP** (#/quiz) : 5 questions QCM générées par Rochbot (banque de secours si pas de clé IA), explications, flammes.
- **Mot du jour** : publié par Rochdi/l'encadrement (Espace propriétaire), affiché en haut de l'accueil avec sa photo.
- **Photo → Rochbot** (📷) : analyse la photo côté sécurité et propose une saisie de main courante à valider.

## v5.56 — Rochbot agit et parle, compte rendu, espace propriétaire

- Rochbot : prépare une saisie de main courante, un appel à renfort ou une passation (validation obligatoire) ; micro 🎤 et réponse vocale 🔊 ; connaît les points d'attention.
- **Compte rendu de fin de vacation** (#/cr) généré automatiquement.
- **Espace propriétaire** (#/proprio) : chiffres clés, points d'attention (clés non rendues, faits ouverts), contrôle des numéros en double, rappel de ronde, **mode démo** (masque noms et numéros à l'écran).
- **Rappel de ronde** automatique (tâche toutes les 10 min, réglable dans l'espace propriétaire).

## v5.54 — Rochbot (assistant IA)

- Bulle « Rochbot » sur toutes les pages (hors clients) : répond à partir du planning de la personne, des consignes, alertes, agents en poste, procédures et du guide de l'appli.
- Nécessite la variable Netlify `ANTHROPIC_API_KEY` (déjà utilisée pour la lecture des commandes). Modèle : `ANTHROPIC_MODEL` (défaut claude-haiku-4-5). 40 questions/heure/personne.

## v5.53 — Accueil simplifié

- Accueil : Ma vacation, bouton Renfort, 8 gros boutons (Alerte, Main courante, Ronde, Planning, Position, Passation, Messages, PTI) et « Tout le menu ». Le reste (météo, flammes, accès rapides) est dans le Menu.

## v5.52 — Besoin de renfort + passation de vacation

- Accueil : bouton **🆘 Besoin de renfort** (position + notification forte à tous les collègues en service).
- **Passation de vacation** : un mot pour l'équipe suivante, visible 24 h, aperçu sur l'accueil.

## v5.51 — Positions partagées entre agents

- Menu « Site et moyens » → **Positions entre agents** : carte GPS (plan ou satellite), liste des positions reçues (valables 2 h), bouton « Itinéraire ».
- **Envoyer ma position** à un, plusieurs ou tous les collègues en service (message facultatif). Pas de suivi continu : la position part seulement au clic.
- **Alerte** : la position GPS de l'agent est jointe automatiquement ; bouton « Voir sur la carte » dans l'alerte.
- Réservé au personnel en service (pas aux clients ni aux agents hors vacation).

## v5.50 · Mise à jour des plannings d'octobre (exports Comète du 22/10)

- Arena Sud de France : 378 vacations. Parc des Expositions : 743 vacations. Import appliqué une seule fois (ids `arena-2026-10-v2210` et `parc-2026-10-v2210`), à la première connexion après la mise en ligne ; la planification interne (`planif`) est conservée.
- Une vacation inchangée (même jour, agent, horaires et poste) garde son identifiant, son rappel SMS et son téléphone.
- Contrôles faits avant livraison : heures par jour identiques à la ligne « Total » des PDF sur les 31 jours (Arena 3 104 h, Parc 6 981 h) et nombre de codes de vacation identique au tableau (Arena 378 + 1 vacation non affectée ignorée, Parc 743).
- Correction du numéro de M'hamed Saoudi (0619993785) dans l'annuaire, le planning et son compte, appliquée une seule fois (`saoudi-tel-2026-10`). Cause : le rapprochement de noms confondait « SAOUDI M'hamed » et « MACHKOKOT M Hamed » (même prénom), donc Saoudi recevait le numéro de Machkokot. Deux noms de famille différents ne se confondent plus (25 paires de faux rapprochements supprimées, aucune vraie correspondance perdue).
- La ligne générique « ADS 1 » de Comète (2 vacations Arena, 6 Parc) est importée telle quelle, comme avant.

## v5.49 · Lien public de disponibilités

- `dispo.html?m=AAAA-MM&k=…` : page publique (sans compte) où l'agent saisit nom, prénom et, pour chaque jour du mois, Jour / Nuit / 24h/24 / Pas dispo (+ remarque). Lien signé par mois (HMAC), 15 envois max par téléphone et par 15 min, un nouvel envoi remplace le précédent.
- Les réponses alimentent la grille centralisée existante (Disponibilités des agents) : cases 24h / J / N / ✖ modifiables à la main.
- Carte « Lien pour les agents » dans la grille : copier, partager, fermer / rouvrir le recueil du mois.
- Export PDF A4 paysage : grille 1er → dernier jour, totaux Dispo jour / Dispo nuit par jour, remarques, liste des agents sans réponse.
- API : `GET/POST /api/dispo-public` (public), `PUT /api/dispo-grille` (fermer/rouvrir), `PATCH` accepte `indispo`.

## v5.48 · Kaelum e-PCS + thèmes

- L'application s'appelle désormais **Kaelum e-PCS** (nom, icônes, manifests, pages publiques).
- 5 thèmes de marque : Kaelum (bleu/noir), Rouge, Or, Émeraude, Violet. Seul le propriétaire les change (Réglages > Thème de l'application), pour tous les utilisateurs et le PC sécurité. Stocké côté serveur (`theme_brand`), `GET /api/theme` public, `POST /api/theme` propriétaire.
- Les rouges d'alerte (SOS, urgences, erreurs) ne changent jamais de couleur.
- Finition visuelle : cartes, champs, focus, transitions.

## Ce qu'il y a dedans

- **Appels rapides** : Jérémy Mercher (Responsable d'exploitation), Alexandre Brand (chef de secteur), Fahd Haddouche, Laurent Hernandez, PC Sécurité. Les numéros ne sont jamais affichés : le téléphone les reçoit seulement au moment de l'appel.
- **Numéros d'urgence** : 18, 15, 17, 112, 114.
- **Météo en direct sur le Parc des Expositions de Pérols** : vent, pluie, orage, chaleur, froid/verglas, neige, brouillard, UV, plus la vigilance officielle Météo-France pour l'Hérault (crues, pluie-inondation, canicule…). Les prévisions viennent de MET Norway (institut météo norvégien), gratuites même pour un usage professionnel, sans clé ni compte.
- **Alertes par mail automatiques** toutes les 30 min à la liste de diffusion (Rochdi Mecheti, Alexandre Brand, Jérémy Mercher, Laurent Hernandez, à compléter dans Administration).
- **Main courante électronique (événementiel)** :
  - un événement par manifestation au Parc des Expositions ou à l'Arena (site, type, halls, organisateur, effectif, dates, responsable) ;
  - chaque saisie est numérotée automatiquement (MC-2026-0001…) et horodatée, avec catégorie, gravité, lieu, faits, intervenants, actions menées, photo et position GPS ;
  - suivi et clôture par le PC, recherche et filtres ;
  - **rapport imprimable / PDF** de l'événement, avec blocs de signature ;
  - une saisie « urgente » part aussi par mail.
- **Périmètre selon le poste au planning** : agent prévu au PCS Arena ➜ main courante PCS Arena (références SDFA) et ne voit / gère que les événements de l'Arena ; agent au P3 ➜ main courante P3, ne voit / gère que les saisies du P3 ; agent au portail ➜ idem portail ; SSIAP 2 du PC Parc ➜ voit et gère l'intégralité des événements, comme le PC (direct, fil de l'eau, rapports, statuts), sans les droits du propriétaire.
- **Main courante par poste** : 3 mains courantes reprenant les familles / types de la main courante Guardtek du site, avec priorité 1 à 4 (qui règle la gravité) : SSIAP 2 / PC (SST, Secours, Incendie, Sûreté, Exploitation, Contrôle d'accès, Contrôle réglementaire, Anomalie / Technique, DATI, REX), poste P3 avenue de l'Élevade (ADS contrôle d'accès entrée / sortie, dépôt de colis, prise et fin de service…) et portail / barrière prestataires (entrées / sorties prestataires, livraisons…), avec société et immatriculation ; plus la main courante générale. Le choix du poste est mémorisé sur le téléphone.
- **Mon service (agent)** : sur l'accueil, Prise de service et Fin de service en un clic, puis accès direct aux rapports Malaise, Incident, DI, Rixe, Intrusion et Forcing.
- **📋 Rapports terrain** (onglet Rapports) : 59 types classés en 6 familles, avec une recherche. Secours à personne (malaise, blessure / chute, arrêt cardiaque / DAE, secours extérieurs, ivresse, personne perdue) ; incendie / SSI (alarme et levée de doute, départ de feu, odeur de fumée ou de gaz, défaut SSI, isolement SSI, permis de feu, extincteur, issue de secours, désenfumage, personne bloquée dans un ascenseur, exercice, évacuation) ; sûreté (rixe, agression, insultes, harcèlement, intrusion, forcing, vol, dégradation, interpellation art. 73, comportement suspect, objet suspect, menace / alerte attentat, véhicule suspect, drone, rassemblement, vente à la sauvette, animal) ; accès / filtrage (refus d'entrée, objet interdit, billet ou badge frauduleux, livraison, clés et badges, jauge / foule, ouverture / fermeture) ; technique (DI, coupure électrique, fuite / inondation, porte trouvée ouverte, alarme intrusion, vidéo / radio) ; rondes / exploitation (ronde, relève, consigne, travaux, prestataire, météo, accident sur parking, réclamation, objet trouvé, incident, autre). Chaque type a ses propres questions. La liste est dans `public/rapports-types.js` (partagée par l'appli et le serveur). Numérotation par type (MAL-2026-0001…), jusqu'à 4 photos, position GPS, intervenants, prestataire concerné. À l'envoi : enregistré pour les responsables, noté en main courante et **envoyé par mail au PC sécurité (pcparc@spl-occitanie-events.com)** avec les photos, le nom de l'agent, son téléphone et **son poste du planning**.
- **📂 Documents PC sécurité** : plans des halls, consignes particulières, brief sécurité, feuille de route, fiche technique… en PDF, JPG ou PNG (4 Mo max.). Tout le monde les consulte dans l'appli (les PDF s'affichent page par page, téléchargement possible). **Seuls le propriétaire, le PC sécurité et Laurent Hernandez** (superviseur, coordinateur PC sécurité, rédacteur en chef — à déclarer dans Administration ➜ Rédacteurs) peuvent en téléverser ou en supprimer.
- **🙋 Disponibilités** : chaque agent (CDD, renforts…) coche ses qualifications (ADS, SSIAP 1, 2, 3) et ses jours disponibles du mois (jour, nuit, jour ou nuit, indisponible), pour le mois en cours et les 3 suivants, même hors vacation. Côté administrateur : vue par jour (qui est disponible, filtre par qualification, appel direct pour la coordination) et par agent ; la coordination « retient » un agent sur une date (il le voit sur son calendrier) et exporte le mois en CSV pour Excel / Comète. Hors vacation, un agent garde accès à son planning, ses disponibilités et sa fiche, rien d'autre.
- **📅 Mon planning** : chaque agent voit uniquement ses propres vacations, même hors vacation (affiché sur l'écran de connexion). Le planning complet reste réservé aux responsables et au PC.
- **Hiérarchie** (onglet Site ➜ Organisation du site) : Alexandre Brand, chef de secteur ; Jérémy Mercher, responsable d'exploitation et de planification, SSIAP 3 ; Fahd Haddouche, adjoint planification, SSIAP 2, chef d'équipe terrain ; Rochdi Mecheti, SSIAP 2 de nuit, SSIAP 3 terrain ; Laurent Hernandez, responsable PC Sécurité.
- **Coordination PC (Laurent Hernandez)** : bouton « 🗂️ Coordination PC » : numéros d'appel rapide, numéros des agents (annuaire SMS), adresse mail du PC, liste de diffusion, accès 24h/24, import du planning Comète. Rien d'autre (boutons, textes, zones, comptes, modèles de SMS, missions restent au propriétaire).
- **Droits** : le propriétaire (mr.mecheti@gmail.com) est le seul à pouvoir tout modifier (boutons, textes, zones, comptes, planning…). Les superviseurs voient tout 24h/24 sans rien modifier ; le rédacteur peut en plus téléverser des documents.
- **Client et prestataires** : client SPLOE (à part) ; prestataires : Colette, Sud Service, Solutions Mobilier, Orsa, Stocklight, Abiprint, SPIE, Nicollin Sécurité, YMCA, Traiteur Grand, Monsieur Louis, Traiteur Germain, Scène Expo, Iperion, Angle Vert, ASPPR, Les Ateliers d'Adages, Pousse Clanet, Durand Events, Otis, Cabiron, Croix-Rouge, Sécurité civile, SML, Orange, GL events, Husser, Loomis. Modifiables dans Administration.
- **Organisation du site** : Parc des Expositions (ERP type T) et Arena Sud de France (ERP type L), un même site exploité par la SPLOE, sécurité assurée par Nicollin Sécurité.
- **Rapports libres** : titre, texte, lieu, position et jusqu'à 4 photos. Chaque rapport, et chaque saisie de main courante, part **par mail au PC sécurité** (avec le nom et le poste planifié de l'agent) avec les photos en pièce jointe (adresse à régler dans Administration).
- **🛠️ Astreinte SPIE (défaut technique)** : dans le rapport DI, la référence à rappeler s'affiche selon le site (Parc Expo PEX S00M02_3595, Arena SDFA S00M02_2368) avec un bouton d'appel de l'astreinte (0 820 077 024) ; niveau d'intervention (non urgent, urgent sans déplacement, urgent avec déplacement d'astreinte — passe le rapport en urgent), n° d'appareil pour les ascenseurs ; fiche procédure dans le Mémo et bouton d'appel rapide « Astreinte SPIE ».
- **🏢 Ouverture / fermeture · éclairage** : tous les halls (Accueil A, A2 à A6, Accueil B, B1 à B5, Centre de conférences) et l'Arena. On choisit un ou plusieurs halls, l'opération (ouverture, fermeture, mise en fonction ou hors fonction de l'éclairage), à la demande de qui (prestataire de la liste, organisateur, SPL OE, PC sécurité, autre) et un commentaire facultatif ; date et heure automatiques. État actuel de chaque hall affiché, historique, fil de l'eau.
- **🚨 Alertes** (onglet Alerte) : agents en vacation, responsables, PC et propriétaire lancent une alerte (enfant perdu, personne recherchée, objet ou comportement suspect, véhicule recherché, évacuation, météo, autre) avec lieu et description. Bandeau rouge en haut de l'écran de tout le monde (mis à jour toutes les 30 s, vibration), mail au PC, disparition automatique au bout d'1 heure ou levée dès que c'est résolu.
- **📜 Fil de l'eau Parc / Arena** (responsables, PC, propriétaire) : tout ce qui se passe, dans l'ordre (main courante, prises de service, rapports, rondes, check-lists, clés, matériel, documents), avec barre de recherche (plusieurs mots), filtre Parc / Arena, filtre par type, période 24 h / 7 jours / 30 jours / date, export pour la coordination.
- **🔴 En direct** (responsables, PC, admin) : agents en service, faits non clos, fil des dernières 24 h, mis à jour toutes les 15 secondes.
- **Sites et zones** : Parc des Expositions (halls et accueils A / B, Centre de conférence, portails, Patte d'oie, portails internes P1 à P8 inter, parkings, 400) et Arena Sud de France (portes 1 à 8, PMR, PC Arena, portes grises, backstage, porte face au P3, cour de service, parkings, 400). L'agent choisit site + zone pour sa prise de service, sa main courante et ses rapports. La vue En direct se filtre par site. Seul le propriétaire modifie la liste (Administration ➜ Sites et zones).
- **🔑 Gestion des clés** : 137 clés déjà chargées (boîte à clés PC Parc / Arena, clés organisateurs Parc série 100, clés organisateurs Arena série 200). Boîte PC : remise à un agent Nicollin (liste des agents, ou nom tapé à la main), à la SPL OE ou à un prestataire, avec la manifestation ; clés orga : chef de projet événementiel, organisation / production, événement. Date et heure automatiques, retour en cochant « Clé rendue », recherche par numéro ou local, historique, export des clés sorties. Les agents en vacation enregistrent les mouvements ; responsables en lecture ; liste modifiable par le propriétaire et la coordination.
- **🧯 Ronde moyens de secours et d'extinction (SSIAP 1)** : check-list guidée de 18 points (extincteurs, RIA, DAE, DM, désenfumage, BAES, issues, dégagements, portes coupe-feu, traiteurs, colonnes sèches, voies engins, sprinklers, locaux à risques, plans), avec un bouton ⓘ qui explique chaque contrôle aux nouveaux agents ; fiche « guide du nouvel SSIAP 1 » dans le Mémo ; accès depuis l'onglet Rondes ; envoi au PC.
- **📦 Prêt de matériel** : 10 casques anti-bruit, 47 radios, 4 PTI (liste modifiable, « Autres » possible). Prêt à un agent (liste des agents ou nom tapé), case « En état de fonctionnement », date automatique ; retour en cochant « Matériel rendu » avec contrôle du fonctionnement. Un matériel rendu en panne passe « hors service » (mail au PC) jusqu'à sa remise en service. Compteurs de disponibilité, filtres, historique.
- **🔦 Rondes NFC** : parcours définis (ronde extérieure Parc 5 points, ronde Parc Expo 15 points, ronde Arena 18 points, déjà chargés avec les références des pointeaux existants). L'agent démarre sa ronde puis passe son téléphone sur chaque pointeau : Android lit directement le numéro du pointeau (Chrome, NFC activé) ; iPhone ouvre le lien écrit dans le pointeau avec NFC Tools ; QR de secours ; pointage à la main signalé si un pointeau est abîmé. Chaque pointage enregistre la position GPS du téléphone ; jusqu'à 3 photos par point (bouton 📷). Anomalie avec photo et position envoyée au PC, rapport de ronde automatique par mail (points oubliés, ordre, durée, liens carte, photos en pièces jointes). Parcours modifiables par le propriétaire et la coordination ; mode « 🎓 Apprendre » pour enregistrer sur le terrain des pointeaux dont on n'a pas le numéro (on scanne chaque pointeau avec un Android et on lui donne un nom) ; page d'impression des pointeaux.
- **Site T / L — événementiel** (Parc des Expositions et Arena) :
  - check-lists par fonction, envoyées par mail au PC (nom et poste de l'agent) : SSIAP 1 (prise de service / ouverture du salon, moyens d'extinction et de secours), SSIAP 2 (prise de poste PC / contrôle SSI), ADS selon le poste (fouille, gardiennage, contrôle d'accès, volant, accueil, contrôle de passe, sanitaires, accès privé, vigilance, parking), événement (ouverture au public, réception des stands, avant spectacle, montage / démontage, CTS, fermeture). La check-list correspondant au rôle de l'agent s'ouvre d'office ;
  - calcul d'effectif en type T, avec la catégorie et la limite des 1 500 personnes pour un chargé de sécurité SSIAP 3 ;
  - fiches réglementaires : type T, T 6, type L (L 14), CTS, GN 6, commission de sécurité (GE 4), missions SSIAP 3, coactivité.
- **Mémo SSIAP / ADS** : message d'alerte, levée de doute, extincteurs, SSI, ERP, missions SSIAP 1/2/3, droits de l'ADS, Vigipirate, secours à personne, météo…
- **Fiche de renseignement agent** : à sa première connexion, l'agent remplit nom, prénom, date de naissance (l'âge est calculé), adresse, téléphone, e-mail et diplômes avec leurs dates de recyclage. L'accès à l'appli est bloqué tant que la fiche n'est pas remplie.
- **Fiches agents** : alerte sur les diplômes expirés ou qui expirent dans les 60 jours (SSIAP, carte pro CNAPS, SST…). Responsables et admins voient toute la fiche ; le PC voit seulement le nom, le téléphone et les diplômes.
- **Planning & rappels de vacation** : les plannings d'octobre 2026 du Parc des Expositions et de l'Arena sont déjà chargés (841 vacations). Chaque mois, importe directement les **PDF Comète** (« Planning site par Agents et par Activités ») : l'appli lit la grille et la légende des codes (J…, N…), ignore les vacations non affectées, les congés et les formations. Tu peux aussi importer un fichier Excel ou CSV, ou faire un copier-coller. Vue jour par jour, et rappel SMS personnalisé pour chaque agent (heure, fin, poste, événement, consigne du poste). Le bouton **« Envoyer les rappels du jour »** enchaîne les agents un par un : tu valides le SMS, puis « Suivant ». Les rappels déjà envoyés sont marqués pour tout le PC. Chaque poste a une **mission prédéfinie** (contrôle d'accès, fouille, SSIAP, PC, parking, salle…), modifiable dans « Postes et missions ». Les SMS sont signés « Le PC Sécurité Parc des Expositions / Arena — 04 67 17 68 68 ». Le numéro est retrouvé automatiquement dans l'annuaire à partir du nom.
- **Notifications & historique** (administrateurs) : chaque action remonte en direct, avec une cloche 🔔 et un compteur (main courante, anomalies de ronde, check-lists, SMS envoyés, accès aux contacts, comptes, planning, connexions). L'historique complet est consultable et filtrable.
- **Prise de poste SMS** (PC, responsables, admin) : les numéros viennent des fiches des agents et d'un annuaire où l'on colle une liste de numéros. Envoi individuel personnalisé avec le prénom, ou SMS groupé à une sélection.
- **Administration** : comptes, contacts, liste de diffusion, points de ronde, journal.
- **Mode programmeur** (Administration) : modifie les intitulés et les textes des boutons sans toucher au code. Les changements s'appliquent sur tous les téléphones.

## Connexion et sécurité

- **Accès 24h/24 en lecture seule** : Administration ➜ « Accès 24h/24 », une adresse e-mail par ligne (bouton pour reprendre la liste de diffusion). Ces personnes créent leur compte avec cette adresse, sans code. Elles se connectent à toute heure et voient tout (en direct, main courante, rapports, notifications), mais ne peuvent **rien modifier ni saisir**.

- **Un seul propriétaire** : seul le compte **mr.mecheti@gmail.com** (connexion de secours `ADMIN_EMAIL` + `ADMIN_PASSWORD`) peut modifier l'application : administration, comptes, codes PIN, adresse du PC, contacts, intitulés, modèles de SMS, annuaire, missions des postes et import du planning. Les responsables et admins voient tout en direct mais ne modifient rien. Les saisies de main courante ne peuvent pas être modifiées ni supprimées : seuls un statut et des notes de suivi datées et signées peuvent y être ajoutés. Cette adresse est réservée et personne ne peut s'inscrire avec.

- **Accès selon le planning** : tout le monde peut créer son compte, mais un agent (ADS, SSIAP 1-2-3) ne peut se connecter **que pendant ses vacations** au planning, de 1 h avant à 1 h après. Il est reconnu par son téléphone ou son nom. En dehors, l'appli lui indique sa prochaine vacation, et il est déconnecté automatiquement à la fin. Pour un remplaçant non planifié : Administration ➜ Comptes ➜ « Accès hors planning ». Responsables, PC et admins ne sont pas concernés.

- **Deux codes PIN d'inscription** : le **PIN agents** donne un compte agent ; le **PIN responsables** donne directement un compte Responsable, qui voit tout en direct (Administration, cartes « Code PIN agents » et « Code PIN responsables »).
- **Inscription des agents** : sur l'écran de connexion, « Créer mon compte » (nom, prénom, e-mail, téléphone, qualification, mot de passe). L'inscription est **impossible sans le code d'accès** que le PC donne au briefing (Administration ➜ Code d'inscription des agents, modifiable ou à fermer à tout moment). Chaque inscription remonte dans les notifications ; un admin peut changer le rôle ou désactiver un compte.

- Connexion par **adresse e-mail + mot de passe** (6 caractères minimum). Après 5 erreurs, le compte est bloqué 10 minutes.
- **Mot de passe oublié** : un code à 6 chiffres est envoyé par mail, valable 15 minutes (ça passe par Brevo).
- **Code PIN interne** : il est demandé en plus pour ouvrir la Prise de poste SMS, les Fiches agents et le Planning, c'est-à-dire tout ce qui contient des numéros. L'accès reste ouvert 4 h ou jusqu'à la fermeture de l'appli, et le bouton « 🔒 Verrouiller » le referme tout de suite. Chaque ouverture et chaque code faux sont notés dans le journal.

## Qui voit quoi

| Rôle | Voit |
|---|---|
| ADS / SSIAP 1-2-3 | Uniquement ses propres signalements et rondes |
| PC Sécurité | Tout, la prise de poste SMS, et des fiches agents seulement le nom, le téléphone et les diplômes |
| Responsable | Comme le PC, plus les fiches agents complètes |
| Admin | Tout, plus l'administration |

Les droits sont vérifiés côté serveur : un agent ne peut pas récupérer les données des autres, même en bidouillant.

## Mise en ligne (Netlify, gratuit)

Le glisser-déposer simple de Netlify ne prend pas les fonctions serveur. Passe plutôt par GitHub :

1. Crée un compte sur **github.com**, puis un nouveau dépôt (ex. `ssiap-pro`, privé). Fais « Add file → Upload files » et dépose tout le contenu du dossier dézippé.
2. Sur **netlify.com** : « Add new site → Import an existing project → GitHub » et choisis le dépôt. Laisse les réglages par défaut, puis « Deploy ».
3. Dans Netlify : **Site configuration → Environment variables**, ajoute :

| Variable | Valeur |
|---|---|
| `APP_SECRET` | une longue phrase aléatoire (40 caractères ou plus) |
| `ADMIN_EMAIL` | `mr.mecheti@gmail.com` (connexion admin de secours) |
| `ADMIN_PASSWORD` | ton mot de passe admin de secours (long et unique) |
| `BREVO_API_KEY` | ta clé API Brevo (voir plus bas) |
| `MAIL_FROM` | `mr.mecheti@gmail.com` (adresse validée dans Brevo) |
| `MF_API_KEY` | facultatif, clé Météo-France pour la vigilance officielle |

4. **Deploys → Trigger deploy** pour prendre en compte les variables.

### Premier lancement

1. Ouvre l'appli et connecte-toi avec `ADMIN_EMAIL` et `ADMIN_PASSWORD`.
2. Va dans Administration et crée les comptes avec l'adresse e-mail, le nom et le rôle. **Le mot de passe est généré et envoyé automatiquement à cette adresse.** Sans adresse e-mail, pas de compte. Le bouton ✉️ renvoie un nouveau mot de passe.
   Les administrateurs prévus : Administrateur (toi), PCS Sécurité, Jérémy Mercher, Alexandre Brand, Laurent Hernandez.
3. Dans Administration ➜ Code d'accès aux contacts, choisis le code secret. Sans lui, personne n'ouvre la Prise de poste SMS ni les Fiches agents. Donne-le uniquement aux personnes habilitées.
4. Renseigne les numéros dans « Contacts d'appel » et les mails de la liste de diffusion.
5. Clique sur « Mail de test ».

### Mails (Brevo, gratuit jusqu'à 300 mails/jour)

Crée un compte sur brevo.com. Dans **Senders**, ajoute et valide `mr.mecheti@gmail.com`, puis copie une clé dans **SMTP & API → API Keys** et colle-la dans `BREVO_API_KEY`.

Avec une adresse Gmail comme expéditeur, les premiers mails peuvent arriver en spam : marque-les « Non spam ». Avec un nom de domaine à toi, c'est plus fiable.

### Vigilance Météo-France (facultatif)

Crée un compte sur portail-api.meteofrance.fr, abonne-toi à l'API « Vigilance » et génère une clé API. Colle-la dans `MF_API_KEY`. Sans cette clé, les alertes sur seuils (vent, pluie, orage, chaleur…) fonctionnent quand même.

## Installer sur le téléphone

- **iPhone** : ouvrir dans Safari → Partager → « Sur l'écran d'accueil ».
- **Android** : Chrome → menu ⋮ → « Installer l'application ».

## Modifier l'appli toi-même

- **Textes et boutons** : Administration ➜ Mode programmeur, depuis le téléphone.
- **Directement dans le code**, sur GitHub (crayon ✏️ sur le fichier, puis « Commit changes » ; Netlify remet le site en ligne tout seul en 1 minute environ) :
  - `public/textes.js` : tous les intitulés par défaut ;
  - `public/memo.js` : les fiches du mémo SSIAP / ADS ;
  - `public/site.js` : les fiches type T / L et les check-lists ;
  - `public/img/hero.jpg` : la photo d'entête, et `public/img/logo-societe.jpg` : le logo. Pour les changer, remplace le fichier en gardant le même nom.
  - `public/app.css` : les couleurs, en haut du fichier (`--red`, etc.).
  - `netlify/lib/planning-initial.json` : le planning d'octobre 2026, préchargé (côté serveur, non téléchargeable).
  - `public/vendor/pdfjs/` : la bibliothèque pdf.js (licence Apache 2.0) qui lit les PDF sur le téléphone.
  - `netlify/lib/annuaire-initial.json` : la liste des agents pour les SMS (importée de ton fichier de contacts). Elle ne sert qu'au premier lancement : ensuite, l'annuaire se gère dans l'appli. Ce fichier reste côté serveur, il n'est jamais téléchargeable depuis le site. **Garde le dépôt GitHub en privé.**

## Régler les seuils d'alerte

Dans `netlify/lib/meteo.mjs`, objet `SEUILS`. Exemple : `rafales: [50, 70, 90]` correspond aux niveaux jaune, orange et rouge en km/h.

## v3.33 — Main courante selon le poste du planning
- Le poste de la vacation en cours fixe la main courante de l'agent : SSIAP 2 PCS Arena, SSIAP 2 PC Parc, SSIAP 3 (tâches d'encadrement en plus), SSIAP 1, SSIAP 1 volant, ADS, ADS volant, Poste P3, Portail.
- Les volants (SSIAP 1 / ADS) ont en plus la famille « Pauses ».
- Poste P3 : prise / fin de service, contrôle d'accès entrée / sortie, dépôt ou refus de colis, rapport libre.
- L'administrateur, le PC et le SSIAP 2 du PC Parc gardent toutes les mains courantes.
- Jusqu'à 4 photos sur chaque saisie de main courante (rapport libre compris), envoyées au PC en pièce jointe.

## v3.34 — Demandes de DPAE (SSIAP 3)
- Plus ➜ « Demandes de DPAE » : le SSIAP 3 (qualification ou poste du planning) choisit un agent de la liste ou crée un nouvel agent (ajouté à la liste).
- Pré-remplissage depuis la fiche de renseignement quand elle existe.
- Envoi par mail au service qui fait la DPAE (adresse réglable par le propriétaire / coordinateur PC, par défaut le propriétaire). Suivi « demandée / faite / annulée ».
- Le n° de sécurité sociale part seulement dans le mail, il n'est pas conservé. Les autres agents n'ont pas accès aux demandes.

## v3.35 — Équipe ADS Arena par groupe (coordinateur Arena)
- Un agent dont le poste au planning contient « COORD » à l'Arena est coordinateur Arena pour sa vacation : bouton « Mon équipe ADS Arena par groupe » à l'accueil.
- Il voit les ADS du planning Arena du jour de sa mission, rangés en 8 groupes : Portes fouilles, Bord terrain, Intervention, Parterre, Entrée joueurs, Accès artistes, Crash, Loges VIP partenaires (+ « À placer »).
- Placement automatique selon l'intitulé du poste, changement de groupe, nombre d'ADS requis par groupe (manques en rouge), ajout d'ADS de la liste ou à la main, retrait / remise, bouton d'appel.
- Le PC, le propriétaire et le coordinateur PC y ont accès pour n'importe quel jour ; les responsables en lecture.

## v3.36 — Dossier des agents
- Plus ➜ « Mon dossier » (aussi hors vacation) : chaque agent dépose ses documents en photo ou PDF (4 Mo max.) avec n°, date d'obtention et échéance (calculée automatiquement : carte pro 5 ans, recyclage SSIAP et habilitation électrique 3 ans, SST 2 ans, visite médicale 2 ans — modifiable).
- Types : diplômes initiaux ADS, SSIAP 1, 2, 3 ; carte pro CNAPS ; recyclage SSIAP ; habilitation électrique ; SST / MAC SST ; visite médicale ; autre.
- Documents obligatoires selon la qualification ; visite médicale en plus pour l'équipe du PCS (Mercher SSIAP 3, Hernandez, Négrier, Bourg, Gomez, Mecheti SSIAP 2 — liste modifiable par le propriétaire).
- Plus ➜ « Dossiers des agents » (PC, responsables, coordinateur PC, propriétaire) : manquants, expirés, à renouveler sous 60 jours. Le propriétaire et le coordinateur PC peuvent ajouter ou supprimer un document pour un agent.
- La visite médicale ne s'ouvre que pour l'agent, le propriétaire et le coordinateur PC.

## v3.37 — PC sécurité administrateur
- pcparc@spl-occitanie-events.com a le rôle Administrateur : voit et fait tout (main courante, rapports, dossiers des agents avec visite médicale, DPAE, équipe Arena, numéros, mails, planning).
- L'écran Administration (comptes, codes, boutons, liste des administrateurs) reste réservé au propriétaire. Liste des administrateurs modifiable dans Administration ➜ 🛡️ Administrateurs.

## v3.38 — Lecture réglementaire des dossiers et alertes
- Chaque obligation est calculée selon la réglementation :
  - SSIAP : recyclage tous les 3 ans depuis le diplôme ou le dernier recyclage / RAN (arrêté du 2 mai 2005, art. 7) ; dépassé ➜ remise à niveau obligatoire.
  - Secourisme SST (MAC tous les 24 mois) ou PSE1 (formation continue annuelle), exigé pour le recyclage SSIAP.
  - Habilitation électrique : recyclage recommandé tous les 3 ans (NF C 18-510).
  - Carte pro CNAPS : 5 ans, renouvellement au plus tard 3 mois avant l'échéance, MAC APS préalable.
  - Visite médicale (équipe PCS) : au plus tous les 5 ans, 3 ans pour le travail de nuit (R4624-17 / R4624-18).
- Une échéance saisie au-delà de la durée réglementaire est ramenée à la date réglementaire.
- Pour chaque document : statut, action à faire, date conseillée, référence du texte.
- Fonction planifiée `dossiers-alertes` (tous les matins) : mail au PC sécurité (adresse du PC) et au coordinateur PC (Laurent Hernandez) + notification, à J-150 (carte pro), J-90, 60, 30, 15, 7, puis chaque semaine si expiré. Bouton « Envoyer un essai » dans Dossiers des agents.

## v3.39 — Nouvelle icône
- Icône SSIAP Pro (pompier, flamme, bâtiment) : écran d'accueil Android (normale + adaptative), iPhone (apple-touch-icon), onglet du navigateur et logo de l'en-tête.

## v3.40 — Main courante archivée par mois
- La main courante est rangée par mois (`mc/AAAA-MM`) : plus aucune saisie effacée (avant : 5 000 dernières seulement). L'appli ne charge que le mois en cours et le précédent ; les archives s'ouvrent à la demande.
- Migration automatique au premier lancement, avec copie de sécurité de l'ancienne liste (`incidents_avant_archivage`).
- Main courante ➜ 📦 Archives : liste des mois, consultation, téléchargement Excel (CSV), envoi de la copie par mail, essai.
- Fonction planifiée `mc-copie-mensuelle` (le 1er du mois) : copie du mois écoulé au PC sécurité et au coordinateur PC (CSV Excel + version imprimable HTML ➜ PDF).
- Durée de conservation réglable par le propriétaire (par défaut désactivée ; proposé : 5 ans, photos 3 ans).

## v3.41 — Plan du site interactif
- Site ➜ 🗺️ Plan du site (aussi dans Plus) : plan de masse redessiné (halls A1-A6, B1-B5, accueils A/B, centre de conférences, Arena, parkings 1A/2A/3A/4A/1B/2B/3B/TAM, Portail 3, allées, entrées A/B) d'après le plan SPLOE. Zoom à deux doigts, déplacement, boutons ➕ ➖ ⟲.
- Sur le plan : ouvert / fermé, éclairage, nombre de faits ouverts par hall.
- Toucher une zone ➜ fiche : type ERP, surface ou places, état, faits ouverts, clés du hall (sorties ou non), fiche sécurité (effectif, SSI, DAE, RIA, coupures, issues, consignes), raccourcis main courante pré-remplie, ouverture / fermeture, clés.
- Fiche sécurité complétée par le propriétaire, le PC (admin) et le coordinateur PC. Hall A1 ajouté aux zones et à l'écran Bâtiments.

## v3.42 — DAE et ADS de l'Arena sur le plan
- DAE du site sur le plan (❤ vert) : service d'exploitation, accueil B ; DAE du PCS (au fond de l'accueil, à gauche) listé, à placer dès que l'accueil est confirmé. Fiches sécurité pré-remplies.
- Fiche Arena : ADS du jour repris automatiquement du planning, rangés par groupe (portes fouilles, bord terrain, intervention, parterre, entrée joueurs, accès artistes, crash, loges VIP) avec la répartition du coordinateur.
- Fiche hall : agents prévus aujourd'hui dont le poste du planning cite le hall.

## v3.43
- Plan du site : plus de clés dans les fiches des halls et de l'Arena (la gestion des clés reste dans son écran).

## v3.44
- DAE du PCS : « dans le couloir du PC sécurité ».
- Plan : le propriétaire, le PC et le coordinateur PC peuvent placer ou déplacer un DAE (📍 dans la liste des DAE, puis toucher l'endroit sur le plan).

## v3.45
- Jérémy Bourg (jeremy.bourg@sfr.fr), responsable PCS journée, administrateur ; ajouté aux contacts et à l'organisation du site. Un administrateur se connecte à toute heure (pas de restriction de vacation).

## v3.46 — Thème professionnel
- Icônes au trait (SVG) à la place des émojis : barre d'onglets, cloche, tuiles, actions rapides, appels.
- Émojis décoratifs retirés partout ; les pastilles d'état (vert / orange / rouge / gris) deviennent des points de couleur sobres.
- Palette graphite, accent rouge réservé aux actions principales et à l'onglet actif, angles plus droits, typographie système.
- Grand visuel du Parc uniquement sur l'écran de connexion ; une fois connecté, en-tête fin (logo + SSIAP PRO + notifications). Fond « pièce Nicollin » retiré.

## v3.47 — Icônes des rapports, gravité en couleurs, notifications sonores
- 60 types de rapports avec une icône au trait chacun, colorée selon la gravité par défaut : vert (info), orange (moyenne), rouge (urgente). Même chose sur les actions rapides de l'accueil.
- Gravité de la main courante et urgence des rapports : boutons vert / orange / rouge ; badges aux mêmes couleurs.
- Fond : logo Nicollin conservé (plus discret).
- Notifications sonores : sirène + vibration à l'arrivée d'une alerte, carillon pour les notifications du PC ; notifications push (Web Push VAPID, clés générées automatiquement) quand l'appli est fermée ou le téléphone en veille : alertes pour les agents en vacation, faits urgents pour le PC et les responsables. Carte « Notifications sonores » à l'accueil, bouton activer / tester dans Plus. iPhone : appli installée sur l'écran d'accueil requise (iOS 16.4+).

## v3.48 — Plan du site professionnel
- Contours des halls relevés sur le plan de masse SPLOE (formes réelles : A2 arrondi, B3, B4, accueil A…), espaces verts et bassin tracés d'après le plan.
- Style plan technique : bâtiments en teinte de zone (B ocre, A et Arena carmin) avec filets fins, parkings hachurés, voirie avec axe, libellés en capitales, entrées A / B, Portail 3.
- Carroyage A–H / 1–19 (≈ 67 m) pour guider par radio (« Hall B2, carreau F8 »), échelle dynamique, outils zoom / recentrer / plein écran, calques (carroyage, parkings, DAE, voirie), légende, cartouche.
- Pictogramme DAE normalisé (vert, cœur + éclair).
- Fiche de zone : type ERP, carreau, surface, état ouvert / éclairage, faits ouverts (couleur de gravité), agents prévus, fiche sécurité (+ point de rassemblement).

## v3.49 — Planification (type Comète)
- Plus ➜ Planification (et accueil) : planning hebdomadaire par agent (grille lundi → dimanche, total d'heures), filtres Parc / Arena, recherche.
- Accès : Jérémy Mercher et Alexandre Brand (planificateurs, liste d'adresses réglable par le propriétaire dans Administration), le propriétaire ; administrateurs et coordinateur PC en lecture seule. Accessible aussi hors vacation pour les planificateurs.
- Téléversement des plannings (PDF Comète, Excel, CSV) : les vacations téléversées sont verrouillées, jamais modifiées ; le mode « remplacer » conserve les vacations saisies.
- Ajout / modification / suppression des vacations saisies par la planification.
- Contrôles signalés en rouge (sans rien modifier) : 48 h max par semaine, 11 h de repos entre deux vacations, un dimanche sur deux libre, 12 h max par vacation (vacations enchaînées cumulées), chevauchements ; en orange : 7 jours de suite, moyenne > 46 h sur 12 semaines (Code du travail, CCN Prévention-sécurité brochure 3196).
- Devis : lignes par qualification, date et horaires, calcul des heures (nuit / dimanche / férié), taux horaire libre par ligne ou grille, frais, remise, TVA, statut, impression PDF avec visa client.
- Tarifs : grille par qualification et majorations (champs libres), plage de nuit, TVA.

## v3.50 — DAE géolocalisé, DPAE dans le planning
- DAE du PC sécurité : photo (couloir du PC, au mur près du déclencheur manuel), fiche DAE avec carreau, coordonnées GPS, précision, distance et direction depuis le téléphone, itinéraire à pied (Google Maps). Bouton « Relever la position GPS ici » (relevé de 8 s, meilleure précision gardée) pour le propriétaire, le PC et le coordinateur.
- Planification : noms des agents en vert (DPAE faite) ou rouge (pas de DPAE) dans la grille ; nouvel onglet « Agents » : liste de tous les agents avec statut DPAE, n°, date d'embauche, heures de la semaine, filtres Tous / DPAE / Sans DPAE.

## v3.51 — Onglet Planif. et validation
- Onglet « Planif. » dans la barre du haut pour les personnes qui ont accès à la planification.
- Rédacteurs : Jérémy Bourg et Laurent Hernandez (liste réglable dans Administration) peuvent ajouter, modifier ou demander la suppression de vacations : c'est enregistré mais pas publié tant que Jérémy Mercher (planificateur) n'a pas validé. Notification au planificateur.
- Onglet « À valider » : valider et publier, refuser avec motif, retirer, tout valider. Les saisies en attente apparaissent en orange pointillé dans la grille, les suppressions demandées barrées.
- Devis, tarifs et téléversement restent réservés aux planificateurs.

## v3.52 — Diagnostic des notifications
- Plus ➜ Notifications sonores : vérification point par point (appli installée, autorisation, service en arrière-plan, abonnement), test local sans serveur, test complet via le serveur avec la réponse du service de notification (Apple / Google / Mozilla / Microsoft), réactivation de l'abonnement. Journal des envois côté serveur.

## v3.53 — Alerte forcée
- Case « Alerte forcée » (cochée par défaut) au lancement d'une alerte : plein écran rouge clignotant et sirène toutes les 4 s sur chaque téléphone en service, jusqu'au bouton « Je confirme la réception ».
- Notification push « ALERTE FORCÉE », puis rappel toutes les 2 minutes (5 fois au plus) aux téléphones qui n'ont pas confirmé (fonction planifiée `alertes-relance`).
- Liste des confirmations (qui a vu l'alerte) dans l'onglet Alerte.

## v3.54 — Planning mensuel, codes couleur, tarification ouverte
- Planning affiché par mois (navigation mois par mois), vue semaine toujours disponible ; page élargie sur ordinateur.
- Codes couleur : jour (neutre), nuit 21 h – 6 h (bleu), samedi / dimanche / férié (violet), colonnes week-end et fériés teintées ; couleur par événement (liseré + légende).
- Tarification et devis modifiables aussi par Jérémy Bourg, Laurent Hernandez et le PC sécurité. TVA supprimée : devis en hors taxes.
- Grille : colonne « Chef d'équipe » (€ HT / h) par qualification ; case « CE » sur chaque ligne de devis.
- DPAE oui / non uniquement dans la liste des agents (retirée de la grille) ; numéros de téléphone de tous les agents (fiches, comptes, annuaire, plannings) avec appel direct.

## v3.55 — Planification : onglet « Postes » (glisser-déposer)
- Création des postes (date, horaires, intitulé, site, événement, qualification, nombre d'agents), avec répétition jour par jour.
- Compteurs : postes · fait (pourvus) · pas fait (agents manquants) · prestations non planifiées (lignes des devis acceptés sans poste, création en un clic).
- Liste des agents à glisser sur les postes (ou toucher l'agent puis la case sur téléphone), heures déjà prévues affichées, contrôles réglementaires avant affectation.
- Brouillon enregistré pour l'équipe (Jérémy Bourg, Laurent Hernandez) : invisible des agents.
- Publication finale réservée aux valideurs (Jérémy Mercher, Alexandre Brand, propriétaire) : crée les vacations visibles dans le planning des agents.

## v3.56 — Messagerie PC ⇄ agents (bulle de discussion)
- Bulle rouge en bas à droite avec compteur de messages non lus, son et notification push.
- Agent : une conversation avec le PC sécurité, uniquement pendant sa vacation (1 h avant à 1 h après) ; texte + photo.
- PC sécurité / administrateurs / SSIAP 2 du PC en vacation : liste des agents en vacation, conversations, message à tous les agents en service, photos.
- Le PC ne peut écrire qu'aux agents en vacation ; hors vacation, l'historique reste en lecture. Responsables : lecture seule.

## v3.57 — Devis SSIAP Pro : calcul à l'événement ou au mois
- Devis, plan et mails : en-tête et signature « SSIAP Pro » (Nicollin Sécurité retiré des documents).
- Choix du calcul : « À l'événement » (chaque poste du … au …) ou « Au mois » (mois choisi + jours de la semaine cochés L M M J V S D).
- Dimanches, jours fériés et heures de nuit majorés automatiquement jour par jour.
- Récapitulatif par qualification (agents, vacations, heures, montant HT) à l'écran et sur le PDF.
- Postes : les devis acceptés sur plusieurs jours ou au mois créent un poste par jour (« Créer tous les postes du devis »).

## v3.58 — Présentation : historique et exemples
- Messagerie retirée.
- Fil de l'eau : carte « Historique · présentation » réservée au propriétaire et aux administrateurs.
  - Créer des exemples avec les vrais agents du planning (main courante, rapports, ronde, check-list, clés, bâtiment, alerte levée), marqués comme exemples.
  - Retirer les exemples.
  - Supprimer tout l'historique (confirmation « SUPPRIMER ») : main courante, rapports, rondes, check-lists, clés, matériel, bâtiments, alertes, notifications. Planning, comptes, documents, dossiers et devis conservés.

## v3.59 — Sauvegarde complète des données
- Administration (propriétaire uniquement) : « Télécharger la sauvegarde » → un fichier JSON avec toutes les données stockées (comptes, planning, main courante, rapports, rondes, clés, documents, dossiers, photos, devis, tarifs, réglages).
- Non exportés : clé privée des notifications et codes de réinitialisation. Chaque sauvegarde est notée dans l'historique.

## v3.60 — Vider les notifications
- Bouton « Tout effacer » dans Notifications et « Vider les notifications (cloche) » dans la carte Historique du Fil de l'eau : propriétaire et administrateurs uniquement.

## v3.61 — Identité SSIAP Pro
- Logo SSIAP Pro en photo de couverture (écran de connexion) et en fond d'écran, à la place des visuels Nicollin (supprimés de l'appli).

## v3.62 — Libellés
- « Agent Nicollin » devient « Agent sécurité » (registre des clés) ; fiche d'info du site sans mention de Nicollin.

## v3.63 — Objets trouvés, présences, bilan du mois, dictée vocale
- **Objets trouvés** : enregistrement avec photo, numéro OT-AAAA-NNNN à coller sur l'étiquette, lieu, rangement ; restitution avec nom, pièce d'identité et signature sur l'écran ; autres suites (police, organisateur, destruction). Visible dans le fil de l'eau.
- **Présences (émargement)** : le planning du jour comparé aux prises et fins de service ; présents, retards (> 10 min), absents (> 30 min), terminés ; actualisation automatique.
- **Bilan du mois** : chiffres clés (main courante, rapports, rondes, alertes, moyens, heures d'agents) à l'écran et en PDF ; joint automatiquement au mail mensuel du 1er.
- **Dictée vocale** : bouton « Dicter » sous chaque zone de texte (main courante, rapports…), en français.

## v3.64 — Planification protégée par un code
- Planif. (planning, postes, validation, contrôles, devis, tarifs) demande un code d'accès à tout le monde, propriétaire compris. Vérifié par le serveur : sans le code, aucune donnée n'est envoyée.
- Ouvert 4 h sur le téléphone ou jusqu'à la fermeture de l'appli ; bouton « Verrouiller » ; 5 erreurs = blocage 15 minutes ; chaque ouverture et chaque erreur est notée dans les notifications.
- Le code n'est pas écrit en clair dans le code source (empreinte). Le propriétaire peut le changer dans Administration.

## v3.65 — Confidentialité des agents
- Un agent ne voit que **son** planning, **ses** saisies de main courante, **ses** rapports, rondes, check-lists, objets trouvés, mouvements de clés, de matériel et de bâtiments.
- Seul le PC sécurité (PC Parc, et PC Arena pour l'Arena) voit ce que font les autres. Les agents P3 et portail ne voient plus les saisies de leurs collègues.
- Tableau des clés : plus de téléphone ni de pièce d'identité des personnes affiché aux agents ; liste des noms d'agents réservée au PC.
- DPAE (SSIAP 3) : le SSIAP 3 ne voit que ses propres demandes et seulement les noms des agents ; les coordonnées sont ajoutées par le serveur depuis la fiche de l'agent.

## v3.66 — Planification simplifiée et automatique, accès SSIAP 3 / administrateurs
- Accès à la planification (planning, postes, devis, tarifs, disponibilités, import) : SSIAP 3, planificateurs et administrateurs uniquement (propriétaire compris). Le compte PC sécurité et les autres n'y ont plus accès, même avec le code.
- PC sécurité : « Agents du jour » seulement (aujourd'hui), plus de planning général.
- Nouvel onglet **Accueil** : chiffres des 7 / 14 / 31 prochains jours (places à pourvoir, postes complets, alertes réglementaires, heures, agents), jours où il manque du monde, charge de la semaine (barre 48 h), alertes.
- **Remplissage automatique** : en un clic, chaque place libre reçoit l'agent qualifié, disponible, qui connaît le poste et a le moins d'heures, sans dépasser 48 h, 12 h, 11 h de repos ni un dimanche sur deux. Propositions en pointillés, en brouillon, à vérifier puis publier.
- Onglets réduits : Accueil, Planning, Postes, Devis, Tarifs (+ À valider, Agents, Contrôles en petit).

## v3.67 — Laurent Hernandez co-propriétaire
- Laurent Hernandez (courrier.laurent@free.fr) a le même niveau que le propriétaire : Administration, réglages, codes, planification (valideur), sauvegarde, historique.
- Liste modifiable sans toucher au code avec la variable Netlify `CO_OWNER_EMAILS` (adresses séparées par des virgules).

## v3.68 — Co-propriétaire : accès total vérifié
- Laurent Hernandez : accès à toutes les pages et fonctions (fil de l'eau, direct, présences, bilan, objets, dossiers, administration, sauvegarde, historique, planification, disponibilités, notifications).
- Correctif : son « Mon planning » affiche bien ses propres vacations.

## v3.69 — Mode crise, consignes avec accusé de lecture, mode hors ligne, co-propriétaires
- **Mode crise** (évacuation, confinement, attentat, incendie…) : écran rouge plein écran + sirène sur tous les téléphones en service ; chaque agent répond en un geste (reçu, en position, zone évacuée, besoin d'aide + position GPS) ; tableau d'appel en direct pour le PC, consignes envoyées à tous, chronomètre, bilan de fin ; début et fin notés automatiquement dans la main courante.
- **Consignes du jour** : le PC diffuse une consigne (Parc, Arena ou tous, dates) ; chaque agent la reçoit en plein écran et confirme « J'ai lu et compris » ; le PC voit qui l'a lue et qui ne l'a pas encore lue parmi les agents en service.
- **Mode hors ligne** : sans réseau (halls en béton…), main courante, rapports et objets trouvés sont gardés sur le téléphone avec l'heure réelle et partent tout seuls au retour du réseau (bandeau orange).
- **Co-propriétaires** réglables dans Administration (adresses e-mail) ; seul le propriétaire principal modifie la liste.

## v3.70 — Accès total en un geste (Mercher, Brand)
- Administration › Co-propriétaires : les comptes de Jérémy Mercher et Alexandre Brand sont repérés automatiquement ; bouton « Donner l'accès total » après vérification de l'adresse (protection contre un faux compte au même nom).

## v3.71 — Un seul propriétaire, droits du planning
- Rochdi Mecheti est le seul propriétaire (fin des co-propriétaires).
- Administrateurs : prise de poste SMS, fiches agents et planning du jour sans code des contacts.
- Planning : seuls Jérémy Mercher et Alexandre Brand (et le propriétaire) créent, modifient, suppriment et publient ; postes, remplissage automatique, import, validation.
- Laurent Hernandez : uniquement le planning du PC Parc (SSIAP 2 jour / nuit), ses saisies partent en validation chez Jérémy Mercher ou Alexandre Brand.
- Administrateurs et SSIAP 3 : planification en lecture (devis et tarifs modifiables par les administrateurs).

## v3.72 — Habilitations professionnelles
- Nouvelle page **Habilitations** (Plus) : modules autorisés pour les agents par qualification (ADS, SSIAP 1, 2, 3) avec interrupteurs : main courante, rapports, rondes, lancer une alerte, clés, matériel, bâtiments, objets trouvés, jauge, plan, documents, mémo, disponibilités.
- Vérifié par le serveur (module refusé même hors de l'appli) et caché dans l'appli ; prise / fin de service et réception des alertes toujours possibles ; chaque modification tracée.
- **Matrice des droits par profil** (propriétaire, planificateurs, administrateurs, SSIAP 2 du PC, Laurent, responsables, coordinateur Arena, agents).
- Réglage par le propriétaire uniquement ; consultation par le PC, les administrateurs et la coordination.

## v3.73 — Centre de commandement, saisie vocale, procédures guidées ; nouveaux droits
- **Centre de commandement** (écran mural du PC) : horloge, météo, alertes et mode crise, compteurs du jour, main courante en direct, agents en vacation (Parc / Arena), rondes en cours, clés sorties, jauge, consignes ; mise à jour toutes les 15 s, bouton plein écran.
- **Dicter un événement** : l'agent parle, l'appli reconnaît la catégorie, la gravité et le lieu, l'agent vérifie puis enregistre dans la main courante (fonctionne aussi hors ligne).
- **Procédures guidées** : alarme incendie / levée de doute, malaise, arrêt cardiaque (DAE), évacuation, colis suspect, ascenseur bloqué ; étapes horodatées, chrono, appels 15 / 17 / 18 / 112 en un geste, lecture à voix haute, enregistrement de toute la chronologie dans la main courante.
- **Annonces vocales** : le mode crise et les consignes importantes sont lus à voix haute sur les téléphones.
- Droits : Laurent Hernandez administrateur (tout sauf le planning général ; planning du PC Parc validé par Jérémy Mercher ou Alexandre Brand) ; le compte PC sécurité passe en vision 24 h/24 (lecture seule).

## v3.74 — Accès total + espace client SPL OE
- Jérémy Mercher, Alexandre Brand et Laurent Hernandez : accès à tout (SMS et fiches sans code, planning modifiable et publiable). L'écran Administration reste au propriétaire seul.
- Administration > « Accès total + planification » : bouton « Donner l'accès total » sur les comptes de Jérémy Mercher et Alexandre Brand dès qu'ils existent.
- Nouveau rôle « Client SPL OE » (3 comptes : responsable sécurité, directeur d'exploitation, chef de projet), créés depuis la carte « Accès client SPL OE ».
- Le client voit le fil de l'eau en direct et le bilan mensuel, sans aucun nom d'agent, sans planning, sans heures du personnel et sans boîte à clés Parc / Arena. Tout le reste est refusé par le serveur (403).
- Matrice des droits mise à jour.

## v3.75 — Relève, registre, secours, signalement QR
- **Brief de relève automatique** (#/releve) : événements ouverts, urgences, clés dehors (retards en rouge), objets en attente, alertes, crise, consignes, rondes avec anomalies, échéances du registre, agents en poste. Lecture à voix haute, impression, bouton « Je prends la relève » horodaté et inscrit en main courante.
- **Registre de sécurité numérique** (#/registre) : 12 installations par site (SSI, désenfumage, extincteurs, RIA, BAES, électricité, gaz, portes coupe-feu, groupe électrogène, ascenseurs, sonorisation, exercice d'évacuation), périodicités paramétrables, prochaine échéance calculée, historique, non-conformité inscrite en main courante.
- **Assistant d'appel des secours** (#/secours) : nature → numéro conseillé, lieu et accès secours, victimes et état, message à dire généré et lu à voix haute, chrono ; l'appel est consigné en main courante, notifié au PC et envoyé par mail.
- **Signalement public par QR code** (#/signalqr + /signaler.html) : affiches à imprimer par lieu, signalement sans compte ni application, QR signés (HMAC), 3 envois par téléphone et par quart d'heure, 40 par heure au total, ouverture / fermeture par l'administrateur. Le téléphone de rappel n'est visible que du PC.
- Navigation : les écouteurs d'écran sont remis à zéro à chaque changement de page.

## v3.76 — Mails à la direction, remise mensuelle des objets trouvés, interface professionnelle
- **Mails** : tous les mails de l'application partent uniquement à Rochdi Mecheti et Laurent Hernandez (liste fixe). Le PC sécurité ne reçoit plus aucun mail ; il est prévenu par les notifications. Les mails personnels (mot de passe, création de compte) restent envoyés à la personne concernée.
- **Objets trouvés, le 30 du mois** (le dernier jour en février) : fonction planifiée `objets-mensuel` vers 9 h. Notification d'alerte à Laurent Hernandez et au PC sécurité, saisie en main courante, rappel sur l'accueil, mail avec le compte rendu PDF à Rochdi et Laurent.
- **Compte rendu PDF** : objets restants à mettre en sac pour M. Pascal Malvezin (responsable sécurité SPL OE), objets restitués du mois, autres suites, cadre de signature. Généré par le serveur (vrai PDF, sans dépendance).
- **Remise** : Objets trouvés > « Valider la remise à M. Pascal Malvezin » avec sa signature à l'écran ; bordereau numéroté RM-AAAA-NNN, objets passés « remis à la SPL OE », PDF signé téléchargé et envoyé par mail.
- **Interface** : nouvel accueil (bandeau d'ouverture avec chiffres du jour, bouton Secours, modules rangés par thème), menu Plus en listes groupées, appels rapides en lignes, écran de connexion épuré, système visuel unifié.

## v3.77 — Rangement des objets trouvés
- Choix du rangement à l'enregistrement, proposé automatiquement selon la catégorie : **bac de rangement en plastique** (vêtements, gourdes, sacs, lunettes, doudous, autres) ou **coffre-fort** (téléphones, portefeuilles et papiers, clés, bijoux et montres, électronique, cartes bancaires, argent liquide), ou « Autre » à préciser.
- Nouvelles catégories : Gourde / bouteille, Argent liquide.
- Remise mensuelle et compte rendu PDF : objets rangés par emplacement (coffre-fort, bac de rangement) pour préparer le sac plus vite.

## v3.78 — Bac de rangement
- « Grande boîte en plastique » devient **« Bac de rangement en plastique »** partout (formulaire, liste, remise, compte rendu PDF). Les objets déjà enregistrés sont renommés automatiquement.

## v3.79 — Codes d'accès des cadenas
- Nouveau module **Codes cadenas** (Moyens et site) : nom du cadenas, site / bâtiment, emplacement, code, remarque.
- Les administrateurs (et le propriétaire) enregistrent, modifient et suppriment les codes. Le PC sécurité les consulte (avec le code d'accès des contacts pour les comptes non administrateurs). Agents et client : aucun accès.
- Codes chiffrés sur le serveur (AES-256-GCM), masqués à l'écran, affichés 30 secondes à la demande ; chaque consultation est notée dans l'historique.

## v3.80 — Tableau de bord en direct sur l'accueil
- Pour le PC sécurité, l'encadrement et le propriétaire : statistiques visibles dès l'accueil, sans clic, actualisées toutes les 20 secondes (indicateur « En direct », heure de la dernière mise à jour).
- Activité des 24 dernières heures (par heure, pic indiqué), gravité du jour (info / moyenne / urgente), 7 derniers jours, top 5 des catégories du jour, agents par site, rondes en cours, clés dehors, objets en stock, rapports, signalements QR, appels secours. Détail au toucher sur chaque barre.
- Finitions : contour animé du bandeau, chiffres lumineux, bouton Secours pulsé, tuiles réactives (animations coupées si le téléphone demande moins de mouvements).
- Les agents ne voient pas ces statistiques (confidentialité).

## v3.81 — Statistiques réservées au client
- Le tableau de statistiques en direct est retiré de l'accueil du PC, de l'encadrement et du propriétaire ; il apparaît uniquement dans l'espace client (au-dessus du fil de l'eau).
- Nouvelle route serveur `stats`, refusée (403) à tout autre profil que le client. Données anonymes : ni noms, ni planning (pas de nombre d'agents), ni boîte à clés.
- Contenu : activité 24 h, gravité du jour, 7 jours, top 5 des catégories, saisies du jour, événements en cours, alertes, rapports, rondes en cours, objets en stock, signalements QR, appels secours ; actualisation toutes les 20 secondes.

## v3.82 — Finition professionnelle
- Style sobre et cohérent : fond uni, cartes plates, icônes monochromes, rouge réservé à l'urgence et aux actions principales, effets lumineux et animations retirés.
- Téléphone : barre de navigation en bas de l'écran (Accueil, Main courante, Rapports, Alerte, Plus) ; Site, Rondes, Planification et Mémo restent sur l'accueil et dans Plus.
- En-tête : cloche et bouton de déconnexion compacts.

## v3.83 — Nom, fonction et statut de la personne connectée
- Accueil : « Bonjour, Prénom Nom » avec la **fonction** (ADS, SSIAP 1, SSIAP 2, SSIAP 3, CDP chef de poste, Responsable) et le **statut** (Propriétaire, Administrateur, Utilisateur, Client), plus le poste du planning pour les agents en vacation. Même information dans l'en-tête et le menu Plus.
- Fonction : prise dans la qualification de l'agent, ou réglée par le propriétaire dans Administration › Comptes (nouveau champ « Fonction »).
- Connexion de secours du propriétaire : affichée « Rochdi Mecheti · SSIAP 2 · Propriétaire » (et non plus « Administrateur »), y compris dans l'historique.

## v3.84 — Planning automatique selon les besoins du client
- Planification › nouvel onglet **Besoins client**, réservé aux administrateurs et au propriétaire (refus serveur pour tous les autres, y compris SSIAP 3 et PC).
- Téléversement de la **fiche PDF du client** : lecture dans le téléphone (pdf.js), reconnaissance des dates (jj/mm, plages « du … au … », « 25 octobre », « tous les jours »), horaires, qualification (ADS, SSIAP 1/2/3, chef d'équipe, cynophile), nombre d'agents, site, nom du client.
- Tableau de vérification modifiable (jours, horaires, poste, qualification, nombre, site), ajout de lignes à la main ou depuis les **postes prédéfinis** (liste réglable : intitulé ; qualification ; début ; fin ; site).
- **Générer le planning** : création des postes du mois puis remplissage automatique avec les agents qualifiés, disponibles (disponibilités déclarées) et en règle (48 h, 12 h, 11 h de repos, un dimanche sur deux). Résultat jour par jour, places manquantes en rouge, annulation possible. Les postes restent en brouillon : publication par les planificateurs.
- Historique des fiches traitées.

## v3.85 — Relevé des postes : photos, géolocalisation, carte du site
- Nouveau module **Carte des postes** (Moyens et site) : liste de départ des postes du site (portails, accès, accueils, portes de l'Arena…), complétable (« Mail central », « poste C »…).
- **Relevé terrain** devant chaque poste : photo (4 maximum) et position GPS haute précision (meilleure mesure sur 12 secondes : latitude, longitude, précision, altitude). Suivi « X / Y postes complets », filtres À relever / Complets.
- **Carte géolocalisée carrée** du Parc des Expositions : fond satellite ou plan (OpenStreetMap), postes numérotés (vert = photo + GPS), zoom au doigt, « Ma position », vue d'ensemble, échelle. Fiche du poste : photos, coordonnées, distance, itinéraire à pied.
- **Plan du site** : nouveau calque « Postes ». Un poste se place à la main (« Placer sur le plan ») ; dès que 2 postes sont à la fois placés et relevés au GPS, tous les autres se positionnent automatiquement (calage GPS → plan).
- Droits : relevé par le PC sécurité, les administrateurs et le propriétaire ; consultation par les agents (habilitation « Plan du site ») ; client exclu.

## v3.86 — Protection de l'écran (tout le monde sauf le propriétaire)
- **Filigrane** permanent et discret sur tous les écrans : nom, adresse e-mail, date et heure de la personne connectée, « SSIAP PRO · CONFIDENTIEL · CAPTURE INTERDITE ». Toute capture est donc identifiable. Il apparaît aussi sur les impressions.
- **Contenu flouté** dès que l'appli passe en arrière-plan (sélecteur d'applis, capture système, changement de fenêtre) et pendant 1,5 s après la touche Impr. écran ou les raccourcis de capture (ordinateur).
- Copie de texte, appui long, menu contextuel et glisser des images bloqués (sauf dans les champs de saisie) ; partage / enregistrement de l'écran depuis le navigateur refusé.
- **Tentatives notées** dans les notifications du propriétaire (capture, copie, enregistrement), une par personne toutes les 30 s au plus.
- Mention sur l'écran de connexion. Le propriétaire n'a aucune de ces restrictions.
- Limite : une application web ne peut pas empêcher techniquement la capture d'écran du téléphone (boutons du téléphone) ; le filigrane nominatif la rend traçable.

## v3.87 — Brief d'événement (Foire Internationale de Montpellier 2026)
- Nouveau module **Brief événement** (Opérations) : points d'attention, consignes par poste, horaires, listes d'accès. Bandeau sur l'accueil pendant l'événement ; chaque agent voit **sa consigne** selon son poste du planning (P3, Mail central, P1 Inter, entrée A, parking, volants, frigo, SSIAP 1, SSIAP 3).
- **Contrôle d'accès** : recherche dans les listes (prestataires autorisés au P3, exposants en dérogation) ; bouton « Entrée » noté en main courante ; société absente de la liste : refus ou autorisation sur ordre du PC, avec immatriculation (signalé dans les notifications).
- Brief FIM 26 préchargé d'après le brief de l'organisateur : horaires de montage, exposants, visiteurs, démontage ; consignes de la période de montage ; 24 prestataires autorisés au P3 + piscinistes hors gabarit ; 30 exposants en dérogation du lundi 05/10.
- Briefs modifiables par les administrateurs et le propriétaire (texte simple, listes collables depuis un tableau), création d'autres briefs.
- Planification › Besoins client : **jeux de besoins enregistrés** ; le besoin FIM 26 · montage (4 – 8 octobre, 37 places, 435 h) est préchargé et se génère en un clic.

## v3.88 — Plannings d'octobre 2026 + Jérémy administrateur
- Plannings Comète d'octobre 2026 intégrés : Parc des Expositions (689 vacations) et Arena Sud de France (326 vacations).
  Appliqués automatiquement une seule fois au premier appel après déploiement : le mois d'octobre de chaque site est remplacé, la planification interne (source « planif ») est conservée. Trace dans le journal.
- jerre34@hotmail.fr (Jérémy) : administrateur, accès total, planning compris (comme Laurent Hernandez). L'écran Administration reste réservé au propriétaire.

## v3.89 — Planning d'octobre 2026 refait (version du 06/10)
- Octobre entièrement refait pour les deux sites à partir des plannings Comète du 06/10 : Parc 689 vacations, Arena 326 vacations.
- Les vacations non affectées sont maintenant visibles dans le planning (« NON AFFECTÉ ») : 15 au Parc, 2 à l'Arena.
- Remplace aussi l'import v3.88 si celui-ci a déjà été appliqué. La planification interne est conservée.

## v3.90 — Compte « SMS seulement »
- Nouveau profil : planning général (lecture, tout le mois, Parc + Arena) et envoi des SMS de prise de poste. Rien d'autre (main courante, alertes, rapports, administration, modification du planning : refusés côté serveur).
- fhadouche@mhscfoot.com (Fahd Hadouche, adjoint responsable planification) a ce profil. Il peut marquer les rappels SMS envoyés ; chaque envoi est tracé au journal.
- Compte SMS : peut aussi gérer l'annuaire des numéros des agents (ajout / modification, tracé au journal). Le texte du modèle de SMS reste réservé au propriétaire.
- Correctif : l'annuaire SMS n'est plus tronqué à 500 numéros à l'enregistrement (limite portée à 2000 ; l'annuaire en compte plus de 600).

## v3.91 — Ajouter le numéro d'un agent en un geste
- Administrateurs, propriétaire et compte SMS (Fahd Hadouche) : bouton « ➕ Ajouter le numéro » sur chaque vacation sans numéro (ou « Corriger » si le nom est approchant), et carte « Ajouter un numéro » dans Numéros des agents.
- Le numéro part dans l'annuaire et est reporté sur les vacations à venir de l'agent ; tracé au journal.
- Les postes non affectés affichent « poste non affecté » (pas de rappel SMS possible).

## v3.92 — Pourvoir les postes non affectés
- Administrateurs, propriétaire et compte SMS : bouton « Affecter » sur chaque poste non affecté du planning. Saisie du nom (liste des agents proposée) et du numéro si besoin ; alerte si l'agent a déjà une vacation qui se chevauche.
- L'affectation est visible de tous (« affecté par … »), modifiable ou annulable (« Remettre en non affecté »), tracée au journal. Le rappel SMS devient possible aussitôt.
- Seuls les postes non affectés peuvent être pourvus ainsi : les vacations de la planification restent intouchables.

## v3.93 — Modifier une vacation au dernier moment
- Bouton « Modifier » sur chaque vacation (administrateurs, propriétaire, compte SMS) : changer l'agent (liste des agents proposée, numéro repris automatiquement), le téléphone et les horaires.
- « Agent absent : passer en non affecté » libère le poste s'il n'y a pas encore de remplaçant.
- Le planning d'origine est conservé (« remplace … »), chaque modification est tracée au journal ; nouvel agent ou nouveaux horaires = rappel SMS à renvoyer.

## v3.94 — SSIAP 2 de l'Arena
- Correctif : un SSIAP 2 placé à l'Arena (représentation, « AGENT SSIAP 2 »…) obtient le profil PCS Arena (événements de l'Arena) et non plus les droits complets du PC Parc. Le site de la vacation est désormais pris en compte.

## v3.95 — Nouveau poste relevé sur place
- Carte des postes › Relevé des postes : bouton « Nouveau poste sur place ». Nom, site, zone, mission, demande (événement / besoin du client) et période ; la position GPS se relève automatiquement (précision affichée), 1 à 4 photos ; tout est enregistré en une fois.
- Le poste apparaît aussitôt sur la carte géolocalisée, avec un badge « demande » et ses dates ; création tracée au journal.
- Réservé au PC sécurité, aux administrateurs et au propriétaire.

## v3.96 — Agents au poste sur la carte et le plan
- Carte des postes et Plan du site : chaque agent du planning s'affiche sur son poste pendant sa vacation (nom, horaires), d'après l'intitulé du poste au planning (ex. « ADS P1 INTER » → poste « P1 inter »).
- Couleur selon la prise de service : vert = en poste (prise de service faite), orange = attendu, rouge = absent / non pointé.
- Liste « Agents en poste maintenant » sous la carte (avec les postes non localisés). Sur le plan, si le poste n'est pas encore placé, l'agent est rattaché au hall, à l'accueil ou au portail du même nom.
- Fiche d'un poste : champ « Intitulés du planning » pour rattacher un intitulé différent.
- Visible par le PC, les administrateurs, la coordination, les SSIAP 3 et le propriétaire.

## v3.97 — Postes des plans d'accès placés sur le plan du site
- 35 postes repris des « Plans d'accès aux postes » (portes 1 à 8 du parvis Arena, P1/P4/P5/P6/P7/P8 inter, P6 rond-point, P3, Mail central, Patte d'oie, Portail 400, parkings VIP / Club / A exposants / Pailletrice / Porcelanosa / frigorifiques, parvis A et B, PC Arena, régie TV, porte arrière backstage, cour de service, tour bus…).
- Placés automatiquement une seule fois sur le plan du site (calage sur les halls), avec les intitulés du planning correspondants : les agents s'affichent dessus pendant leur vacation.
- Les postes déjà placés à la main ne sont pas déplacés. Chaque poste reste modifiable (Placer sur le plan, intitulés, GPS, photos).

## v3.98 — Barrières, portails, portes de l'Arena et délimitations sur le plan
- Nouveau calque « Accès » sur le plan du site (activable / désactivable) : barrières (P1, P4, P5, P6, P7, P8 inter, P6 rond-point, Mail central, Patte d'oie), portails (P3, Portail 400, Pailletrice, Porcelanosa, cour de service), portes 1 à 8 du parvis Arena.
- Délimitations : enceinte du site (pointillés), parvis Arena, cour de service, parking des véhicules frigorifiques.

## v3.99 — Agents de chaque vacation sur le plan
- Sélecteur « Jour / Heure » au-dessus du plan : affiche les agents prévus à n'importe quelle vacation (bouton « Maintenant » pour revenir au direct, avec le statut de prise de service).
- Couleur par catégorie : SSIAP (rouge), ADS (bleu), volants (violet) ; point de couleur = en poste / attendu / absent / prévu.
- SSIAP 1 placés dans leur hall (« SSIAP 1 HALL / A6-A3 », « REGUL HALL A3 »…), sinon regroupés « SSIAP · tous halls » dans l'allée des halls (ou « SSIAP Arena ») ; ADS sur leur poste ; volants regroupés « Volants » ; postes intérieurs de l'Arena (devant de scène, parterre, court / jardin, loges, porte grise…) rattachés à l'Arena.
- Liste des agents sans poste localisé sous le sélecteur.

## v4.00 — Postes toujours visibles sur le plan
- Tous les postes placés sont affichés en permanence sur le plan, avec leur nom (le calque « Postes » n'est plus désactivable).
- Poste tenu (agent en poste, ou agent prévu sur la vacation choisie) : point vert clignotant. Poste vacant : point rouge.

## v4.01 — L'application devient « Kaelum e-PCS »
- Nouveau nom partout : titre, en-tête, écran de connexion, icône de l'appli (écran d'accueil du téléphone), notifications, PDF, mails, page de signalement QR, centre de commandement.
- Nouveau logo (icônes 64 / 180 / 192 / 512 et maskable) et nouvelle image de l'écran de connexion.
- Signature inchangée : « Application créée par Rochdi Mecheti ». Les données, comptes et réglages ne changent pas.

## v4.02 — Devis au nom de Kaelum e-PCS + pré-paie
- Devis : en-tête Kaelum e-PCS (logo, « Prestations de sécurité incendie et sûreté », Rochdi Mecheti · mr.mecheti@gmail.com), signature « Pour Kaelum e-PCS ».
- Planification › Paie (administrateurs et propriétaire) : pré-paie mensuelle calculée depuis le planning selon la CCN Prévention et sécurité (IDCC 1351) et le Code du travail :
  heures, nuit 21h–6h (+10 %), dimanche (+10 %), jours fériés (+100 %), heures supplémentaires par semaine civile (+25 % de 35 à 43 h, +50 % au-delà, semaine rattachée au mois de son dimanche), panier par vacation de 6 h et plus, indemnité chien, contrôle du SMIC, alertes Code du travail (12 h, 11 h de repos, 48 h, dimanches).
- Paramètres modifiables (taux horaires par qualification, SMIC, majorations, panier…), export CSV pour le cabinet de paie, impression PDF.
- Estimation de pré-paie : ne remplace pas le bulletin de paie (ancienneté, absences, congés, prime annuelle, cotisations non calculées).

## v4.03 — Licences planificateur
- Administration › Licences planificateur (propriétaire) : jusqu'à 100 licences nominatives (e-mail du compte), niveau valideur / rédacteur / lecture, site (tous, Parc, Arena), date de fin, actif / suspendu, dernière connexion.
- Une licence n'ouvre que la planification (et le planning) : pas la main courante, ni les dossiers, ni l'administration ; fonctionne même hors vacation. Le code de la planification reste demandé.
- Rédacteur : propose des vacations, publiées après validation d'un valideur (« À valider »). Site : modifications refusées hors du site de la licence.
- Travail à plusieurs : si une vacation a été modifiée entre-temps par un autre planificateur, l'enregistrement est refusé avec son nom (rien n'est écrasé).

## v4.04 — Grille des disponibilités + mises à jour
- Disponibilités des agents (Plus › Équipe, et menu de l'adjoint planification) : tous les agents du mois (planning, comptes, annuaire), une case par jour à cocher (✓ journée, J jour, N nuit). Fichier centralisé, enregistré case par case, partagé entre l'adjoint planification, le PC et les administrateurs ; recherche ; totaux par agent et par jour ; export PDF (A4 paysage).
- Laurent Hernandez : nouveau numéro (07 57 54 83 62), fonction « Chef de poste Parc des Expositions / Arena » (contacts, compte, annuaire SMS).
- « Avenue de l'Élevade » devient « avenue des Levades » (poste P3, Patte d'oie, zones et postes enregistrés).

## v4.05 — Main courante et accès par niveau
- SSIAP 3 : plus de main courante, seulement le rapport libre (et la prise / fin de service).
- Événements : un événement de l'Arena est géré par le SSIAP 2 du PC Parc et le SSIAP 2 de l'Arena ; un événement du Parc par le SSIAP 2 du PC Parc seulement (+ administrateurs et propriétaire). Le SSIAP 2 de l'Arena ne peut ni créer, ni modifier, ni clôturer un événement du Parc, ni y rattacher une main courante.
- Main courante : chaque agent ne peut saisir que les types de la main courante de son poste (contrôle par le serveur).
- Accès par niveau : ADS et SSIAP 1 n'ont plus accès aux modules du niveau SSIAP 2 / PC (clés, prêt de matériel, bâtiments, documents du PC) ; ils disparaissent de leur menu. Réglable dans Habilitations.

## v4.06 — Droits par responsable + tableau de bord
- Propriétaire (Rochdi Mecheti) : tous les niveaux + modification de l'application (inchangé).
- Laurent Hernandez (responsable PCS sécurité) et Jérémy Bourg (référent chef de poste PCS jour) : administrateurs (tous les niveaux) ; planification limitée au planning SSIAP 2 du PC Parc, publiée directement (pas d'import, ni postes, ni devis). Liste réglable : clé « planif_valideurs_pc ».
- Compte du PC Parc et SSIAP 2 du PC Parc : accès à tout (droits du PC), sauf modifier le planning et les devis ; planning général du mois en lecture et grille des disponibilités.
- Tableau de bord (Plus › Pilotage) : chiffres du jour (agents prévus / en poste / retards / absents, main courante, faits ouverts, urgents, alertes, rondes), mode crise, alertes actives, plan interactif avec les agents, agents du jour (filtres), main courante du jour, fil de l'eau, événements, rondes, jauge, consignes, clés sorties, météo. Mise à jour automatique (1 min ; plan toutes les 3 min).

## v4.07 — Accès du client (exploitant) étendu, anonymisé
- Le client voit tout ce qui se passe sur le site, en lecture seule et sans aucun nom d'agent : tableau de bord, fil de l'eau, bilan et statistiques, main courante du site, rapports d'intervention et rapports libres, objets trouvés, brief événement (listes des prestataires comprises), plan du site, bâtiments, registre de sécurité, clés organisateurs, jauge, alertes, météo, crise.
- Aucune information sur la société de sécurité et ses agents : pas de planning, présences, disponibilités, dossiers, fiches, contacts, SMS, paie, planification ; pas de prises / fins de service, ni de famille REX ; noms, postes et intervenants retirés côté serveur.
- Clés : seulement les boîtes à clés organisateurs (Parc série 100, Arena série 200), jamais la boîte à clés du PC.

## v4.08 — Ma paie (estimation) pour chaque agent
- Plus › Équipe › Ma paie (estimation) : chaque agent voit, mois par mois, ses heures (nuit, dimanche, férié, heures sup.), son brut estimé et ses indemnités (panier dès 6 h, habillage / entretien de tenue, chien), avec le détail de ses vacations.
- Grille de référence affichée : taux horaires bruts ADS, SSIAP 1, SSIAP 2, SSIAP 3, cynophile, chef d'équipe ; nuit +10 %, dimanche +10 %, férié +100 %, heures sup. +25 % / +50 %, panier, chien, habillage. Les taux se règlent dans Planification › Paie (nouveau paramètre « habillage / entretien tenue », 8,78 €/mois par défaut).
- Accessible aussi hors vacation. Estimation indicative avant cotisations : le bulletin de l'employeur fait foi.

## v4.09 — Ma paie : chacun saisit ses montants
- Montants vides par défaut (taux horaires, panier, chien, habillage, SMIC) : plus aucun prix prérempli.
- Ma paie › « Mes paramètres de paie » : chaque agent saisit son contrat (CDI / CDD), si ses montants sont en brut ou en net, son taux horaire, sa prime de panier par vacation, l'habillage, ses majorations (nuit, dimanche, férié, heures sup.), l'indemnité chien ; en CDD : précarité et congés payés (10 % par défaut). Paramètres personnels, vus par lui seul.
- Le calcul (heures du planning × ses montants) s'affiche aussitôt, en brut ou en net selon sa saisie.

## v4.10 — Alerte agents non pointés, recherche globale, raccourcis

- **Alerte « Agent non pointé »** : fonction planifiée toutes les 5 min (`agents-non-pointes.mjs`). 15 min après le début d'une vacation sans prise de service, notification push au PC sécurité, au propriétaire et aux admins + trace au journal (une seule alerte par vacation).
- **Recherche globale** (🔍) : main courante (3 mois), objets trouvés, clés, planning (J-1 à J+14), événements, rapports. Réservée à l'encadrement / PC / propriétaire.
- **Raccourcis d'accueil** « Tableau de bord » et « Rechercher » pour les profils de pilotage.
- Balayage complet de tous les rôles : 0 erreur JS.

## v4.11 — Version pro : fiabilité, finitions, remplacement express

**Nouvelles fonctions**
- **Remplacement express** (planning ➜ Modifier / Affecter ➜ ⚡) : l'appli propose les agents libres et qualifiés, classés selon la dispo déclarée, le repos de 11 h, les 48 h / semaine et la connaissance du poste. Un bouton « Choisir » remplit la fiche, un bouton « SMS » envoie la proposition.
- **Prise de service géolocalisée** : la position est relevée une seule fois, au moment de valider. Elle est comparée au site : « 📍 sur site », ou « ⚠️ hors site » avec une alerte au PC. Il n'y a aucun suivi pendant la vacation.
- **Filtre par événement** sur le plan des agents.

**Fiabilité**
- Délai réseau et nouvel essai automatique sur les lectures.
- Hors ligne, les derniers écrans consultés restent lisibles, avec le bandeau « données du … ».
- Bandeau « Nouvelle version disponible » : on n'a plus besoin de recharger 2 fois.
- Remontée automatique des erreurs vers l'Administration (propriétaire seulement).
- Écran d'erreur avec bouton « Réessayer ».

**Finitions**
- Notifications empilées et colorées (succès / erreur).
- Squelettes de chargement et transitions douces.
- « Tirer vers le bas pour actualiser » sur l'appli installée.
- Vibration à la prise de service.
- Focus clavier visible.

## v4.12 — Aperçu des profils, PTI / DATI, gestion de la société

**Aperçu des profils (propriétaire)** : Plus ➜ « Voir comme… (profils) ».

- Profils disponibles : Admin, PC Parc, PC Arena, SSIAP 1, ADS, Client, Planificateur, SSIAP 3, Adjoint planificateur, Chef de site.
- L'appli s'affiche exactement comme le profil la voit, en lecture seule. Le jeton dure 2 h et ne peut être créé que par le propriétaire.
- Le bandeau rouge « Profils / Quitter » ramène au compte propriétaire.

**PTI / DATI (travailleur isolé)** :

- Contrôle toutes les 15 à 60 min, avec un push « Tout va bien ? ».
- Sans réponse au bout de 3 min : alarme au PC, avec la position, une saisie en main courante et une relance toutes les 5 min jusqu'à la prise en compte.
- SOS en maintenant le bouton 2 s.
- Détection de chute (appli ouverte).
- Supervision PC : prise en compte, arrêt.
- Fonction planifiée `pti-veille.mjs` lancée toutes les minutes.
- C'est un complément : ça ne remplace pas un DATI certifié.

**Compte rendu d'intervention** : nouveau type de rapport, avec les heures d'appel, d'arrivée et de fin, le constat, les actions, les moyens, le résultat et les suites.

**Gestion de la société (propriétaire)** :

- **Synthèse.**
- **Clients.**
- **Factures** :
  - numérotation continue FA-AAAA-0001, attribuée à l'émission ;
  - brouillon modifiable, facture émise verrouillée ;
  - import d'un devis ;
  - PDF avec les mentions légales (pénalités, indemnité de 40 €, CNAPS, art. L612-15 CSI, franchise de TVA).
- **Contrats** : fins de CDD et de période d'essai.
- **Stocks / EPI** : entrées, dotations, retours, seuils, renouvellements.
- **Marge** : CA facturé comparé aux heures du planning × coût horaire chargé (saisi par le propriétaire, vide par défaut).
- **Échéances** : dossiers agents (CNAPS, SSIAP, SST, visite médicale), contrats, impayés, stocks, EPI.
- **Ma société** : SIRET, n° CNAPS, IBAN, franchise de TVA.

## v4.13 — Mot de Roch, droits planning, feuille de route du jour

- **Prise / fin de service sans géolocalisation.** Aucune position n'est relevée, et le serveur ignore toute position envoyée.
- **Mot de motivation signé Roch** (`public/motivation.js`, 7 messages qui changent chaque jour) :
  - une carte sur l'accueil des agents ;
  - un plein écran après la prise de service ;
  - une notification push au début de chaque vacation, une seule fois par vacation (fonction `agents-non-pointes.mjs`).
- **Jérémy Mercher et Alexandre Brand** : administrateurs plus planificateurs complets (planning général compris).
  - Ils sont reconnus par leur adresse : jerre34@hotmail.fr ou la liste « Planificateurs » de l'Administration.
  - À défaut, ils sont reconnus par leur nom, mais seulement le premier compte créé à ce nom.
- **Laurent Hernandez** : met en place le planning PCS (inchangé).
- **Téléchargement du planning général** (mois, Excel et PDF paysage, sans numéros de téléphone) : réservé à Rochdi, Jérémy Mercher, Alexandre Brand et Laurent Hernandez.
- **Feuille de route du jour** (Équipe ➜ Feuille de route), pour le compte PC, les SSIAP 2 du PCS, les admins et le propriétaire :
  - un événement par page A4 paysage ;
  - SSIAP 3 en premier ;
  - postes non affectés laissés vides ;
  - colonnes arrivée, départ et émargement ;
  - invisible pour le client.

- v4.13b : Alexandre Brand reconnu par son adresse a.brand@groupenicollin.com (admin + planificateur complet + téléchargement du planning).

## v4.14 — Relevé d'heures et compteur

- **Ma paie et mes heures** (pour chaque agent) : un compteur d'heures et un relevé mensuel en PDF.
  - Le relevé détaille chaque vacation (date, poste, événement, horaires, heures, nuit, dimanche, férié) avec les totaux.
  - Il contient le décompte des heures sup. à la semaine et deux cases de signature (agent et responsable).
- **CDI** : contrat de 151,67 h par mois. Les heures au-delà sont comptées en heures sup. ; en dessous, l'appli affiche ce qui manque pour atteindre le contrat.
- **CDD** : heures du mois plus le cumul depuis le début du contrat, jusqu'à la fin du contrat ou du mois.
- **Contrat de l'agent** : le registre « Gestion de la société » est prioritaire. À défaut, l'appli prend les paramètres de l'agent (contrat, heures par mois, début et fin du contrat).
- **Relevés d'heures** (Équipe) : PC, admins, planificateurs et propriétaire choisissent un agent et un mois, puis exportent son relevé en PDF.

## v4.15 — Confort agent, thème clair, rapidité

- **Carte « Ma vacation »** sur l'accueil des agents :
  - poste, événement, site et horaires ;
  - une barre de progression avec « fin dans… » ;
  - l'état du service : non pris, en service depuis HH:MM, ou terminé ;
  - le bon bouton mis en avant (prise ou fin de service).

  La carte se met à jour toute seule (route `monservice`).
- **Mon confort** (Plus), réglé pour chaque téléphone :
  - thème Sombre, Clair ou Auto (le clair est lisible en plein soleil) ;
  - taille du texte Normal, Grand ou Très grand ;
  - mode nuit pour les rondes (écran rouge, qui préserve la vision nocturne) ;
  - vibrations oui ou non.
- **Thème clair complet** : la carte d'accueil et le centre de commandement restent sombres. Le thème est appliqué avant l'affichage, sans flash (`theme-init.js`).
- **Ouverture instantanée** : les fichiers de l'appli sont servis depuis le cache et mis à jour en arrière-plan. Une nouvelle version affiche le bandeau « Mettre à jour ».
- **Ergonomie** :
  - grandes zones tactiles (boutons de service, actions rapides, barre d'onglets) ;
  - retour visuel au toucher.

## v4.16 — Commande client → planning, filigrane discret, rôles

- **Commande client → planning** (Équipe), réservé aux planificateurs, avec le code de la planification :
  1. La commande : photo, PDF, image ou texte collé.
  2. Les besoins sont extraits (dates, horaires, postes, qualifications, nombre) et restent modifiables.
  3. Le planning est proposé. Chaque agent est choisi selon :
     - sa dispo déclarée ;
     - son habitude du poste (tout le planning, octobre compris) ;
     - le même poste la veille ;
     - la qualification exacte ;
     - le repos de 11 h et les 48 h par semaine.

     Chaque proposition est modifiable, puis enregistrée dans le planning. Les postes vides sont enregistrés en non affecté.
- **Lecture des photos** : elle nécessite `ANTHROPIC_API_KEY` dans les variables Netlify (modèle réglable par `ANTHROPIC_MODEL`, `claude-haiku-4-5` par défaut). Sans clé, les PDF texte et le texte collé sont lus localement.
- **Filigrane anti-capture discret** : seulement un code `NM-XXXXXX-date`, presque invisible, sans nom ni e-mail. Le propriétaire retrouve le compte dans Administration ➜ « Retrouver l'auteur d'une capture ».
- **Rôles** : chef de site, chef de secteur, SSIAP 3 et responsable planification correspondent aux mêmes personnes, Jérémy Mercher et Alexandre Brand (accès à tout). Rochdi s'affiche « SSIAP 3 » quand il est planifié en SSIAP 3 ; sinon rien ne change.

- v4.16b : commande client en **PDF uniquement** (plus de photo), site Arena détecté automatiquement ; propositions testées sur le planning Arena d'octobre (portes, SSIAP 1, PC Arena).

## v4.17 — QR de signalement d'anomalie (bâtiments privés)

- **Anciens QR supprimés** : halls, parkings et sécurité incendie publics. Ils affichent « QR non reconnu ou remplacé ».
- **6 QR seulement**, pour le personnel SPL :
  - Atelier SPL ;
  - Bureaux d'exploitation SPL ;
  - Bureaux de direction SPL ;
  - Bureaux Arena ;
  - Local Sud Service ;
  - Salle de pause R+1 CDC.
- **Page publique `signaler.html`** : accès direct, sans compte, sans connexion à Kaelum e-PCS, Netlify ou GitHub.
  - Le salarié choisit une anomalie de **sûreté** (porte forcée, intrusion, colis suspect, vol, menace) ou de **sécurité** (issue bloquée, extincteur / RIA / DAE, BAES, fumée / gaz, fuite, chute).
  - Il peut écrire un message de 3 000 caractères maximum et joindre une photo, compressée sur le téléphone.
  - Son nom ou service et son téléphone sont facultatifs.
- **Côté PC** : notification push, journal, et saisie en main courante « Signalement anomalie (QR) » avec la photo.
- **Anti-abus** : 10 signalements par quart d'heure et par réseau, 40 par heure au total.

## v4.18 — Prise de service sur tous les postes, slogan signé Kaelum e-PCS

- **Prise et fin de service** : un sélecteur « Poste » est présent sur tous les postes.
  - Le poste du planning est proposé d'office.
  - Trois postes sont toujours disponibles : **PCS Parc des Expositions**, **PCS Arena Sud de France** et **P3 (avenue des Levades)**.
  - « Autre poste / zone… » permet de choisir n'importe quelle zone du site.
  - Si le poste n'est pas au planning, le choix par défaut dépend du profil : PC → PCS Parc, Arena → PCS Arena, P3 → P3.
- **Mot de motivation** signé « Kaelum e-PCS » (et non plus « Roch ») : carte d'accueil, plein écran après la prise de service et notification.

## v4.19 — Retour des consignes (objets trouvés)

- **Bouton « Retour des consignes (fermeture accueil / consigne) »** dans Objets trouvés.
- **Saisie** : service (consigne A, B, Centre de conférence, Arena, vestiaire, autre) et personne qui remet les objets.
- **Pour chaque objet** :
  - n° de ticket de consigne, catégorie, description ;
  - rangement Bac, Coffre (proposé d'office pour les objets de valeur) ou Autre (à préciser) ;
  - photo.
- **Après l'enregistrement** :
  - chaque objet reçoit son numéro OT, marqué « consigne · ticket … » ;
  - un filtre « Consignes » regroupe ces objets, et la recherche fonctionne aussi par n° de ticket ;
  - une seule saisie récapitulative va en main courante.
- **Suite du circuit** : restitution signée et remise mensuelle à la SPL, comme les autres objets.

## v4.20 — Absences dans la planification

- **Nouvel onglet « Absences »** en Planification : EV (événement familial), CP (congés payés), FOR (formation), CSS (congé sans solde), AT (accident du travail), AM (arrêt maladie).
- **Saisie** : agent, type, du / au. Une option fait passer ses vacations de la période en « non affecté », à repourvoir.
- **Effets d'une absence** :
  - pastille de couleur dans la grille du planning (mois et semaine) ;
  - impossible de planifier ou d'affecter l'agent ces jours-là (message clair) ;
  - l'agent est exclu du remplacement express et des propositions de la commande client ;
  - l'agent voit sa propre absence dans « Mon planning » ;
  - le relevé d'heures du mois affiche le nombre de jours par type.
- **Confidentialité** : le motif (AT, AM…) n'est visible que des planificateurs, des admins et de l'agent lui-même.

## v4.21 — Le PCS Parc imprime tout

- **Bouton « Imprimer » dans l'en-tête** pour le PCS Parc (compte PC et SSIAP 2 du PC), les administrateurs et le propriétaire.
  - Il imprime la page affichée, quelle qu'elle soit : rapports, présences, clés, registre, consignes, fiches, planning, dossiers, matériel, bâtiments…
  - La mise en page est prévue pour l'impression : fond blanc, en-tête Kaelum e-PCS, date et auteur, valeurs des champs à la place des cases, détails dépliés, boutons retirés.
  - On peut aussi enregistrer la page en PDF.
- **Planning général** (Excel et PDF du mois) : le PCS Parc peut maintenant le télécharger.
- **Rappel** : la feuille de route du jour, le relevé d'heures, la main courante, le bilan, les objets trouvés et les fiches de devis gardent leurs PDF dédiés.

## v4.22 — « Voir comme… » pour Laurent Hernandez

- Laurent Hernandez (courrier.laurent@free.fr) a le bouton « Voir comme… (profils) », comme le propriétaire : il voit l'appli exactement comme chaque profil, en lecture seule, et revient à son compte avec le bandeau rouge.
- Chaque aperçu est noté au journal avec son nom.
- Aucun autre compte n'y a accès (testé : ADS et Alexandre Brand refusés).

## v4.23 — Registre des moyens de secours et d'extinction, cadenas

- **Moyens de secours** (Opérations ➜ « Moyens de secours », lien aussi depuis Rondes) : un registre par hall ou bâtiment.
  - Moyens suivis : extincteurs, RIA, BAES, issues de secours, déclencheurs manuels, DAE, portes coupe-feu, désenfumage, colonne sèche, autre. Le site n'a ni sprinkleurs ni rideau d'eau.
  - **Ronde** : pour chaque équipement, Conforme ou Anomalie (type, précision, photo). Les équipements manquants s'ajoutent pendant la ronde : la liste se remplit au fil des rondes.
  - **Suivi des anomalies** : elles restent enregistrées. À la ronde suivante, on indique « Rectifiée » ou « Toujours en anomalie ». Saisie en main courante et journal.
  - **Onglets Registre, Anomalies en cours et Rondes faites.**
  - **Fiche imprimable** A4 paysage, pour un hall ou tous : type, n°, emplacement, détail, état, anomalie, dernier contrôle, colonne de contrôle, signatures.
  - **Accès** : rondes par les SSIAP 1, 2 et 3 et le PC ; modification du registre par les SSIAP 2 / 3, le PC, les admins et le propriétaire.
- **Codes cadenas** : Laurent Hernandez ajoute et supprime les codes (vérifié).

## v4.24 — Rondes des moyens de secours : SSIAP 1 et SSIAP 2 du PCS

- Les rondes des moyens de secours sont faites par les SSIAP 1 et les SSIAP 2 du PCS. Les SSIAP 3 n'en font pas.
- Le module est retiré des comptes SSIAP 3 et des ADS.
- Le registre reste modifiable par le PCS (SSIAP 2), les admins et le propriétaire.

## v4.25 — Rondes ADS : malveillance et fermeture des halls / du site

- **Nouveau module « Rondes fermeture / malveillance »** (Opérations), réservé aux ADS. Le PCS, les SSIAP 1 et les responsables y ont aussi accès.
- **Type de ronde** : fermeture des halls / du site, ou malveillance.
- **Points contrôlés** par hall, « Site — extérieurs et portails » ou « Parkings » : portails / barrières, portes, issues, rideaux métalliques, vitrages, clôtures, locaux, éclairage, alarme intrusion…
  - La liste se remplit au fil des rondes.
- **Pour chaque point** : « Fermé / OK » (« RAS » en malveillance) ou « Anomalie ».
  - Types d'anomalie : ouvert, serrure HS, effraction, dégradation, intrusion, objet suspect, éclairage resté allumé, alarme HS…
  - On peut ajouter une précision et une photo, plus des observations générales sur la ronde.
- **Suivi** : les anomalies restent enregistrées jusqu'à la ronde suivante (rectifié / toujours en anomalie). Chaque ronde va en main courante, et le PC est prévenu.
- **Onglets et impression** : Registre, Anomalies en cours, Rondes faites, et fiche imprimable par zone ou pour toutes les zones.

## v4.26 — Bouton Retour, feuille de route modifiable, installation sur ordinateur

- **Bouton « ← Retour »** en haut de toutes les pages, sauf l'accueil : il revient à la page précédente, ou à l'accueil.
- **Feuille de route du jour modifiable à la main** : PCS (SSIAP 2), SSIAP 3, adjoint planification (Fahd), admins, propriétaire.
  - On peut changer les noms, postes, qualifications et horaires, ajouter ou retirer des lignes et des événements.
  - La feuille modifiée est marquée « modifiée par… », avec un lien pour revenir au planning. Le planning lui-même n'est pas changé.
  - L'adjoint planification et les SSIAP 3 y ont maintenant accès.
- **Installation sur ordinateur** :
  - manifeste complété (id, scope, captures d'écran, raccourcis) : Chrome et Edge ne signalent plus aucune erreur d'installation ;
  - bouton « Installer Kaelum e-PCS » sur l'écran de connexion et dans Plus, avec un guide pas à pas selon le navigateur (Edge, Chrome, Safari, Firefox, iPhone, Android) ;
  - bandeau discret sur ordinateur, une fois par jour ;
  - solution de secours : un raccourci Bureau à télécharger (`Kaelum e-PCS.url` sur Windows, `.webloc` sur Mac), avec `favicon.ico`.

## v4.27 — Plan de l'Arena (RDC), mise à jour des cadenas, consignes permanentes

- **Plan interactif de l'Arena (RDC)**, redessiné d'après le plan de masse de Laurent Hernandez, dans le même style que le plan du site (bascule « Site complet / Arena · RDC ») :
  - **Extérieurs** : parking loges partners, parvis, portes 1 à 8, filtrages 401 à 407, zones 400 / 408 / 409, bulle, portail pompiers, entrée et sortie, cour de service, hérisson, P3.
  - **Intérieur** : tribunes A à E, télescopiques F / G / H, parterre (configuration sport), bande des 8 m, zones expo Z1 à Z5, escaliers 1 à 10, accès coursive, vanne RIA, boussole.
  - **Agents de l'Arena** placés automatiquement : « PORTE n » sur la porte n, backstage, cour de service, parking VIP, SSIAP / PC.
  - **Fiche au toucher** : agents présents et faits en cours.
  - Zoom, déplacement et plein écran.
- **Cadenas** : mise à jour de toute la liste par copier-coller (« Nom ; code », titres de sections). Les codes existants sont remplacés, les nouveaux ajoutés, avec une option pour retirer les autres. Les codes ne sont jamais écrits dans le code de l'appli.
- **Consignes permanentes** (Urgence ➜ « Consignes permanentes ») : notes PC01 à PC07, Process sécurité, note interne Sécurité des biens et des personnes.
  - Chaque document s'affiche page par page, à l'identique.
  - Recherche dans le texte et impression.
  - Les documents sont servis par la fonction `consignes`, seulement aux comptes connectés : jamais au public, jamais au client.

## v4.28 — Consignes permanentes : titres, source, N Sécurité

- **Titres** : « Note 1 » à « Note 7 » à la place de « Note PC01 » à « PC07 », dans la liste et sur les documents.
- **Source** sur chaque consigne : « Rédigé par Laurent Hernandez ».
- **« PSI SECURITE » remplacé** par « N SÉCURITÉ – NICOLLIN SÉCURITÉ » dans les notes 1 à 7, et « PSI » par « N Sécurité » dans le Process. Le texte de recherche suit aussi.
- **Clé « Bureau PSI »** renommée « Bureau N Sécurité » (migration automatique).

## v4.29
- Codes d'accès (cadenas, bornes, téléphones du PC) : code PIN obligatoire avant tout affichage (valable 15 min, gardé en mémoire uniquement, lien « verrouiller », 5 essais max / 15 min, chaque consultation et chaque erreur notée dans l'historique). Le PIN est le même que celui de la planification par défaut ; il n'est jamais écrit dans le code (empreinte uniquement).
- Import collé : sections « Bornes : » et « Téléphones PC : » rangées dans leurs propres groupes.
- Consignes permanentes notes 1 à 7 : Thierry MARCON remplacé par Gregory TOSELLO.

## v4.30
- Nouveau module « Contacts SPL » (Urgence) : nom, prénom, fonction, poste fixe et mobile, recherche, appel en un clic.
- Accès : compte PC sécurité, SSIAP 2, Rochdi, Jérémy Mercher, Laurent Hernandez. Personne d'autre (ni clients, ni ADS, ni SSIAP 3, ni adjoint planif).
- Mise à jour par copier-coller (Rochdi et Laurent). Liste chiffrée dans le stockage Netlify, jamais dans le code ; consultations notées dans l'historique.

## v4.31
- Mise à jour forcée : si l'appli affichée est plus ancienne que le serveur, elle vide son cache et se recharge toute seule (une fois).
- Service worker : installation tolérante (un fichier en échec ne bloque plus la mise à jour), fichiers toujours pris sur le réseau ; sw.js et index.html jamais gardés en cache.
- Page de secours /reparer.html : efface l'ancienne version sur l'appareil et relance la dernière (la connexion est gardée).

## v4.32
- Postes de l'Arena : 30 postes (portes 1 à 8, backstage, cour de service, portes grises, parvis, parkings, terrain/FOP, régie, parterre, devant de scène, gradin haut, côtés cour/jardin, étages, zones sportives, PC, volants) reconnus à partir des intitulés des plannings.
- Plan Arena : chaque poste placé sur le plan (point vert plein = agent présent), fiche au toucher ; postes hors plan RDC (étages, parkings extérieurs, zones sportives, volants) listés sous le plan avec leurs agents.
- Prise de service : liste « Postes Arena Sud de France ». Carte des postes : postes Arena ajoutés (consignes, photos, GPS).

## v4.33
- Plan interactif (site et Arena) : extincteurs, RIA, BAES, issues, DM, PCF, désenfumage, colonnes sèches… et points de fermeture (portails, portes, rideaux…) affichés sur le plan ; anomalie en cours = cerclé orange clignotant ; fiche au toucher (état, anomalie, dernier contrôle, historique).
- Bouton « Placer » dans le registre (ronde et registre) : on touche l'endroit sur le plan, la position est gardée pour toutes les rondes suivantes. « Déplacer sur le plan » depuis la fiche.
- Rondes sur le plan : ordre de passage enregistré (heure de chaque contrôle), tracé numéroté de la ronde (orange = anomalie), durée, résultats ; choix de la ronde sous le plan ou « Voir la ronde sur le plan » dans Rondes faites. Calques Moyens de secours / Points de fermeture.

## v4.34
- Rondes NFC → « NFC Tools » : préparation des pointeaux dans l'ordre de la ronde. On écrit les points (un par ligne), l'appli crée un lien unique par pointeau ; bouton « Copier le lien » à coller dans NFC Tools (Écrire → URL), case « Écrit », test du pointeau (Android), impression des étiquettes + QR de secours. Fonctionne sur iPhone et Android.

## v4.35
- Rondes → « Pointeaux » (Rochdi uniquement) : sur les 3 listes, on scanne le pointeau avec le téléphone (Android + Chrome), l'appli récupère son numéro et le met sur le point choisi ; « Scanner toute la liste dans l'ordre » enchaîne les points ; bouton N° pour taper un numéro à la main ; ajouter, renommer, monter, retirer des points. Un point commun à plusieurs listes (ex. PCS début de ronde) est mis à jour partout.
- Parcours et pointeaux modifiables uniquement par le propriétaire (serveur). Assistant NFC Tools retiré.

## v4.36
- Pointeau N°1 « PCS Parc Expo – début de ronde » (0411E11A301291) enregistré dans les 3 rondes, y compris les rondes déjà en cours.
- Pendant une ronde, si Rochdi scanne un pointeau inconnu, l'appli propose de l'associer tout de suite à un point (numéro récupéré par le scan) puis le pointe.
- Toute modification des parcours est appliquée aux rondes en cours.

## v4.37
- Rondes NFC : pointage à la main (✋) réservé à Rochdi et Laurent Hernandez (bouton masqué pour les autres, refus côté serveur). Les autres agents scannent le pointeau ou son QR de secours ; une anomalie se signale sur un point déjà scanné.

## v4.38
- Ronde Arena : pointeau N°02 « Cage d'escaliers n°4 – côté cour » enregistré (040DD61A301291), y compris dans la ronde en cours.

## v4.39
- Impression : la protection anti-capture ne floute plus la page pendant l'impression (PCS Parc et tous les comptes : PDF, feuille de route, rapports, fiches, planning…).
- Codes cadenas : le PC sécurité y accède directement (plus de code contacts en plus) ; le code PIN reste demandé pour afficher chaque code.

## v4.40
- Rondes NFC : dès qu'un pointeau est scanné, la ligne passe en vert (orange si anomalie) avec un flash, double vibration et sonnerie ; pointeau refusé = longue vibration + son grave. Icônes photo et pointage à la main visibles.

## v4.41
- Impression ouverte au PC sécurité, aux SSIAP 2, aux administrateurs, aux responsables et à Rochdi : bouton « Imprimer » sur tous les écrans + toutes les fiches. Code d'impression demandé une fois (valable 12 h sur l'appareil, vérifié par le serveur, 5 essais max) ; Rochdi sans code. Les autres comptes ne peuvent pas imprimer.

## v4.42
- Impression aussi par le menu du navigateur (Ctrl+P) : l'écran affiché s'imprime dès que le code a été entré (Rochdi sans code). Bandeau « Installer » masqué pendant l'aperçu d'impression (il cachait le bouton Fermer sur ordinateur).

## v4.43
- Aperçus d'impression / PDF (consignes permanentes, fiches, registres, feuille de route, rapports…) : barre fixe en haut avec « ← Retour » et « Imprimer / PDF » ; le bouton retour du téléphone ferme aussi l'aperçu.

## v4.44
- Rondes NFC : après chaque pointeau scanné, choix « RAS » ou « Anomalie à signaler » ; bouton Anomalie sur chaque point pointé (choix rapides, description, photo). Chaque anomalie de pointeau apparaît au fil de l'eau à l'heure où elle est rédigée.
- Fin de ronde : rapport PDF (points dans l'ordre, heures, RAS / anomalie / oublié, observations, photos) envoyé en pièce jointe à courrier.laurent@free.fr (liste de diffusion Rochdi + Laurent). Bouton « Rapport PDF » dans l'historique des rondes.

## v4.45
- Impression blanche corrigée : le filigrane anti-capture recouvrait toute la page à l'impression. Il est masqué à l'impression ; le code de traçage NM-… est imprimé en pied de page.
- Code d'impression accepté pour les comptes responsables (ils étaient bloqués par la lecture seule). Barre « Retour » jamais imprimée.

## v4.46
- Impression vérifiée écran par écran (propriétaire, compte PC, SSIAP 2) : 60+ aperçus testés, tous lisibles. Bilan mensuel imprimé dans l'appli (plus de fenêtre bloquée sur téléphone / appli installée), relève imprimée avec le même aperçu (code + Retour).

## v4.47
- Impression : plus aucune restriction par profil (PC, Laurent, SSIAP 2, responsables, adjoint planification, agents…) — seul le code d'impression est demandé (le code de planification est aussi accepté s'il a été changé). Marche aussi hors vacation et en mode « Voir comme ». Client : pas d'impression.

## v4.48
- Feuilles de route au format du PC : une feuille par jour et par événement, bandeau à la couleur de l'événement (nom, site, date, page), tableau NOM Prénom / Prise de service / Fin / Poste-Mission / N° Radio / N° Clé / N° PTI / HALL, sections SSIAP 3 → SSIAP 2 → SSIAP 1 → Agents de sécurité (ADS). Bouton « Imprimer plusieurs jours » (jusqu'à 31 jours d'un coup).

## v4.49
- Codes cadenas / bornes / téléphones PC : les 31 codes de la liste officielle sont intégrés à l'appli, chiffrés (clé dérivée du code PIN, jamais en clair dans le code). Ils s'installent tout seuls au premier code PIN correct dans « Codes cadenas » (la liste remplace l'ancienne).

## v4.50
- Nouveau parcours « Ronde test Parc (6 points) » avec les 6 pointeaux scannés par Rochdi (n° 1 à 6).

## v4.51
- Nouveau répertoire « Ascenseurs » (Moyens et site) : 7 appareils Arena (AS1 à AS6 + monte-charges à cour) et 5 Parc, avec référence OTIS, téléphone cabine (appel en un clic), localisation. Bouton « Appeler OTIS » (0 800 24 24 07), consignes interphone (PCSI, 15 s, touche 3), procédure interventions bâtiment (SPIE).
- Signaler une panne ou des personnes bloquées : main courante automatique, appareil en rouge/orange en haut, « OTIS prévenu », « Remis en service », historique. Mail à Rochdi et Laurent pour une personne bloquée.

## v4.52
- Ascenseurs : les numéros sont les lignes des interphones. Nouvel encadré « Un interphone appelle ? » : on tape les derniers chiffres du numéro affiché (ou on touche une case 6941, 6942…) et l'appli affiche l'appareil (AS3 · Loges artistes…) avec « Signaler » et « OTIS ». Boutons « Interphone 04 67 17 … » pour rappeler la cabine.

## v4.53
- Nouveau module « Permis de feu » (Opérations) : date + heure (fin facultative), photo du permis (jusqu'à 4 pages, qualité lisible), précisions facultatives → enregistré (PF-AAAA-NNNN), noté en main courante / fil de l'eau et envoyé par mail avec les photos à la liste de diffusion des permis de feu.
- Liste de diffusion des permis de feu gérée par Rochdi et Laurent (une adresse par ligne). Tant qu'elle est vide : envoi à Rochdi et Laurent.

## v4.54
- Ronde test Parc : le pointeau 04:21:BE:02:F8:0F:91 devient le n° 1 (échangé avec le n° 2), y compris dans une ronde test en cours.

## v4.55
- Ronde test Parc : ordre réel des 6 pastilles (1 = 04:21:BE…, 2 = 04:F2:EF…, 3 = 04:36:88…, 4 = 04:CE:40…, 5 = 04:53:C6…, 6 = 04:59:D5…), appliqué aussi à une ronde test en cours.

## v4.56
- Aide-mémoire SST interactif (Urgence) : appels PC / 15 / 18 / 112, plan d'intervention en 4 étapes (protéger, examiner, faire alerter, secourir), examen guidé par questions OUI / NON qui mène à la bonne fiche, 8 fiches « secourir » à cocher, métronome de massage cardiaque (110/min, 30/2 ou 15/2, bip + vibration). Fonctionne hors connexion.

## v4.57
- Nouvelle navigation, simple et sans doublon. Barre du bas pour tous : Accueil · Main courante · Téléphone · Alerte · Menu.
- Accueil allégé : ma vacation, rappels, 6 accès rapides selon le profil (plus de grille complète du menu, plus de numéros en double).
- Menu par groupes : Sur le terrain · Urgence · Site et moyens · Équipe et planning · Pilotage · Mon espace · Réglages. Un appui sur un groupe l'ouvre (bouton Retour), recherche en haut. Chaque fonction n'apparaît qu'une fois.
- Nouvel onglet Téléphone : urgences, PC sécurité et encadrement, prestataires (OTIS, SPIE), client SPL, agents — selon le niveau : ADS et SSIAP 1 n'ont que les urgences, le PC et l'encadrement (prestataires, client et agents refusés aussi côté serveur).
- Main courante simplifiée : l'essentiel d'abord (type, lieu, faits, gravité, photo), le reste dans « Plus de détails ».

## v4.58
- Procédures guidées remplacées par les consignes de la direction SPL Occitanie Events (notes PC 01 à 07, V2 sept. 2024) : détection incendie (feu avéré / sans départ de feu), secours à la personne, alerte à la bombe, colis suspect, rixe, attaque terroriste, conditions exceptionnelles. Anciennes fiches supprimées. Bouton « Voir la note » (numéros de la direction) ; le code CMSI n'est pas écrit dans l'appli.
- Alexandre Brand supprimé de l'application : compte supprimé, connexion refusée, session coupée, retiré des planificateurs, administrateurs, licences, contacts et destinataires.

## v4.59
- « Retour de consignes » devient un registre à part (Site et moyens, à côté des objets trouvés), qui fonctionne comme les objets trouvés : numéro RC-AAAA-NNNN, n° du ticket, consigne d'origine, catégorie, description, remis par, déposé au coffre / dans le bac de rangement / autre, photo, restitution signée, autres suites, recherche. Retiré de l'écran des objets trouvés.
- Ronde test Parc : pointeaux n° 2 et n° 3 inversés.

## v4.60
- Plan Arena : affectation des agents sur les postes (portes 1 à 8 et postes du plan). Carte « Affectations » (un menu par agent, non placés en premier) et, sur la fiche d'un poste, « Affecter un agent ici ».
- L'affectation manuelle passe avant le placement automatique ; elle est gardée par date (60 jours) et tracée au journal.
- Modification : propriétaire, admin, PC, coordinateurs et planificateurs. Lecture : encadrement et SSIAP 3. Jamais le client.

## v4.61
- Rapports SSI du PC sécurité, en tête de la page Rapports. Les anciens types « Défaut / dérangement SSI » et « Mise hors service / isolement SSI » sont retirés (les rapports déjà faits restent dans l'historique).
- SSI · PCS Parc des expositions : prise en compte SSI Parc (ECS, AEB, CMSI : essai de signalisation coché + bilan), report SSI Arena (ECS, CMSI), anomalie SSI Parc et anomalie report Parc (rapport + photo), mise en essai et mise hors service zones / points (PCS Parc ou PCS Arena, sous la demande de).
- SSI · SSIAP 2 PCS Arena : SSI Arena (ECS, CMSI), anomalie SSI Arena (rapport + photo), mise hors service zones / points.
- Réservé au PC, aux SSIAP 2, au propriétaire et aux admins (contrôlé aussi côté serveur). Le PCS Arena ne voit que la partie Arena.

## v4.62
- Main courante : nouvelle famille « SPL - SSI » (SSIAP 2 PC Parc et SSIAP 2 PCS Arena). Choisir un type SSI affiche directement le formulaire SSI (cases d'essai + bilans, anomalie + photo, mise en essai / hors service), enregistré en rapport et en main courante.

## v4.63
- SSI : ajout de « Détection incendie · SSI Parc des expositions » et « Détection incendie · SSI Arena » (zone / point, résultat de la levée de doute, SDI et CMSI réarmés, bilan, photo), en rapport et en main courante (famille SPL - SSI).
- « Prise en compte SSI Parc des expositions » devient « SSI Parc des expositions ».

## v4.64
- Photo de profil : Menu > Mon espace > « Ma photo de profil » (recadrée en carré, affichée sur l'accueil). Le propriétaire et les admins peuvent mettre la photo d'un collègue. Jamais visible par le client.
- Photos de l'équipe PC (5) livrées chiffrées dans `netlify/lib/avatars-initiaux.json` : installées avec le code PIN depuis « Ma photo de profil », puis rattachées à chaque compte par le nom.

## v4.65
- Nouvelle photo de Laurent Hernandez. Le lot de photos est versionné : s'il a déjà été installé, la carte d'installation revient et remplace les photos posées par Kaelum e-PCS (pas celles changées par la personne).

## v4.66
- Photo de Laurent Hernandez : retour à la photo sur fond blanc (lot de photos v3).

## v4.67
- Photo de profil de Xavier Négrier ajoutée (lot de photos v4, 6 photos).

## v4.68
- Nouvelle photo de profil de Rochdi Mecheti (lot de photos v5).

## v4.69
- Messagerie à sens unique : seul le propriétaire écrit (Menu > Mon espace > Messagerie), à des profils (PC, SSIAP 3, SSIAP 2, SSIAP 1, ADS, admins, responsables) et/ou à des personnes choisies. Option « Important ». Notification sur le téléphone.
- Les destinataires lisent sans répondre (« Messages de Rochdi », bandeau rouge sur l'accueil s'il y a du nouveau), même hors vacation. Accusé de lecture : « Lu par X / Y » avec les noms. Suppression possible. Jamais le client.

## v4.70
- Messagerie : messages types « Bienvenue » (collaborateur, collaboratrice, à toutes et à tous) chargés en un clic, modifiables avant envoi.

## v4.71
- Messagerie : un seul message de bienvenue, au pluriel, signé « L'équipe Kaelum e-PCS · Application créée par Rochdi Mecheti ».

## v4.72
- Connexion par badge NFC (cartes existantes du PCS) : bouton « Se connecter avec mon badge NFC » sur l'écran de connexion (Android + Chrome). Le numéro du badge est haché côté serveur (jamais en clair), 5 essais puis 15 min de blocage, chaque connexion par badge est notée au journal.
- Menu > Mon espace > « Badges NFC de connexion » (propriétaire seul) : associer un badge à un compte SSIAP 2 / PC (ou à soi), voir la dernière connexion, retirer un badge.

## v4.73
- Fahd Hadouche repasse en accès SSIAP 2 : retiré de la liste « SMS / planning seulement », compte remis en SSIAP 2 (migration fahd-ssiap2-2026-10).

## v4.74
- Fahd Hadouche : SSIAP 2 + adjoint planification (liste `adjoints_planif`). Il garde, à toute heure : planning général et rappels SMS, numéros des agents, grille des disponibilités, feuille de route (voir, modifier, ajouter), modifier / affecter une vacation. Le reste de l'appli suit les règles SSIAP 2 (1 h avant / 1 h après la vacation).
- Nouveau champ « Intitulé du poste » dans « Modifier la vacation » (adjoint, coordination, planificateurs) : changement noté au journal, intitulé d'origine gardé.

## v4.75
- « Planning du mois (Parc / Arena) » (#/planmois) : adjoint planification (Fahd), PC, coordination, planificateurs. Mois au choix, filtre Tout / Parc / Arena, recherche par agent ou par poste.
- Modifier une vacation (intitulé du poste, agent, horaires), passer en non affecté, supprimer un poste. Les SMS de rappel suivent le planning (rappel à renvoyer si agent / horaires / poste changent) et la feuille de route retouchée à la main est mise à jour automatiquement.
- Planning d'un agent : « Imprimer / PDF » et envoi du PDF par mail à une adresse saisie (noté au journal).

## v4.76
- Planning du mois : vue « Tableau 31 jours » (par défaut) — une ligne par agent, une colonne par jour, en-têtes et noms figés, bleu = Parc, orange = Arena. Toucher une case : modifier la vacation ; toucher une case vide : ajouter une vacation (poste, horaires, site, événement). Filtres Tout / Parc / Arena et recherche agent / poste conservés.
- Nouvelle route POST planning/ajouter (adjoint planification, coordination, planificateurs) : ajout noté au journal, feuille de route retouchée mise à jour, rappel SMS à envoyer.

## v4.77
- SSI · SSIAP 2 PCS Arena : ajout de « Mise en essai zones / points · PCS Arena » (rapports et main courante).
- Nouveau logo Kaelum e-PCS (icônes, écran de connexion, favicon). Mention « © Kaelum e-PCS — logo, graphisme et mise en page propriété de Kaelum e-PCS » sur l'écran de connexion, le pied de page et les impressions.
- Filigrane de traçage présent en permanence pour tout le monde, propriétaire compris ; code de traçage imprimé en pied de page de chaque impression.
- Niveaux de badge : Or (Rochdi, Laurent Hernandez, Jérémy Mercher), All accès (SSIAP 2 du PC Parc + adjoint planification), Admin, Utilisateur (agents). Affichés sur l'accueil et dans le menu.
- Connexion NFC sans mot de passe réservée aux badges Or et All accès.
- Sécurité de session : session gardée seulement le temps de l'appli ouverte (fermer l'appli = déconnexion), 15 min sans activité = déconnexion, appli quittée plus de 2 min = déconnexion (sauf écran mural du centre de commandement). Les notifications continuent d'arriver grâce à un jeton « notifications » limité à la lecture de la dernière notification.

## v4.78
- Photo de profil de Fahd Hadouche ajoutée (lot de photos v6, 7 personnes).

## v4.79
- Thème « Cockpit » (mode sombre) : fond animé lumière rouge / bleue avec grille, cartes en verre fumé, boutons néon avec reflet, segments et champs lumineux, barre d'onglets en verre avec indicateur néon, accueil façon cockpit (balayage, compteurs lumineux, bouton Secours pulsé), menus avec halo, notifications en verre, entrée animée des écrans. Respecte « réduire les animations » du téléphone ; le mode clair est inchangé.

## v4.80
- Écran de connexion spectaculaire : logo vivant (flottement, reflet, double anneau lumineux qui tourne), carte de connexion au bord lumineux animé, bouton « badge NFC » avec ondes qui pulsent pendant le scan.
- Écran « Accès autorisé » (ou « Badge NFC reconnu ») après chaque connexion : photo de profil dans un anneau tournant, coche verte, nom, niveau de badge (or, rouge, bleu, gris), vibration, barre de chargement ; disparaît seul en 2 s ou au toucher.

## v4.81
- Badge NFC de Laurent Hernandez préparé : seule l'empreinte du numéro est dans le code (jamais le numéro). Il est rattaché à son compte au premier passage de la carte, puis visible dans « Badges NFC de connexion ».

## v4.82
- Slogan : « Votre sécurité, notre priorité » · « Prévention · Sûreté · Sécurité incendie » · « Créé par Rochdi Mecheti ». Mentions de protection retirées de l'affichage de l'appli (pied de page et impressions).

## v4.83
- Fiche réflexe : une saisie de main courante (ou un rapport « Détection incendie » non intempestif) qui correspond à une consigne de la direction ouvre aussitôt la procédure guidée associée (incendie, secours, alerte à la bombe, colis suspect, rixe, attaque, conditions exceptionnelles), avec les numéros d'urgence.
- Chrono des faits non clos dans la main courante : « ouvert depuis… », orange puis rouge clignotant (urgent > 15 min, moyen > 60 min).
- Relance automatique (fonction planifiée faits-escalade, toutes les 5 min) : un fait urgent toujours ouvert déclenche une notification au PC à 15, 30 et 60 min ; un fait moyen à 60 min. Noté au journal.

## v4.84
- Feuille de route imprimable au design « noir sur blanc » de la plaquette : logo Kaelum e-PCS, titre de l'événement en noir, couleur de l'événement en filet (barre à gauche, pastille, séparateurs de sections) au lieu des bandeaux pleins, tableau aéré, pied de page « Kaelum e-PCS · Votre sécurité, notre priorité · PC Sécurité ». Même organisation : une feuille par jour et par événement, SSIAP 3 → SSIAP 2 → SSIAP 1 → ADS, colonnes N° Radio / Clé / PTI / HALL à remplir.

## v4.85
- 2e badge NFC de Laurent Hernandez préparé (empreinte seulement), activé au premier passage.

## v4.86
- Brief Foire Internationale de Montpellier 2026 : consignes d'EXPLOITATION du brief gardiens ajoutées en tête (alertes : véhicules autorisés, cohabitations Urologie / Century 21 / Legend, inauguration, Moinon / Kouign Amann, soirées officielles du 13/10, parkings Pailletrice et P1 / P6 Inter, scolaires, événements éphémères) et consignes par poste : fouilles, parking exposant A, parvis A, Portail P3, pâte d'oie, Mail central, P6 rond-point, P1 / P6 Inter, contrôle pass montage (1er jour), agents de nuit, PC sécurité, avec les macarons. Chaque agent voit automatiquement la consigne de son poste du planning. Les consignes de montage restent à la suite (« (montage) »). Migration fim26-exploitation-v1.

## v4.87
- Feuilles de route : retour au gabarit PC d'origine, en A4 paysage, avec un bandeau couleur par événement (Foire, Legend, agents clefs…). Ordre des sections : SSIAP 3, SSIAP 2, SSIAP 1, chef d'équipe, ADS, ADS de nuit, cynophile. Colonnes N° Radio / N° Clé / N° PTI, plus HALL au Parc. Pied de page « Visa responsable ».
- L'écran Feuille de route affiche directement les feuilles du gabarit : ce qu'on voit est ce qui s'imprime. Deux événements du même jour n'ont jamais la même couleur.
- Nettoyage : refus propre d'un compte sans mot de passe valide (plus d'erreur serveur à la connexion). L'accès client ne charge plus les zones internes.

## v4.88
- Réponses aux alertes : sur chaque alerte en cours (et sur l'écran plein de l'alerte forcée), les collègues répondent en un geste : « J'arrive », « Plus de détails ? », « Ne te mets pas en danger ! ». Chaque réponse s'affiche avec le nom et le poste de l'agent, l'heure, part en notification à l'auteur et au PC, et s'inscrit au journal.
- L'auteur de l'alerte (ou le PC) ajoute une précision, diffusée à tous les agents en service.
- Alarme PTI / SOS : désormais tous les agents en service sont prévenus (bandeau « Collègue en danger », sirène, notification) et peuvent répondre de la même façon. L'agent en alarme voit les réponses en direct et peut préciser sa situation. Un SOS réactive la protection si elle était arrêtée.
- L'alerte affiche aussi le poste de celui qui l'a lancée. Les alertes et alarmes en cours passent en haut de leur page. L'accès client ne voit ni les noms ni les réponses.

## v4.89
- Retour d'expérience (menu Sur le terrain → Retour d'expérience) : Anomalie, Amélioration, Faille de sécurité, Autre. La vacation et l'événement du jour sont remplis tout seuls. Proposé automatiquement après chaque fin de service (ou « Rien à signaler »). Chaque retour (RX-2026-0001…) part au SSIAP 3, qui le traite un par un : nouveau → en cours → traité / classé, avec une réponse visible par l'agent. Une faille de sécurité n'est visible que par l'agent et le SSIAP 3.
- Flammes de fidélité : prise de service (+10, +15 si à l'heure), fin de service (+10), vacation complète (+5), série de 10 vacations complètes (+50), consigne lue (+5), ronde complète (+30), « J'arrive » sur une alerte ou un PTI (+15 / +20), retour d'expérience (+20, +50 s'il est jugé utile).
- Un badge de plus tous les 1 000 flammes (Recrue, Sentinelle, Veilleur, Gardien, Vigie, Rempart, Pilier, Bouclier, Vétéran, Élite, Légende), avec un écran de fête. Profil d'agent : ancienneté, efficacité, réactivité (étoiles), série en cours, classement.
- Missions : un malaise, un feu maîtrisé ou un fait important saisi en main courante crée une mission que le SSIAP 3 valide (150 / 250 / 100 flammes, modifiable) ou refuse. Rien n'est automatique.
- Médailles de vaillant (secours à personne, feu maîtrisé, sang-froid, vigilance, esprit d'équipe) : remises par le SSIAP 3 avec un motif, +300 flammes. Tableau d'honneur et dernières médailles visibles par l'équipe (jamais par le client).
- Accueil : carte flammes avec la barre vers le prochain badge.

## v4.90
- Missions créditées automatiquement : un malaise / secours (+150), un feu maîtrisé (+250) ou un fait important (+100) saisi en main courante rapporte les flammes tout de suite. Le SSIAP 3 est prévenu, peut annuler une mission abusive (les flammes sont retirées) ou remettre une médaille de vaillant directement depuis la mission.
- Podomètre : compte les pas quand l'appli est ouverte et le téléphone sur soi (activé tout seul sur Android, bouton « Activer » sur iPhone). +5 flammes tous les 1 000 pas, 30 000 pas comptés par jour au maximum, 200 pas par minute au plus (anti-triche). Pas du jour et kilomètres affichés sur l'accueil et dans Mes flammes.
- Classement des marcheurs : aujourd'hui, ce mois, depuis le début (pas et km).

## v4.91
- Médailles de vaillant affichées sur les profils : sous le nom à l'accueil (badge + médailles, pour les agents comme pour les administrateurs), dans la liste des comptes de l'administration (badge, flammes et médailles de chaque utilisateur), et dans le tableau d'honneur. Une médaille par type, avec « ×3 » si elle a été reçue plusieurs fois ; un appui ouvre le détail (motif et date).

## v4.92
- Agent du mois (menu Mon espace → Agent du mois), style « employé du mois », visible uniquement entre agents (jamais côté client) : cadre doré avec la photo, le badge, les médailles, les quatre notes (ponctualité, assiduité, professionnalisme, réactivité), la note globale et le mot du SSIAP 3.
- Désigné automatiquement au début de chaque mois d'après les notes du mois précédent (3 vacations minimum), +200 flammes et notification. Le SSIAP 3 peut choisir un autre agent et ajouter un mot.
- La course du mois en cours : ta place et tes quatre notes, le classement, les meilleurs par compétence, l'historique des agents du mois. Carte « Agent du mois » sur l'accueil.
- Notes sur 100 : ponctualité = prises de service à l'heure ; assiduité = fins de service et vacations complètes ; professionnalisme = consignes lues, rondes, retours d'expérience, main courante ; réactivité = « J'arrive », missions, médailles. Les compteurs du mois démarrent à la mise en ligne de cette version.

## v4.93
- Commande client → planning : lecture du « dispositif sécurité » des PDF clients (tableau Désignation | Début | Fin | Hrs jour | Hrs nuit | Agts). Seul le dispositif sécurité est pris (sécurité incendie, entrées / fouilles, salle, scène, extérieurs et parkings) ; le dispositif contrôle, le nettoyage, le tri des déchets et les traiteurs sont ignorés. Date, événement et site lus dans le document.
- Spécialités des agents (Équipe et planning → Spécialités des agents) : Rochdi, Jérémy Mercher et Laurent Hernandez renseignent les postes maîtrisés par chaque agent (ex. SSIAP 1 hall, Agent P3, Mail central), avec les habitudes tirées du planning comme suggestions. La proposition place en priorité le spécialiste du poste.
- Proposition de planning : rythme 2 jours sur 2 au choix, vacations de plus de 12 h coupées en deux relèves, repos de 11 h et 48 h / semaine obligatoires, 6 jours travaillés d'affilée au maximum, plannings déjà prévus pris en compte.

## v4.94
- Chaque commande client téléversée (PDF) enrichit un catalogue des postes du dispositif sécurité (poste, qualification, site, nombre de fois, événements). Ce catalogue est proposé en premier dans les spécialités des agents ; un poste peut être retiré du catalogue.

## v4.95
- Lancement du protocole de motivation : à la première ouverture après la mise à jour, chaque agent voit une fois la présentation (flammes, badges, médailles de vaillant, agent du mois, podomètre, retour d'expérience), sur tous ses appareils. Jamais côté client.
- Messagerie : nouveau modèle « Lancement : flammes, médailles, agent du mois » à envoyer à tous les profils.

## v4.96
- Phase de test du programme : bandeau « Phase de test » sur Mes flammes et Agent du mois, présentation adaptée pour les testeurs, nouveau type de retour d'expérience « Avis phase de test ». Le propriétaire déclenche le lancement officiel (remise à zéro des flammes, badges, médailles, missions et agents du mois de test ; retours d'expérience gardés).
- Tout le monde participe, encadrement et propriétaire compris. Les agents (badge Utilisateur) ne voient pas les activités des badges Or et All accès dans les classements, le tableau d'honneur, les médailles récentes et la course du mois ; Or, All accès, admins et SSIAP 3 voient tout. Les badges Or et All accès ne sont pas désignés agent du mois automatiquement.

## v4.97
- VICTOIRE : nom du programme. Le message « VICTOIRE » est prêt dans la messagerie (modèle « Victoire (phase de test) ») : le propriétaire l'envoie lui-même.
- Activité agents (Pilotage → Activité agents · Victoire), pour les badges Or, All accès, l'encadrement et le SSIAP 3 : chiffres du mois (participants, flammes, ponctualité, « J'arrive », missions, médailles, pas, retours à traiter), liste de tous les agents avec recherche et tri (flammes, course, pas, dernière activité), détail par agent, fil d'activité.

## v4.98
- Slogan du programme VICTOIRE : « Vous n'êtes pas des numéros, vous êtes indispensables. » Affiché dans la présentation, en tête de Mes flammes, sur le tableau Agent du mois et sur Activité agents, et sous le titre du message VICTOIRE.

## v4.99
- Publicité VICTOIRE à chaque ouverture de l'appli (une fois par ouverture, jamais côté client) : affiche plein écran avec le slogan, la bulle de discussion de Rochdi avec sa photo de profil, les flammes et le badge de l'agent, bouton « Je relève le défi ». Se ferme d'un appui (✕ ou « Plus tard »). Le propriétaire l'active / la désactive et modifie le texte de sa bulle dans Mes flammes (avec aperçu).

## v5.00
- Publicité VICTOIRE : s'affiche à chaque connexion / ouverture de session (avant, elle ne revenait pas après une déconnexion automatique dans le même onglet). À la toute première ouverture, c'est la présentation de VICTOIRE qui s'affiche à la place ; la publicité prend le relais dès l'ouverture suivante.

## v5.01
- Correctif connexion : « Netlify Blobs has generated an internal error (Failed to decode token: Token expired) ». Le magasin de données gardait le jeton d'accès de la première requête, qui expirait quand le serveur restait allumé longtemps. Il est maintenant recréé à chaque opération avec le jeton de la requête en cours, et une seconde tentative est faite si le jeton est refusé.

## v5.02
- Commande client → planning : téléversement de plusieurs PDF d'un coup (tout le dossier du client). Seuls les PDF contenant le dispositif sécurité sont gardés ; les autres (nettoyage, contrôle, traiteurs…) sont ignorés et listés. Les besoins de tous les jours sont regroupés (doublons retirés), puis la proposition place les agents (spécialités, dispos, habitudes, repos 11 h, 48 h / semaine, 2/2).

## v5.03
- Lecture page par page des PDF clients : seules les pages / parties « dispositif (ou commande) sécurité » sont gardées, même dans un PDF qui mélange ménage, contrôle, traiteurs, tri des déchets… La date est lue sur chaque page (plusieurs jours dans un même PDF). Horaires au format 17:30 ou 17h30, nombre d'agents en colonne ou devant l'intitulé.
- Modification / ajout du client le jour même : la commande est comparée au planning déjà enregistré. Les postes inchangés ne sont pas repris, les horaires modifiés mettent à jour la vacation existante (l'agent est gardé, à confirmer), seuls les nouveaux postes sont proposés ; les postes qui ne sont plus dans la commande sont signalés (rien n'est supprimé).
- Placement des agents : 1er passage avec les pros de chaque poste (spécialités), CDI en tête ; 2e passage pour le reste. Case « CDI » dans les spécialités (ou contrat CDI du registre de la société).
- Règles : 11 h de repos entre deux vacations, 48 h travaillées par semaine, 48 h de repos d'affilée par semaine (option cochée par défaut), 6 jours d'affilée au maximum, plannings déjà prévus pris en compte, rythme 2/2 au choix, vacations de plus de 12 h coupées en deux relèves.

## v5.04
- Nouveau logo (Kaelum e-PCS, verre noir et rouge) : icônes de l'appli (192, 512, maskable, Apple), favicon, écran de connexion, bandeau d'accueil.

## v5.05
- Réinitialisation du mot de passe à la prochaine connexion : bouton 🔓 dans la liste des comptes (Administration). Pendant 72 h, à sa prochaine connexion, l'agent choisit lui-même un nouveau mot de passe (avec les 4 derniers chiffres de son téléphone s'il est renseigné), une seule fois.
- Ludivine : réinitialisée automatiquement à la mise en ligne de cette version (si un seul compte « Ludivine » existe ; sinon une ligne au journal invite à le faire dans Administration).

## v5.06
- L'application s'appelle désormais Kaelum e-PCS partout : titre en haut, nom de l'appli installée, onglet, messages, notifications, mails, PDF (main courante, rondes, rapports), centre de commandement.

## v5.07
- Images du logo renommées (m-icon-192.png, m-icon-512.png, m-icon-maskable-512.png, m-apple-touch-icon.png, m-favicon-64.png, fond-mmanager.jpg) pour que les téléphones ne gardent plus l'ancien logo N Manager en mémoire.

## v5.08
- On reste connecté : la session est gardée sur le téléphone quand on quitte l'appli ou la page, plus de déconnexion automatique (15 min sans activité / appli quittée 2 min). Session valable 30 jours, jusqu'au bouton « Déconnexion ». La publicité VICTOIRE reste affichée à chaque ouverture de l'appli.

## v5.09
- Sauvegarde automatique chaque dimanche vers 4 h (nouvelle tâche sauvegarde-hebdo) : toutes les données sauf les photos sont copiées dans un coffre séparé (magasin « ssiap-pro-sauvegardes », 10 dernières gardées) et une copie chiffrée (.mmsave) est envoyée par mail au propriétaire. Sauvegarde manuelle et restauration en un clic (l'état actuel est sauvegardé avant toute restauration, confirmation « RESTAURER »).
- Santé de l'appli (Pilotage, propriétaire) : version en ligne et version du téléphone, historique des mises en ligne, sauvegardes, passage des tâches automatiques (PTI, relances, météo…), erreurs remontées par les téléphones, accès refusés (avec déblocage), comptes en attente d'un nouveau mot de passe, derniers événements à surveiller, réglages (mails, lecture automatique, clé secrète).

## v5.10

Bouton « ➕ Créer un poste » (adjoint planification Fahd Hadouche, planificateurs, coordination, propriétaire) : nom prénom, poste, date et horaires, mission, site, événement. Enregistré dans le planning général, la fiche SMS ({mission}) et la feuille de route (mission sous le poste).

## v5.11

Plan du site : les noms des agents sont masqués par défaut (bouton « 👤 Afficher les noms » pour les voir à la demande, plan du site et plan Arena). Les postes extérieurs sont toujours nommés : P1 inter, P6 rond-point, P6 inter, P7 inter, P8 inter, P3, Mail central, Patte d'oie.

## v5.12

« 📋 Liste des postes · ajouter un poste » pour l'adjoint planification (Fahd Hadouche), aussi ouvert au PC et aux responsables : nom du poste + mission facultative, recherche, modification de la mission. Les postes de la liste sont proposés dans « Créer un poste », qui reprend leur mission automatiquement (fiche SMS, feuille de route).

## v5.13

Fahd Hadouche est reconnu adjoint planification aussi par son nom (quel que soit l'identifiant de son compte) : boutons « ➕ Créer un poste » et « 📋 Liste des postes » toujours visibles pour lui. Liens « Liste des postes » ajoutés dans Planning du mois, Feuille de route et la fenêtre « Créer un poste ».

## v5.14

Fahd Hadouche (adjoint planification) a le même accès que Jérémy Mercher (planification, planning général, badge Or, contacts, spécialités…), sauf les devis et les tarifs : onglets masqués et accès refusé côté serveur.

## v5.15

Liste des postes : chaque poste peut avoir ses horaires (début / fin) en plus de la mission. Champs facultatifs « Nom Prénom » + date + site pour affecter l'agent tout de suite (planning général, fiche SMS, feuille de route). Bouton « Affecter » sur chaque poste de la liste (ouvre « Créer un poste » pré-rempli). « Créer un poste » reprend aussi les horaires du poste choisi.

## v5.16

Accès de l'adjoint planification (Fahd Hadouche) réparés : une ancienne liste « SMS seulement » enregistrée ne peut plus le rétrograder (il reste au niveau de Jérémy Mercher, sauf devis). Au lancement, l'appli redessine l'écran dès que les droits du compte changent.

## v5.17

Boutons « ➕ Créer un poste » et « 📋 Liste des postes » déplacés sur la page Planification (sous les onglets), retirés de l'accueil.

## v5.18

« Créer un poste » contrôle l'agent avant d'enregistrer : déjà planifié sur le créneau, repos de 11 h, 48 h / semaine (alerte dès 44 h), 6 jours d'affilée, absence, vacation de plus de 12 h. Alerte claire, puis « Confirmer quand même » ou changer l'agent / les horaires. Même contrôle pour l'affectation depuis la liste des postes.

## v5.19

Plan du site : toucher un hall l'affiche en grand (zoom animé) pour lire les détails (moyens de secours, postes, agents) ; bouton « ⤺ Plan complet » pour revenir.

## v5.20

Plan : cases « ➕ Ajouter sur le plan » sous le plan (extincteur, RIA, BAES, issue, DM, DAE, porte coupe-feu, désenfumage, colonne sèche, coupures gaz / électricité / eau, hydrant, point de rassemblement, accès pompiers, SSI, trousse de secours, « Autre » avec nom libre). Chaque ajout est rangé dans le registre des moyens de secours : il figure donc aussi dans les rondes incendie. Impression du plan par hall (ou tous les halls, une page par hall) : plan recadré sur le hall, sans aucun nom d'agent, et liste des équipements avec cases de ronde. Bouton « 🖨 Imprimer ce hall » quand un hall est affiché en grand.

## v5.21
Mise à jour des plannings d'octobre 2026 (exports Comète du 14/10) : Arena Sud de France (358 vacations) et Parc des Expositions (708). Import appliqué une seule fois (ids `*-2026-10-v1410`) ; la planification interne est conservée.

## v5.22
Planning ↔ feuille de route ↔ fiches SMS : après une mise à jour du planning, les feuilles de route retouchées à la main (jours à venir du mois importé) sont recalées sur le nouveau planning ; notes, organisateur, effectif et missions sont conservés. Les feuilles non retouchées et les fiches SMS se recalculent déjà depuis le planning.

## v5.23
- Accueil par profil : tuiles d'accès rapide adaptées (propriétaire, adjoint planification, PC / SSIAP 2, SSIAP 3 / coordinateur, SSIAP 1, agent).
- Mode hors ligne : les rondes saisies sans réseau partent au retour du réseau avec leur heure réelle (main courante, rapports et objets trouvés l'étaient déjà).
- Vitesse : sources lisibles dans `src/`, fichiers allégés générés dans `public/` par `./build.sh` (esbuild). **Toujours modifier `src/`, puis lancer `./build.sh`.**
- Brochure Kaelum e-PCS refaite avec captures à jour et noms d'agents anonymisés.

## v5.24
Brochure Kaelum e-PCS partagée par lien : `/doc/Kaelum-e-PCS-plaquette-<code>.pdf` (non indexée). Toute personne qui a le lien peut l'ouvrir.

## v5.25 · Appli Android (podomètre en veille)
- Dossier `apk/` : configuration Capacitor + plugin natif `StepsPlugin` (capteur matériel de pas du téléphone, lu à l'ouverture et chaque minute). L'appli Android charge le site Kaelum e-PCS (mises à jour automatiques).
- `apk/apk.yml` : workflow GitHub à déplacer en `.github/workflows/apk.yml` (modifier le nom du fichier dans l'éditeur GitHub). Onglet Actions → « Appli Android » → Run workflow : construit l'APK, le publie en Release `android` et dans `/doc/Kaelum-e-PCS-appli-android.apk`.
- Serveur : `flammes/pas` accepte `{ natif: true, jourPas }` (total du jour du capteur, plafonné à 200 pas/min depuis minuit et 30 000/jour).

## v5.26 — Compte rendu par hall
- Plan : toucher un hall affiche « 📋 Compte rendu · ronde » et, dans la fiche, « Faire la ronde sécurité incendie » (fiche de ronde sans plan, par hall) et « Compte rendu du hall ».
- Moyens de secours et d'extinction / Sûreté : nouvel onglet « Compte rendu » (mois + hall ou tous les halls) → impression PDF A4 : synthèse tous halls, rondes du mois, détail des anomalies (constatées, rectifiées), anomalies en cours, signatures.

## v5.27 — Centre de commandement : radar des halls
- `#/ecran` : nouveau panneau « Radar des halls » (état de chaque hall : RAS / anomalies / dernière ronde, balayage radar animé, fond grille néon), bâtiments ouverts et éclairés. Données ajoutées à `GET /api/ecran` (`radar`, `bats`), non transmises au client.

## v5.28 — Alerte sonore du centre de commandement
- `#/ecran` : bouton « Activer l'alerte sonore » : bip + annonce vocale quand le niveau passe en vigilance ou tension (le navigateur exige un clic pour autoriser le son).

## v5.29 — Roch SSI Simulator
- Module `#/ssi` (SSIAP, PCS, responsables, propriétaire) : tableau SSI virtuel (3 scénarios : fausse alerte, feu confirmé, déclencheur manuel), départ de feu sur un hall avec les données du site (rassemblement, extincteurs enregistrés, accès pompiers), quiz SSIAP de 30 questions (10 tirées au hasard). Entraînement seulement : rien n'est envoyé au serveur, meilleurs scores gardés sur le téléphone. Fichier `src/ssi.js` chargé à la demande.

## v5.30 — Radio agents
- `#/radio` : messages vocaux appuyer-parler entre agents (canaux Parc, Arena, PC, Urgence), lecture automatique, historique 24 h purgé automatiquement, notification push (Urgence forcée). API `radio` (GET, POST, GET radio/audio/<id>). Interdit au client. Le micro doit être autorisé dans le navigateur ; l'appli Android native demandera la permission micro à une prochaine version de l'APK.

## v5.31 — Radio ROCH 2105 façon talkie-walkie
- Interface réaliste : antenne, molette de canal (cliquable), bouton URG orange, plaque ROCH 2105, écran LCD (RX/TX, canal, signal), grille de haut-parleur, touches ◀ MON ▶, grosse touche PTT.
- Raccourci : tuile « Radio ROCH 2105 » toujours en tête des accès rapides ; page installable `/radio.html` (icône et nom propres « ROCH 2105 » sur l'écran d'accueil) ; raccourci d'appui long sur l'icône Kaelum e-PCS.

## v5.32 — Radio : mise en marche
- Bouton « ALLUMER LA RADIO » (un geste est exigé par les téléphones pour le micro et le son), messages d'erreur lisibles sur l'écran LCD (micro refusé, absent, navigateur sans micro), micro gardé ouvert seulement pendant que l'écran radio est ouvert, correction du relâchement du bouton avant que le micro soit prêt.

## v5.33 — Noms et micro
- « Kaelum e-PCS Radio » (plaque, menu, icône d'installation `/radio.html`, raccourci) et « Simulateur SSI ». Bannière radio en tête de l'accueil et première tuile des accès rapides.
- Radio : diagnostic du micro (état de l'autorisation, code d'erreur, étapes Android / iPhone, bouton Réessayer, méthode de secours « enregistrer avec le téléphone »).

## v5.34 — Photo preuve horodatée
- `#/preuve` : photo avec date et heure (Paris), lieu, légende, position GPS, code de traçabilité de l'agent (jamais son nom) et empreinte incrustés ; enregistrer, partager ou joindre à une main courante. Les photos ajoutées depuis la main courante sont aussi horodatées.

## v5.35 — Photos et messages radio éphémères (24 h)
- `POST /api/preuves` : la photo preuve peut être envoyée au PC ; elle est effacée (fichier compris) après 24 h. Même règle pour les messages vocaux de la radio. Effacement à chaque appel et toutes les heures par `netlify/functions/ephemeres-purge.mjs`. Les photos jointes à une main courante gardent la durée de conservation de la main courante.

## v5.36 — BAES Arena et A1 dans la ronde incendie
- Migration unique `baes-arena-a1-2026-10` : pour Arena Sud de France et le hall A1, BAES AC01→AC59 (clarté) et A001→A045 (sur les issues de secours) ajoutés au registre des moyens de secours, donc à la ronde incendie. Rien n'est dupliqué si elle est rejouée.

## v5.37 — Emplacements réels des BAES d'Arena
- Clarté AC01→AC59 : portes vitrées face parking Nord, côtés Est et Ouest (moitié du bâtiment). Issues de secours : A045 au PCS (départ de ronde) vers le côté aéroport (A007). La fiche de ronde suit ce sens (A045 → A001). Migration `baes-emplacements-2026-10` sans écraser les modifications manuelles.

## v5.38 — « Clarites »
- Les BAES AC01→AC59 portent le nom « Clarites » (migration `baes-clarites-2026-10`).

## v5.39 — Radio et simulateur SSI supprimés
- Suppression de la radio (messages vocaux : écran, API, page `/radio.html`, icônes, raccourci) et du simulateur SSI. Les messages vocaux déjà enregistrés sont effacés au premier appel (`radio-supprimee-2026-10`). La photo preuve (effacée après 24 h), le centre de commandement et les BAES restent.

## v5.40 — Suppression groupée dans le registre
- Registre des moyens de secours (propriétaire, PCS, SSIAP 2) : bouton « Supprimer plusieurs », « Cocher les ajouts récents » (ajouts manuels des 48 dernières heures du hall choisi) et « Supprimer la sélection ». Le matériel retiré disparaît aussi du plan.

## v5.41 — Accès retiré

Compte supprimé et accès coupés pour une personne désignée par le propriétaire (liste des comptes bloqués, retrait automatique des listes et du contact au prochain démarrage du serveur).

## v5.42 — Planning Arena du 15/10

Planning Arena Sud de France d'octobre remplacé par la dernière édition Comète (359 vacations). Parc des Expositions inchangé. La planification interne est conservée.

## v5.43 — Message de refus

Un compte bloqué voit « Accès non autorisé » à la connexion. Les vacations d'un compte bloqué restent visibles dans le planning.

## v5.44 — Feuilles de route : enregistrer en PDF

Bouton « Enregistrer sur mon téléphone » : crée un PDF A4 paysage identique à l'impression et le télécharge (iPhone : feuille de partage, « Enregistrer dans Fichiers »). Aussi disponible dans l'aperçu d'impression et pour plusieurs jours.

## v5.45 — Lettres de reconnaissance (PDF)

Mon espace ➜ « Lettres de reconnaissance ». Le propriétaire, les SSIAP 3 et la coordination choisissent un agent, un motif, un mot personnel facultatif et envoient une lettre (notification à l'agent). L'agent la retrouve dans l'appli et l'enregistre en PDF A4 sur son téléphone. Le client n'y a pas accès.

## v5.46 — Plus de message VICTOIRE à l'ouverture

La publicité VICTOIRE et la présentation du protocole ne s'affichent plus automatiquement sur l'écran d'accueil. Les flammes, médailles et l'agent du mois restent dans « Mon espace ».

## v5.47 — Lettre de reconnaissance au tutoiement

Texte réécrit (tutoiement, qualités, « le PCS est très fier d'avoir des éléments comme toi »), signée « Kaelum e-PCS ». Plus de champ « fonction ».

## v5.62 · Mode testeur : badge or, accès total pour une personne
- Les 4 testeurs gardent leurs droits habituels ; ils ont seulement le badge or « TESTEUR ».
- L'accès total (24 h / 24, tout consulter sauf planification et codes d'accès) est réservé à Henry Samantha (`testeurTotal`). Gérable dans Espace propriétaire → Mode testeur (bouton « Accès total »).

## v5.63 · Discussions (testeurs + propriétaire seulement)
- Messagerie façon Messenger : discussions privées et groupes, photos, réactions, « Vu », notifications push.
- Messages éphémères : durée 1 h / 24 h / 7 j (défaut) / 30 j réglable par discussion (⚙️). Purge horaire `chat-purge.mjs` + filtre à la lecture ; les photos sont effacées avec le message.
- Réservé aux comptes testeurs et au propriétaire (API `chat`, blobs `chat_convs`, `chat_m_<id>`, store `chat-img`).

## v5.64 · Accès 24/24 pour les 4 testeurs
- Ludivine, Johan, Anthony rejoignent Samantha en accès total (toujours sans planification ni codes d'accès) ; message « 24/24 heures » envoyé.

## v5.65 · Bulle Rochbot
- Se déplace en la glissant (position mémorisée), se masque avec ✕ ; Menu → Mon espace → « Afficher Rochbot » la remet.

## v5.66 · Discussions : effacement après 15 minutes
- Durée par défaut 15 min (option 15 min ajoutée), appliquée à toutes les discussions existantes ; purge toutes les 5 min + filtre à la lecture.

## v5.71 · Remarques des disponibilités visibles

- Dans « Disponibilités des agents », la remarque d'un agent (indisponibilité, contrainte…) s'affiche sur une ligne juste sous sa ligne, sur fond rouge clair, au lieu d'être cachée. Elle apparaît aussi dans l'export PDF.
- La recherche masque la remarque avec l'agent.

## v5.70 · Disponibilités : notification pour Rochdi et Jérémy Mercher

- À chaque envoi de disponibilités d'un agent (formulaire public ou « Mes disponibilités »), une notification arrive sur l'application de **Rochdi** et de **Jérémy Mercher** (appuyer dessus ouvre la grille des disponibilités).
- Il faut avoir activé les notifications dans l'application (Réglages) sur son téléphone. L'envoi est consigné au journal, comme avant.

## v5.69 · Compte Jérémy Mercher (mot de passe provisoire 123456789)

- Compte créé automatiquement au premier démarrage : **jerre34@hotmail.fr** (Jérémy MERCHER, SSIAP 3). Si un compte à son nom ou à cette adresse existe déjà, rien n'est créé et le journal l'indique.
- Mot de passe de départ : 123456789 (à changer dès la première connexion). Il peut aussi le changer par : écran de connexion → « Mot de passe oublié » → son adresse → code à 6 chiffres reçu par mail → nouveau mot de passe.
- Ses droits suivent son nom (planification, badge or), comme prévu depuis les versions précédentes.

## v5.67 · Rotation automatique des couleurs
- Espace propriétaire / thème : « Changer les couleurs automatiquement » (jamais, tous les jours, chaque semaine, chaque mois). Le thème tourne entre Kaelum, Émeraude, Violet, Or, Rouge pour tous les utilisateurs.

## v5.72–v5.73
- Compte créé pour Yazid (cyberologue@gmail.com ; l'adresse y.mecheti@gmail.com était une erreur, désactivée), mot de passe provisoire 123456789, rôle SSIAP 2 (modifiable dans Administration).

## v5.74
- Accueil « Groupe Kaelum » avant connexion : tuile Kaelum e-PCS (e-mail, mot de passe, code du site ; 176868 = Parc des Expositions · Arena) et tuile Loctel (page vide pour l'instant). Autres clients : ajouter leur code dans `SITES` (src/app.js).

## v5.75
- Code du site Parc des Expositions · Arena : 176868 (remplace 76868).

## v5.76
- Espace Loctel (accueil Groupe Kaelum) : catalogue (téléphones, tablettes, NFC, photo, appels/connexion, accès, clés, rapports, appareils spéciaux, accessoires), tout sur devis, commande confirmée à la signature, livraison sous 24 h hors fériés et week-ends, charte assurance, espace client (demande de devis par e-mail à Jérémy).

## v5.77
- Espace client Loctel protégé par un code d'accès (1234), constante LOCTEL_CODE dans src/app.js.

## v5.78
- Page Loctel : nom, fonction et téléphone retirés ; contact par un bouton « Nous écrire » (adresse non affichée).

## v5.79
- Loctel : téléphones et tablettes durcis Doogee.

## v5.80
- Loctel : fiches techniques du matériel (Doogee Fire 5, Fire 5 Ultra, Fire 7, tablette R20) avec photo (Fire 5) ou emplacement photo.

## v5.81
- Loctel : le forfait (voix + connexion, selon la demande) est inclus dans la location, téléphones et tablettes ; aucun prix affiché.

## v5.82
- Loctel : marque des appareils retirée (fiches génériques, logo masqué sur la photo), données limitées à ce qui est vérifié, section « Documents remis ».

## v5.83
- Loctel : options et services (pointeaux NFC, écran de poste de commandement, installation de l'application au PC sécurité, sur mesure).

## v5.84
- ACCÈS RESTREINT : seuls Rochdi Mecheti, Yazid Mecheti, Laurent Hernandez et Jérémy Mercher entrent (api.mjs : ACCES_RESTREINT, IDS_AUTORISES, NOMS_AUTORISES). Connexion refusée aux autres, jetons existants rejetés (déconnexion), inscription, formulaire public de disponibilités, QR signalement, réinitialisation de mot de passe et notifications fermés. Pour rouvrir : ACCES_RESTREINT = false.

## v5.85 · MULTI-SITE
- Une seule appli, plusieurs sites : chaque client a un **code du site** (6 chiffres) et ses propres données (préfixe `t~<id>~` dans Netlify Blobs ; l'Arena n'est jamais préfixée, donc intacte). Codes fixes : **176868** Parc Expo / Arena (réel), **000222** Centre hospitalier Les Oliviers (démo fictive, Lattes 34970, données créées à la 1re connexion), **000333** site vierge à remplir par le client.
- Badge **Diamant** : propriétaire (tous les droits partout) et administrateur d'un site client (tous les droits sur CE site seulement). Équipe Kaelum (Laurent, Yazid, Jérémy, Rochdi) entre dans tous les sites, statut Or.
- Écrans : **Sites clients** (propriétaire : créer un site + code + admin avec mot de passe provisoire, suspendre, nouveau mot de passe, remettre la démo à zéro), **Paramétrage du site** (nom, adresse, GPS météo, secteurs, postes), **Agents et comptes** (ajout un par un ou par liste collée), **Planning du site** (ajout / répétition / affectation / import collé), **Plan interactif** (le client dépose son plan, détection automatique des pièces ou tracé à la main, zones avec fiches, points poste / accès / pompiers / secours / NFC).
- « Voir comme » dans un site client : SSIAP 3, SSIAP 1, agent, direction, administrateur.
- Écrans propres à l'Arena masqués dans les sites clients ; libellés Parc / Arena remplacés par le nom et les secteurs du site (adapterSite). Aucune liste par défaut d'Arena dans un site client (TENANT()).
- Crons (rappels, purge, sauvegarde hebdo…) exécutés pour chaque site actif. La vigilance météo automatique (meteo-alertes) reste propre à l'Arena.
- Déploiement : remplacer les fichiers par ceux du zip, attendre Netlify, ouvrir /reparer.html, vérifier /api/etat = 5.85.

## v5.86
- Accès de Fahd Hadouche (badge Or) au site d'origine Parc / Arena uniquement (accesFahd) ; les sites clients restent réservés à l'équipe Kaelum.

## v5.87
- (remplacé en 5.88)

## v5.88
- Vidéo de présentation « Kaelum Groupe présente » (plaquette e-PCS + fin Loctel : téléphones pro et tablettes compris dans l'abonnement), sans noms de personnes : public/doc/Kaelum-Groupe-video-*.mp4, bouton « Voir la vidéo » sur le portail et la page Loctel. La plaquette PDF du groupe n'est plus dans l'appli.

## v5.89
Nouvelle vidéo publicitaire "Kaelum Groupe présente" (Kaelum e-PCS + location Loctel), remplace la v5.88.

## v5.90
Portail : accès Loctel retiré, remplacé par la vidéo et la plaquette Groupe Kaelum (e-PCS · Loctel · Conseil). SMS agents : signature remplacée par « Numéro PCS sécurité / Joignable 24/24 / 0467176868 » (sans numéro sur les sites clients).

## v5.91
Portail : la plaquette 2 pages est remplacée par le prospectus Groupe Kaelum (11 pages).

## v5.92 · Plannings de novembre 2026 (exports Comète du 28/10)
- Arena Sud de France : 74 vacations. Parc des Expositions : 201 vacations. Import appliqué une seule fois (ids `arena-2026-11-v2810` et `parc-2026-11-v2810`) à la première connexion après la mise en ligne ; octobre et la planification interne sont conservés.
- Les vacations « non affectées » (16) ne sont pas importées, comme pour octobre. Les lignes « S01 » du PDF Arena (agents travaillant au Parc) ne sont pas dupliquées.
- Contrôles : 275 vacations = tous les codes du PDF ; les 117 vacations Parc listées dans le PDF Arena concordent exactement ; horaires conformes à la légende ; aucun chevauchement ni doublon.

## v5.93
Correctif vidéo : le fichier .mp4 était servi avec le type « PDF » (netlify.toml) et passait par le cache du service worker ; types séparés PDF / MP4 et /doc hors service worker.

## v5.94
Accès client de démonstration sur le site fictif 000222 : identifiant `Client001` (sans adresse e-mail), mot de passe `123456789` (créé une seule fois ; modifiable ensuite).

## v5.95 · Espace client élargi
- Le client voit tout en direct sauf les noms des agents, les boîtes à clés Parc / Arena, les plannings et les feuilles de route.
- Nouvel **écran de commandement client** (fil de l'eau, alertes, crise, météo, niveau de sécurité, consignes, rondes sans noms) sur un seul écran, avec boutons Imprimer / PDF et Plein écran.
- Le client imprime et enregistre en PDF sans code d'impression. Fil de l'eau : plus de noms dans les alertes levées ni dans les prêts de matériel.
